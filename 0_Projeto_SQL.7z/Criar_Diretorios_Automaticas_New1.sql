--AUTOR        : FERNANDO KINKEL SEREJO'+CHAR(13)+
--DATA         : 10/08/2024
--DEPARTAMENTO : CASA
--ASSUNTO      : Criar Diret�rios

Declare
@Menu varchar(20),
@Sitb varchar(20),
@exec varchar(2000)

IF OBJECT_ID('TempDB.dbo.#NEW') IS NOT NULL Drop Table #NEW

select SIMD_MENU = D.SIMD_MENU, SITB_COD
Into #NEW
from	sita A
			INNER JOIN SITS B on B.SITS_SITA = A.SITA_COD  
			INNER JOIN SITB C on C.SITB_COD = B.SITS_SITB
			INNER JOIN SIMD D on D.SIMD_COD = C.SITB_SIMD
Where SITA_COD = 1
	and simd_sequ <> ''
Order by D.simd_sequ

--select D.SIMD_MENU, SITB_COD
While (Select count(1) From #NEW) > 0
Begin

	Select top 1	@exec = 'master..xp_cmdshell ' + char(39) + 'MKDIR D:\0_Projeto_Web\WebGutEng\WebGutEngProjeto\WebGutEng\Pages\'  + SIMD_MENU + '\' + SITB_COD + char(39),
								@Sitb = SITB_COD,
								@Menu = SIMD_MENU
	from	#NEW

	print @exec
	Exec (@exec)

	Delete
	From #new 
	Where SIMD_MENU = @Menu
		and SITB_COD = @Sitb

End



