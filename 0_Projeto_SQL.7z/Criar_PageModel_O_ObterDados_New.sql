
--AUTOR        : FERNANDO KINKEL SEREJO'+CHAR(13)+
--DATA         : 02/09/2024
--DEPARTAMENTO : CASA
--ASSUNTO      : Criar PageModel e ModelView Index (Obter)


Declare
@Base varchar(50),
@Rota varchar(20),
@Classe varchar(20),
@Sitb varchar(20),
@Tab varchar(20),
@C varchar(2),
@Campo varchar(20),
@CampoModelo varchar(20),
@Habi varchar(30),
@Desc varchar(50),
@NomeTab varchar(20),
@HintTab Varchar(100),
@Tipo varchar(20),
@preTipo varchar(100),
@posTipo varchar(100),
@preNulo varchar(100),
@posNulo varchar(100),
@Chave varchar(1000),
@RotaChave varchar(4000),
@RotaValor varchar(4000),
@linha nvarchar(2000),
@path varchar(1000),
@arq varchar(1000),
@linhaaux varchar(100),
@i int


IF OBJECT_ID('TempDB.dbo.#ListaPageModels') IS NOT NULL Drop Table #LIstaPageModels
IF OBJECT_ID('TempDB.dbo.#VM_View') IS NOT NULL Delete from #VM_View
IF OBJECT_ID('TempDB.dbo.#VM_Rota') IS NOT NULL Delete from #VM_Rota
select SIMD_MENU = D.SIMD_MENU, SITB_COD, SIMD_Status = 'A', Base = replace(A.SITA_BASE, '_', '') 
Into #ListaPageModels
from	sita A
			INNER JOIN SITS B on B.SITS_SITA = A.SITA_COD  
			INNER JOIN SITB C on C.SITB_COD = B.SITS_SITB
			INNER JOIN SIMD D on D.SIMD_COD = C.SITB_SIMD
Where SITA_COD = 1
	and simd_sequ <> ''
Order by D.simd_sequ

--Select * from SIDC

While (Select count(1) From #ListaPageModels Where SIMD_Status = 'A') > 0
Begin
	IF OBJECT_ID('TempDB.dbo.##PageModels') IS NOT NULL Drop Table ##PageModels
	Select Seq = Identity(Int,1,1), SITB_COD, Linha = @Linha
	Into ##PageModels
	From	#ListaPageModels
	Where 1 = 0

	--Tabelas Auxiliares para estrutura dos campos
	IF OBJECT_ID('TempDB.dbo.#PM_Get') IS NOT NULL Drop Table #PM_Get
	IF OBJECT_ID('TempDB.dbo.#PM_Post') IS NOT NULL Drop Table #PM_Post
	IF OBJECT_ID('TempDB.dbo.#PM_View') IS NOT NULL Drop Table #PM_View
	--IF OBJECT_ID('TempDB.dbo.#VM_Rota') IS NOT NULL Drop Table #VM_Rota
	--IF OBJECT_ID('TempDB.dbo.#VM_View') IS NOT NULL Drop Table #VM_View
	Select Seq = Identity(Int,1,1), SITB_COD, Linha Into #PM_Get From ##PageModels
	Select SITB_COD, Linha Into #PM_Post From ##PageModels
	Select SITB_COD, Linha Into #PM_View From ##PageModels
	--Select SITB_COD, Linha Into #VM_View From ##PageModels
	IF OBJECT_ID('TempDB.dbo.#VM_View') IS NULL Select SITB_COD, ThTd='AA', Linha Into #VM_View From ##PageModels Where 1 = 0
	IF OBJECT_ID('TempDB.dbo.#VM_Rota') IS NULL Select SITB_COD, Metodo='A', Linha Into #VM_Rota From ##PageModels Where 1 = 0

	Select Top 1 @Base = Base, @Rota = SIMD_MENU, @Classe = 'Index', @Sitb = SITB_COD, @Tab =Stuff(Lower(SITB_COD),1,1, Upper(Substring(SITB_COD,1,1)))
	From #ListaPageModels
	Where SIMD_Status = 'A'

	Select @path = 'D:\0_Projeto_Web\WebGutEng\WebGutEngProjeto\WebGutEng\Pages\' + @Rota + '\'+ @Sitb,
				 @arq = @Classe + '.cshtml.cs'

				 --Antes deCome�ar a criar a estrutura Vamos criar os campos
	IF OBJECT_ID('TempDB.dbo.#Campos') IS NOT NULL Drop Table #Campos
	Select * 
	Into #Campos
	From	#ListaPageModels A
				INNER JOIN SIDC B on B.SIDC_SITB = A.SITB_COD
				Left Join SIDI C on C.SIDI_SIDC = B.SIDC_COD AND C.SIDI_SITB = B.SIDC_SITB 
	Where A.SITB_COD = @Sitb
		and B.SIDC_FISI = 'S'
		and	C.SIDI_COD = '01'
	
	Set @RotaChave = ''
	--Select * From #Campos order by SIDC_SEQU
	While (Select Count(1) From #Campos ) > 0 
	Begin		
		Select Top 1	@Campo = SIDC_COD, 
									@Desc = SIDI_TEXT, 
									@Tipo = Case SIDC_TIPO 
														When 'char' Then 'string'
														When 'varchar' Then 'string'
														When 'int' Then 'int'
														When 'numeric' Then 'integer'
														When 'datetime' Then 'DateOnly'
														When 'decimal' Then 'decimal'
														When 'float' Then 'decimal'
														When 'varbinary' Then 'integer'
														When 'text' Then 'integer'
														else 'string'
													End,
									@posNulo = SIDC_NULO,
									@Chave =	Case SIDC_CHAV 
															When 'S' then SIDC_COD + ', '
															Else ''
														End,
									@RotaValor =	SIDC_CHAV 
		From #Campos Order By SIDC_SEQU
		if (@RotaValor = 'S')
		Begin
			Select @RotaChave = @RotaChave + 'asp-route-' +Lower(@Campo)+ '="@item.' +@Campo+ '" '
		End
		--Select 'Chave � : ' + @Chave + ' ----- Rota: ' + @RotaChave

		if (@Tipo = 'DateOnly') 
		Begin
			Select	@preTipo = 'DateOnly.FromDateTime(', 
							@posTipo = ')'
		End
		Else Select @preTipo ='', @posTipo = ''
		if (@posNulo = 'S')
		Begin
			if (@Tipo = 'DateOnly') 
			Begin
				Select	@preNulo = '',
								@preTipo = @preTipo + '(DateTime)'
			End 
			Else Select @preNulo = '(' + @Tipo + ')'
		End
		Else Select @preNulo = ''
		Select @CampoModelo = LOWER(@Campo)
		While (Select charindex('_', @CampoModelo)) > 0
		Begin 
			Select @CampoModelo = Upper(Substring(@CampoModelo,1,1)) + Substring(@CampoModelo,2,len(@CampoModelo)-1)
			Select @c = Substring(@CampoModelo, Charindex('_', @CampoModelo) +1, 1)
			Select @CampoModelo = REPLACE(@CampoModelo, '_'+Lower(@c), Upper(@c))

			
		End

		Select @Habi = ''
		--print @Desc

		if((Select Charindex('_USU', @Campo))=0 and (Select Charindex('_DTU', @Campo))=0)
		Begin 
--            GLCTGut.GlctCod = ModelView.GLCT_COD;
			
			Insert into #PM_Get Select @Sitb, '								' + Upper(@Campo) + ' = ' + @preTipo + @preNulo + 'item.' + @CampoModelo + @posTipo + ', '

			--Insert into #PM_Post Select @Sitb, '						' + Upper(@Tab) + 'Gut.' + @CampoModelo + ' = ModelView.' + Upper(@Campo) + @TipoD + ';'

			Insert into #PM_View Select @Sitb, '				[Display(Name ="'+ @Desc +'")]'
			Insert into #PM_View Select @Sitb, '				public '+ @Tipo +' '+ @Campo +' { get; set; }'

			Insert into #VM_View Select @Sitb, 'TH','<th>'
			Insert into #VM_View Select @Sitb, 'TH','    @Html.DisplayNameFor(model => model.' +@Sitb + 'Gut[0].' + @Campo + ')'
			Insert into #VM_View Select @Sitb, 'TH','</th>'

			Insert into #VM_View Select @Sitb, 'TD','<td>'
			Insert into #VM_View Select @Sitb, 'TD','    @Html.DisplayFor(modelItem => item.' + @Campo + ')'
			Insert into #VM_View Select @Sitb, 'TD','</td>'
		End		

		Delete
		From #Campos
		Where SIDC_SITB = @Sitb
			and SIDC_COD = @Campo
	End

	--print @RotaChave + '  --  ' + @Sitb
	insert into #VM_Rota Select @Sitb, 'I', @RotaChave

	--select * from #VM_Rota

	Select @i = Max(Seq)
	From #PM_Get 
	Where SITB_COD = @Sitb 			
	
	--select @linhaaux

	Update #PM_Get
	Set Linha = Substring(linha, 1, Len(linha)-1)
	--select *
	From #PM_Get
	Where Seq = @i

	--select * from #VM_View
	
	Insert into ##PageModels Select @Sitb, 'using System;'
	
	Insert into ##PageModels Select @Sitb, 'using System.Collections.Generic;'
	Insert into ##PageModels Select @Sitb, 'using System.ComponentModel.DataAnnotations;'
	Insert into ##PageModels Select @Sitb, 'using System.Linq;'
	Insert into ##PageModels Select @Sitb, 'using System.Threading.Tasks;'
	Insert into ##PageModels Select @Sitb, 'using Microsoft.AspNetCore.Mvc;'
	Insert into ##PageModels Select @Sitb, 'using Microsoft.AspNetCore.Authorization;'
	Insert into ##PageModels Select @Sitb, 'using Microsoft.AspNetCore.Mvc.RazorPages;'
	Insert into ##PageModels Select @Sitb, 'using Microsoft.AspNetCore.Mvc.Rendering;'
	Insert into ##PageModels Select @Sitb, 'using WebGutEng.Models;'
	Insert into ##PageModels Select @Sitb, 'using NToastNotify;'
	Insert into ##PageModels Select @Sitb, 'using WebGutEng.Services;'
	Insert into ##PageModels Select @Sitb, 'using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;'
	
	Insert into ##PageModels Select @Sitb, 'namespace WebGutEng.Pages.' + @Rota + '.' + @Sitb
	Insert into ##PageModels Select @Sitb, '{'
	Insert into ##PageModels Select @Sitb, '	[Authorize(Roles = "Usuario")]'
	Insert into ##PageModels Select @Sitb, '		public class ' + @Classe +'Model : PageModel'
	Insert into ##PageModels Select @Sitb, '		{'
	Insert into ##PageModels Select @Sitb, '				private readonly WebGutEng.Models.' + @Base + 'Context _context;'
	Insert into ##PageModels Select @Sitb, '				private readonly IToastNotification _toastNotification;'
	--Insert into ##PageModels Select @Sitb, '				//private readonly IEmailSender _emailSender;'
	Insert into ##PageModels Select @Sitb, '				private IEmailService _EmailService;'
	Insert into ##PageModels Select @Sitb, '				[BindProperty]'
	Insert into ##PageModels Select @Sitb, '				public ' + @Classe + 'ModelView ModelView { get; set; }'
	Insert into ##PageModels Select @Sitb, '				public IList<' + @Classe + 'ModelView> ' + @Sitb + 'Gut { get; set; } = default!;'
	--                                              public IList<IndexModelView> SiusGut { get; set; } = default!;
	Insert into ##PageModels Select @Sitb, '				public ' + @Classe + 'Model(' + @Base + 'Context context, IToastNotification toastNotification, IEmailService emailService)'
	Insert into ##PageModels Select @Sitb, '				{'
	Insert into ##PageModels Select @Sitb, '						_context = context;'
	Insert into ##PageModels Select @Sitb, '						_toastNotification = toastNotification;'
	Insert into ##PageModels Select @Sitb, '						_EmailService = emailService;'
	Insert into ##PageModels Select @Sitb, '						ModelView = new ' + @Classe + 'ModelView();'	 
	Insert into ##PageModels Select @Sitb, '				}'
	Insert into ##PageModels Select @Sitb, '				public IActionResult OnGet()'
	Insert into ##PageModels Select @Sitb, '				{'

	Insert into ##PageModels Select @Sitb, '					var lista = _context.' + @Tab + 'Guts.ToList().Take(50);'
	Insert into ##PageModels Select @Sitb, '					if (' + Upper(@Tab) + 'Gut == null)'
	Insert into ##PageModels Select @Sitb, '					{'
	Insert into ##PageModels Select @Sitb, '						' + Upper(@Tab) + 'Gut = new List<IndexModelView>();'
	Insert into ##PageModels Select @Sitb, '					}'
	Insert into ##PageModels Select @Sitb, '					foreach (var item in lista)'
	Insert into ##PageModels Select @Sitb, '					{'
	Insert into ##PageModels Select @Sitb, '						' + Upper(@Tab) + 'Gut.Add(new IndexModelView {'

	/*
	            var lista = await _context.SiusGuts.ToListAsync();
            if (SiusGut == null)
            {
                SiusGut = new List<IndexModelView>();
            }
            foreach (var item in lista)
            {
							SiusGut.Add(new IndexModelView {

	*/
	--Colocar a tabela temporaria #PM_Get
	Insert into ##PageModels Select SITB_COD, Linha From #PM_Get

	Insert into ##PageModels Select @Sitb, '					});}'

	Insert into ##PageModels Select @Sitb, '						return Page();'
	Insert into ##PageModels Select @Sitb, '				}'
	--Insert into ##PageModels Select @Sitb, '				public async Task<IActionResult> OnPostAsync()'
	--Insert into ##PageModels Select @Sitb, '				{'
	--Insert into ##PageModels Select @Sitb, '						if (!ModelState.IsValid)'
	--Insert into ##PageModels Select @Sitb, '						{'
--Colocar aqui mensagem de erro 
	--Insert into ##PageModels Select @Sitb, '								return Page();'
	--Insert into ##PageModels Select @Sitb, '						}'
	--Insert into ##PageModels Select @Sitb, '						' + Upper(@Tab) + 'Gut = new '+ @Tab + 'Gut();'

--Colocar a tabela temporaria #PM_Post
	--Insert into ##PageModels Select * From #PM_Post

	--Insert into ##PageModels Select @Sitb, '						_context.' + @Tab + 'Guts.Add('+ Upper(@Tab) + 'Gut);'
	--Insert into ##PageModels Select @Sitb, '						await _context.SaveChangesAsync();'
	--Insert into ##PageModels Select @Sitb, '						return Page();'
	--Insert into ##PageModels Select @Sitb, '				}'
	Insert into ##PageModels Select @Sitb, '		}'
	Insert into ##PageModels Select @Sitb, '		public class ' + @Classe + 'ModelView'
	Insert into ##PageModels Select @Sitb, '		{'

--Colocar a tabela Temporaria #PM_View
	Insert Into ##PageModels Select * From #PM_View

	Insert into ##PageModels Select @Sitb, '				public ' + @Classe + 'ModelView() { }'
	Insert into ##PageModels Select @Sitb, '		}'
	Insert into ##PageModels Select @Sitb, '}'	

	set @linha = 'exec master..xp_cmdshell '+char(39)+'bcp "select Linha from ##PageModels  " queryout "'+@path+'\'+@arq+'" -c -T -C1252 -U sa -P casa230'+CHAR(39)
	exec(@linha)

	--Select @Sitb, @RotaChave, 'I'
	--Delete
	Update #ListaPageModels
	Set SIMD_Status = 'B'
	From #ListaPageModels
	Where SIMD_MENU = @Rota
		and SITB_COD = @Sitb

End

select * from #VM_Rota

--Select * From #ListaPageModels

While (Select count(1) From #ListaPageModels Where SIMD_Status = 'B') > 0
Begin
	IF OBJECT_ID('TempDB.dbo.##ViewModels') IS NOT NULL Drop Table ##ViewModels
	Select Seq = Identity(Int,1,1), A.SITB_COD, Linha = @Linha
	Into ##ViewModels
	From	#ListaPageModels A
	Where 1 = 0

	Select Top 1 @Rota = SIMD_MENU, @Classe = 'Index', @Sitb = A.SITB_COD, @Tab =Stuff(Lower(A.SITB_COD),1,1, Upper(Substring(A.SITB_COD,1,1))),
				@NomeTab = B.SITB_NOM, @HintTab = B.SITB_DESCR
	From #ListaPageModels A
				INNER JOIN SITB B on B.SITB_COD = A.SITB_COD
	Where SIMD_Status = 'B'

	Select @path = 'D:\0_Projeto_Web\WebGutEng\WebGutEngProjeto\WebGutEng\Pages\' + @Rota + '\'+ @Sitb,
				 @arq = @Classe + '.cshtml'

	--Select * From #VM_View Where SITB_COD = @sitb

	Insert into ##ViewModels Select @Sitb, '@page'

	Insert into ##ViewModels Select @Sitb, '@using static WebGutEng.Pages.' + @Rota + '.' + @Sitb +'.'+ @Classe + 'ModelView'
	Insert into ##ViewModels Select @Sitb, '@model WebGutEng.Pages.' + @Rota + '.' + @sitb+ '.' + @Classe + 'Model'
	Insert into ##ViewModels Select @Sitb, '@{'
	Insert into ##ViewModels Select @Sitb, '    ViewData["Title"] = "Visualizar ' + @NomeTab + '";'
	Insert into ##ViewModels Select @Sitb, '}'
	Insert into ##ViewModels Select @Sitb, '<h1 class="titulo-principal">Visualizar ' + @HintTab + '</h1>'
	Insert into ##ViewModels Select @Sitb, '<p>'
  Insert into ##ViewModels Select @Sitb, '  <div id="divright">'
	Insert into ##ViewModels Select @Sitb, '       <a asp-page="Incluir" class="btn btn-primary"><i class="bi bi-pencil-square"></i> Incluir</a>'
	Insert into ##ViewModels Select @Sitb, '    </div>'
	Insert into ##ViewModels Select @Sitb, '</p>'
	Insert into ##ViewModels Select @Sitb, '<table class="table">'
	Insert into ##ViewModels Select @Sitb, '    <thead>'
	Insert into ##ViewModels Select @Sitb, '			<tr>'

	Insert into ##ViewModels Select SITB_COD, Linha From #VM_View Where SITB_COD = @Sitb and ThTd = 'TH'

	Insert into ##ViewModels Select @Sitb, '       </tr>'
	Insert into ##ViewModels Select @Sitb, '     </thead>'
	Insert into ##ViewModels Select @Sitb, '     <tbody>'
	Insert into ##ViewModels Select @Sitb, '    @foreach (var item in Model.' + @Sitb + 'Gut)'
	Insert into ##ViewModels Select @Sitb, '    {'
	Insert into ##ViewModels Select @Sitb, '        <tr>'

	Insert into ##ViewModels Select SITB_COD, Linha From #VM_View Where SITB_COD = @Sitb and ThTd = 'TD'
	       
	Insert into ##ViewModels Select @Sitb, '                <td>'
	--Insert into ##ViewModels Select @Sitb, '                    <a asp-page="./Alterar" ' + @RotaChave + '" style="color:blue">'
	Insert into ##ViewModels Select SITB_COD, '                    <a asp-page="./Alterar" style="color:blue" ' + Linha + '>' From #VM_Rota Where SITB_COD = @Sitb 
	
	Insert into ##ViewModels Select @Sitb, '                        <i class="bi bi-pencil" '
	Insert into ##ViewModels Select @Sitb, '                           data-toggle="tooltip"'
	Insert into ##ViewModels Select @Sitb, '                           title="Alterar Registro"></i>'
	Insert into ##ViewModels Select @Sitb, '                    </a> |'
--	Insert into ##ViewModels Select @Sitb, '                    <a asp-page="./Detalhes' + '" asp-route-id="@item.' + @Chave + '" style="color:forestgreen"> '
	Insert into ##ViewModels Select SITB_COD, '                    <a asp-page="./Detalhes" style="color:forestgreen" ' + Linha + '>' From #VM_Rota Where SITB_COD = @Sitb 
	Insert into ##ViewModels Select @Sitb, '                        <i class="bi bi-ticket-detailed"'
	Insert into ##ViewModels Select @Sitb, '                           data-toggle="tooltip"'
	Insert into ##ViewModels Select @Sitb, '                           title="Detalhes do Registro"></i>'
	Insert into ##ViewModels Select @Sitb, '                    </a> |'
--	Insert into ##ViewModels Select @Sitb, '                    <a asp-page="./Excluir' + '" asp-route-id="@item.' + @Chave + '" style="color:red" >'
	Insert into ##ViewModels Select SITB_COD, '                    <a asp-page="./Excluir" style="color:red" ' + Linha + '>' From #VM_Rota Where SITB_COD = @Sitb 
	Insert into ##ViewModels Select @Sitb, '                        <i class="bi bi-trash3"'
	Insert into ##ViewModels Select @Sitb, '                           data-toggle="tooltip"'
	Insert into ##ViewModels Select @Sitb, '                           title="Excluir Registro"></i>'
	Insert into ##ViewModels Select @Sitb, '                    </a>'
	Insert into ##ViewModels Select @Sitb, '                </td>'
	Insert into ##ViewModels Select @Sitb, '            </tr>'
	Insert into ##ViewModels Select @Sitb, '        }'
	Insert into ##ViewModels Select @Sitb, '    </tbody>'
	Insert into ##ViewModels Select @Sitb, '</table>'

	set @linha = 'exec master..xp_cmdshell '+char(39)+'bcp "select Linha from ##ViewModels  " queryout "'+@path+'\'+@arq+'" -c -T -C1252 -U sa -P casa230'+CHAR(39)
--	select * from ##ViewModels
	exec(@linha)

	--Delete
	Update #ListaPageModels
	Set SIMD_Status = 'C'
	From #ListaPageModels
	Where SIMD_MENU = @Rota
		and SITB_COD = @Sitb

End


/*
BULK INSERT - Exemplo:
set @cmd = 'bulk insert TABELA from
''' + @FileName + ''' WITH (CODEPAGE = 1252)'
exec(@cmd)

*/

--Select * from #VM_Rota
