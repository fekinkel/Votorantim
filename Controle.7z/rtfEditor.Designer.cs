﻿
namespace WinFormMDI.Controle
{
    partial class rtfEditor
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rtfEditor));
            this.tspRtf = new System.Windows.Forms.ToolStrip();
            this.btsAlterar = new System.Windows.Forms.ToolStripButton();
            this.btsAbrir = new System.Windows.Forms.ToolStripButton();
            this.btsSalvar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btsNegrito = new System.Windows.Forms.ToolStripButton();
            this.btsItalico = new System.Windows.Forms.ToolStripButton();
            this.btsSublinhado = new System.Windows.Forms.ToolStripButton();
            this.btsCorFonte = new System.Windows.Forms.ToolStripButton();
            this.btsCorDestaque = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btsAlinhamentoEsquerda = new System.Windows.Forms.ToolStripButton();
            this.btsAlinhamentoCentro = new System.Windows.Forms.ToolStripButton();
            this.btsAlinhamentoDireita = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.cbsMacro = new System.Windows.Forms.ToolStripComboBox();
            this.rtdTextBox = new System.Windows.Forms.RichTextBox();
            this.tspRtf.SuspendLayout();
            this.SuspendLayout();
            // 
            // tspRtf
            // 
            this.tspRtf.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btsAlterar,
            this.btsAbrir,
            this.btsSalvar,
            this.toolStripSeparator1,
            this.btsNegrito,
            this.btsItalico,
            this.btsSublinhado,
            this.btsCorFonte,
            this.btsCorDestaque,
            this.toolStripSeparator2,
            this.btsAlinhamentoEsquerda,
            this.btsAlinhamentoCentro,
            this.btsAlinhamentoDireita,
            this.toolStripSeparator3,
            this.cbsMacro});
            this.tspRtf.Location = new System.Drawing.Point(0, 0);
            this.tspRtf.Name = "tspRtf";
            this.tspRtf.Size = new System.Drawing.Size(826, 25);
            this.tspRtf.TabIndex = 0;
            this.tspRtf.Text = "toolStrip1";
            // 
            // btsAlterar
            // 
            this.btsAlterar.CheckOnClick = true;
            this.btsAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btsAlterar.Image")));
            this.btsAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsAlterar.Name = "btsAlterar";
            this.btsAlterar.Size = new System.Drawing.Size(23, 22);
            this.btsAlterar.Text = "Alterar Arquivo";
            this.btsAlterar.Click += new System.EventHandler(this.btsAlterar_Click);
            // 
            // btsAbrir
            // 
            this.btsAbrir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsAbrir.Image = ((System.Drawing.Image)(resources.GetObject("btsAbrir.Image")));
            this.btsAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsAbrir.Name = "btsAbrir";
            this.btsAbrir.Size = new System.Drawing.Size(23, 22);
            this.btsAbrir.Text = "Abrir arquivo";
            this.btsAbrir.Click += new System.EventHandler(this.btsAbrir_Click);
            // 
            // btsSalvar
            // 
            this.btsSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btsSalvar.Image")));
            this.btsSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsSalvar.Name = "btsSalvar";
            this.btsSalvar.Size = new System.Drawing.Size(23, 22);
            this.btsSalvar.Text = "Salvar Arquivo";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btsNegrito
            // 
            this.btsNegrito.CheckOnClick = true;
            this.btsNegrito.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsNegrito.Image = ((System.Drawing.Image)(resources.GetObject("btsNegrito.Image")));
            this.btsNegrito.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsNegrito.Name = "btsNegrito";
            this.btsNegrito.Size = new System.Drawing.Size(23, 22);
            this.btsNegrito.Text = "Negrito";
            this.btsNegrito.Click += new System.EventHandler(this.btsNegrito_Click);
            // 
            // btsItalico
            // 
            this.btsItalico.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsItalico.Image = ((System.Drawing.Image)(resources.GetObject("btsItalico.Image")));
            this.btsItalico.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsItalico.Name = "btsItalico";
            this.btsItalico.Size = new System.Drawing.Size(23, 22);
            this.btsItalico.Text = "toolStripButton2";
            this.btsItalico.Click += new System.EventHandler(this.btsItalico_Click);
            // 
            // btsSublinhado
            // 
            this.btsSublinhado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsSublinhado.Image = ((System.Drawing.Image)(resources.GetObject("btsSublinhado.Image")));
            this.btsSublinhado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsSublinhado.Name = "btsSublinhado";
            this.btsSublinhado.Size = new System.Drawing.Size(23, 22);
            this.btsSublinhado.Text = "toolStripButton3";
            // 
            // btsCorFonte
            // 
            this.btsCorFonte.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsCorFonte.Image = ((System.Drawing.Image)(resources.GetObject("btsCorFonte.Image")));
            this.btsCorFonte.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsCorFonte.Name = "btsCorFonte";
            this.btsCorFonte.Size = new System.Drawing.Size(23, 22);
            this.btsCorFonte.Text = "toolStripButton4";
            // 
            // btsCorDestaque
            // 
            this.btsCorDestaque.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsCorDestaque.Image = ((System.Drawing.Image)(resources.GetObject("btsCorDestaque.Image")));
            this.btsCorDestaque.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsCorDestaque.Name = "btsCorDestaque";
            this.btsCorDestaque.Size = new System.Drawing.Size(23, 22);
            this.btsCorDestaque.Text = "toolStripButton5";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btsAlinhamentoEsquerda
            // 
            this.btsAlinhamentoEsquerda.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsAlinhamentoEsquerda.Image = ((System.Drawing.Image)(resources.GetObject("btsAlinhamentoEsquerda.Image")));
            this.btsAlinhamentoEsquerda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsAlinhamentoEsquerda.Name = "btsAlinhamentoEsquerda";
            this.btsAlinhamentoEsquerda.Size = new System.Drawing.Size(23, 22);
            this.btsAlinhamentoEsquerda.Text = "toolStripButton1";
            // 
            // btsAlinhamentoCentro
            // 
            this.btsAlinhamentoCentro.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsAlinhamentoCentro.Image = ((System.Drawing.Image)(resources.GetObject("btsAlinhamentoCentro.Image")));
            this.btsAlinhamentoCentro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsAlinhamentoCentro.Name = "btsAlinhamentoCentro";
            this.btsAlinhamentoCentro.Size = new System.Drawing.Size(23, 22);
            this.btsAlinhamentoCentro.Text = "toolStripButton2";
            // 
            // btsAlinhamentoDireita
            // 
            this.btsAlinhamentoDireita.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsAlinhamentoDireita.Image = ((System.Drawing.Image)(resources.GetObject("btsAlinhamentoDireita.Image")));
            this.btsAlinhamentoDireita.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsAlinhamentoDireita.Name = "btsAlinhamentoDireita";
            this.btsAlinhamentoDireita.Size = new System.Drawing.Size(23, 22);
            this.btsAlinhamentoDireita.Text = "toolStripButton3";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // cbsMacro
            // 
            this.cbsMacro.Name = "cbsMacro";
            this.cbsMacro.Size = new System.Drawing.Size(180, 25);
            this.cbsMacro.Text = "Selecione um item para ser substituido";
            this.cbsMacro.DropDownStyleChanged += new System.EventHandler(this.cbsMacro_DropDownStyleChanged);
            this.cbsMacro.SelectedIndexChanged += new System.EventHandler(this.cbsMacro_SelectedIndexChanged);
            // 
            // rtdTextBox
            // 
            this.rtdTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtdTextBox.Location = new System.Drawing.Point(0, 25);
            this.rtdTextBox.Name = "rtdTextBox";
            this.rtdTextBox.Size = new System.Drawing.Size(826, 426);
            this.rtdTextBox.TabIndex = 1;
            this.rtdTextBox.Text = "";
            this.rtdTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.rtdTextBox_MouseClick);
            this.rtdTextBox.TextChanged += new System.EventHandler(this.rtdTextBox_TextChanged);
            // 
            // rtfEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.rtdTextBox);
            this.Controls.Add(this.tspRtf);
            this.Name = "rtfEditor";
            this.Size = new System.Drawing.Size(826, 451);
            this.tspRtf.ResumeLayout(false);
            this.tspRtf.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tspRtf;
        private System.Windows.Forms.ToolStripButton btsAlterar;
        private System.Windows.Forms.ToolStripButton btsAbrir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btsNegrito;
        private System.Windows.Forms.ToolStripButton btsItalico;
        private System.Windows.Forms.ToolStripButton btsSublinhado;
        private System.Windows.Forms.ToolStripButton btsCorFonte;
        private System.Windows.Forms.ToolStripButton btsCorDestaque;
        private System.Windows.Forms.RichTextBox rtdTextBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btsAlinhamentoEsquerda;
        private System.Windows.Forms.ToolStripButton btsAlinhamentoCentro;
        private System.Windows.Forms.ToolStripButton btsAlinhamentoDireita;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripComboBox cbsMacro;
        private System.Windows.Forms.ToolStripButton btsSalvar;
    }
}
