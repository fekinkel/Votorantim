﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Documents;
using System.Windows.Forms;


namespace WinFormMDI.Controle
{
    public partial class rtfEditor : UserControl
    {
        public delegate void EnviarSalvar(String msg);
        private EnviarSalvar OnSalvar; private String dirArquivo;
        private Dictionary<String, String> _dic;
        private String _Text;
        private bool _Alterado;
        private bool _Edicao;
        public string Text { get { return getText(); } set { setText(value); } }
        public bool ReadOnly { set { tspRtf.Enabled = !value; rtdTextBox.Enabled = !value; } }
        public rtfEditor()
        {
            InitializeComponent();
            tspRtf.Enabled = false;
        }
        private void setText(string texto)
        {
            _Alterado = false;
            _Edicao = false;
            _Text = "";            
            _Text = texto;
            DesabilitarControles();
            CarregarRich();
        }
        private void CarregarRich()
        {
            rtdTextBox.Clear();
            try
            {
                string[] strs = _Text.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                Stream stringStream = new MemoryStream();
                string linha;
                foreach (string line in strs)
                {
                    linha = line;
                    if (!_Edicao)
                    {
                        if (_dic != null)
                        {
                            foreach (var item in _dic)
                            {
                                string s = $"@{item.Key}";
                                if (linha.IndexOf(s) >= 0)
                                {
                                    linha = linha.Replace(s, item.Value);
                                }
                            }
                        }
                    }
                    StreamWriter writer = new StreamWriter(stringStream);
                    writer.Write(linha + "\r\n");
                    writer.Flush();
                }
                stringStream.Position = 0;
                rtdTextBox.LoadFile(stringStream, RichTextBoxStreamType.RichText);
                stringStream.Close();
            }
            catch (Exception ex)
            { }

        }
        private string getText()
        {
            if (_Alterado)
            {
                /*
                _Text = "";
                Stream stringStream = new MemoryStream();
                rtdTextBox.SaveFile("C:\\Temp\\temp_out.rtf");
                StreamReader reader = new StreamReader("C:\\Temp\\temp_out.rtf");
                //rtdTextBox.SaveFile(stringStream, RichTextBoxStreamType.PlainText);
                //StreamReader reader = new StreamReader(stringStream);
                string linha;
                while ((linha = reader.ReadLine()) != null)
                {
                    _Text = _Text + linha + "\r\n";
                }
                reader.Close();
                File.Delete("C:\\Temp\\temp_out.rtf");
                */
                using (var rtfMemoryStream = new MemoryStream())
                {
                    rtdTextBox.SaveFile(rtfMemoryStream, RichTextBoxStreamType.RichText);
                    rtfMemoryStream.Seek(0, SeekOrigin.Begin);
                    using (var rtfStreamReader = new StreamReader(rtfMemoryStream))
                    {
                        return rtfStreamReader.ReadToEnd();
                    }
                }
            }
            return _Text;

        }
        public void MacroSubstituicao(Dictionary<String, String> dic)
        {
            cbsMacro.Items.Clear();
            if (dic != null)
            {
                cbsMacro.Visible = true;
                cbsMacro.Items.Add($"Selecione um item para Substituir...");
                if (dic.Count > 0)
                {
                    try
                    {
                        _dic = dic;
                        foreach (var item in dic)
                        {
                            if (item.Key.IndexOf(" ") == -1)
                            {
                                cbsMacro.Items.Add($"{item.Key}({item.Value})");
                            }
                            else
                            {
                                throw new ArgumentException("Chave não pode ter espaço em branco!");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        cbsMacro.Visible = false;
                        _dic.Clear();
                    }
                }
            }
            else
            {
                cbsMacro.Visible = false;
            }
        }

        private void cbsMacro_DropDownStyleChanged(object sender, EventArgs e)
        {
        }

        private void btsAbrir_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.InitialDirectory = @"C:\\";
            dialog.Filter = "Ritch Text Format (rtf) |*.rtf";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                rtdTextBox.LoadFile(dialog.FileName);
            }
        }

        private void cbsMacro_SelectedIndexChanged(object sender, EventArgs e)
        {
            string txt = rtdTextBox.SelectedText;

            int k = cbsMacro.SelectedIndex;
            int i = 1;
            foreach (var item in _dic)
            {
                if (i == k)
                {
                    string s = $" @{item.Key} ";

                    rtdTextBox.SelectedText = s;
                    //Clipboard.SetText(s);

                    //Clipboard.GetText;
                    //MessageBox.Show(s);
                }
                i++;
            }
        }

        private void rtdTextBox_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void rtdTextBox_TextChanged(object sender, EventArgs e)
        {
            _Alterado = true;
        }

        private void btsAlterar_Click(object sender, EventArgs e)
        {
            if(_Edicao)
            {
                _Text = getText(); 
            }
            _Edicao = !_Edicao;
            DesabilitarControles();
            CarregarRich();
        }
        private void DesabilitarControles()
        {
            rtdTextBox.Enabled = _Edicao;
        }

        private void btsNegrito_Click(object sender, EventArgs e)
        {
            Font fonte_selecionada = rtdTextBox.SelectionFont;
            if(fonte_selecionada != null)
            {
                rtdTextBox.SelectionFont = new Font(fonte_selecionada, fonte_selecionada.Style ^ FontStyle.Bold);
            }
        }

        private string getTextHtml()
        {
            if (_Alterado)
            {
                _Text = "";
                Stream stringStream = new MemoryStream();
                
                //rtdTextBox.SaveFile("C:\\Temp\\temp_out.rtf", DataFormats.Rtf);
                //StreamReader reader = new StreamReader("C:\\Temp\\temp_out.rtf");
                
                //rtdTextBox.SaveFile(stringStream, DataFormats.);
                StreamReader reader = new StreamReader(stringStream);
                string linha;
                while ((linha = reader.ReadLine()) != null)
                {
                    _Text = _Text + linha + "\r\n";
                }
                reader.Close();
                //File.Delete("C:\\Temp\\temp_out.rtf");
            }
            return _Text;

        }

        private void btsItalico_Click(object sender, EventArgs e)
        {
            
        }
    }
}
