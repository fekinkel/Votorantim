﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Biblioteca;
using PMV.Tributario.BL.Shared.Acesso;
using PMV.Tributario.BL.Shared.Tabela;
using PMV.Tributario.BL.Shared.Utilitario;
using PMV.Tributario.DL.Fiscalizacao.DS;
using PMV.Tributario.Imobiliario.Relatorio;
using Geral = PMV.Tributario.BL.Shared.Utilitario.Geral;

namespace PMV.Tributario.Fiscalizacao.Notificacao
{
    public partial class NotificacaoLancamento : Shared.Modelo.Cadastro
    {
        #region "Propriedades"

        public string tipoNotificacao { get; set; }
        private readonly string _cep;
        string ISSconstrucaoDescricaoUFM = string.Empty;
        string ISSdemolicaoDescricaoUFM = string.Empty;
        string ISSreformaDescricaoUFM = string.Empty;
        string ISSengenhariaDescricaoUFM = string.Empty;
        string TXlicencaDescricaoUFM = string.Empty;
        string TXconstrucaoDescricaoUFM = string.Empty;
        string TXalinhamentoDescricaoUFM = string.Empty;
        string TXalvaraDescricaoUFM = string.Empty;
        string TXnumeracaoPredialDescricaoUFM = string.Empty;
        string TXpenalidadeDescricaoUFM = string.Empty;
        string status = string.Empty;
        private bool fechaForcado = false;
        private bool bloquearAtualizacaoUFM = false;
        private bool cobrarIssEngenharia = true;
        private bool cobrarIssconstrucao = true;
        private bool diferimento = false;
        private bool trocarExigibilidade = false;
        private bool edicaoSujeicao = false;

        private readonly DataTable _dtAgravante;
        decimal areaTestado = 0;
        decimal areaTerreno = 0;
        decimal aliquotaConstrucao = 0;
        decimal aliquotaReforma = 0;
        decimal aliquotaDemolicao = 0;
        decimal aliquotaEngenharia = 0;
        decimal penalidadeReparcelamento = 0;
        decimal ImpostoISSConstrucaoSecundario = 0;
        decimal ImpostoISSEngenhariaSecundario = 0;
        decimal ImpostoISSDemolicaoSecundario = 0;
        decimal ImpostoISSReformaSecundario = 0;
        decimal TaxaConstrucaoSecundario = 0;
        decimal TaxaReformaSecundario = 0;
        decimal TaxaAlinhamentoSecundario = 0;
        decimal TaxaAlvaraSecundario = 0;
        decimal TaxaPenalidadeSecundario = 0;

        private Geral.ModoTabela _modoTabela;
        private Geral.ModoTabela _modoTabelaContribuinte;
        private Geral.ModoTabela _modotabelaConstrucao;
        private Geral.ModoTabela _modoDocDigital;

        private readonly BL.Fiscalizacao.Notificacao.NotificacaoLancamento blNotificacao;
        private readonly BL.Imobiliario.Cadastro.Evento blEventoImobiliario = new BL.Imobiliario.Cadastro.Evento();
        private readonly BL.Shared.Cadastro.Endereco blEndereco;
        private readonly BL.Fiscalizacao.Notificacao.NotificacaoLancamentoTabela blTabelaLancamento;
        private readonly BL.Imobiliario.Cadastro.Pessoa blPessoa;
        private readonly BL.Imobiliario.Cadastro.PessoaEndereco blPessoaEndereco;
        private readonly BL.Imobiliario.Cadastro.Loteamento blLoteamento;
        private readonly BL.Imobiliario.Cadastro.Condominio blCondominio;
        private readonly BL.Mobiliario.Tabela.TipoDocumentoDigital blTipoDocumentoDigital;

        DL.Shared.DS.DSShared.SH_TB_PARAMETRORow drParametro;
        readonly Parametro blTbParametro = new Parametro();
        private DSDebito.CAD_MOBIDataTable _dtDebito = new DSDebito.CAD_MOBIDataTable();
        private readonly DSDebito.CAD_MOBIRow _drDebito;
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTORow _drNotificacao;
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICODataTable _dtNotificacaoHistorico = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEDataTable _dtNotificacaoContribuinte = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEDataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTODataTable _dtNotificacaoLancamento = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTODataTable();
        private readonly DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTODataTable _dtListarDebito = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_UNIFICACAODataTable _dtNotificacaoUnificacao = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_UNIFICACAODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAODataTable _dtQualificacao = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTODataTable _dtNotificacaoParcelamento = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_COMPLEMENTODataTable _dtNotificacaoParcelamentoComplemento = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_COMPLEMENTODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADODataTable _dtNotificacaoParcelamentoAtualizado = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELADataTable _dtNotificacaoParcela = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELADataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHEDataTable _dtNotificacaoParcelaDetalhe = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHEDataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_SUJEICAODataTable _dtQualificacaoSujeicao = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_SUJEICAODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_SUBTIPODataTable _dtTipoNotificacao = new DSNotificacaoLancamento.MO_NOTIFICACAO_SUBTIPODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_SUBTIPODataTable _dtTipoNotificacaoSubNivel = new DSNotificacaoLancamento.MO_NOTIFICACAO_SUBTIPODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_SUBTIPODataTable _dtTipoNotificacaoTipoImovel = new DSNotificacaoLancamento.MO_NOTIFICACAO_SUBTIPODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_TABELA_UFMDataTable _dtUFM = new DSNotificacaoLancamento.MO_NOTIFICACAO_TABELA_UFMDataTable();
        private readonly DSNotificacaoLancamento.MO_NOTIFICACAO_TABELA_UFMDataTable _dtUFMMisto = new DSNotificacaoLancamento.MO_NOTIFICACAO_TABELA_UFMDataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_PARAMETRODataTable _dtParametro = new DSNotificacaoLancamento.MO_NOTIFICACAO_PARAMETRODataTable();
        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_TERMOREMESSADataTable _dtTermoRemessa = new DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_TERMOREMESSADataTable();

        private ToolTip tipEnquadramento = new ToolTip();
        private Geral.ModoTabela modoTabela
        {
            get { return _modoTabela; }
            set
            {
                _modoTabela = value;

                if (dgvNotificacao != null)
                {
                    this.Text = this.Tag.ToString();

                    bindingNavigator.Enabled = false;

                    txtANO_NOTIFICACAO.ReadOnly = true;
                    txtID_NOTIFICACAO.ReadOnly = true;
                    txtNUMERO_NOTIFICACAO.ReadOnly = true;

                    //btnContrAdicionar.Enabled = false;
                    //btnContrDescartar.Enabled = false;

                    //PRECISEI COMENTAR NOVAMENTE, NO MOMENTO ~~AO LEMBRO O MOTIVO DE DESABILITAR NESSE PONTO DO SISTEMA
                    //btnOpcoesParcelamento.Enabled = false;
                    //btnEditar.Enabled = false;
                    btnFinalizar.Enabled = false;

                    dgvNotificacao.Enabled = true;
                    //dgvLancamentoConstrucao.Columns["Excluir"].Visible = true;
                    dgvContribuinte.Columns[0].Visible = true;

                    //grpSujeicao.Enabled = true;

                    //DesabilitarContribuinte(true);

                    if (modoTabela == Geral.ModoTabela.MODO_CONSULTA)
                    {
                        this.Text += " (Modo Consulta)";

                        bindingNavigator.Enabled = true;

                        txtCodParcelamento.Visible = true;
                        lblCodParcelamento.Visible = true;
                        txtCodParcelamento.ReadOnly = true;
                        //btnContrAdicionar.Enabled = false;
                        //btnContrDescartar.Enabled = false;
                        btnFinalizar.Enabled = false;
                        btnOpcoes.Enabled = true;

                        //grpSujeicao.Enabled = false;
                        
                        //DesabilitarContribuinte(false);
                        grpUnificacao.Enabled = false;

                        //dgvLancamentoConstrucao.Columns["Excluir"].Visible = false;
                        dgvContribuinte.Columns[0].Visible = false;

                    }
                    else if (modoTabela == Geral.ModoTabela.MODO_EDICAO)
                    {
                        lblCodParcelamento.Visible = false;
                        txtCodParcelamento.Visible = false;
                        //btnContrAdicionar.Enabled = true;
                        //btnContrDescartar.Enabled = true;
                        btnEditar.Enabled = false;
                        btnFinalizar.Enabled = true;
                        btnOpcoes.Enabled = true;

                        txtQtdeParcela.ReadOnly = false;
                        txtExigibilidade.ReadOnly = false;
                        txtCiencia.ReadOnly = false;
                        txtVencimento.ReadOnly = false;

                        //grpSujeicao.Enabled = true;
                        //DesabilitarContribuinte(true);
                        grpUnificacao.Enabled = true;

                        GroupBox4.Enabled = true;
                        groupBox2.Enabled = true;

                        //dgvLancamentoConstrucao.Columns["Excluir"].Visible = true;
                        dgvContribuinte.Columns[0].Visible = true;

                        this.Text += " (Modo Edição)";
                    }
                    else if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                    {
                        this.Text += " (Modo Inclusão)";
                        LimparCampos(this);

                        status = "A";

                        UFV objUFV = new UFV();

                        DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(DateTime.Now);

                        drParametro = blTbParametro.BuscarAno(DateTime.Now.Year);

                        txtExpediente.Text = (drParametro.EXPEDIENTE_UFV * drUFV.VALOR).ToString("N2");

                        lblCodParcelamento.Visible = false;
                        txtCodParcelamento.Visible = false;
                        txtCodParcelamento.ReadOnly = true;
                        //btnContrAdicionar.Enabled = true;
                        //btnContrDescartar.Enabled = true;
                        btnFinalizar.Enabled = false;

                        GroupBox4.Enabled = true;
                        groupBox2.Enabled = true;

                        txtINSCRICAO.Focus();

                    }
                    else if (modoTabela == Geral.ModoTabela.MODO_PESQUISA)
                    {
                        this.Text += " (Modo Pesquisa)";

                        txtANO_NOTIFICACAO.ReadOnly = true;
                        txtID_NOTIFICACAO.ReadOnly = true;
                        txtNUMERO_NOTIFICACAO.ReadOnly = true;
                        txtCodParcelamento.ReadOnly = false;
                        txtCodParcelamento.Visible = true;
                        lblCodParcelamento.Visible = true;

                        //btnContrAdicionar.Enabled = false;
                        //btnContrDescartar.Enabled = false;
                        btnFinalizar.Enabled = false;

                        //grpSujeicao.Enabled = false;
                        //DesabilitarContribuinte(false);
                        //dgvLancamentoConstrucao.Columns["Excluir"].Visible = false;
                        dgvContribuinte.Columns[0].Visible = false;

                        bindingNavigator.Enabled = true;
                    }

                    DesabilitarCampos(modoTabela == Geral.ModoTabela.MODO_CONSULTA);
                }
            }
        }
        private Geral.ModoTabela modoTabelaContribuinte
        {
            get { return _modoTabelaContribuinte; }
            set
            {
                _modoTabelaContribuinte = value;
                pnl_Botoes_Contribuinte.Enabled = (modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_INCLUSAO);
                if (modoTabelaContribuinte == Geral.ModoTabela.MODO_CONSULTA)
                {
                    btnEditarContribuinte.Enabled = true;
                    btnIncluirContribuinte.Enabled = true;
                    btnExcluirContribuinte.Enabled = true;
                    btnGravarContribuinte.Enabled = false;
                    btnLimparContribuinte.Visible = false;
                    grpSujeicao.Enabled = false;
                }
                else if (modoTabelaContribuinte == Geral.ModoTabela.MODO_EDICAO || modoTabelaContribuinte == Geral.ModoTabela.MODO_INCLUSAO)
                {
                    btnEditarContribuinte.Enabled = false;
                    btnIncluirContribuinte.Enabled = false;
                    btnExcluirContribuinte.Enabled = false;
                    btnGravarContribuinte.Enabled = true;
                    btnLimparContribuinte.Visible = true;
                    grpSujeicao.Enabled = true;
                }

                //DesabilitarContribuinte(modoTabelaContribuinte == Geral.ModoTabela.MODO_CONSULTA);
            }
        }
        private Geral.ModoTabela modoTabelaConstrucao
        {
            get { return _modotabelaConstrucao; }
            set
            {
                _modotabelaConstrucao = value;
                pnl_Botoes_Construcao.Enabled = (modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_INCLUSAO);
                if (modoTabelaConstrucao == Geral.ModoTabela.MODO_CONSULTA)
                {
                    btnEditarConstrucao.Enabled = true;
                    btnIncluirConstrucao.Enabled = true;
                    btnExcluirConstrucao.Enabled = true;
                    btnGravarConstrucao.Enabled = false;
                    btnLimparConstrucao.Visible = false;
                    grpConstrucao.Enabled = false;
                }
                else if (modoTabelaConstrucao == Geral.ModoTabela.MODO_EDICAO || modoTabelaConstrucao == Geral.ModoTabela.MODO_INCLUSAO)
                {
                    btnEditarConstrucao.Enabled = false;
                    btnIncluirConstrucao.Enabled = false;
                    btnExcluirConstrucao.Enabled = false;
                    btnGravarConstrucao.Enabled = true;
                    btnLimparConstrucao.Visible = true;
                    grpConstrucao.Enabled = true;
                }
                //DesabilitarConstrucao();
            }

        }
        #endregion "Propriedades"

        #region "Construtor"
        public NotificacaoLancamento()
        {
            blEndereco = new BL.Shared.Cadastro.Endereco();
            blNotificacao = new BL.Fiscalizacao.Notificacao.NotificacaoLancamento();
            blTabelaLancamento = new BL.Fiscalizacao.Notificacao.NotificacaoLancamentoTabela();
            blPessoa = new BL.Imobiliario.Cadastro.Pessoa();
            blPessoaEndereco = new BL.Imobiliario.Cadastro.PessoaEndereco();
            blLoteamento = new BL.Imobiliario.Cadastro.Loteamento();
            blCondominio = new BL.Imobiliario.Cadastro.Condominio();
            blTipoDocumentoDigital = new BL.Mobiliario.Tabela.TipoDocumentoDigital();


            _dtAgravante = new DataTable();

            InitializeComponent();

            this.Tag = this.Text;

            modoTabela = Geral.ModoTabela.MODO_PESQUISA;
        }
        #endregion

        private void PegarErro(DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTORow dr)
        {
            foreach (DataColumn dc in dr.GetColumnsInError())
            {
                if (dc.ColumnName.ToUpper() == "ANO_NOTIFICACAO")
                    errorProvider.SetError(txtANO_NOTIFICACAO, dr.GetColumnError(dc.ColumnName));
                if (dc.ColumnName.ToUpper() == "NUMERO_NOTIFICACAO")
                    errorProvider.SetError(txtNUMERO_NOTIFICACAO, dr.GetColumnError(dc.ColumnName));

            }
        }

        public class DataGridViewDisableButtonColumn : DataGridViewButtonColumn
        {
            public DataGridViewDisableButtonColumn()
            {
                this.CellTemplate = new DataGridViewDisableButtonCell();
            }
        }

        public class DataGridViewDisableButtonCell : DataGridViewButtonCell
        {
            private bool enabledValue;
            public bool Enabled
            {
                get { return enabledValue; }
                set
                {
                    if (enabledValue == value) return;
                    enabledValue = value;
                    // force the cell to be re-painted
                    DataGridView?.InvalidateCell(this);
                }
            }

            // Override the Clone method so that the Enabled property is copied.
            public override object Clone()
            {
                DataGridViewDisableButtonCell cell =
                    (DataGridViewDisableButtonCell)base.Clone();
                cell.Enabled = this.Enabled;
                return cell;
            }

            // By default, enable the button cell.
            public DataGridViewDisableButtonCell()
            {
                this.enabledValue = true;
            }

            protected override void Paint(Graphics graphics,
                Rectangle clipBounds, Rectangle cellBounds, int rowIndex,
                DataGridViewElementStates elementState, object value,
                object formattedValue, string errorText,
                DataGridViewCellStyle cellStyle,
                DataGridViewAdvancedBorderStyle advancedBorderStyle,
                DataGridViewPaintParts paintParts)
            {
                // The button cell is disabled, so paint the border,  
                // background, and disabled button for the cell.
                if (!this.enabledValue)
                {
                    // Draw the cell background, if specified.
                    if ((paintParts & DataGridViewPaintParts.Background) ==
                        DataGridViewPaintParts.Background)
                    {
                        SolidBrush cellBackground =
                            new SolidBrush(cellStyle.BackColor);
                        graphics.FillRectangle(cellBackground, cellBounds);
                        cellBackground.Dispose();
                    }

                    // Draw the cell borders, if specified.
                    if ((paintParts & DataGridViewPaintParts.Border) ==
                        DataGridViewPaintParts.Border)
                    {
                        PaintBorder(graphics, clipBounds, cellBounds, cellStyle,
                            advancedBorderStyle);
                    }

                    // Calculate the area in which to draw the button.
                    Rectangle buttonArea = cellBounds;
                    Rectangle buttonAdjustment =
                        this.BorderWidths(advancedBorderStyle);
                    buttonArea.X += buttonAdjustment.X;
                    buttonArea.Y += buttonAdjustment.Y;
                    buttonArea.Height -= buttonAdjustment.Height;
                    buttonArea.Width -= buttonAdjustment.Width;

                    // Draw the disabled button.                
                    ButtonRenderer.DrawButton(graphics, buttonArea, PushButtonState.Disabled);

                    // Draw the disabled button text. 
                    if (this.FormattedValue is String)
                    {
                        TextRenderer.DrawText(graphics,
                            (string)this.FormattedValue,
                            this.DataGridView.Font,
                            buttonArea, SystemColors.GrayText);
                    }
                }
                else
                {
                    // The button cell is enabled, so let the base class 
                    // handle the painting.
                    base.Paint(graphics, clipBounds, cellBounds, rowIndex,
                        elementState, value, formattedValue, errorText,
                        cellStyle, advancedBorderStyle, paintParts);
                }
            }
        }

        #region Metodos 

        private void FormatarCampos()
        {
            #region "Tags de pesquisa"

            txtINSCRICAO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.INSCRICAO;OPERADOR_=;";
            txtNUMERO_NOTIFICACAO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.NUMERO_NOTIFICACAO;OPERADOR_=;";
            txtANO_NOTIFICACAO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.ANO_NOTIFICACAO;OPERADOR_=;";
            txtCEP.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.CEP;OPERADOR_=;";
            txtLOGRADOURO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.LOGRADOURO;OPERADOR_LIKE;";
            txtNUMERO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.NUMERO;OPERADOR_=;";
            txtCOMPLEMENTO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.COMPLEMENTO;OPERADOR_LIKE;";
            txtBAIRRO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.BAIRRO;OPERADOR_LIKE;";
            txtEMAIL.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.EMAIL;OPERADOR_LIKE;";
            txtNUMERO_PROCESSO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.NUMERO_PROCESSO;OPERADOR_LIKE;";
            txtOBSERVACAO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.OBSERVACAO;OPERADOR_LIKE;";
            txtFATO_JURIDICO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.FATO_JURIDICO;OPERADOR_LIKE;";
            txtASSUNTO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.ASSUNTO;OPERADOR_LIKE;";
            txtCiencia.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.DATA_CIENCIA;OPERADOR_=;";
            txtExigibilidade.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO.DATA_EXIGIBILIDADE;OPERADOR_=;";

            //txtQUALIFICACAO.Tag = "MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE.QUALIFICACAO;OPERADOR_LIKE;";
            txtCPFCNPJ.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE.CPFCNPJ;OPERADOR_=;";
            txtNOME_RAZAO.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE.NOME_RAZAO;OPERADOR_LIKE;";
            txtCONTRIBUINTE.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE.CONTRIBUINTE;OPERADOR_LIKE;";
            txtComoResponsavel.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE.COMO_RESPONSAVEL;OPERADOR_LIKE;";
            txtOBSERVACAO_P.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE.OBSERVACAO;OPERADOR_LIKE;";

            txtCodParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.ID_NOTIFICACAO_PARCELAMENTO;OPERADOR_LIKE;";
            txtCPFCNPJParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.CPF;OPERADOR_LIKE;";
            txtNOME_RAZAOParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.NOME;OPERADOR_LIKE;";
            txtResponsavelParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.RESPONSAVEL;OPERADOR_LIKE;";
            txtCPFResponsavelParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.RESPONSAVEL_CPF;OPERADOR_LIKE;";
            txtCepRespParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.CEP;OPERADOR_LIKE;";
            txtLogradouroRespParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.LOGRADOURO;OPERADOR_LIKE;";
            txtNumeroRespParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.NUMERO;OPERADOR_LIKE;";
            txtBairroRespParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.BAIRRO;OPERADOR_LIKE;";
            txtUFParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.UF;OPERADOR_LIKE;;";
            txtCidadeParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.CIDADE;OPERADOR_LIKE;";
            txtProcurador.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.PROCURADOR;OPERADOR_LIKE;";
            txtCPFProcurador.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.PROCURADOR_CPF;OPERADOR_LIKE;";
            txtComplRespParcelamento.Tag = "CAMPO_MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO.COMPLEMENTO;OPERADOR_LIKE;";


            #endregion "Tags de pesquisa"

            // Carrega Combos
            Geral.CarregarCombo(cbxUF, Geral.uf, true);
            Geral.CarregarCombo(cbxUFResp, Geral.uf, true);
            Geral.CarregarCombo(cbxTipo, Geral.tipoNotificacao, false);
            Geral.CarregarCombo(cbxLOTEAMENTO, blLoteamento.ListarNome(), "ID_LOTEAMENTO", "NOME");
            Geral.CarregarCombo(cbxCONDOMINIO, blCondominio.ListarNome(), "ID_CONDOMINIO", "NOME", true);
            Geral.CarregarCombo(cbxLOTEAMENTOUNI, blLoteamento.ListarNome(), "ID_LOTEAMENTO", "NOME");
            Geral.CarregarCombo(cbxCONDOMINIOUNI, blCondominio.ListarNome(), "ID_CONDOMINIO", "NOME", true);
            Geral.CarregarCombo(cbxDocDigID_TIPO_DOC_DIGITAL, blTipoDocumentoDigital.Listar(), "ID_TIPO_DOC_DIGITAL", "DESCRICAO", true);

            // Padroniza janela
            //BL.Shared.Utilitario.Padrao.PadronizarJanelaGrid(this, dgvLancamento);
            Padrao.TrocarTABporEnter(this);
            Padrao.SetarCorCampoReadOnly(this);

        }

        private void FormatarMedidas(string medida)
        {
            lblMedidaISSConstrucao.Text = medida;
            lblMedidaISSReforma.Text = medida;
            lblMedidaISSDemolicao.Text = medida;
            lblMedidaISSEngenharia.Text = medida;
            lblMedidaPenalidade.Text = medida;
        }

        private void CarregarQualificacao()
        {
            if (cbxTipo.SelectedValue != null)
            {
                _dtQualificacao = blNotificacao.ListarQualificacao(cbxTipo.SelectedValue.ToString());

                var checkBoxList = (ListBox)ckbQualificacao;

                checkBoxList.DataSource = _dtQualificacao.Where(x => x.IsSUBNIVELNull() ).ToList();
                checkBoxList.DisplayMember = "qualificacao";
                checkBoxList.ValueMember = "ID";
            }
            else
            {
                var checkBoxList = (ListBox)ckbQualificacao;

                checkBoxList.DataSource = null;
                checkBoxList.DisplayMember = "qualificacao";
                checkBoxList.ValueMember = "ID";
            }
        }

        private void CarregarTipoLancamento()
        {
            tblLancamentos.TabPages.Remove(tbgConstrucao);
            tblLancamentos.TabPages.Remove(tbgInscricao);
            tblLancamentos.TabPages.Remove(tbgIptu);

            if (cbxTipo.SelectedValue.ToString() == "P")
            {
                tblLancamentos.TabPages.Add(tbgConstrucao);
                tblLancamentos.TabPages.Add(tbgInscricao);

                _dtTipoNotificacao = blNotificacao.ListarTipoPrincipal(cbxTipo.SelectedValue.ToString());

                DataRow dr = _dtTipoNotificacao.NewMO_NOTIFICACAO_SUBTIPORow();

                dr["DESCRICAO"] = "SELECIONE...";
                dr["SUBTIPO"] = "";

                _dtTipoNotificacao.Rows.InsertAt(dr, 0);

                cbxTipoConstr.DataSource = _dtTipoNotificacao;
                cbxTipoConstr.DisplayMember = "DESCRICAO";
                cbxTipoConstr.ValueMember = "SUBTIPO";
            }
            else if (cbxTipo.SelectedValue.ToString() == "I")
            {
                tblLancamentos.TabPages.Add(tbgIptu);
            }
            else
            {
                cbxTipoConstr.DataSource = null;
                cbxTipoConstr.DisplayMember = "DESCRICAO";
                cbxTipoConstr.ValueMember = "SUBTIPO";
            }
        }

        private void DesabilitarCampos(bool isDesabilitado)
        {
            txtANO_NOTIFICACAO.ReadOnly = modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_CONSULTA;
            txtID_NOTIFICACAO.ReadOnly = modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_CONSULTA;
            txtINSCRICAO.ReadOnly = modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_CONSULTA;
            txtNUMERO_NOTIFICACAO.ReadOnly = modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_CONSULTA;
            txtDATA_NOTIFICACAO.ReadOnly = modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_CONSULTA;

            cbxCIDADE.Enabled = !isDesabilitado;
            cbxUF.Enabled = !isDesabilitado;
            cbxLOTEAMENTO.Enabled = !isDesabilitado;
            cbxCONDOMINIO.Enabled = !isDesabilitado;
            grpTipoCiencia.Enabled = !isDesabilitado;

            txtCEP.ReadOnly = isDesabilitado;
            txtLOGRADOURO.ReadOnly = isDesabilitado;
            txtNUMERO.ReadOnly = isDesabilitado;
            txtCOMPLEMENTO.ReadOnly = isDesabilitado;
            txtBAIRRO.ReadOnly = isDesabilitado;
            txtEMAIL.ReadOnly = isDesabilitado;
            txtNUMERO_PROCESSO.ReadOnly = isDesabilitado;
            txtOBSERVACAO.ReadOnly = isDesabilitado;
            txtFATO_JURIDICO.ReadOnly = isDesabilitado;
            txtASSUNTO.ReadOnly = isDesabilitado;
            txtQUADRA_IMOVEL.ReadOnly = isDesabilitado;
            txtLOTE_IMOVEL.ReadOnly = isDesabilitado;
            cbxCONDOMINIO.Enabled = !isDesabilitado;
            cbxTipoConstr.Enabled = !isDesabilitado;
            cbxTipoImovel.Enabled = !isDesabilitado;
            cbxSubtipoImovel.Enabled = !isDesabilitado;
            txtQtdeParcela.Enabled = !isDesabilitado;
            txtExigibilidade.Enabled = !isDesabilitado;
            txtCiencia.Enabled = !isDesabilitado;
            txtVencimento.Enabled = !isDesabilitado;
            txtExpedienteAnterior.Enabled = !isDesabilitado;
            txtCPFCNPJ.ReadOnly = isDesabilitado;
            txtNOME_RAZAO.ReadOnly = isDesabilitado;
            txtCONTRIBUINTE.ReadOnly = isDesabilitado;
            txtComoResponsavel.ReadOnly = isDesabilitado;
            txtResponsavel.ReadOnly = isDesabilitado;
            txtCPFResponsavel.ReadOnly = isDesabilitado;
            txtOBSERVACAO_P.ReadOnly = isDesabilitado;
            txtIncidencia.ReadOnly = isDesabilitado;
            rdbIncidenciaSim.Enabled = !isDesabilitado;
            rdbIncidenciaNao.Enabled = !isDesabilitado;
            txtDiferimento.ReadOnly = isDesabilitado;
            rdbDiferimentoSim.Enabled = !isDesabilitado;
            rdbDiferimentoNao.Enabled = !isDesabilitado;
            //AREA DO PARCELAMENTO
            //pnlParcelamentoDados.Enabled = !isDesabilitado;
            txtCPFCNPJParcelamento.Enabled = !isDesabilitado;
            txtNOME_RAZAOParcelamento.Enabled = !isDesabilitado;
            txtResponsavelParcelamento.Enabled = !isDesabilitado;
            txtCPFResponsavelParcelamento.Enabled = !isDesabilitado;
            txtCepRespParcelamento.Enabled = !isDesabilitado;
            txtLogradouroRespParcelamento.Enabled = !isDesabilitado;
            txtNumeroRespParcelamento.Enabled = !isDesabilitado;
            txtComplRespParcelamento.Enabled = !isDesabilitado;
            txtBairroRespParcelamento.Enabled = !isDesabilitado;
            txtUFParcelamento.Enabled = !isDesabilitado;
            txtCidadeParcelamento.Enabled = !isDesabilitado;
            txtProcurador.Enabled = !isDesabilitado;
            txtCPFProcurador.Enabled = !isDesabilitado;
            txtAssuntoParcelamento.Enabled = !isDesabilitado;
        }

        private void LimparCampos(Control _ctrl)
        {
            mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.DataSource = null;
            mO_NOTIFICACAO_LANCAMENTOBindingSource.DataSource = null;
            mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.DataSource = null;

            _dtAgravante.Clear();
            _dtNotificacaoContribuinte.Clear();
            _dtNotificacaoLancamento.Clear();
            _dtNotificacaoHistorico.Clear();
            _dtNotificacaoParcela.Clear();
            _dtNotificacaoParcelamentoComplemento.Clear();

            _dtAgravante.AcceptChanges();
            _dtNotificacaoHistorico.AcceptChanges();
            _dtNotificacaoContribuinte.AcceptChanges();
            _dtNotificacaoLancamento.AcceptChanges();
            _dtNotificacaoParcela.AcceptChanges();
            _dtNotificacaoParcelamentoComplemento.AcceptChanges();

            _drNotificacao = null;

            Geral.LimparCamposAuto(this);

            txtAREA_TERRENO.Text = "0";
            txtTESTADA_PRINCIPAL.Text = "0";
            txtAreaOriginal.Text = "0";
            txtTestadaOriginal.Text = "0";
            txtAreaConstruir.Text = "0";
            txtAreaDecadConstr.Text = "0";
            txtAreaDecadDemolir.Text = "0";
            txtAreaDemolir.Text = "0";
            txtAreaExistenteLegalConst.Text = "0";
            txtAreaLegalConstr.Text = "0";
            txtAreaLegalDemolir.Text = "0";
            txtAreaLegalReformar.Text = "0";
            txtAreaReformar.Text = "0";
            txtAreaTotal.Text = "0";
            txtUnidades.Text = "1";
            ckbImplantada.Checked = false;
            txtDesmontavelLegalizar.Text = "0";
            txtDesmontavelLegalizado.Text = "0";
            txtNumeroUnidAutonomas.Text = "0";
            txtAreaTerrenoDeduzir.Text = "0";
            txtAreaTerrenoAumentar.Text = "0";
            txtTestadaDeduzir.Text = "0";
            txtTestadaAumentar.Text = "0";
            txtAreaEdicula.Text = "0";
            txtQtdeParcela.Text = "1";
            txtValor.Text = "0";
            txtDescontoPenalidade.Text = "0";
            txtTotalDevido.Text = "0";
            txtJurosCompensatorios.Text = "0";
            txtJuros.Text = "0";
            txtMulta.Text = "0";
            txtCorrecao.Text = "0";
            txtExpediente.Text = "0";
            txtValorTotal.Text = "0";
            txtValorParcela.Text = "0";
            areaTerreno = 0;
            areaTestado = 0;
            status = "";
            txtMATRICULA_DATA_REGISTRO.Text = "";
            txtMATRICULA_NUMERO.Text = "";
            txtMATRICULA_CARTORIO.Text = "";
            txtMATRICULA_CARTORIO_CIDADE.Text = "";

            //txtAss.Text = "Aprovação de projeto";
            lblStatusNotificacao.Text = "";
            lblRetificada.Visible = false;
            txtExpedienteAnterior.Visible = false;
            txtExpedienteAnterior.Text = "0";
            lblExpedienteAnterior.Visible = false;
            LimparPastaContrib(true);

            //pnlParcelamentoParcela.Enabled = false;
            txtQtdeParcela.ReadOnly = true;
            //txtExigibilidade.ReadOnly = true;
            //txtCiencia.ReadOnly = true;
            txtVencimento.ReadOnly = true;
            btnRerratificar.Enabled = false;
            btnSuspender.Enabled = false;
            btnExcluir.Enabled = false;
            btnGravar.Enabled = true;
            btnEditar.Enabled = false;
            btnFinalizar.Enabled = false;
            btnOpcoesParcelamento.Enabled = false;
            btnOpcoes.Enabled = false;
            pnlCanceladoRemessa.Visible = false;
            pnlRemessa.Visible = false;
            txtCodParcelamento.Visible = true;
            lblCodParcelamento.Visible = true;
            mnuCarne.Visible = false;
            mnutermoConfissao.Visible = false;
            btnDa.Enabled = false;
            mnuDemonstrativoParc.Visible = false;
            rdbIncidenciaSim.Checked = true;
            rdbDiferimentoNao.Checked = true;
            txtIncidencia.Enabled = false;
            txtDiferimento.Enabled = false;
            errorProvider.Clear();

            Padrao.PadronizarIconPadding(this, errorProvider);
        }

        private void CarregarDados()
        {
            Cursor = Cursors.WaitCursor;

            try
            {
                #region "Dados da Notificacao"

                _drNotificacao = blNotificacao.BuscarNotificacaoId(Convert.ToInt32(txtID_NOTIFICACAO.Text))[0];
                _dtNotificacaoUnificacao = blNotificacao.ObterUnificacao(Convert.ToInt32(txtID_NOTIFICACAO.Text));

                #endregion

                #region "Carrega campos com dados carregados"

                tipoNotificacao = _drNotificacao.TIPO;
                txtINSCRICAO.Text = _drNotificacao.INSCRICAO;
                txtNUMERO_PROCESSO.Text = _drNotificacao.NUMERO_PROCESSO;
                txtNUMERO_NOTIFICACAO.Text = _drNotificacao.NUMERO_NOTIFICACAO.ToString();
                txtANO_NOTIFICACAO.Text = _drNotificacao.ANO_NOTIFICACAO.ToString();
                txtDATA_NOTIFICACAO.Text = _drNotificacao.IsDATA_NOTIFICACAONull() ? string.Empty : _drNotificacao.DATA_NOTIFICACAO.ToLongDateString();
                txtCEP.Text = _drNotificacao.IsCEPNull() ? string.Empty : _drNotificacao.CEP.Trim();
                txtLOGRADOURO.Text = _drNotificacao.IsLOGRADOURONull() ? string.Empty : _drNotificacao.LOGRADOURO.Trim();
                txtNUMERO.Text = _drNotificacao.IsNUMERONull() ? string.Empty : _drNotificacao.NUMERO.Trim();
                txtCOMPLEMENTO.Text = _drNotificacao.IsCOMPLEMENTONull() ? string.Empty : _drNotificacao.COMPLEMENTO.Trim();
                txtBAIRRO.Text = _drNotificacao.IsBAIRRONull() ? string.Empty : _drNotificacao.BAIRRO.Trim();

                txtMATRICULA_CARTORIO.Text = _drNotificacao.IsMATRICULA_CARTORIONull() ? string.Empty : _drNotificacao.MATRICULA_CARTORIO.ToString();
                txtMATRICULA_CARTORIO_CIDADE.Text = _drNotificacao.IsMATRICULA_CARTORIO_CIDADENull() ? string.Empty : _drNotificacao.MATRICULA_CARTORIO_CIDADE;
                txtMATRICULA_NUMERO.Text = _drNotificacao.IsMATRICULA_NUMERONull() ? string.Empty : _drNotificacao.MATRICULA_NUMERO.ToString();

                var end = Biblioteca.Geral.FormatarPrimeiraMaiuscula_2($"{txtLOGRADOURO.Text}, Quadra {_drNotificacao.QUADRA}, Lote {_drNotificacao.LOTE}, {_drNotificacao.BAIRRO}, {_drNotificacao.CIDADE}/ {_drNotificacao.UF}");
                Dictionary<string, string> dic = new Dictionary<string, string>();
                dic.Add("Incricao", txtINSCRICAO.Text);
                dic.Add("Endereco", end);
                dic.Add("Processo_Digital", txtNUMERO_PROCESSO.Text);
                if (!string.IsNullOrEmpty(txtMATRICULA_CARTORIO_CIDADE.Text) & txtMATRICULA_CARTORIO_CIDADE.TextLength >= 5)
                {
                    var cidade = txtMATRICULA_CARTORIO_CIDADE.Text.ToLower().Substring(3, txtMATRICULA_CARTORIO_CIDADE.TextLength - 3);
                    cidade = cidade.Substring(0, 1).ToUpper() + cidade.Substring(1);
                    dic.Add("Matricula", $"{txtMATRICULA_NUMERO.Text} no Oficial de Registro de Im\\u243\\'f3veis de {cidade}");
                }
                txtASSUNTO.MacroSubstituicao(dic);

                txtASSUNTO.Text = _drNotificacao.IsASSUNTONull() ? string.Empty : _drNotificacao.ASSUNTO.Trim();

                txtASSUNTO.Parametro = "TRIFIS#NOTIFI";

                txtFATO_JURIDICO.Text = "";// _drNotificacao.IsFATO_JURIDICONull() ? string.Empty : _drNotificacao.FATO_JURIDICO.Trim();

                //string s = _drNotificacao.IsFATO_JURIDICONull() ? string.Empty : _drNotificacao.FATO_JURIDICO.Trim();

                //string[] strs = s.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                /*
                Stream stringStream = new MemoryStream();
                
                StreamReader reader = new StreamReader("C:\\Temp\\temp_RTF_Open_2025314_189.rtf");
                string strs;
                string linha;
                while ((linha = reader.ReadLine()) != null)
                {
                    strs = linha + "\r\n";
                }
                */

                txtNUMERO_PROCESSO.Text = _drNotificacao.NUMERO_PROCESSO.ToString();
                txtEMAIL.Text = _drNotificacao.EMAIL.ToString();
                txtOBSERVACAO.Text = _drNotificacao.OBSERVACAO;
                txtLOTE_IMOVEL.Text = _drNotificacao.IsLOTENull() ? string.Empty : _drNotificacao.LOTE.Trim();
                txtQUADRA_IMOVEL.Text = _drNotificacao.IsQUADRANull() ? string.Empty : _drNotificacao.QUADRA.Trim();
                txtAreaOriginal.Text = _drNotificacao.AREA_TERRENO.ToString();
                txtTestadaOriginal.Text = _drNotificacao.AREA_TESTADO.ToString();
                txtExigibilidade.Text = _drNotificacao.DATA_EXIGIBILIDADE.ToShortDateString();
                txtCiencia.Text = _drNotificacao.DATA_CIENCIA.ToShortDateString();
                txtIncidencia.Text = _drNotificacao.INCIDENCIA_ISS_CONSTRUCAO_OBS;
                txtDiferimento.Text = _drNotificacao.DIFERIMENTO_OBS;

                if (_drNotificacao.INCIDENCIA_ISS_CONSTRUCAO)
                {
                    rdbIncidenciaSim.Checked = true;
                    txtIncidencia.Enabled = false;
                }
                else
                {
                    rdbIncidenciaNao.Checked = true;
                    txtIncidencia.Enabled = true;
                }

                if (_drNotificacao.DIFERIMENTO)
                {
                    rdbDiferimentoSim.Checked = true;
                    txtDiferimento.Enabled = true;
                }
                else
                {
                    rdbDiferimentoNao.Checked = true;
                    txtDiferimento.Enabled = false;
                }

                status = _drNotificacao.STATUS;

                if (status == "F")
                {
                    pnlRemessa.Visible = false;
                    mnuCarne.Visible = true;
                    mnutermoConfissao.Visible = true;
                    btnDa.Enabled = true;
                    mnuDemonstrativoParc.Visible = true;
                    btnOpcoesParcelamento.Enabled = true;
                    btnExcluir.Enabled = true;
                    btnGravar.Enabled = false;
                    btnEditar.Enabled = false;
                    btnFinalizar.Enabled = false;
                    btnOpcoes.Enabled = true;
                    pnlCanceladoRemessa.Visible = false;
                    btnSuspender.Enabled = true;
                    lblRetificada.Visible = false;

                    if (_drNotificacao.DATA_EXIGIBILIDADE >= DateTime.Now)
                    {
                        btnRerratificar.Enabled = true;
                    }

                    _dtParametro = blNotificacao.ObterParametro();

                    int diasPermitidoExigibilidade = Convert.ToInt32(_dtParametro.Select("CHAVE = 'DATA_EXIGIBILIDADE'")[0]["VALOR"]);

                    if (_drNotificacao.DATA_EXIGIBILIDADE.AddDays(diasPermitidoExigibilidade) >= DateTime.Now)
                    {
                        //COMENTADO POIS É NECESSARIO ALTERAR EM OUTROS MOMENTOS.
                        //if (_drNotificacao.DATA_EXIGIBILIDADE_ALTERADA == false)
                        //{
                        //pcbData.Visible = true;
                        //}
                    }
                    else
                    {
                        //pcbData.Visible = false;
                    }

                    if (_drNotificacao.SUSPENSO)
                    {
                        btnRerratificar.Enabled = false;
                        pnlCanceladoRemessa.Visible = true;
                        btnExcluir.Enabled = false;
                        btnSuspender.Text = "Ativar";
                        lblSuspCanc.Text = "Dados Suspensão";

                        _dtNotificacaoHistorico = blNotificacao.ObterUltimoHistorico(_drNotificacao.ID_NOTIFICACAO, "SUSPENSÃO");

                        if (_dtNotificacaoHistorico.Rows.Count > 0)
                        {
                            txtDATA_CANCELAMENTO.Text = _dtNotificacaoHistorico.Rows[0]["DATA"].ToString();
                            txtPROCESSO_CANCELAMENTO.Text = _dtNotificacaoHistorico.Rows[0]["PROCESSO"].ToString();
                            txtMOTIVO_CANCELAMENTO.Text = _dtNotificacaoHistorico.Rows[0]["MOTIVO"].ToString();

                            lblStatusNotificacao.Text = "NOTIFICAÇÃO SUSPENSA";
                        }
                    }
                    else
                    {
                        lblStatusNotificacao.Text = "NOTIFICAÇÃO FINALIZADA";
                        pnlCanceladoRemessa.Visible = false;
                        btnSuspender.Text = "Suspender";
                    }

                    if (_drNotificacao.RETIFICADA)
                    {
                        lblRetificada.Text = "NOTIFICAÇÃO RETIFICADA";
                        lblRetificada.Visible = true;
                        btnRerratificar.Enabled = false;
                        btnOpcoesParcelamento.Enabled = false;
                        btnExcluir.Enabled = false;
                        btnGravar.Enabled = false;
                        btnEditar.Enabled = false;
                        btnFinalizar.Enabled = false;
                        btnOpcoes.Enabled = true;
                        pnlCanceladoRemessa.Visible = false;
                        btnSuspender.Enabled = false;
                        //pcbData.Visible = false;
                    }

                    if (_drNotificacao.ID_NOTIFICACAO_PAI != 0)
                    {
                        lblRetificada.Text = "NOTIFICAÇÃO RERRATIFICADA";
                        lblRetificada.Visible = true;
                        btnRerratificar.Enabled = false;
                    }

                    if (_drNotificacao.DA_ENCAMINHADO)
                    {
                        btnRerratificar.Enabled = false;
                        btnOpcoesParcelamento.Enabled = false;
                        btnExcluir.Enabled = false;
                        btnGravar.Enabled = false;
                        btnEditar.Enabled = false;
                        btnFinalizar.Enabled = false;
                        btnOpcoes.Enabled = true;
                        pnlCanceladoRemessa.Visible = false;
                        btnSuspender.Enabled = false;

                        if (!_drNotificacao.DA_ENCAMINHADO && !_drNotificacao.DA_PROCESSADO)
                        {
                            lblStatusNotificacao.Text = "NOTIFICAÇÃO ENCAMINHADA PARA D.A.";
                        }
                        else if (!_drNotificacao.DA_PROCESSADO)
                        {
                            lblStatusNotificacao.Text = "NOTIFICAÇÃO PROCESSADO PELA D.A.";
                            btnDa.Enabled = false;
                        }

                        pnlRemessa.Visible = true;

                        _dtTermoRemessa = blNotificacao.ObterTermoRemessa(_drNotificacao.ID_NOTIFICACAO);

                        if (_dtTermoRemessa.Rows.Count > 0)
                        {
                            txtDataRemessa.Text = _dtTermoRemessa.Rows[0]["DATA_ENCAMINHAMENTO"].ToString();
                            txtProcessoRemessa.Text = _dtTermoRemessa.Rows[0]["PROCESSO"].ToString() + "/" + _dtTermoRemessa.Rows[0]["PROCESSO_ANO"].ToString();
                            txtControleLegalidade.Text = _dtTermoRemessa.Rows[0]["CONTROLE_LEGALIDADE"].ToString();
                        }


                    }

                    _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                    if (_dtNotificacaoParcelamento.Rows.Count > 0)
                    {
                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                        if (dtr == null)
                        {
                            mnuCarne.Visible = false;
                            mnutermoConfissao.Visible = false;
                        }
                    }
                }
                else if (status == "C")
                {
                    pnlRemessa.Visible = false;
                    mnuCarne.Visible = false;
                    mnutermoConfissao.Visible = false;
                    btnDa.Enabled = false;
                    mnuDemonstrativoParc.Visible = false;
                    btnOpcoesParcelamento.Enabled = false;
                    btnRerratificar.Enabled = false;
                    btnExcluir.Enabled = false;
                    btnGravar.Enabled = false;
                    btnEditar.Enabled = false;
                    btnFinalizar.Enabled = false;
                    pnlCanceladoRemessa.Visible = true;
                    lblSuspCanc.Text = "Dados Cancelamento";
                    lblStatusNotificacao.Text = "NOTIFICAÇÃO CANCELADA";
                    btnSuspender.Enabled = false;
                    lblRetificada.Visible = false;

                    txtDATA_CANCELAMENTO.Text = _drNotificacao.CANCELAMENTO_DATA.ToShortDateString();
                    txtPROCESSO_CANCELAMENTO.Text = _drNotificacao.CANCELAMENTO_PROCESSO + "/" + _drNotificacao.CANCELAMENTO_PROCESSO_ANO;
                    txtMOTIVO_CANCELAMENTO.Text = _drNotificacao.CANCELAMENTO_MOTIVO;
                }
                else
                {
                    btnOpcoes.Enabled = true;
                    pnlRemessa.Visible = false;
                    mnuCarne.Visible = false;
                    mnutermoConfissao.Visible = false;
                    btnDa.Enabled = false;
                    mnuDemonstrativoParc.Visible = false;
                    btnOpcoesParcelamento.Enabled = true;
                    btnSuspender.Enabled = false;
                    btnRerratificar.Enabled = false;
                    btnExcluir.Enabled = false;
                    btnGravar.Enabled = true;
                    btnEditar.Enabled = true;
                    pnlCanceladoRemessa.Visible = false;
                    lblStatusNotificacao.Text = "NOTIFICAÇÃO EM ANDAMENTO";
                    lblRetificada.Visible = false;

                    if (_drNotificacao.ID_NOTIFICACAO_PAI != 0)
                    {
                        lblRetificada.Text = "NOTIFICAÇÃO RERRATIFICADA";
                        lblRetificada.Visible = true;
                        btnRerratificar.Enabled = false;
                    }
                }
                //obter as areas de terrenos que foram unificados.

                if (_dtNotificacaoUnificacao.Rows.Count > 0)
                {
                    for (int i = 0; i < _dtNotificacaoUnificacao.Rows.Count; i++)
                    {
                        areaTerreno = Convert.ToDecimal(areaTerreno) + Convert.ToDecimal(_dtNotificacaoUnificacao.Rows[i]["AREA_TERRENO"].ToString());
                        areaTestado = Convert.ToDecimal(areaTestado) + Convert.ToDecimal(_dtNotificacaoUnificacao.Rows[i]["AREA_TERRENO_TESTADO"].ToString());
                    }

                    txtAREA_TERRENO.Text = areaTerreno.ToString();
                    txtTESTADA_PRINCIPAL.Text = areaTestado.ToString();
                }
                else
                {
                    txtAREA_TERRENO.Text = _drNotificacao.AREA_TERRENO.ToString();
                    txtTESTADA_PRINCIPAL.Text = _drNotificacao.AREA_TESTADO.ToString();

                    areaTerreno = Convert.ToDecimal(_drNotificacao.AREA_TERRENO.ToString());
                    areaTestado = Convert.ToDecimal(_drNotificacao.AREA_TESTADO.ToString());
                }

                cbxUF.Text = "SP";
                cbxUF_SelectedIndexChanged(null, null);
                cbxCIDADE.Text = "VOTORANTIM";
                cbxTipo.SelectedValue = _drNotificacao.TIPO_QUALIFICACAO;
                cbxCONDOMINIO.Text = _drNotificacao.IsCONDOMINIONull() ? string.Empty : _drNotificacao.CONDOMINIO.Trim();
                cbxLOTEAMENTO.Text = _drNotificacao.IsLOTEAMENTONull() ? string.Empty : _drNotificacao.LOTEAMENTO.Trim();

                #endregion "Carrega campos com dados carregados"

                // bind deve ser feito a todo momento que carrega as tabelas (bind carrega suas correspondentes tabelas)
                BindGridView();

                //PRECISA SER ANALISADO AS REGRAS QUE FARÃO O BLOQUEIO DA UFM. PROVAVELMENTE FAREMOS O BLOQUEIO PARA DEMAIS CAMPOS EM TELA 
                bloquearAtualizacaoUFM = false;
                //dgvLancamentoConstrucao.Columns["EXCLUIR"].Visible = false;
            }
            catch (Biblioteca.Exceptions.LNE ex)
            {
                Cursor = Cursors.Default;
                modoTabela = Geral.ModoTabela.MODO_PESQUISA;
                Mensagem.MsgAlert("Registro não encontrado.\n" + ex.Message, "Atenção");
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                modoTabela = Geral.ModoTabela.MODO_PESQUISA;
                Mensagem.MsgExcecao("Atenção", ex);
            }
            Cursor = Cursors.Default;
        }

        private void BindGridView()
        {
            if (_drNotificacao != null)
            {
                _dtNotificacaoContribuinte = blNotificacao.ListarContribuinteIdNotificacao(_drNotificacao.ID_NOTIFICACAO);                
                _dtNotificacaoLancamento = blNotificacao.ListarLancamentoNotificacaoIdNotificacao(_drNotificacao.ID_NOTIFICACAO);
                _dtNotificacaoUnificacao = blNotificacao.ObterUnificacao(_drNotificacao.ID_NOTIFICACAO);
                _dtNotificacaoHistorico = blNotificacao.ListarHistorico(_drNotificacao.ID_NOTIFICACAO);

                CarregarDadosParcela();

                if (status == "A" || status == "R")
                {
                    CalcularExpedienteAnterior();
                    CalcularParcelamento();
                    AtualizarAgrupamento();
                }
            }
            else
            {
                _dtNotificacaoContribuinte.Clear();
                _dtNotificacaoLancamento.Clear();
                _dtNotificacaoUnificacao.Clear();
            }

            #region "Dados do Contribuinte"

            this.CarregarGridContribuinte();

            #endregion "Dados do Contribuinte"

            #region "Dados do Lançamento"

            this.CarregarGridLancamentoConstrucao();

            #endregion "Dados do Lançamento"

            #region "Dados Unificação"  

            this.CarregarGridUnificacao();

            #endregion

            #region "Dados Historico"  

            this.CarregarGridHistorico();

            #endregion
        }

        private void CarregarInscricao(string pstrInscricao, string pstrTributo, bool unificacao)
        {
            try
            {

                if (pstrTributo == "I")
                {
                    BL.Imobiliario.Cadastro.Imobiliario blImobiliario = new BL.Imobiliario.Cadastro.Imobiliario();
                    DL.Imobiliario.DS.DSRelatorio.FichaImobiliariaDataTable dtFichaImobiliaria = blImobiliario.FichaImobiliaria(pstrInscricao);

                    if (dtFichaImobiliaria.Rows.Count == 0)
                    {
                        Mensagem.MsgAlert("Inscrição Imobiliária não encontrada !", "Aviso");
                        return;
                    }

                    DL.Imobiliario.DS.DSRelatorio.FichaImobiliariaRow drImobiliario = dtFichaImobiliaria[0];

                    if (drImobiliario.ID_COBRANCA == 3 || drImobiliario.ID_COBRANCA == 5)
                    {
                        Mensagem.MsgAlert("Inscrição Inativa/Municípal !", "Aviso");
                        return;
                    }

                    if (!unificacao)
                    {
                        _dtNotificacaoContribuinte.Clear();

                        txtCEP.Text = drImobiliario.IsCEPNull() ? string.Empty : drImobiliario.CEP.Trim();
                        txtLOGRADOURO.Text = drImobiliario.IsLOGRADOURONull() ? string.Empty : drImobiliario.LOGRADOURO.Trim();
                        txtNUMERO.Text = drImobiliario.IsNUMERO_IMOVELNull() ? string.Empty : drImobiliario.NUMERO_IMOVEL.Trim();
                        txtCOMPLEMENTO.Text = drImobiliario.IsCOMPLEMENTO_IMOVELNull() ? string.Empty : drImobiliario.COMPLEMENTO_IMOVEL.Trim();
                        txtBAIRRO.Text = drImobiliario.IsBAIRRONull() ? string.Empty : drImobiliario.BAIRRO.Trim();
                        txtQUADRA_IMOVEL.Text = drImobiliario.IsQUADRA_IMOVELNull() ? string.Empty : drImobiliario.QUADRA_IMOVEL.Trim();
                        txtLOTE_IMOVEL.Text = drImobiliario.IsLOTE_IMOVELNull() ? string.Empty : drImobiliario.LOTE_IMOVEL.Trim();
                        txtAREA_TERRENO.Text = drImobiliario.IsAREA_TERRENONull() ? "0" : drImobiliario.AREA_TERRENO.ToString();
                        txtAreaOriginal.Text = drImobiliario.IsAREA_TERRENONull() ? "0" : drImobiliario.AREA_TERRENO.ToString();

                        txtMATRICULA_NUMERO.Text = drImobiliario.IsMATRICULA_NUMERONull() ? string.Empty : drImobiliario.MATRICULA_NUMERO.ToString();
                        txtMATRICULA_CARTORIO.Text = drImobiliario.IsMATRICULA_CARTORIONull() ? string.Empty : drImobiliario.MATRICULA_CARTORIO.ToString();
                        txtMATRICULA_CARTORIO_CIDADE.Text = drImobiliario.IsMATRICULA_CARTORIO_CIDADENull() ? string.Empty : drImobiliario.MATRICULA_CARTORIO_CIDADE.Trim();
                        txtMATRICULA_DATA_REGISTRO.Text = drImobiliario.IsMATRICULA_DATA_REGISTRONull() ? string.Empty : drImobiliario.MATRICULA_DATA_REGISTRO.ToString("d");


                        areaTerreno = 0;
                        areaTestado = 0;

                        areaTerreno = drImobiliario.IsAREA_TERRENONull() ? 0 : Convert.ToDecimal(drImobiliario.AREA_TERRENO.ToString());

                        areaTestado += drImobiliario.IsTESTADA_PRINCIPALNull() ? 0 : drImobiliario.TESTADA_PRINCIPAL;
                        areaTestado += drImobiliario.IsTESTADA_2Null() ? 0 : drImobiliario.TESTADA_2;
                        areaTestado += drImobiliario.IsTESTADA_3Null() ? 0 : drImobiliario.TESTADA_3;
                        areaTestado += drImobiliario.IsTESTADA_4Null() ? 0 : drImobiliario.TESTADA_4;

                        txtTESTADA_PRINCIPAL.Text = areaTestado.ToString();
                        txtTestadaOriginal.Text = areaTestado.ToString();

                        cbxLOTEAMENTO.SelectedValue = drImobiliario.IsID_LOTEAMENTONull() ? cbxLOTEAMENTO.SelectedValue = -1 : drImobiliario.ID_LOTEAMENTO;
                        cbxCONDOMINIO.SelectedValue = drImobiliario.IsID_CONDOMINIONull() ? -1 : drImobiliario.ID_CONDOMINIO;

                        cbxUF.Text = "SP";
                        cbxUF_SelectedIndexChanged(null, null);
                        cbxCIDADE.Text = "VOTORANTIM";
                        cbxCIDADE.Text = drImobiliario.IsCIDADE_ENTREGANull() ? string.Empty : drImobiliario.CIDADE_ENTREGA.Trim();

                        DataTable dtbProprietarios = blImobiliario.ListarProprietarioInscricao(pstrInscricao);

                        DL.Imobiliario.DS.DSCadastro.IM_PESSOARow drPessoa = null;
                        DL.Imobiliario.DS.DSCadastro.IM_PESSOA_ENDERECODataTable dtEndereco = null;

                        if (dtbProprietarios.Rows.Count > 0)
                        {
                            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow drContribuinte = null;

                            try
                            {
                                for (int i = 0; i < dtbProprietarios.Rows.Count; i++)
                                {
                                    drContribuinte = _dtNotificacaoContribuinte.NewMO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow();

                                    drPessoa = blPessoa.BuscarCpfCnpj(dtbProprietarios.Rows[i]["CPFCNPJ_PESSOA"].ToString());
                                    dtEndereco = blPessoaEndereco.ListarCpfCnpj(dtbProprietarios.Rows[i]["CPFCNPJ_PESSOA"].ToString());

                                    DL.Imobiliario.DS.DSCadastro.IM_PESSOA_ENDERECORow drEndereco = null;

                                    drContribuinte.CPFCNPJ = dtbProprietarios.Rows[i]["CPFCNPJ_PESSOA"].ToString();
                                    drContribuinte.NOME_RAZAO = drPessoa.NOME_RAZAO;
                                    //  drContribuinte.TIPO_CONTRIBUINTE = "C";
                                    drContribuinte.QUALIFICACAO = "";
                                    drContribuinte.CONTRIBUINTE = "";
                                    drContribuinte.RESPONSAVEL = "";
                                    drContribuinte.OBSERVACAO = "";
                                    drContribuinte.PRINCIPAL = false;
                                    drContribuinte.ID_NOTIFICACAO_CONTRIBUINTE = (i + 1) * (-1);

                                    if (dtEndereco.Count > 0)
                                    {
                                        drEndereco = dtEndereco[0];

                                        drContribuinte.CIDADE = drEndereco.CIDADE;
                                        drContribuinte.BAIRRO = drEndereco.BAIRRO;
                                        drContribuinte.COMPLEMENTO = drEndereco.COMPLEMENTO;
                                        drContribuinte.LOGRADOURO = drEndereco.LOGRADOURO;
                                        drContribuinte.NUMERO = drEndereco.NUMERO;
                                        drContribuinte.UF = drEndereco.ESTADO;
                                        drContribuinte.CEP = drEndereco.CEP;
                                    }

                                    drContribuinte.ID_NOTIFICACAO = -1;

                                    _dtNotificacaoContribuinte.AddMO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow(drContribuinte);
                                }

                                CarregarGridContribuinte();

                            }
                            catch (Exception)
                            {
                                // Mensagem.MsgExcecao("Erro ao atualizar contribuinte.\nVerifique preenchimento dos campos.", "Atenção", ex);
                            }
                        }
                    }
                    else
                    {
                        txtAreaTerrenoUnificacao.Text = drImobiliario.IsAREA_TERRENONull() ? "0" : drImobiliario.AREA_TERRENO.ToString();

                        decimal areaTestadoUnificacao = 0;

                        areaTestadoUnificacao += drImobiliario.IsTESTADA_PRINCIPALNull() ? 0 : drImobiliario.TESTADA_PRINCIPAL;
                        areaTestadoUnificacao += drImobiliario.IsTESTADA_2Null() ? 0 : drImobiliario.TESTADA_2;
                        areaTestadoUnificacao += drImobiliario.IsTESTADA_3Null() ? 0 : drImobiliario.TESTADA_3;
                        areaTestadoUnificacao += drImobiliario.IsTESTADA_4Null() ? 0 : drImobiliario.TESTADA_4;

                        txtTestadaUnificacao.Text = areaTestadoUnificacao.ToString();

                        TXTCEPUNI.Text = drImobiliario.IsCEPNull() ? string.Empty : drImobiliario.CEP.Trim();
                        TXTLOGRADOUROUNI.Text = drImobiliario.IsLOGRADOURONull() ? string.Empty : drImobiliario.LOGRADOURO.Trim();
                        TXTNUMEROUNI.Text = drImobiliario.IsNUMERO_IMOVELNull() ? string.Empty : drImobiliario.NUMERO_IMOVEL.Trim();
                        TXTCOMPLEMENTOUNI.Text = drImobiliario.IsCOMPLEMENTO_IMOVELNull() ? string.Empty : drImobiliario.COMPLEMENTO_IMOVEL.Trim();
                        TXTBAIRROUNI.Text = drImobiliario.IsBAIRRONull() ? string.Empty : drImobiliario.BAIRRO.Trim();
                        TXTQUADRAUNI.Text = drImobiliario.IsQUADRA_IMOVELNull() ? string.Empty : drImobiliario.QUADRA_IMOVEL.Trim();
                        TXTLOTEUNI.Text = drImobiliario.IsLOTE_IMOVELNull() ? string.Empty : drImobiliario.LOTE_IMOVEL.Trim();
                        cbxLOTEAMENTOUNI.SelectedValue = drImobiliario.IsID_LOTEAMENTONull() ? cbxLOTEAMENTOUNI.SelectedValue = -1 : drImobiliario.ID_LOTEAMENTO;
                        cbxCONDOMINIOUNI.SelectedValue = drImobiliario.IsID_CONDOMINIONull() ? -1 : drImobiliario.ID_CONDOMINIO;
                        TXTUFUNI.Text = "SP";
                        TXTCIDADEUNI.Text = drImobiliario.IsCIDADE_ENTREGANull() ? string.Empty : drImobiliario.CIDADE_ENTREGA.Trim();
                    }
                }
                else
                {
                    _dtNotificacaoContribuinte.Clear();

                    //DSCertidao.DadosMobiliarioRow drMobilairio;
                    DL.Mobiliario.DS.DSCadastro.MO_MOBILIARIORow drMobiliario;
                    DL.Shared.DS.DSShared.SH_PESSOARow drPessoa;

                    try
                    {
                        //BL.Fiscalizacao.Certidao.Cadastro blCadastro = new BL.Fiscalizacao.Certidao.Cadastro();
                        //drMobilairio = blCadastro.BuscarMobiliario(Convert.ToInt32(pstrInscricao));

                        BL.Mobiliario.Cadastro.Mobiliario blMobiliario = new BL.Mobiliario.Cadastro.Mobiliario();
                        drMobiliario = blMobiliario.BuscarInscMunicipal(Convert.ToInt32(pstrInscricao));
                        drPessoa = drMobiliario.Pessoa;

                    }
                    catch (Biblioteca.Exceptions.LNE)
                    {
                        Mensagem.MsgAlert("Inscrição Municipal não encontrada !", "Aviso");
                        return;
                    }

                    if (!drMobiliario.IsDATA_ENCERRAMENTONull() || !drMobiliario.IsDATA_BLOQUEIONull() || !drMobiliario.IsDATA_CANCELAMENTONull())
                    {
                        Mensagem.MsgAlert("Inscrição mobiliária ENCERRADA\\CANCELADA\\BLOQUEADA!", "Aviso");
                    }

                    if (drPessoa != null)
                    {
                        txtCPFCNPJ.Text = drPessoa.CPFCNPJ;
                        //txtRG.Text = drPessoa.IsRGIENull() ? string.Empty : drPessoa.RGIE;
                        txtNOME_RAZAO.Text = drPessoa.IsNOME_RAZAONull() ? string.Empty : drPessoa.NOME_RAZAO.Trim();

                        if (drPessoa.Endereco != null && drPessoa.Endereco.Count > 0)
                        {
                            DL.Shared.DS.DSShared.SH_ENDERECORow drEndereco = drPessoa.Endereco[0];
                            txtCEP.Text = drEndereco.IsCEPNull() ? string.Empty : drEndereco.CEP;
                            txtLOGRADOURO.Text = drEndereco.IsLOGRADOURONull() ? string.Empty : drEndereco.LOGRADOURO;
                            txtNUMERO.Text = drEndereco.IsNUMERONull() ? string.Empty : drEndereco.NUMERO;
                            txtCOMPLEMENTO.Text = drEndereco.IsCOMPLEMENTONull() ? string.Empty : drEndereco.COMPLEMENTO;
                            txtBAIRRO.Text = drEndereco.IsBAIRRONull() ? string.Empty : drEndereco.BAIRRO;
                            cbxUF.Text = drEndereco.IsESTADONull() ? string.Empty : drEndereco.ESTADO;
                            cbxUF_SelectedIndexChanged(null, null);
                            cbxCIDADE.Text = drEndereco.IsCIDADENull() ? string.Empty : drEndereco.CIDADE;
                        }
                    }


                    //cbxUF.Text = "SP";
                    //cbxUF_SelectedIndexChanged(null, null);
                    //cbxCIDADE.Text = "VOTORANTIM";

                    DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow drContribuinte = null;

                    drContribuinte = _dtNotificacaoContribuinte.NewMO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow();

                    drContribuinte.CPFCNPJ = txtCPFCNPJ.Text.Replace(".", "").Replace("-", "").Replace("/", "");
                    drContribuinte.NOME_RAZAO = txtNOME_RAZAO.Text;
                    drContribuinte.QUALIFICACAO = "";
                    drContribuinte.CONTRIBUINTE = "";
                    drContribuinte.RESPONSAVEL = "";
                    drContribuinte.OBSERVACAO = "";
                    drContribuinte.PRINCIPAL = false;
                    drContribuinte.ID_NOTIFICACAO_CONTRIBUINTE = -1;
                    drContribuinte.CIDADE = "";
                    drContribuinte.BAIRRO = "";
                    drContribuinte.COMPLEMENTO = "";
                    drContribuinte.LOGRADOURO = txtLOGRADOURO.Text;
                    drContribuinte.NUMERO = txtNUMERO.Text;
                    drContribuinte.UF = "";
                    drContribuinte.CEP = txtCEP.Text.Replace("-", "");

                    drContribuinte.ID_NOTIFICACAO = -1;

                    _dtNotificacaoContribuinte.AddMO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow(drContribuinte);

                    CarregarGridContribuinte();
                }

                txtExigibilidade.Text = DateTime.Now.AddDays(32).ToShortDateString();
                txtVencimento.Text = DateTime.Now.AddDays(32).ToShortDateString();
                txtCiencia.Text = DateTime.Now.AddDays(2).ToShortDateString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Pesquisar()
        {
            try
            {
                BL.Fiscalizacao.Utilitario.FontePesquisa fonte = new BL.Fiscalizacao.Utilitario.FontePesquisa();
                PesquisaTag tag = new PesquisaTag();

                DataTable dt = tag.PesquisarCampos(this, fonte.fontePesquisaNotificacaoLancamento);

                // Atenção! Dataset como fonte de dados!!
                dSNotificacaoLancamento.EnforceConstraints = false;
                dSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO.Clear();
                dSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO.Merge(dt);

                // Bind no dataset!
                mO_NOTIFICACAO_LANCAMENTOBindingSource.DataSource = dSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO;

                // Se encontrar entra no modo de consulta
                if (dt.Rows.Count > 0)
                {
                    txtID_NOTIFICACAO.Text = dt.Rows[0]["ID_NOTIFICACAO"].ToString();

                    modoTabela = Geral.ModoTabela.MODO_CONSULTA;
                }
                else
                    Mensagem.MsgInfo("Pesquisa não retornou resultado para os campos informados.", "Pesquisa");
            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Não foi possível realizar a pesquisa.", "Atenção", ex);
            }
        }

        private void Incluir()
        {
            if (Permissao.VerAcesso(EnumDLL.Permissao.FI_CertidãoRegularidadeFiscal_EmitirCertidão))
            {
                if (modoTabela == Geral.ModoTabela.MODO_CONSULTA ||
                    modoTabela == Geral.ModoTabela.MODO_PESQUISA)
                {
                    LimparCampos(this);

                    modoTabela = Geral.ModoTabela.MODO_INCLUSAO;
                }
                else if (modoTabela == Geral.ModoTabela.MODO_EDICAO)
                    Mensagem.MsgInfo("Registro está sendo editado. Inclusão não permitida.", "Atenção");
            }
        }

        private void Editar()
        {
            //if (Permissao.VerAcesso(EnumDLL.Permissao.IM_Imobiliário_Editar, true))
            //{
            //    if (modoTabela == BL.Shared.Utilitario.Geral.ModoTabela.MODO_EDICAO)
            //        return;
            //    else if (modoTabela == BL.Shared.Utilitario.Geral.ModoTabela.MODO_INCLUSAO)
            //        Mensagem.MsgInfo("Registro está sendo incluído. Edição não permitida.", "Atenção");
            //    else if (modoTabela == BL.Shared.Utilitario.Geral.ModoTabela.MODO_PESQUISA)
            //        Mensagem.MsgInfo("Selecione o registro a ser editado.", "Atenção");
            //    else
            modoTabela = Geral.ModoTabela.MODO_EDICAO;
            //}
            //else if (Permissao.VerAcesso(EnumDLL.Permissao.IM_Imobiliário_EditarDadosEntrega, true))
            //{
            //    if (modoTabela == BL.Shared.Utilitario.Geral.ModoTabela.MODO_EDICAO)
            //        return;
            //    else if (modoTabela == BL.Shared.Utilitario.Geral.ModoTabela.MODO_INCLUSAO)
            //        Mensagem.MsgInfo("Registro está sendo incluído. Edição não permitida.", "Atenção");
            //    else if (modoTabela == BL.Shared.Utilitario.Geral.ModoTabela.MODO_PESQUISA)
            //        Mensagem.MsgInfo("Selecione o registro a ser editado.", "Atenção");
            //    else
            //    {
            //        modoTabela = BL.Shared.Utilitario.Geral.ModoTabela.MODO_EDICAO;
            //        DesabilitarCampos(true);
            //    }
            //}
            //else
            //    Mensagem.MsgAlert("Usuário não possui permissão de acesso a esta rotina.", "Permissão de acesso");
        }

        private void CarregarDadosDaTela(DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTORow dr)
        {
            dr.TIPO = tipoNotificacao;
            dr.NUMERO_NOTIFICACAO = (txtNUMERO_NOTIFICACAO.Text == string.Empty) ? 0 : Convert.ToInt32(txtNUMERO_NOTIFICACAO.Text);
            dr.ANO_NOTIFICACAO = (txtANO_NOTIFICACAO.Text == string.Empty) ? 0 : Convert.ToInt32(txtANO_NOTIFICACAO.Text);
            //dr.DATA_NOTIFICACAO = (txtDATA_NOTIFICACAO.Text.Length > 0) ? Convert.ToDateTime(txtDATA_NOTIFICACAO.Text) : BL.Shared.Utilitario.Servidor.GetDataServidor();
            dr.INSCRICAO = txtINSCRICAO.Text;
            dr.CEP = txtCEP.Text.Replace("-", "");
            dr.LOGRADOURO = txtLOGRADOURO.Text;
            dr.NUMERO = txtNUMERO.Text;
            dr.COMPLEMENTO = txtCOMPLEMENTO.Text;
            dr.BAIRRO = txtBAIRRO.Text;
            dr.CIDADE = cbxCIDADE.Text;
            dr.UF = cbxUF.Text;
            dr.FATO_JURIDICO = "";// txtFATO_JURIDICO.Text;
            dr.FATO_JURIDICO_HTML = "";// txtFATO_JURIDICO.Html;
            dr.ASSUNTO = txtASSUNTO.Text;
            dr.ASSUNTO_HTML = txtASSUNTO.Html;
            dr.OBSERVACAO = txtOBSERVACAO.Text;
            dr.EMAIL = txtEMAIL.Text;
            dr.DATA_VENCIMENTO = Convert.ToDateTime(txtVencimento.Text ?? DateTime.Now.ToString());
            dr.DATA_EXIGIBILIDADE = Convert.ToDateTime(txtExigibilidade.Text);
            dr.DATA_CIENCIA = Convert.ToDateTime(txtCiencia.Text);
            dr.NUMERO_PROCESSO = txtNUMERO_PROCESSO.Text;
            dr.TIPO_QUALIFICACAO = cbxTipo.SelectedValue.ToString();
            dr.LOTEAMENTO = cbxLOTEAMENTO.Text;
            dr.LOTE = txtLOTE_IMOVEL.Text;
            dr.QUADRA = txtQUADRA_IMOVEL.Text;
            dr.CONDOMINIO = cbxCONDOMINIO.Text;
            dr.AREA_TERRENO = Convert.ToDecimal(txtAreaOriginal.Text);
            dr.AREA_TESTADO = Convert.ToDecimal(txtTestadaOriginal.Text);
            dr.INCIDENCIA_ISS_CONSTRUCAO = rdbIncidenciaSim.Checked == true ? true : false;
            dr.INCIDENCIA_ISS_CONSTRUCAO_OBS = txtIncidencia.Text;
            dr.DIFERIMENTO = rdbDiferimentoSim.Checked == true ? true : false;
            dr.DIFERIMENTO_OBS = txtDiferimento.Text;
            dr.MATRICULA_CARTORIO = txtMATRICULA_CARTORIO.Text == string.Empty ? 0 : Convert.ToInt32(txtMATRICULA_CARTORIO.Text);
            dr.MATRICULA_CARTORIO_CIDADE = txtMATRICULA_CARTORIO_CIDADE.Text;
            dr.MATRICULA_NUMERO = txtMATRICULA_NUMERO.Text;
            //dr.MATRICULA_DATA_REGISTRO = txtMATRICULA_DATA_REGISTRO.Text == string.Empty ? null : Convert.ToDateTime(txtMATRICULA_DATA_REGISTRO.Text);

        }

        private void Gravar()
        {

            if (modoTabela != Geral.ModoTabela.MODO_EDICAO && modoTabela != Geral.ModoTabela.MODO_INCLUSAO)
            {
                Mensagem.MsgAlert("Tabela deve estar no modo \"inclusão\" ou \"edição\".", "Gravação");
                return;
            }

            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTORow dr = null;

            try
            {
                errorProvider.Clear();
                Padrao.PadronizarIconPadding(this, errorProvider);

                // Carrega dados da linha a ser gravada
                dr = CarregarLinha();

                if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                {
                    dr.TIPO = "NL";
                    dr.STATUS = status;

                    blNotificacao.Incluir(dr, _dtNotificacaoContribuinte, _dtNotificacaoLancamento, _dtNotificacaoUnificacao);

                    dSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO.ImportRow(dr);

                    txtID_NOTIFICACAO.Text = dr.ID_NOTIFICACAO.ToString();
                }
                else if (modoTabela == Geral.ModoTabela.MODO_EDICAO)
                {
                    dr.TIPO = "NL";
                    dr.STATUS = status;

                    if (status == "F")
                    {
                        dr.DATA_NOTIFICACAO = Servidor.GetDataServidor();
                    }

                    blNotificacao.Alterar(dr, _dtNotificacaoContribuinte, _dtNotificacaoLancamento, _dtNotificacaoUnificacao);

                    if (status == "F")
                    {
                        if (dr.INSCRICAO.Length > 7)
                        {
                            blEventoImobiliario.IncluirEventoImobiliario(dr.INSCRICAO, dr.DATA_NOTIFICACAO.Date, (tipoNotificacao == "NL" ? "INCLUSÃO REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + dr.NUMERO_NOTIFICACAO.ToString() + "/" + dr.ANO_NOTIFICACAO.ToString(), "Código: " + dr.ID_NOTIFICACAO.ToString() + "  Processo: " + dr.NUMERO_PROCESSO, 0, 0, 97);
                        }
                        else
                        {
                            IntegracaoAccess.Mobiliario blMobiliarioAccess = new IntegracaoAccess.Mobiliario();


                            using (DL.Mobiliario.DS.DSCadastro.MO_EVENTODataTable dtEvento = new DL.Mobiliario.DS.DSCadastro.MO_EVENTODataTable())
                            {
                                BL.Mobiliario.Cadastro.Evento blEventoMob = new BL.Mobiliario.Cadastro.Evento();
                                DL.Mobiliario.DS.DSCadastro.MO_EVENTORow drEvento = dtEvento.NewMO_EVENTORow();

                                drEvento.DATA_EVENTO = dr.DATA_NOTIFICACAO.Date;
                                drEvento.INSCRICAO = Convert.ToInt32(dr.INSCRICAO);
                                drEvento.DESCRICAO = (tipoNotificacao == "NL" ? "NOTIFICAÇÃO DE LANÇAMENTO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + dr.NUMERO_NOTIFICACAO.ToString() + "/" + dr.ANO_NOTIFICACAO.ToString();
                                drEvento.COMPLEMENTO = "Código: " + dr.ID_NOTIFICACAO.ToString() + "  Processo: " + dr.NUMERO_PROCESSO;
                                drEvento.HISTORICO = "166";
                                dtEvento.AddMO_EVENTORow(drEvento);
                                blEventoMob.Incluir(drEvento);
                            }

                            //blMobiliarioAccess.IncluirEvento(Convert.ToInt32(dr.INSCRICAO), dr.DATA_NOTIFICACAO.Date, (tipoNotificacao == "NL" ? "NOTIFICAÇÃO DE LANÇAMENTO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + dr.NUMERO_NOTIFICACAO.ToString() + "/" + dr.ANO_NOTIFICACAO.ToString(), "Código: " + dr.ID_NOTIFICACAO.ToString() + "  Processo: " + dr.NUMERO_PROCESSO, 0, 0, "166");
                        }
                    }

                    txtID_NOTIFICACAO.Text = dr.ID_NOTIFICACAO.ToString();
                }

                blNotificacao.ExcluirParcelamento(Convert.ToInt32(txtID_NOTIFICACAO.Text));

                CarregarDados();

                try
                {
                    IncluirParcelamento();

                    //// Volta para modo consulta
                    modoTabela = Geral.ModoTabela.MODO_CONSULTA;

                    CarregarDados();
                }
                catch (Exception ex)
                {
                    dr.STATUS = "A";

                    blNotificacao.Alterar(dr, _dtNotificacaoContribuinte, _dtNotificacaoLancamento, _dtNotificacaoUnificacao);

                    if (status == "F")
                    {
                        Mensagem.MsgAlert("Erro na inclusão do parcelamento." + ex.Message, "Parcelamento");
                        status = "A";

                        modoTabela = Geral.ModoTabela.MODO_CONSULTA;
                        tbcCadastro.SelectedTab = tbpCadastro;
                        return;
                    }
                }
                Mensagem.MsgInfo("Gravação realizada com sucesso.", "Gravação");

                //pnlParcelamentoParcela.Enabled = false;
                txtQtdeParcela.ReadOnly = true;
                //txtExigibilidade.ReadOnly = true;
                //txtCiencia.ReadOnly = true;
                txtVencimento.ReadOnly = true;

                tbcCadastro.SelectedTab = tbpCadastro;
            }
            catch (Biblioteca.Exceptions.FalhaParametros ex)
            {
                if (dr != null)
                    PegarErro(dr);

                Mensagem.MsgAlert(ex.Message, "Preenchimento de campos");
            }
            catch (Biblioteca.Exceptions.LJE ex)
            {
                Mensagem.MsgAlert(ex.Message, "Atenção");
            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Gravação não pode ser realizada.\nVerifique preenchimento dos campos.", "Atenção", ex);
            }
        }

        private DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTORow CarregarLinha()
        {
            DSNotificacaoLancamento dsCad = new DSNotificacaoLancamento();
            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTORow dr = null;

            dsCad.EnforceConstraints = false;

            try
            {
                if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                    dr = dsCad.MO_NOTIFICACAO_LANCAMENTO.NewMO_NOTIFICACAO_LANCAMENTORow();
                else if (modoTabela == Geral.ModoTabela.MODO_EDICAO)
                    dr = blNotificacao.BuscarNotificacaoId(Convert.ToInt32(txtID_NOTIFICACAO.Text))[0];

                CarregarDadosDaTela(dr);

                if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                    dsCad.MO_NOTIFICACAO_LANCAMENTO.AddMO_NOTIFICACAO_LANCAMENTORow(dr);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dr;
        }
        private void AdicionarContribuinte(string qualificacao, string qualificacaoDesc)
        {
            try
            {
                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow drContribuinte = null;

                if (lblId.Text == string.Empty)
                {
                    drContribuinte = _dtNotificacaoContribuinte.NewMO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow();

                    drContribuinte.CPFCNPJ = txtCPFCNPJ.Text;
                    drContribuinte.NOME_RAZAO = txtNOME_RAZAO.Text;
                    drContribuinte.DOCUMENTO = txtDocProfissional.Text;
                    drContribuinte.QUALIFICACAO = qualificacao;
                    drContribuinte.QUALIFICACAO_DESCRICAO = qualificacaoDesc;
                    drContribuinte.CONTRIBUINTE = txtCONTRIBUINTE.Text;
                    drContribuinte.COMO_RESPONSAVEL = txtComoResponsavel.Text;
                    drContribuinte.RESPONSAVEL = txtResponsavel.Text;
                    drContribuinte.CPF_RESPONSAVEL = txtCPFResponsavel.Text;
                    drContribuinte.OBSERVACAO = txtOBSERVACAO_P.Text;
                    drContribuinte.PRINCIPAL = chkPRINCIPAL.Checked;
                    drContribuinte.CIDADE = cbxCidadeResp.SelectedValue.ToString();
                    drContribuinte.BAIRRO = txtBairroResp.Text;
                    drContribuinte.COMPLEMENTO = txtComplResp.Text;
                    drContribuinte.LOGRADOURO = txtLogradouroResp.Text;
                    drContribuinte.NUMERO = txtNumeroResp.Text;
                    drContribuinte.UF = cbxUFResp.SelectedValue.ToString();
                    drContribuinte.CEP = txtCepResp.Text;
                    drContribuinte.INSCRICAO_MUNICIPAL = txtInscriMun.Text;

                    DataRow[] dtrAdicionados = _dtNotificacaoContribuinte.Select("ID_NOTIFICACAO_CONTRIBUINTE < 0");

                    if (dtrAdicionados.Length == 0)
                    {
                        drContribuinte.ID_NOTIFICACAO_CONTRIBUINTE = -1;
                    }
                    else
                    {
                        string index = "0";

                        for (int i = 0; i < dtrAdicionados.OrderByDescending(x => x["ID_NOTIFICACAO_CONTRIBUINTE"]).Count(); i++)
                        {
                            index = dtrAdicionados[i]["ID_NOTIFICACAO_CONTRIBUINTE"].ToString();

                            break;
                        }

                        drContribuinte.ID_NOTIFICACAO_CONTRIBUINTE = Convert.ToInt32(index) + (-1);
                    }

                    if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                        drContribuinte.ID_NOTIFICACAO = -1;
                    else
                        drContribuinte.ID_NOTIFICACAO = Convert.ToInt32(txtID_NOTIFICACAO.Text);

                    _dtNotificacaoContribuinte.AddMO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow(drContribuinte);
                }
                else
                {
                    drContribuinte = _dtNotificacaoContribuinte.FindByID_NOTIFICACAO_CONTRIBUINTE(Convert.ToInt32(lblId.Text)); // (DL.Fiscalizacao.DS.DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTERow)((DataRowView)mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.Current).Row;

                    drContribuinte.CPFCNPJ = txtCPFCNPJ.Text;
                    drContribuinte.NOME_RAZAO = txtNOME_RAZAO.Text;
                    drContribuinte.DOCUMENTO = txtDocProfissional.Text;
                    drContribuinte.QUALIFICACAO = qualificacao;
                    drContribuinte.QUALIFICACAO_DESCRICAO = qualificacaoDesc;
                    drContribuinte.CONTRIBUINTE = txtCONTRIBUINTE.Text;
                    drContribuinte.COMO_RESPONSAVEL = txtComoResponsavel.Text;
                    drContribuinte.RESPONSAVEL = txtResponsavel.Text;
                    drContribuinte.CPF_RESPONSAVEL = txtCPFResponsavel.Text;
                    drContribuinte.OBSERVACAO = txtOBSERVACAO_P.Text;
                    drContribuinte.PRINCIPAL = chkPRINCIPAL.Checked;
                    drContribuinte.CIDADE = cbxCidadeResp.SelectedValue.ToString();
                    drContribuinte.BAIRRO = txtBairroResp.Text;
                    drContribuinte.COMPLEMENTO = txtComplResp.Text;
                    drContribuinte.LOGRADOURO = txtLogradouroResp.Text;
                    drContribuinte.NUMERO = txtNumeroResp.Text;
                    drContribuinte.UF = cbxUFResp.SelectedValue.ToString();
                    drContribuinte.CEP = txtCepResp.Text;
                    drContribuinte.INSCRICAO_MUNICIPAL = txtInscriMun.Text;
                }

                lblId.Text = string.Empty;

            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Erro ao atualizar contribuinte.\nVerifique preenchimento dos campos ou se o CNPJ/CPF é unico.", "Atenção", ex);
            }
        }

        private void CarregarGridContribuinte()
        {
            cobrarIssEngenharia = true;

            for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
            {
                if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted)
                {
                    if (_dtNotificacaoContribuinte.Rows[i]["QUALIFICACAO"].ToString().Contains("3-"))
                    {
                        string INSCRICAO_MUNICIPAL = _dtNotificacaoContribuinte.Rows[i]["INSCRICAO_MUNICIPAL"].ToString();

                        if (INSCRICAO_MUNICIPAL != string.Empty)
                        {
                            cobrarIssEngenharia = false;
                        }
                        else
                        {
                            cobrarIssEngenharia = true;
                            break;
                        }
                    }
                }
            }

            dgvContribuinte.CellEnter -= dgvContribuinte_CellDoubleClick;

            mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.ResetBindings(true);
            mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.DataSource = _dtNotificacaoContribuinte;

            dgvContribuinte.CellEnter += dgvContribuinte_CellDoubleClick;

            if (_dtNotificacaoContribuinte.Rows.Count > 0)
            {
                var args = new DataGridViewCellEventArgs(0, 0);

                dgvContribuinte_CellDoubleClick(dgvContribuinte, args);
            }
        }

        private void CarregarGridUnificacao()
        {
            mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource.DataSource = _dtNotificacaoUnificacao;

            dgvUnificacao.DataSource = mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource;
            dgvUnificacao.Refresh();
        }

        private void CarregarGridParcela()
        {
            if (_drNotificacao != null)
            {
                bool parcelamentoAtivo = true;
                _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                if (dtr != null)
                {
                    //parcelamentoAtivo = false;


                    mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource.DataSource = _dtNotificacaoParcela;

                    dgvParcela.DataSource = mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource;
                    dgvParcela.Columns["idParcela"].Visible = false;

                    if (status != "A")
                    {
                        if (!parcelamentoAtivo)
                            dgvParcela.Columns["Baixar"].Visible = false;
                        else
                            dgvParcela.Columns["Baixar"].Visible = true;
                    }
                    else
                    {
                        dgvParcela.Columns["Baixar"].Visible = false;
                    }

                    for (int i = 0; i < dgvParcela.Rows.Count; i++)
                    {
                        if (this.dgvParcela.Rows[i].Cells["DATA_BAIXA"].Value.ToString() != "")
                        {
                            dgvParcela.Rows[i].Cells["BAIXAR"].Value = "";
                        }
                    }

                    dgvParcela.Refresh();

                    mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource.DataSource = _dtNotificacaoParcelamentoComplemento;
                    dgvParcelamantoComplemento.DataSource = _dtNotificacaoParcelamentoComplemento;
                }
                else
                {
                    dgvParcela_CellClick(null, null);
                }
            }
        }

        private void CarregarGridHistorico()
        {
            bindingSourceHistorico.DataSource = _dtNotificacaoHistorico;

            dgvHistorico.DataSource = bindingSourceHistorico;
            dgvHistorico.Refresh();
        }

        private void LimparPastaContrib(bool principal)
        {
            txtCPFCNPJ.Enabled = true;
            txtCPFCNPJ.Text = string.Empty;
            txtNOME_RAZAO.Text = string.Empty;
            txtCONTRIBUINTE.Text = string.Empty;
            txtComoResponsavel.Text = string.Empty;
            txtResponsavel.Text = string.Empty;
            txtCPFResponsavel.Text = string.Empty;
            txtOBSERVACAO_P.Text = string.Empty;
            chkPRINCIPAL.Checked = principal;//
            txtCepResp.Text = string.Empty;
            txtLogradouroResp.Text = string.Empty;
            txtBairroResp.Text = string.Empty;
            txtComplResp.Text = string.Empty;
            txtNumeroResp.Text = string.Empty;
            txtDocProfissional.Text = string.Empty;
            lblId.Text = string.Empty;
            txtInscriMun.Text = string.Empty;

            for (int i = 0; i < ckbQualificacao.Items.Count; i++)
            {
                ckbQualificacao.SetItemChecked(i, false);
            }

            for (int i = 0; i < ckbSubnivel.Items.Count; i++)
            {
                ckbSubnivel.SetItemChecked(i, false);
            }

            errorProvider.SetError(cbxCidadeResp, "");
            errorProvider.SetError(cbxUFResp, "");
            errorProvider.SetError(txtCPFCNPJ, "");
            errorProvider.SetError(txtNOME_RAZAO, "");
            errorProvider.SetError(txtCONTRIBUINTE, "");
            errorProvider.SetError(txtComoResponsavel, "");
            errorProvider.SetError(txtResponsavel, "");
            errorProvider.SetError(txtCPFResponsavel, "");
            errorProvider.SetError(txtCepResp, "");
            errorProvider.SetError(txtLogradouroResp, "");
            errorProvider.SetError(txtBairroResp, "");
            errorProvider.SetError(txtComplResp, "");
            errorProvider.SetError(txtNumeroResp, "");
            errorProvider.SetError(txtDocProfissional, "");
        }

        private void dgvContribuinte_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void AdicionarLancamentoConstrucao()
        {
            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow drLancamento = null;

            try
            {
                if (lblIdLancamento.Text == string.Empty)
                {
                    drLancamento = _dtNotificacaoLancamento.NewMO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow();

                    drLancamento.TIPO = cbxTipoConstr.Text;
                    drLancamento.TIPO_IMOVEL = cbxTipoImovel.Text;
                    drLancamento.SUBTIPO_IMOVEL = cbxSubtipoImovel.Text;
                    drLancamento.AREA_TERRENO = Convert.ToDecimal(txtAREA_TERRENO.Text);
                    drLancamento.AREA_TERRENO_TESTADO = Convert.ToDecimal(txtTESTADA_PRINCIPAL.Text);
                    drLancamento.AREA_CONSTRUIR = Convert.ToDecimal(txtAreaConstruir.Text);
                    drLancamento.AREA_REFORMAR = Convert.ToDecimal(txtAreaReformar.Text);
                    drLancamento.AREA_LEGAL_CONSTRUCAO = Convert.ToDecimal(txtAreaLegalConstr.Text);
                    drLancamento.AREA_LEGAL_REFORMA = Convert.ToDecimal(txtAreaLegalReformar.Text);
                    drLancamento.AREA_LEGAL_EXISTENTE_CONSTRUCAO = Convert.ToDecimal(txtAreaExistenteLegalConst.Text);
                    drLancamento.AREA_DEMOLIR = Convert.ToDecimal(txtAreaDemolir.Text);
                    drLancamento.AREA_DEMOLIR_LEGAL = Convert.ToDecimal(txtAreaLegalDemolir.Text);
                    drLancamento.AREA_DECADENCIA_CONSTRUCAO = Convert.ToDecimal(txtAreaDecadConstr.Text);
                    drLancamento.AREA_DECADENCIA_DEMOLICAO = Convert.ToDecimal(txtAreaDecadDemolir.Text);
                    drLancamento.NUMERO_UNIDADES = Convert.ToInt32(txtUnidades.Text);
                    drLancamento.AREA_IMPLANTADA_LEGALIZAR = ckbImplantada.Checked;
                    drLancamento.ABRIGO_DESMONTAVEL_LEGALIZAR = Convert.ToDecimal(txtDesmontavelLegalizar.Text);
                    drLancamento.ABRIGO_DESMONTAVEL_EXISTENTE = Convert.ToDecimal(txtDesmontavelLegalizado.Text);
                    drLancamento.NUMERO_ABRIGO_DESMONTAVEL = Convert.ToInt32(txtNumeroUnidAutonomas.Text);
                    drLancamento.AREA_DEDUZIR = Convert.ToDecimal(txtAreaTerrenoDeduzir.Text);
                    drLancamento.AREA_AUMENTAR = Convert.ToDecimal(txtAreaTerrenoAumentar.Text);
                    drLancamento.AREA_TESTADA_DEDUZIR = Convert.ToDecimal(txtTestadaDeduzir.Text);
                    drLancamento.AREA_TESTADA_AUMENTAR = Convert.ToDecimal(txtTestadaAumentar.Text);
                    drLancamento.ELEVADOR = ckbElevador.Checked;
                    drLancamento.AREA_TOTAL = Convert.ToDecimal(txtAreaTotal.Text);
                    drLancamento.AREA_EDICULA = Convert.ToDecimal(txtAreaEdicula.Text);
                    drLancamento.AREA_ENQUADRAMENTO = Convert.ToDecimal(txtEnquadramento.Text);
                    drLancamento.AREA_ENQUADRAMENTO_DEMOLICAO = Convert.ToDecimal(txtEnquadramentoDemolicao.Text);
                    drLancamento.AREA_ENQUADRAMENTO_REFORMA = Convert.ToDecimal(txtEnquadramentoReforma.Text);
                    drLancamento.AREA_ENQUADRAMENTO_PENALIDADE = Convert.ToDecimal(txtEnquadramentoPenalidade.Text);
                    drLancamento.AREA_PENALIDADE_CONSTRUCAO = Convert.ToDecimal(lblPenalidade.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_ENGENHARIA = Convert.ToDecimal(lblAreaBaseISSEngenharia.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_CONSTRUCAO = Convert.ToDecimal(lblAreaBaseIssConstr.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_DEMOLICAO = Convert.ToDecimal(lblAreaBaseIssDemol.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_REFORMA = Convert.ToDecimal(lblAreaBaseIssRefor.Text.Replace(" m²", ""));
                    drLancamento.BASE_ISS_CONSTRUCAO = Convert.ToDecimal(lblBaseISSConstrucao.Text.Replace("R$ ", ""));
                    drLancamento.BASE_ISS_DEMOLICAO = Convert.ToDecimal(lblBaseISSDemolicao.Text.Replace("R$ ", ""));
                    drLancamento.BASE_ISS_REFORMA = Convert.ToDecimal(lblBaseISSReforma.Text.Replace("R$ ", ""));
                    drLancamento.CONSTRUCAO_ALIQUOTA = aliquotaConstrucao;
                    drLancamento.ENGENHARIA_ALIQUOTA = aliquotaEngenharia;
                    drLancamento.REFORMA_ALIQUOTA = aliquotaReforma;
                    drLancamento.DEMOLICAO_ALIQUOTA = aliquotaDemolicao;
                    drLancamento.IMPOSTO_ISS_CONSTRUCAO = Convert.ToDecimal(lblImpostoISSConstrucao.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_CONSTRUCAO_SECUNDARIO = ImpostoISSConstrucaoSecundario;
                    drLancamento.IMPOSTO_ISS_DEMOLICAO = Convert.ToDecimal(lblImpostoISSDemolicao.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_DEMOLICAO_SECUNDARIO = ImpostoISSDemolicaoSecundario;
                    drLancamento.IMPOSTO_ISS_REFORMA = Convert.ToDecimal(lblImpostoISSReforma.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_REFORMA_SECUNDARIO = ImpostoISSReformaSecundario;
                    drLancamento.BASE_ISS_ENGENHARIA = Convert.ToDecimal(lblBaseISSEngenharia.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_ENGENHARIA = Convert.ToDecimal(lblImpostoSSEngenharia.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_ENGENHARIA_SECUNDARIO = ImpostoISSEngenhariaSecundario;
                    drLancamento.TX_LICENCA_CONSTRUCAO = Convert.ToDecimal(lblTaxaConstrucao.Text.Replace("R$ ", ""));
                    drLancamento.TX_LICENCA_CONSTRUCAO_SECUNDARIO = TaxaConstrucaoSecundario;
                    drLancamento.TX_LICENCA_REFORMA_DEMOLICAO = Convert.ToDecimal(lblTaxaLicenca.Text.Replace("R$ ", ""));
                    drLancamento.TX_LICENCA_REFORMA_DEMOLICAO_SECUNDARIO = TaxaReformaSecundario;
                    drLancamento.TX_ALINHAMENTO = Convert.ToDecimal(lblTaxaAlinhamento.Text.Replace("R$ ", ""));
                    drLancamento.TX_ALINHAMENTO_SECUNDARIO = TaxaAlinhamentoSecundario;
                    drLancamento.TX_ALVARA = Convert.ToDecimal(lblTaxaAlvara.Text.Replace("R$ ", ""));
                    drLancamento.TX_ALVARA_SECUNDARIO = TaxaAlvaraSecundario;
                    drLancamento.TX_PENALIDADES = Convert.ToDecimal(lblTaxaPenalidades.Text.Replace("R$ ", ""));
                    drLancamento.TX_PENALIDADES_SECUNDARIO = TaxaPenalidadeSecundario;
                    drLancamento.TX_NUMERACAO_PREDIAL = Convert.ToDecimal(lblTaxaNumPredial.Text.Replace("R$", ""));
                    drLancamento.VALOR_TOTAL = 0;
                    drLancamento.TX_LICENCA_UFM_DESCRICAO = TXlicencaDescricaoUFM;
                    drLancamento.TX_ALVARA_UFM_DESCRICAO = TXalvaraDescricaoUFM;
                    drLancamento.TX_NUMERACAO_PREDIAL_UFM_DESCRICAO = TXnumeracaoPredialDescricaoUFM;
                    drLancamento.TX_PENALIDADES_UFM_DESCRICAO = TXpenalidadeDescricaoUFM;
                    drLancamento.ISS_CONSTRUCAO_UFM_DESCRICAO = ISSconstrucaoDescricaoUFM;
                    drLancamento.ISS_DEMOLICAO_UFM_DESCRICAO = ISSdemolicaoDescricaoUFM;
                    drLancamento.ISS_REFORMA_UFM_DESCRICAO = ISSreformaDescricaoUFM;
                    drLancamento.ISS_ENGENHARIA_UFM_DESCRICAO = ISSengenhariaDescricaoUFM;
                    drLancamento.TX_CONSTRUCAO_UFM_DESCRICAO = TXconstrucaoDescricaoUFM;
                    drLancamento.TX_ALINHAMENTO_UFM_DESCRICAO = TXalinhamentoDescricaoUFM;
                    drLancamento.ID_NOTIFICACAO_LANCAMENTO_AGRAVANTE = -1;
                    //drLancamento.

                    //drLancamento.MEDIDA_UTILIZADA = grpAreas.Text;

                    DataRow[] dtrAdicionados = _dtNotificacaoLancamento.Select("ID_NOTIFICACAO_LANCAMENTO < 0");

                    if (dtrAdicionados.Length == 0)
                    {
                        drLancamento.ID_NOTIFICACAO_LANCAMENTO = -1;
                    }
                    else
                    {
                        string index = "0";

                        for (int i = 0; i < dtrAdicionados.OrderByDescending(x => x["ID_NOTIFICACAO_LANCAMENTO"]).Count(); i++)
                        {
                            index = dtrAdicionados[i]["ID_NOTIFICACAO_LANCAMENTO"].ToString();

                            break;
                        }

                        drLancamento.ID_NOTIFICACAO_LANCAMENTO = Convert.ToInt32(index) + (-1);
                    }

                    if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                        drLancamento.ID_NOTIFICACAO = -1;
                    else
                        drLancamento.ID_NOTIFICACAO = Convert.ToInt32(txtID_NOTIFICACAO.Text);

                    _dtNotificacaoLancamento.AddMO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow(drLancamento);
                }
                else
                {
                    drLancamento = (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow)((DataRowView)mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.Current).Row;

                    drLancamento.TIPO = cbxTipoConstr.Text;
                    drLancamento.TIPO_IMOVEL = cbxTipoImovel.Text;
                    drLancamento.SUBTIPO_IMOVEL = cbxSubtipoImovel.Text;
                    drLancamento.AREA_TERRENO = Convert.ToDecimal(txtAREA_TERRENO.Text);
                    drLancamento.AREA_TERRENO_TESTADO = Convert.ToDecimal(txtTESTADA_PRINCIPAL.Text);
                    drLancamento.AREA_CONSTRUIR = Convert.ToDecimal(txtAreaConstruir.Text);
                    drLancamento.AREA_REFORMAR = Convert.ToDecimal(txtAreaReformar.Text);
                    drLancamento.AREA_LEGAL_CONSTRUCAO = Convert.ToDecimal(txtAreaLegalConstr.Text);
                    drLancamento.AREA_LEGAL_REFORMA = Convert.ToDecimal(txtAreaLegalReformar.Text);
                    drLancamento.AREA_LEGAL_EXISTENTE_CONSTRUCAO = Convert.ToDecimal(txtAreaExistenteLegalConst.Text);
                    drLancamento.AREA_DEMOLIR = Convert.ToDecimal(txtAreaDemolir.Text);
                    drLancamento.AREA_DEMOLIR_LEGAL = Convert.ToDecimal(txtAreaLegalDemolir.Text);
                    drLancamento.AREA_DECADENCIA_CONSTRUCAO = Convert.ToDecimal(txtAreaDecadConstr.Text);
                    drLancamento.AREA_DECADENCIA_DEMOLICAO = Convert.ToDecimal(txtAreaDecadDemolir.Text);
                    drLancamento.NUMERO_UNIDADES = Convert.ToInt32(txtUnidades.Text);
                    drLancamento.AREA_IMPLANTADA_LEGALIZAR = ckbImplantada.Checked;
                    drLancamento.ABRIGO_DESMONTAVEL_LEGALIZAR = Convert.ToDecimal(txtDesmontavelLegalizar.Text);
                    drLancamento.ABRIGO_DESMONTAVEL_EXISTENTE = Convert.ToDecimal(txtDesmontavelLegalizado.Text);
                    drLancamento.NUMERO_ABRIGO_DESMONTAVEL = Convert.ToInt32(txtNumeroUnidAutonomas.Text);
                    drLancamento.AREA_DEDUZIR = Convert.ToDecimal(txtAreaTerrenoDeduzir.Text);
                    drLancamento.AREA_AUMENTAR = Convert.ToDecimal(txtAreaTerrenoAumentar.Text);
                    drLancamento.AREA_TESTADA_DEDUZIR = Convert.ToDecimal(txtTestadaDeduzir.Text);
                    drLancamento.AREA_TESTADA_AUMENTAR = Convert.ToDecimal(txtTestadaAumentar.Text);
                    drLancamento.ELEVADOR = ckbElevador.Checked;
                    drLancamento.AREA_TOTAL = Convert.ToDecimal(txtAreaTotal.Text);
                    drLancamento.AREA_EDICULA = Convert.ToDecimal(txtAreaEdicula.Text);
                    drLancamento.AREA_ENQUADRAMENTO = Convert.ToDecimal(txtEnquadramento.Text);
                    drLancamento.AREA_ENQUADRAMENTO_DEMOLICAO = Convert.ToDecimal(txtEnquadramentoDemolicao.Text);
                    drLancamento.AREA_ENQUADRAMENTO_REFORMA = Convert.ToDecimal(txtEnquadramentoReforma.Text);
                    drLancamento.AREA_ENQUADRAMENTO_PENALIDADE = Convert.ToDecimal(txtEnquadramentoPenalidade.Text);
                    drLancamento.AREA_PENALIDADE_CONSTRUCAO = Convert.ToDecimal(lblPenalidade.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_ENGENHARIA = Convert.ToDecimal(lblAreaBaseISSEngenharia.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_CONSTRUCAO = Convert.ToDecimal(lblAreaBaseIssConstr.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_DEMOLICAO = Convert.ToDecimal(lblAreaBaseIssDemol.Text.Replace(" m²", ""));
                    drLancamento.AREA_BASE_ISS_REFORMA = Convert.ToDecimal(lblAreaBaseIssRefor.Text.Replace(" m²", ""));
                    drLancamento.BASE_ISS_CONSTRUCAO = Convert.ToDecimal(lblBaseISSConstrucao.Text.Replace("R$ ", ""));
                    drLancamento.BASE_ISS_DEMOLICAO = Convert.ToDecimal(lblBaseISSDemolicao.Text.Replace("R$ ", ""));
                    drLancamento.BASE_ISS_REFORMA = Convert.ToDecimal(lblBaseISSReforma.Text.Replace("R$ ", ""));
                    drLancamento.CONSTRUCAO_ALIQUOTA = aliquotaConstrucao;
                    drLancamento.ENGENHARIA_ALIQUOTA = aliquotaEngenharia;
                    drLancamento.REFORMA_ALIQUOTA = aliquotaReforma;
                    drLancamento.DEMOLICAO_ALIQUOTA = aliquotaDemolicao;
                    drLancamento.IMPOSTO_ISS_CONSTRUCAO = Convert.ToDecimal(lblImpostoISSConstrucao.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_CONSTRUCAO_SECUNDARIO = ImpostoISSConstrucaoSecundario;
                    drLancamento.IMPOSTO_ISS_DEMOLICAO = Convert.ToDecimal(lblImpostoISSDemolicao.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_DEMOLICAO_SECUNDARIO = ImpostoISSDemolicaoSecundario;
                    drLancamento.IMPOSTO_ISS_REFORMA = Convert.ToDecimal(lblImpostoISSReforma.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_REFORMA_SECUNDARIO = ImpostoISSReformaSecundario;
                    drLancamento.BASE_ISS_ENGENHARIA = Convert.ToDecimal(lblBaseISSEngenharia.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_ENGENHARIA = Convert.ToDecimal(lblImpostoSSEngenharia.Text.Replace("R$ ", ""));
                    drLancamento.IMPOSTO_ISS_ENGENHARIA_SECUNDARIO = ImpostoISSEngenhariaSecundario;
                    drLancamento.TX_LICENCA_CONSTRUCAO = Convert.ToDecimal(lblTaxaConstrucao.Text.Replace("R$ ", ""));
                    drLancamento.TX_LICENCA_CONSTRUCAO_SECUNDARIO = TaxaConstrucaoSecundario;
                    drLancamento.TX_LICENCA_REFORMA_DEMOLICAO = Convert.ToDecimal(lblTaxaLicenca.Text.Replace("R$ ", ""));
                    drLancamento.TX_LICENCA_REFORMA_DEMOLICAO_SECUNDARIO = TaxaReformaSecundario;
                    drLancamento.TX_ALINHAMENTO = Convert.ToDecimal(lblTaxaAlinhamento.Text.Replace("R$ ", ""));
                    drLancamento.TX_ALINHAMENTO_SECUNDARIO = TaxaAlinhamentoSecundario;
                    drLancamento.TX_ALVARA = Convert.ToDecimal(lblTaxaAlvara.Text.Replace("R$ ", ""));
                    drLancamento.TX_ALVARA_SECUNDARIO = TaxaAlvaraSecundario;
                    drLancamento.TX_PENALIDADES = Convert.ToDecimal(lblTaxaPenalidades.Text.Replace("R$ ", ""));
                    drLancamento.TX_PENALIDADES_SECUNDARIO = TaxaPenalidadeSecundario;
                    drLancamento.TX_NUMERACAO_PREDIAL = Convert.ToDecimal(lblTaxaNumPredial.Text.Replace("R$", ""));
                    drLancamento.VALOR_TOTAL = 0;
                    drLancamento.TX_LICENCA_UFM_DESCRICAO = TXlicencaDescricaoUFM;
                    drLancamento.TX_ALVARA_UFM_DESCRICAO = TXalvaraDescricaoUFM;
                    drLancamento.TX_NUMERACAO_PREDIAL_UFM_DESCRICAO = TXnumeracaoPredialDescricaoUFM;
                    drLancamento.TX_PENALIDADES_UFM_DESCRICAO = TXpenalidadeDescricaoUFM;
                    drLancamento.ISS_CONSTRUCAO_UFM_DESCRICAO = ISSconstrucaoDescricaoUFM;
                    drLancamento.ISS_DEMOLICAO_UFM_DESCRICAO = ISSdemolicaoDescricaoUFM;
                    drLancamento.ISS_REFORMA_UFM_DESCRICAO = ISSreformaDescricaoUFM;
                    drLancamento.ISS_ENGENHARIA_UFM_DESCRICAO = ISSengenhariaDescricaoUFM;
                    drLancamento.TX_CONSTRUCAO_UFM_DESCRICAO = TXconstrucaoDescricaoUFM;
                    drLancamento.TX_ALINHAMENTO_UFM_DESCRICAO = TXalinhamentoDescricaoUFM;
                    drLancamento.ID_NOTIFICACAO_LANCAMENTO_AGRAVANTE = -1;
                    //drLancamento.MEDIDA_UTILIZADA = grpAreas.Text;
                }

                CarregarGridLancamentoConstrucao();

                LimparPastaLancamentoConstrucao();

                lblIdLancamento.Text = string.Empty;

            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Erro ao atualizar lançamento.\nVerifique preenchimento dos campos.", "Atenção", ex);
            }
        }

        private void AdicionarUnificacao()
        {
            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_UNIFICACAORow drLancamento = null;

            try
            {
                if (dgvLancamentoConstrucao.Rows.Count == 0)
                {

                    if (lblIdUnificacao.Text == string.Empty)
                    {
                        drLancamento = _dtNotificacaoUnificacao.NewMO_NOTIFICACAO_LANCAMENTO_UNIFICACAORow();

                        drLancamento.INSCRICAO = txtInscricaoUnificacao.Text;
                        drLancamento.AREA_TERRENO = Convert.ToDecimal(txtAreaTerrenoUnificacao.Text);
                        drLancamento.AREA_TERRENO_TESTADO = Convert.ToDecimal(txtTestadaUnificacao.Text);
                        drLancamento.CEP = TXTCEPUNI.Text.Replace("-", "");
                        drLancamento.LOGRADOURO = TXTLOGRADOUROUNI.Text;
                        drLancamento.NUMERO = TXTNUMEROUNI.Text;
                        drLancamento.COMPLEMENTO = TXTCOMPLEMENTOUNI.Text;
                        drLancamento.BAIRRO = TXTBAIRROUNI.Text;
                        drLancamento.QUADRA = TXTQUADRAUNI.Text;
                        drLancamento.LOTE = TXTLOTEUNI.Text;
                        drLancamento.LOTEAMENTO = cbxLOTEAMENTOUNI.Text;
                        drLancamento.CONDOMINIO = cbxCONDOMINIOUNI.Text;
                        drLancamento.UF = TXTUFUNI.Text;
                        drLancamento.CIDADE = TXTCIDADEUNI.Text;

                        DataRow[] dtrAdicionados = _dtNotificacaoUnificacao.Select("ID_NOTIFICACAO_UNIFICACAO < 0");

                        if (dtrAdicionados.Length == 0)
                        {
                            drLancamento.ID_NOTIFICACAO_UNIFICACAO = -1;
                        }
                        else
                        {
                            string index = "0";

                            for (int i = 0; i < dtrAdicionados.OrderByDescending(x => x["ID_NOTIFICACAO_UNIFICACAO"]).Count(); i++)
                            {
                                index = dtrAdicionados[i]["ID_NOTIFICACAO_UNIFICACAO"].ToString();

                                break;
                            }

                            drLancamento.ID_NOTIFICACAO_UNIFICACAO = Convert.ToInt32(index) + (-1);
                        }

                        if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                            drLancamento.ID_NOTIFICACAO = -1;
                        else
                            drLancamento.ID_NOTIFICACAO = Convert.ToInt32(txtID_NOTIFICACAO.Text);

                        _dtNotificacaoUnificacao.AddMO_NOTIFICACAO_LANCAMENTO_UNIFICACAORow(drLancamento);
                    }
                    else
                    {
                        drLancamento = (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_UNIFICACAORow)((DataRowView)mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource.Current).Row;

                        drLancamento.INSCRICAO = txtInscricaoUnificacao.Text;
                        drLancamento.AREA_TERRENO = Convert.ToDecimal(txtAreaTerrenoUnificacao.Text);
                        drLancamento.AREA_TERRENO_TESTADO = Convert.ToDecimal(txtTestadaUnificacao.Text);
                        drLancamento.CEP = TXTCEPUNI.Text.Replace("-", "");
                        drLancamento.LOGRADOURO = TXTLOGRADOUROUNI.Text;
                        drLancamento.NUMERO = TXTNUMEROUNI.Text;
                        drLancamento.COMPLEMENTO = TXTCOMPLEMENTOUNI.Text;
                        drLancamento.BAIRRO = TXTBAIRROUNI.Text;
                        drLancamento.QUADRA = TXTQUADRAUNI.Text;
                        drLancamento.LOTE = TXTLOTEUNI.Text;
                        drLancamento.LOTEAMENTO = cbxLOTEAMENTOUNI.Text;
                        drLancamento.CONDOMINIO = cbxCONDOMINIOUNI.Text;
                        drLancamento.UF = TXTUFUNI.Text;
                        drLancamento.CIDADE = TXTCIDADEUNI.Text;
                    }

                    areaTerreno = Convert.ToDecimal(areaTerreno) + Convert.ToDecimal(txtAreaTerrenoUnificacao.Text);
                    areaTestado += Convert.ToDecimal(txtTestadaUnificacao.Text);

                    txtAREA_TERRENO.Text = areaTerreno.ToString();
                    txtTESTADA_PRINCIPAL.Text = areaTestado.ToString();

                    CarregarGridUnificacao();

                    LimparPastaUnificacao();
                }
                else
                {
                    Mensagem.MsgAlert("Somente é possível lançar uma unificação quando não houver lançamentos adicionados.", "Atenção");
                }
            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Erro ao atualizar lançamento.\nVerifique preenchimento dos campos.", "Atenção", ex);
            }
        }

        private void CarregarGridLancamentoConstrucao()
        {
            dgvLancamentoConstrucao.CellEnter -= dgvLancamentoConstrucao_CellDoubleClick;

            mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.ResetBindings(true);
            mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.DataSource = _dtNotificacaoLancamento;

            dgvLancamentoConstrucao.CellEnter += dgvLancamentoConstrucao_CellDoubleClick;

            if (cbxTipo.Text == "Planta")
            {
                dgvLancamentoConstrucao.DataSource = mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource;
                dgvLancamentoConstrucao.Columns["ID_NOTIFICACAOC"].Visible = false;

                if (_dtNotificacaoLancamento.Rows.Count > 0)
                {
                    var args = new DataGridViewCellEventArgs(0, 0);

                    dgvLancamentoConstrucao_CellDoubleClick(dgvLancamentoConstrucao, args);
                }
                else
                {
                    LimparPastaLancamentoConstrucao();
                    //DesabilitarCampos(false);
                }
            }
            else
            {

            }
        }

        private void LimparPastaLancamentoConstrucao()
        {
            txtAREA_TERRENO.Text = areaTerreno.ToString();
            txtTESTADA_PRINCIPAL.Text = areaTestado.ToString();
            txtAreaConstruir.Text = "0";
            txtAreaDecadConstr.Text = "0";
            txtAreaDecadDemolir.Text = "0";
            txtAreaDemolir.Text = "0";
            txtAreaExistenteLegalConst.Text = "0";
            txtAreaLegalConstr.Text = "0";
            txtAreaLegalDemolir.Text = "0";
            txtAreaLegalReformar.Text = "0";
            txtAreaReformar.Text = "0";
            txtAreaTotal.Text = "0";
            txtUnidades.Text = "1";
            ckbImplantada.Checked = false;
            txtDesmontavelLegalizar.Text = "0";
            txtDesmontavelLegalizado.Text = "0";
            txtNumeroUnidAutonomas.Text = "0";
            txtAreaTerrenoDeduzir.Text = "0";
            txtAreaTerrenoAumentar.Text = "0";
            txtTestadaDeduzir.Text = "0";
            txtTestadaAumentar.Text = "0";
            txtEnquadramento.Text = "0";
            txtEnquadramentoReforma.Text = "0";
            txtEnquadramentoDemolicao.Text = "0";
            txtEnquadramentoPenalidade.Text = "0";
            txtAreaEdicula.Text = "0";
            lblAreaBaseISSEngenharia.Text = "0";
            lblAreaBaseIssConstr.Text = "0";
            lblAreaBaseIssDemol.Text = "0";
            lblAreaBaseIssRefor.Text = "0";
            lblPenalidade.Text = "0";
            lblAreaBaseIssRefor.Text = "0";
            lblBaseISSConstrucao.Text = "0";
            lblBaseISSDemolicao.Text = "0";
            lblBaseISSReforma.Text = "0";
            lblImpostoISSConstrucao.Text = "0";
            lblImpostoISSDemolicao.Text = "0";
            lblImpostoISSReforma.Text = "0";
            lblBaseISSEngenharia.Text = "0";
            lblImpostoSSEngenharia.Text = "0";
            ImpostoISSConstrucaoSecundario = 0;
            ImpostoISSEngenhariaSecundario = 0;
            ImpostoISSDemolicaoSecundario = 0;
            ImpostoISSReformaSecundario = 0;
            TaxaConstrucaoSecundario = 0;
            TaxaReformaSecundario = 0;
            TaxaAlinhamentoSecundario = 0;
            TaxaAlvaraSecundario = 0;
            TaxaPenalidadeSecundario = 0;
            lblTaxaConstrucao.Text = "0";
            lblTaxaLicenca.Text = "0";
            lblTaxaAlinhamento.Text = "0";
            lblTaxaAlvara.Text = "0";
            lblTaxaPenalidades.Text = "0";
            ckbElevador.Checked = false;
            lblIdLancamento.Text = string.Empty;

            ckbImplantada.Visible = true;

            label65.Enabled = true;
            txtDesmontavelLegalizar.Enabled = true;

            label66.Enabled = true;
            txtDesmontavelLegalizado.Enabled = true;

            label89.Enabled = true;
            txtNumeroUnidAutonomas.Enabled = true;

            label91.Enabled = true;
            txtAreaTerrenoDeduzir.Enabled = true;

            label97.Enabled = true;
            txtAreaTerrenoAumentar.Enabled = true;

            label95.Enabled = true;
            txtTestadaDeduzir.Enabled = true;

            label93.Enabled = true;
            txtTestadaAumentar.Enabled = true;

            label87.Enabled = true;
            txtAreaEdicula.Enabled = true;

            label99.Enabled = true;
            txtEnquadramento.Enabled = true;

            label6.Enabled = true;
            txtEnquadramentoReforma.Enabled = true;

            label7.Enabled = true;
            txtEnquadramentoDemolicao.Enabled = true;

            label14.Enabled = true;
            txtEnquadramentoPenalidade.Enabled = true;

            label74.Enabled = true;
            txtAreaConstruir.Enabled = true;

            label70.Enabled = true;
            txtAreaLegalConstr.Enabled = true;

            label76.Enabled = true;
            txtAreaExistenteLegalConst.Enabled = true;

            label75.Enabled = true;
            txtAreaDemolir.Enabled = true;

            label72.Enabled = true;
            txtAreaLegalDemolir.Enabled = true;

            label73.Enabled = true;
            txtAreaReformar.Enabled = true;

            label69.Enabled = true;
            txtAreaLegalReformar.Enabled = true;

            label71.Enabled = true;
            txtAreaDecadConstr.Enabled = true;

            label82.Enabled = true;
            txtAreaDecadDemolir.Enabled = true;

            label63.Enabled = true;
            txtUnidades.Enabled = true;

            ckbElevador.Enabled = true;
            ckbElevador.Visible = true;
            GroupBox4.Enabled = false;
        }

        private void LimparPastaUnificacao()
        {
            lblIdUnificacao.Text = "";
            txtInscricaoUnificacao.Text = string.Empty;
            txtAreaTerrenoUnificacao.Text = string.Empty;
            txtTestadaUnificacao.Text = string.Empty;
            TXTCEPUNI.Text = string.Empty;
            TXTLOGRADOUROUNI.Text = string.Empty;
            TXTNUMEROUNI.Text = string.Empty;
            TXTCOMPLEMENTOUNI.Text = string.Empty;
            TXTBAIRROUNI.Text = string.Empty;
            TXTQUADRAUNI.Text = string.Empty;
            TXTLOTEUNI.Text = string.Empty;
            cbxLOTEAMENTOUNI.SelectedIndex = -1;
            cbxCONDOMINIOUNI.SelectedIndex = -1;
            TXTUFUNI.Text = string.Empty;
            TXTCIDADEUNI.Text = string.Empty;
        }

        private bool ValidacaoAba1()
        {
            bool validado = true;

            #region Validação campos obrigatórios primeira aba

            if (string.IsNullOrEmpty(txtCEP.Text))
            {
                errorProvider.SetError(txtCEP, "Campo obrigatório");
                validado = false;
            }
            if (string.IsNullOrEmpty(txtLOGRADOURO.Text))
            {
                errorProvider.SetError(txtLOGRADOURO, "Campo obrigatório");
                validado = false;
            }
            if (string.IsNullOrEmpty(txtNUMERO.Text))
            {
                errorProvider.SetError(txtNUMERO, "Campo obrigatório");
                validado = false;
            }
            if (string.IsNullOrEmpty(txtBAIRRO.Text))
            {
                errorProvider.SetError(txtBAIRRO, "Campo obrigatório");
                validado = false;
            }
            if (string.IsNullOrEmpty(txtNUMERO_PROCESSO.Text))
            {
                errorProvider.SetError(txtNUMERO_PROCESSO, "Campo obrigatório");
                validado = false;
            }
            if (string.IsNullOrEmpty(cbxUF.Text))
            {
                errorProvider.SetError(cbxUF, "Campo obrigatório");
                validado = false;
            }
            if (string.IsNullOrEmpty(cbxCIDADE.Text))
            {
                errorProvider.SetError(cbxCIDADE, "Campo obrigatório");
                validado = false;
            }
            if (rdbIncidenciaNao.Checked && string.IsNullOrEmpty(txtIncidencia.Text))
            {
                errorProvider.SetError(txtIncidencia, "Campo obrigatório");
                validado = false;
            }
            if (rdbDiferimentoSim.Checked && string.IsNullOrEmpty(txtDiferimento.Text))
            {
                errorProvider.SetError(txtDiferimento, "Campo obrigatório");
                validado = false;
            }

            #endregion

            return validado;
        }

        private bool ValidacaoAba2()
        {
            bool validado = true;

            #region campos obrigatorios sujeição passiva

            if (_dtNotificacaoContribuinte.Rows.Count > 0)
            {
                for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
                {
                    if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted)
                    {
                        if (_dtNotificacaoContribuinte.Rows[i]["QUALIFICACAO"].ToString() == "")
                        {
                            validado = false;
                        }
                    }
                }
            }
            else
            {
                validado = false;
            }

            #endregion        

            return validado;
        }

        private Tuple<bool, string> ValidacaoObrigatoriedadeParcelamento()
        {
            bool validado = true;
            string campoErro = "";
            if (string.IsNullOrEmpty(txtCPFCNPJParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: CPFCNPJ em branco ";
            }
            if (string.IsNullOrEmpty(txtNOME_RAZAOParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: Razão em branco ";
            }
            if (string.IsNullOrEmpty(txtCepRespParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: Responsável em branco ";
            }
            if (string.IsNullOrEmpty(txtLogradouroRespParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: Endereço em branco ";
            }
            if (string.IsNullOrEmpty(txtNumeroRespParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: Número em branco ";
            }
            if (string.IsNullOrEmpty(txtBairroRespParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: Bairro em branco ";
            }
            if (string.IsNullOrEmpty(txtUFParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: UF em branco ";
            }
            if (string.IsNullOrEmpty(txtCidadeParcelamento.Text))
            {
                validado = false;
                campoErro += "Dados Parcelamento: Cidade em branco ";
            }

            var resutado = new Tuple<bool, string>(validado, campoErro);

            return resutado;
        }

        private void VerPessoa(string tipoOperacao)
        {
            Pessoa frm = new Pessoa(txtCPFCNPJ.Text, tipoOperacao);
            frm.ShowDialog();

            DL.Imobiliario.DS.DSCadastro.IM_PESSOARow drPessoa = null;
            DL.Imobiliario.DS.DSCadastro.IM_PESSOA_ENDERECORow drEndereco = null;

            try
            {
                if (tipoOperacao == "E")
                {
                    try
                    {
                        // Pesquisa alterações
                        drPessoa = blPessoa.BuscarCpfCnpj(frm._cpfCnpj);
                        drEndereco = blPessoaEndereco.ListarCpfCnpj(drPessoa.CPFCNPJ)[0];
                    }
                    catch (Biblioteca.Exceptions.LNE)
                    {
                        Mensagem.MsgStop("Problema na localização do CPF/CNPJ.", "Atenção");
                        this.Close();
                    }
                }
                else if (tipoOperacao == "I")
                {
                    try
                    {
                        drPessoa = blPessoa.BuscarCpfCnpj(frm._cpfCnpj);
                        drEndereco = blPessoaEndereco.ListarCpfCnpj(drPessoa.CPFCNPJ)[0];
                    }
                    catch (Biblioteca.Exceptions.LNE) // se nao encontrou nao gravou na tela de pessoa
                    {
                        // Volta situação anterior
                        if (modoTabela == Geral.ModoTabela.MODO_CONSULTA)
                            drPessoa = blPessoa.BuscarCpfCnpj(frm._cpfCnpj);
                        else
                        {
                            try
                            {
                                drPessoa = blPessoa.BuscarCpfCnpj(txtCPFCNPJ.Text); // carrega Pessoa antes da tela de manutenção

                                drEndereco = blPessoaEndereco.ListarCpfCnpj(drPessoa.CPFCNPJ)[0];
                            }
                            catch (Biblioteca.Exceptions.LNE)
                            {
                            }
                            catch (Exception ex)
                            {
                                Mensagem.MsgExcecao(ex.Message, "Atenção", ex.InnerException);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao(ex.Message, "Atenção", ex.InnerException);
            }

            //if (drPessoa != null)
            //{
            //    CarregarCamposProprietarioPessoa(drPessoa);
            //    CarregarCamposProprietarioPessoaEndereco(drEndereco);
            //}
        }

        private void BuscarPessoa()
        {
            if (txtCPFCNPJ.Text != string.Empty)
            {
                DL.Imobiliario.DS.DSCadastro.IM_PESSOARow drPessoa = null;
                DL.Imobiliario.DS.DSCadastro.IM_PESSOA_ENDERECODataTable dtEndereco = null;

                try
                {
                    drPessoa = blPessoa.BuscarCpfCnpj(txtCPFCNPJ.Text);
                    dtEndereco = blPessoaEndereco.ListarCpfCnpj(txtCPFCNPJ.Text);

                    txtNOME_RAZAO.Text = drPessoa.NOME_RAZAO.TrimEnd();

                    if (dtEndereco.Count > 0)
                    {
                        DL.Imobiliario.DS.DSCadastro.IM_PESSOA_ENDERECORow drEndereco = dtEndereco[0];

                        txtLogradouroResp.Text = drEndereco.LOGRADOURO;
                        txtBairroResp.Text = drEndereco.BAIRRO;
                        txtNumeroResp.Text = drEndereco.NUMERO;
                        txtCepResp.Text = drEndereco.CEP;
                        txtComplResp.Text = drEndereco.COMPLEMENTO;
                        cbxUFResp.SelectedValue = drEndereco.ESTADO;
                        cbxCidadeResp.SelectedValue = drEndereco.CIDADE;
                    }

                }
                catch (Biblioteca.Exceptions.LNE)
                {
                    if (!Validacao.ValidaCpfCnpj(txtCPFCNPJ.Text))
                    {
                        Mensagem.MsgAlert("CPF/CNPJ não é válido.", "Atenção");

                        txtCPFCNPJ.Text = "";
                        txtCPFCNPJ.Focus();
                    }
                    else
                    {
                        Mensagem.MsgAlert("CPF/CNPJ não cadastrado. Por favor realize o cadastro para continuar.", "Cadastramento de CPF/CNPJ");

                        //if (Permissao.VerAcesso(EnumDLL.Permissao.MO_Pessoa_Incluir))
                        //{
                        VerPessoa("I");
                        txtCPFCNPJ.Focus();
                        //}
                        //else
                        //{
                        //    Mensagem.MsgAlert("Você não possui permissão para cadastrar.", "Cadastramento de CPF/CNPJ");

                        //    txtCPFCNPJ.Focus();
                        //}

                    }
                }
                catch (Exception)
                {

                }
            }

        }

        private void CarregarDadosParcela()
        {
            try
            {
                decimal valorTotal = 0;
                txtExpedienteAnterior.Text = "";
                lblExpedienteAnterior.Visible = false;
                txtExpedienteAnterior.Visible = false;

                if (status == "A")
                {
                    btnOpcoesParcelamento.Enabled = false;
                    txtCodParcelamento.Visible = false;
                    lblCodParcelamento.Visible = false;
                    //pcbData.Visible = false;
                    txtCPFProcurador.Enabled = true;
                    txtProcurador.Enabled = true;
                    txtAssuntoParcelamento.Enabled = true;
                    txtQtdeParcela.Enabled = true;
                    txtParcCancelado.Visible = false;
                    txtParcCancelado.Text = "";
                    txtCPFCNPJParcelamento.Text = "";
                    txtNOME_RAZAOParcelamento.Text = "";
                    txtResponsavelParcelamento.Text = "";
                    txtCPFResponsavelParcelamento.Text = "";
                    txtCidadeParcelamento.Text = "";
                    txtBairroRespParcelamento.Text = "";
                    txtComplRespParcelamento.Text = "";
                    txtLogradouroRespParcelamento.Text = "";
                    txtNumeroRespParcelamento.Text = "";
                    txtUFParcelamento.Text = "";
                    txtCepRespParcelamento.Text = "";
                    txtCodParcelamento.Text = "";

                    //PARA VERIFICAÇÃO SE É O REGISTRO PRINCIPAL
                    for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
                    {
                        if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted)
                        {
                            if (_dtNotificacaoContribuinte.Rows[i]["PRINCIPAL"].ToString() == "True")
                            {
                                txtCPFCNPJParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["CPFCNPJ"].ToString();
                                txtNOME_RAZAOParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["NOME_RAZAO"].ToString();
                                txtResponsavelParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["RESPONSAVEL"].ToString();
                                txtCPFResponsavelParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["CPF_RESPONSAVEL"].ToString();
                                txtCidadeParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["CIDADE"].ToString();
                                txtBairroRespParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["BAIRRO"].ToString();
                                txtComplRespParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["COMPLEMENTO"].ToString();
                                txtLogradouroRespParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["LOGRADOURO"].ToString();
                                txtNumeroRespParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["NUMERO"].ToString();
                                txtUFParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["UF"].ToString();
                                txtCepRespParcelamento.Text = _dtNotificacaoContribuinte.Rows[i]["CEP"].ToString();
                            }
                        }
                    }

                    if (_drNotificacao != null)
                    {
                        if (modoTabela == Geral.ModoTabela.MODO_CONSULTA || modoTabela == Geral.ModoTabela.MODO_PESQUISA)
                        {//listagem das parcelas ainda no modo temporario, pois a notificação ainda está em abert0.
                            _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                            if (_dtNotificacaoParcelamento.Rows.Count > 0)
                            {
                                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                                txtVencimento.Text = dtr.DATA_VENCIMENTO.ToShortDateString();
                                //txtExigibilidade.Text = dtr.DATA_ELEGIBILIDADE.ToShortDateString();
                                //txtCiencia.Text = dtr.DATA_CIENCIA.ToShortDateString();
                                txtProcurador.Text = dtr.PROCURADOR.ToString();
                                txtCPFProcurador.Text = dtr.PROCURADOR_CPF.ToString();
                                txtQtdeParcela.Text = dtr.PARCELAS.ToString();
                                txtExpediente.Text = dtr.EXPEDIENTE.ToString();
                                txtCodParcelamento.Text = dtr.ID_NOTIFICACAO_PARCELAMENTO.ToString();
                                txtAssuntoParcelamento.Text = dtr.ASSUNTO.ToString();
                                txtQtdeParcela.Text = dtr.PARCELAS.ToString();
                                txtValor.Text = dtr.VALOR_BRUTO.ToString();
                                txtDescontoPenalidade.Text = dtr.DESCONTO_PENALIDADE.ToString();
                                txtTotalDevido.Text = dtr.SUBTOTAL.ToString();
                                txtJurosCompensatorios.Text = dtr.JUROS_COMPENSATORIO.ToString();
                                txtExpediente.Text = dtr.EXPEDIENTE.ToString();
                                txtValorTotal.Text = dtr.TOTAL.ToString();
                                txtValorParcela.Text = dtr.VALOR_PARCELA.ToString();
                                txtJuros.Text = dtr.JUROS.ToString();
                                txtMulta.Text = dtr.MULTA.ToString();
                                txtCorrecao.Text = dtr.CORRECAO.ToString();

                                _dtNotificacaoParcela = blNotificacao.ObterParcela(dtr.ID_NOTIFICACAO_PARCELAMENTO);
                                _dtNotificacaoParcelamentoComplemento = blNotificacao.ObterParcelamentoComplemento(dtr.ID_NOTIFICACAO_PARCELAMENTO);

                                CarregarGridParcela();
                            }
                        }
                    }
                }
                else if (status == "F" || status == "C")
                {
                    txtCPFProcurador.Enabled = false;
                    txtProcurador.Enabled = false;
                    txtAssuntoParcelamento.Enabled = false;

                    _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                    if (_dtNotificacaoParcelamento.Rows.Count > 0)
                    {
                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                        if (dtr == null)
                        {
                            dtr = _dtNotificacaoParcelamento.OrderByDescending(x => x.ID_NOTIFICACAO_PARCELAMENTO).First();
                        }

                        txtQtdeParcela.Enabled = false;
                        txtCodParcelamento.Visible = true;
                        lblCodParcelamento.Visible = true;

                        txtCPFCNPJParcelamento.Text = dtr.CPF.ToString();
                        txtNOME_RAZAOParcelamento.Text = dtr.NOME.ToString();
                        txtResponsavelParcelamento.Text = dtr.RESPONSAVEL.ToString();
                        txtCPFResponsavelParcelamento.Text = dtr.RESPONSAVEL_CPF.ToString();
                        txtCidadeParcelamento.Text = dtr.CIDADE.ToString();
                        txtBairroRespParcelamento.Text = dtr.BAIRRO.ToString();
                        txtComplRespParcelamento.Text = dtr.COMPLEMENTO.ToString();
                        txtLogradouroRespParcelamento.Text = dtr.LOGRADOURO.ToString();
                        txtNumeroRespParcelamento.Text = dtr.NUMERO.ToString();
                        txtUFParcelamento.Text = dtr.UF.ToString();
                        txtCepRespParcelamento.Text = CEP.ToString();
                        txtAssuntoParcelamento.Text = dtr.ASSUNTO.ToString();
                        txtCodParcelamento.Text = dtr.ID_NOTIFICACAO_PARCELAMENTO.ToString();
                        txtQtdeParcela.Text = dtr.PARCELAS.ToString();
                        txtValor.Text = dtr.VALOR_BRUTO.ToString();
                        txtDescontoPenalidade.Text = dtr.DESCONTO_PENALIDADE.ToString();
                        txtTotalDevido.Text = dtr.SUBTOTAL.ToString();
                        txtJurosCompensatorios.Text = dtr.JUROS_COMPENSATORIO.ToString();
                        txtExpediente.Text = dtr.EXPEDIENTE.ToString();
                        txtValorTotal.Text = dtr.TOTAL.ToString();
                        txtValorParcela.Text = dtr.VALOR_PARCELA.ToString();
                        //txtExigibilidade.Text = dtr.DATA_ELEGIBILIDADE.ToShortDateString();
                        //txtCiencia.Text = dtr.DATA_CIENCIA.ToShortDateString();
                        txtVencimento.Text = dtr.DATA_VENCIMENTO.ToShortDateString();
                        txtProcurador.Text = dtr.PROCURADOR.ToString();
                        txtCPFProcurador.Text = dtr.PROCURADOR_CPF.ToString();
                        txtJuros.Text = dtr.JUROS.ToString();
                        txtMulta.Text = dtr.MULTA.ToString();
                        txtCorrecao.Text = dtr.CORRECAO.ToString();
                        txtParcCancelado.Visible = false;
                        txtParcCancelado.Text = "";

                        if (dtr.ATIVO == false)
                        {
                            txtParcCancelado.Visible = true;
                            txtParcCancelado.Text = "CANCELADO: " + dtr.CANCELAMENTO_MOTIVO.ToUpper() + Environment.NewLine + "PROCESSO:" + dtr.CANCELAMENTO_PROCESSO.ToUpper() + "/" + dtr.CANCELAMENTO_PROCESSO_ANO + Environment.NewLine + "DATA: " + dtr.CANCELAMENTO_DATA;
                            tsmCalcular.Visible = true;
                            mnuCarne.Visible = false;
                            mnutermoConfissao.Visible = false;
                        }
                        else
                        {
                            tsmCalcular.Visible = false;
                            txtParcCancelado.Visible = false;
                            txtParcCancelado.Text = "";

                            if (dtr.SUSPENSO)
                            {
                                txtParcCancelado.Visible = true;
                                txtParcCancelado.Text = "SUSPENDIDO: " + dtr.SUSPENSO_MOTIVO.ToUpper() + Environment.NewLine + "PROCESSO:" + dtr.SUSPENSO_PROCESSO.ToUpper() + Environment.NewLine + "DATA: " + dtr.SUSPENSO_DATA;

                                btnOpcoesParcelamento.Enabled = false;
                                //pcbData.Visible = false;
                            }
                        }

                        _dtNotificacaoParcela = blNotificacao.ObterParcela(dtr.ID_NOTIFICACAO_PARCELAMENTO);

                        mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource.DataSource = _dtNotificacaoParcelamento.Select("ATIVO = 'False'");

                        dgvParcelamentoAnterior.DataSource = mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource;

                        _dtNotificacaoParcelamentoComplemento = blNotificacao.ObterParcelamentoComplemento(dtr.ID_NOTIFICACAO_PARCELAMENTO);

                        txtExpedienteAnterior.Text = _dtNotificacaoParcelamentoComplemento.Where(x => x.TRIBUTO == "24").OrderByDescending(x => x.ID_NOTIFICACACAO_PARCELAMENTO_ATUALIZADO).Sum(x => x.TOTAL).ToString();
                        txtExpedienteAnterior.Text = (Convert.ToDecimal(txtExpedienteAnterior.Text) - Convert.ToDecimal(txtExpediente.Text)).ToString();

                        if (!string.IsNullOrEmpty(txtExpedienteAnterior.Text) && Convert.ToDecimal(txtExpedienteAnterior.Text) > 0)
                        {
                            lblExpedienteAnterior.Visible = true;
                            txtExpedienteAnterior.Visible = true;
                        }

                        CarregarGridParcela();

                    }
                }
                else if (status == "R")
                {
                    _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                    if (_dtNotificacaoParcelamento.Rows.Count > 0)
                    {
                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.OrderByDescending(x => x.ID_NOTIFICACAO_PARCELAMENTO).First();

                        decimal expediente = 0;
                        decimal penalidade = 0;
                        decimal valor = 0;

                        txtCPFCNPJParcelamento.Text = dtr.CPF.ToString();
                        txtNOME_RAZAOParcelamento.Text = dtr.NOME.ToString();
                        txtResponsavelParcelamento.Text = dtr.RESPONSAVEL.ToString();
                        txtCPFResponsavelParcelamento.Text = dtr.RESPONSAVEL_CPF.ToString();
                        txtCidadeParcelamento.Text = dtr.CIDADE.ToString();
                        txtBairroRespParcelamento.Text = dtr.BAIRRO.ToString();
                        txtComplRespParcelamento.Text = dtr.COMPLEMENTO.ToString();
                        txtLogradouroRespParcelamento.Text = dtr.LOGRADOURO.ToString();
                        txtNumeroRespParcelamento.Text = dtr.NUMERO.ToString();
                        txtUFParcelamento.Text = dtr.UF.ToString();
                        txtCepRespParcelamento.Text = CEP.ToString();
                        txtAssuntoParcelamento.Text = dtr.ASSUNTO.ToString();
                        txtProcurador.Text = dtr.PROCURADOR.ToString();
                        txtCPFProcurador.Text = dtr.PROCURADOR_CPF.ToString();
                        //txtExigibilidade.Text = dtr.DATA_ELEGIBILIDADE.ToShortDateString();
                        txtVencimento.Text = dtr.DATA_VENCIMENTO.ToShortDateString();
                        txtCiencia.Text = dtr.DATA_CIENCIA.ToShortDateString();
                        txtQtdeParcela.Text = "1";
                        txtTotalDevido.Text = "0";
                        txtJurosCompensatorios.Text = "0";
                        txtJuros.Text = "0";
                        txtMulta.Text = "0";
                        txtCorrecao.Text = "0";
                        txtDescontoPenalidade.Text = "0";

                        txtCodParcelamento.Visible = false;
                        lblCodParcelamento.Visible = false;
                        _dtNotificacaoParcelamentoAtualizado = blNotificacao.ObterParcelamentoAtualizado(_drNotificacao.ID_NOTIFICACAO);

                        foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow dtrAtualizado in _dtNotificacaoParcelamentoAtualizado.Where(x => x.TRIBUTO != "24"))
                        {
                            switch (dtrAtualizado.TRIBUTO)
                            {
                                case "11":
                                    valor += dtrAtualizado.VALOR_UFM;
                                    penalidadeReparcelamento = dtrAtualizado.VALOR_UFM;
                                    break;
                                default:
                                    valor += dtrAtualizado.VALOR_UFM;
                                    break;
                            }
                        }


                        UFV objUFV = new UFV();

                        DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(Convert.ToDateTime(txtVencimento.Text));

                        //txtValor.Text = (valor * drUFV.VALOR).ToString("D2");
                        txtValor.Text = (valor * drUFV.VALOR).ToString();
                        penalidadeReparcelamento = (penalidadeReparcelamento * drUFV.VALOR);

                        this.CalcularExpedienteAnterior();

                        mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource.DataSource = null;
                        dgvParcelamantoComplemento.DataSource = null;

                        txtQtdeParcela_Validating(null, null);

                        CarregarGridParcela();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void CalcularParcelamento()
        {
            try
            {
                drParametro = blTbParametro.BuscarAno(DateTime.Now.Year);

                decimal valorTotal = 0;
                decimal issConstrucao = 0;
                decimal issDemolicao = 0;
                decimal issReforma = 0;
                decimal issEngenharia = 0;
                decimal licencaConstrucao = 0;
                decimal licencaReformaDemo = 0;
                decimal alinhamento = 0;
                decimal alvara = 0;
                decimal penalidade = 0;
                decimal expediente = 0;
                decimal numeracaopredial = 0;

                int totalParcela = 1;
                bool construcaoCobrado = false;
                bool implantacaoCobrado = false;
                bool desmenbramentoCobrado = false;
                bool unificacaoCobrado = false;
                //alinhamento é cobrado uma unica vez
                //alvara cobrado uma vez por tipo de lancamento

                if (status != "R")
                {
                    //CARREGAR OS VALORES DO LANÇAMENTO
                    
                    foreach (DataRow drLancamento in _dtNotificacaoLancamento.Rows)
                    {
                        #region Taxas

                        alvara = 0;

                        if (alinhamento == 0)
                        {
                            alinhamento = Convert.ToDecimal(drLancamento["TX_ALINHAMENTO"]);
                        }
                        else
                        {
                            alinhamento = 0;
                        }

                        if (drLancamento["TIPO"].ToString() == "CONSTRUÇÃO/REFORMA/DEMOLIÇÃO" && construcaoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            construcaoCobrado = true;
                        }
                        else if (drLancamento["TIPO"].ToString() == "IMPLANTAÇÃO" && implantacaoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            implantacaoCobrado = true;
                        }
                        else if (drLancamento["TIPO"].ToString() == "DESMEMBRAMENTO" && desmenbramentoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            desmenbramentoCobrado = true;
                        }
                        else if (drLancamento["TIPO"].ToString() == "UNIFICAÇÃO" && unificacaoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            unificacaoCobrado = true;
                        }
                        numeracaopredial = Convert.ToDecimal(drLancamento["TX_NUMERACAO_PREDIAL"]);
                        if (numeracaopredial != 0)
                        {
                            ckbNumeracaoPredial.Checked = true;
                        }

                        issConstrucao += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_CONSTRUCAO"]);
                        issDemolicao += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_DEMOLICAO"]);
                        issReforma += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_REFORMA"]);
                        issEngenharia += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_ENGENHARIA"]);
                        licencaConstrucao += Convert.ToDecimal(drLancamento["TX_LICENCA_CONSTRUCAO"]);
                        licencaReformaDemo += Convert.ToDecimal(drLancamento["TX_LICENCA_REFORMA_DEMOLICAO"]);
                        penalidade += Convert.ToDecimal(drLancamento["TX_PENALIDADES"]);

                        valorTotal += issConstrucao + issDemolicao + issReforma + issEngenharia + licencaConstrucao + licencaReformaDemo + alinhamento + alvara + penalidade + numeracaopredial;

                        #endregion
                    }
                    if (_dtNotificacaoLancamento.Count > 0)
                    {
                        valorTotal = _dtNotificacaoLancamento.Sum(x => x.IMPOSTO_ISS_CONSTRUCAO) +
                                     _dtNotificacaoLancamento.Sum(x => x.IMPOSTO_ISS_DEMOLICAO) +
                                     _dtNotificacaoLancamento.Sum(x => x.IMPOSTO_ISS_REFORMA) +
                                     _dtNotificacaoLancamento.Sum(x => x.IMPOSTO_ISS_ENGENHARIA) +
                                     _dtNotificacaoLancamento.Sum(x => x.TX_LICENCA_CONSTRUCAO) +
                                     _dtNotificacaoLancamento.Sum(x => x.TX_LICENCA_REFORMA_DEMOLICAO) +
                                     _dtNotificacaoLancamento.Max(x => x.TX_ALINHAMENTO) +
                                     _dtNotificacaoLancamento.Max(x => x.TX_ALVARA) +
                                     _dtNotificacaoLancamento.Max(x => x.TX_PENALIDADES) +
                                     _dtNotificacaoLancamento.Max(x => x.TX_NUMERACAO_PREDIAL);

                        txtValor.Text = valorTotal.ToString("N2");
                        txtJurosCompensatorios.Text = "0";
                    }
                }
                else
                {
                    valorTotal = Convert.ToDecimal(txtValor.Text);
                    penalidade = penalidadeReparcelamento;
                }

                if (valorTotal > 0)
                {
                    if (Convert.ToDateTime(txtVencimento.Text) > Convert.ToDateTime(txtExigibilidade.Text))
                    {
                        txtDescontoPenalidade.Text = "0";
                        lblDescontoPenalidade.Text = "Penalidade:";
                    }
                    else
                    {
                        if ((Convert.ToInt32(txtQtdeParcela.Text) == 99 ? 1 : Convert.ToInt32(txtQtdeParcela.Text)) > 1 && penalidade > 0)
                        {
                            txtDescontoPenalidade.Text = ((0.20M * penalidade)).ToString("N2");

                            if (Convert.ToInt32(txtQtdeParcela.Text) > 12)
                            {
                                totalParcela = Convert.ToInt32(txtQtdeParcela.Text) - 12;

                            }

                            lblDescontoPenalidade.Text = "Penalidade -20%:";
                        }
                        else if (penalidade > 0)
                        {
                            txtDescontoPenalidade.Text = ((0.40M * penalidade)).ToString("N2");
                            lblDescontoPenalidade.Text = "Penalidade -40%:";
                        }
                    }
                }
                else
                {
                    txtValor.Text = "0";
                    txtTotalDevido.Text = "0";
                    txtJurosCompensatorios.Text = "0";
                    txtValorTotal.Text = "0";
                    txtValorParcela.Text = "0";
                    txtJuros.Text = "0";
                    txtMulta.Text = "0";
                    txtCorrecao.Text = "0";
                }

                if (valorTotal > 0)
                {
                    UFV objUFV = new UFV();

                    DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(Convert.ToDateTime(txtExigibilidade.Text));

                    txtExpedienteAnterior.Text = txtExpedienteAnterior.Text == "" ? "0" : txtExpedienteAnterior.Text;

                    txtTotalDevido.Text = (valorTotal - Convert.ToDecimal(txtDescontoPenalidade.Text)).ToString("N2");

                    Geral.ValorCorrecao valorCalculado;

                    expediente = Convert.ToDecimal(txtExpedienteAnterior.Text);

                    decimal valorConvertido = (Convert.ToDecimal(txtTotalDevido.Text)) / drUFV.VALOR;

                    try
                    {
                        valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                        //txtJuros.Text = valorCalculado.Juros.ToString();
                        //txtMulta.Text = valorCalculado.Multa.ToString();
                        //txtCorrecao.Text = valorCalculado.Correcao.ToString();

                        txtJuros.Text = (Convert.ToDecimal(txtJuros.Text) + valorCalculado.Juros).ToString("N2");
                        txtMulta.Text = (Convert.ToDecimal(txtMulta.Text) + valorCalculado.Multa).ToString("N2");
                        txtCorrecao.Text = (Convert.ToDecimal(txtCorrecao.Text) + valorCalculado.Correcao).ToString("N2");

                        valorTotal = valorCalculado.Principal + Convert.ToDecimal(txtJuros.Text) + Convert.ToDecimal(txtMulta.Text) + Convert.ToDecimal(txtCorrecao.Text) + expediente;

                        txtJurosCompensatorios.Text = blTbParametro.CalcularJurosCompensatorios(Convert.ToDateTime(txtExigibilidade.Text), valorTotal, Convert.ToInt32(txtQtdeParcela.Text)).ToString("N2");

                        valorTotal = valorTotal + Convert.ToDecimal(txtJurosCompensatorios.Text);

                        txtValorTotal.Text = (valorTotal + Convert.ToDecimal(txtExpediente.Text)).ToString("N2");
                        txtValorParcela.Text = ((valorTotal + Convert.ToDecimal(txtExpediente.Text)) / (Convert.ToInt32(txtQtdeParcela.Text) == 99 ? 1 : Convert.ToInt32(txtQtdeParcela.Text))).ToString("N2");

                        if (tbcCadastro.SelectedTab == tbpParcelamento)
                        {
                            if (Convert.ToDecimal(txtValor.Text) > 0)
                            {
                                decimal parcelaMinima = drParametro.PARCELA_MINIMA * drUFV.VALOR;

                                if (Convert.ToDecimal(txtValorParcela.Text) < parcelaMinima && Convert.ToInt32(txtQtdeParcela.Text) > 1)
                                {
                                    Mensagem.MsgAlert("Valor da parcela inferior ao minimo legal.");
                                    txtQtdeParcela.Focus();
                                    txtQtdeParcela.Select();
                                }
                            }
                        }
                    }
                    catch (Exception)
                    {
                        Mensagem.MsgAlert("Unidade fiscal não cadastrada.");
                    }
                }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Verifique a data de vencimento senão está muito longa.");
            }
        }

        private void IncluirParcelamento()
        {
            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow _drParcelamento;
            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_COMPLEMENTORow _drParcelamentoComplemento = _dtNotificacaoParcelamentoComplemento.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_COMPLEMENTORow();
            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

            try
            {
                _dtNotificacaoParcela.Clear();
                _dtNotificacaoParcelamentoAtualizado.Clear();
                _dtNotificacaoParcelaDetalhe.Clear();
                _dtNotificacaoParcelamentoComplemento.Clear();

                if (status == "R")
                {
                    _drParcelamento = _dtNotificacaoParcelamento.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow();
                }
                else
                {
                    _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                    if (_dtNotificacaoParcelamento.Rows.Count > 0)
                    {
                        _drParcelamento = _dtNotificacaoParcelamento.Where(x => x.ID_NOTIFICACAO == _drNotificacao.ID_NOTIFICACAO).FirstOrDefault();
                    }
                    else
                    {
                        _drParcelamento = _dtNotificacaoParcelamento.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow();
                    }
                }

                _drParcelamento.ASSUNTO = txtAssuntoParcelamento.Text;
                _drParcelamento.BAIRRO = txtBairroRespParcelamento.Text;
                _drParcelamento.CEP = txtCepRespParcelamento.Text;
                _drParcelamento.CIDADE = txtCidadeParcelamento.Text;
                _drParcelamento.COMPLEMENTO = txtComplRespParcelamento.Text;
                _drParcelamento.CPF = txtCPFCNPJParcelamento.Text;
                _drParcelamento.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                _drParcelamento.LOGRADOURO = txtLogradouroRespParcelamento.Text;
                _drParcelamento.NOME = txtNOME_RAZAOParcelamento.Text;
                _drParcelamento.NOTIFICACAO = txtNUMERO_NOTIFICACAO.Text + "/" + txtANO_NOTIFICACAO.Text;
                _drParcelamento.PROCURADOR = txtProcurador.Text;
                _drParcelamento.PROCURADOR_CPF = txtCPFProcurador.Text;
                _drParcelamento.RESPONSAVEL = txtResponsavelParcelamento.Text;
                _drParcelamento.RESPONSAVEL_CPF = txtCPFResponsavelParcelamento.Text;
                _drParcelamento.UF = txtUFParcelamento.Text;
                _drParcelamento.NUMERO = txtNumeroRespParcelamento.Text;
                _drParcelamento.ATIVO = true;
                _drParcelamento.PARCELAS = Convert.ToInt32(txtQtdeParcela.Text);
                _drParcelamento.VALOR_BRUTO = Convert.ToDecimal(txtValor.Text);
                _drParcelamento.DESCONTO_PENALIDADE = Convert.ToDecimal(txtDescontoPenalidade.Text);
                _drParcelamento.SUBTOTAL = Convert.ToDecimal(txtTotalDevido.Text);
                _drParcelamento.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text);
                _drParcelamento.EXPEDIENTE = Convert.ToDecimal(txtExpediente.Text);
                _drParcelamento.TOTAL = Convert.ToDecimal(txtValorTotal.Text);
                _drParcelamento.VALOR_PARCELA = Convert.ToDecimal(txtValorParcela.Text);
                _drParcelamento.MULTA = Convert.ToDecimal(txtMulta.Text);
                _drParcelamento.JUROS = Convert.ToDecimal(txtJuros.Text);
                _drParcelamento.CORRECAO = Convert.ToDecimal(txtCorrecao.Text);
                _drParcelamento.SUSPENSO = false;
                _drParcelamento.DATA_CRIACAO = DateTime.Now;
                _drParcelamento.DATA_ELEGIBILIDADE = Convert.ToDateTime(txtExigibilidade.Text);
                _drParcelamento.DATA_VENCIMENTO = Convert.ToDateTime(txtVencimento.Text);
                _drParcelamento.DATA_CIENCIA = Convert.ToDateTime(txtVencimento.Text).AddDays(2);

                if (_dtNotificacaoParcelamento.Rows.Count == 0 || status == "R")
                {
                    _drParcelamento.ID_NOTIFICACAO_PARCELAMENTO = -1;
                    _dtNotificacaoParcelamento.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow(_drParcelamento);
                }

                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow _drParcela;
                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow _drParcelaDetalhe;

                UFV objUFV = new UFV();

                DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(Convert.ToDateTime(txtExigibilidade.Text));

                decimal valorTabela = drUFV.VALOR;

                decimal issConstrucao = 0;
                decimal issDemolicao = 0;
                decimal issReforma = 0;
                decimal issEngenharia = 0;
                decimal licencaConstrucao = 0;
                decimal licencaReformaDemo = 0;
                decimal alinhamento = 0;
                decimal alvara = 0;
                decimal numerocaopredial = 0;
                decimal penalidade = 0;
                decimal expedienteAnterior = 0;
                bool construcaoCobrado = false;
                bool implantacaoCobrado = false;
                bool desmenbramentoCobrado = false;
                bool unificacaoCobrado = false;
                int qtdeParcela = Convert.ToInt32(txtQtdeParcela.Text);
                //alinhamento é cobrado uma unica vez
                //alvara cobrado uma vez por tipo de lancamento


                if (status != "R")
                {
                    foreach (DataRow drLancamento in _dtNotificacaoLancamento.Rows)
                    {
                        if (alinhamento == 0)
                        {
                            alinhamento = Convert.ToDecimal(drLancamento["TX_ALINHAMENTO"]);
                        }

                        if (drLancamento["TIPO"].ToString() == "CONSTRUÇÃO/REFORMA/DEMOLIÇÃO" && construcaoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            construcaoCobrado = true;
                        }
                        else if (drLancamento["TIPO"].ToString() == "IMPLANTAÇÃO" && implantacaoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            implantacaoCobrado = true;
                        }
                        else if (drLancamento["TIPO"].ToString() == "DESMEMBRAMENTO" && desmenbramentoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            desmenbramentoCobrado = true;
                        }
                        else if (drLancamento["TIPO"].ToString() == "UNIFICAÇÃO" && unificacaoCobrado == false)
                        {
                            alvara += Convert.ToDecimal(drLancamento["TX_ALVARA"]);

                            unificacaoCobrado = true;
                        }
                        if(ckbNumeracaoPredial.Checked & numerocaopredial <=0)
                        {
                            numerocaopredial = Convert.ToDecimal(drLancamento["TX_NUMERACAO_PREDIAL"]);
                        }
                        issConstrucao += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_CONSTRUCAO"]);
                        issDemolicao += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_DEMOLICAO"]);
                        issReforma += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_REFORMA"]);
                        issEngenharia += Convert.ToDecimal(drLancamento["IMPOSTO_ISS_ENGENHARIA"]);
                        licencaConstrucao += Convert.ToDecimal(drLancamento["TX_LICENCA_CONSTRUCAO"]);
                        licencaReformaDemo += Convert.ToDecimal(drLancamento["TX_LICENCA_REFORMA_DEMOLICAO"]);
                        penalidade += Convert.ToDecimal(drLancamento["TX_PENALIDADES"]);
                    }

                    #region INCLUSAO DOS VALORES ATUALIZADOS.

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -1;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "01";
                    _drParcelamentoAtualizado.VALOR = (issConstrucao + issDemolicao + issReforma + issEngenharia);
                    _drParcelamentoAtualizado.VALOR_UFM = (issConstrucao + issDemolicao + issReforma + issEngenharia) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -2;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "07";
                    _drParcelamentoAtualizado.VALOR = (licencaConstrucao + licencaReformaDemo);
                    _drParcelamentoAtualizado.VALOR_UFM = (licencaConstrucao + licencaReformaDemo) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -3;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "13";
                    _drParcelamentoAtualizado.VALOR = (alinhamento);
                    _drParcelamentoAtualizado.VALOR_UFM = (alinhamento) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -4;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "09";
                    _drParcelamentoAtualizado.VALOR = (alvara);
                    _drParcelamentoAtualizado.VALOR_UFM = (alvara) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -5;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "11";
                    _drParcelamentoAtualizado.VALOR = (penalidade);
                    _drParcelamentoAtualizado.VALOR_UFM = (penalidade) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = Convert.ToDecimal(txtDescontoPenalidade.Text) / valorTabela;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -6;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "24";
                    _drParcelamentoAtualizado.VALOR = (Convert.ToDecimal(txtExpediente.Text));
                    _drParcelamentoAtualizado.VALOR_UFM = (Convert.ToDecimal(txtExpediente.Text)) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);

                    _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                    _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -7;
                    _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                    _drParcelamentoAtualizado.TRIBUTO = "33";
                    _drParcelamentoAtualizado.VALOR = (numerocaopredial);
                    _drParcelamentoAtualizado.VALOR_UFM = (numerocaopredial) / valorTabela;
                    _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                    _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);

                    _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);
                    #endregion
                }

                if (status != "R")
                {
                    //processo para calcular como parcela unica para aplicar o desconto na penalidade, após a inclusão da parcela unica o sistema prossegue com as demais parcelas.
                    txtQtdeParcela.Text = "1";

                    //carrega os dados e aplica o desconto.
                    CalcularExpedienteAnterior();
                    CalcularParcelamento();

                    //volta a quantidade de parcela selecionado pelo usuário
                    txtQtdeParcela.Text = qtdeParcela.ToString();

                    //para incluir a parcela unica
                    qtdeParcela = 99;

                    txtExpedienteAnterior.Text = txtExpedienteAnterior.Text == "" ? "0" : txtExpedienteAnterior.Text;
                }
                else
                {
                    //processo para calcular como parcela unica para aplicar o desconto na penalidade, após a inclusão da parcela unica o sistema prossegue com as demais parcelas.
                    txtQtdeParcela.Text = "1";

                    //carrega os dados e aplica o desconto.
                    CalcularExpedienteAnterior();
                    CalcularParcelamento();

                    //volta a quantidade de parcela selecionado pelo usuário
                    txtQtdeParcela.Text = qtdeParcela.ToString();

                    //para incluir a parcela unica
                    qtdeParcela = 99;

                    //txtExpedienteAnterior.Text = txtExpedienteAnterior.Text == "" ? "0" : txtExpedienteAnterior.Text;
                }

            parcelamento:
                if (qtdeParcela > 1 || status == "R")
                {
                    Geral.ValorCorrecao valorCalculado;

                    decimal valorConvertido = 0;

                    for (int i = 1; i <= qtdeParcela; i++)
                    {
                        //SE FOR REPARCELAMENTO NÃO PODE CALCULAR MULTA E JUROS NO EXPEDIENTE ATUAL.
                        //if (status == "R")                        
                        //    valorConvertido = Convert.ToDecimal(txtTotalDevido.Text) / drUFV.VALOR;                        
                        //else                        
                        //    valorConvertido = (Convert.ToDecimal(txtTotalDevido.Text) + Convert.ToDecimal(txtExpediente.Text)) / drUFV.VALOR;                        

                        //valorConvertido = (valorConvertido) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                        //valorCalculado = BL.Shared.Utilitario.Geral.CorrigirValor(Math.Round(valorConvertido,4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                        //decimal valorParcela = valorCalculado.Principal;

                        decimal valorParcela = Convert.ToDecimal(txtTotalDevido.Text);

                        if (status == "R")
                            valorParcela = (valorParcela + Convert.ToDecimal(txtJurosCompensatorios.Text) + Convert.ToDecimal(txtExpedienteAnterior.Text) + Convert.ToDecimal(txtExpediente.Text)) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                        else
                            valorParcela = (valorParcela + Convert.ToDecimal(txtJurosCompensatorios.Text) + Convert.ToDecimal(txtExpediente.Text)) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                        // valorParcela = ((valorParcela + Convert.ToDecimal(txtJurosCompensatorios.Text)) / (qtdeParcela == 99 ? 1 : qtdeParcela));

                        _drParcela = _dtNotificacaoParcela.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow();

                        _drParcela.ID_NOTIFICACAO_PARCELAMENTO = -1;
                        _drParcela.AVISO = "25";
                        _drParcela.PARCELA = qtdeParcela == 99 ? 99 : i;
                        _drParcela.VALOR_PARCELA = valorParcela;
                        _drParcela.VALOR_PARCELA_UFM = valorParcela / valorTabela;
                        _drParcela.DATA_VENCIMENTO = Geral.ProximoDiaUtil(Convert.ToDateTime(txtVencimento.Text).AddDays(qtdeParcela == 99 ? 0 : i == 1 ? 0 : ((i - 1) * 30)));
                        _drParcela.VALOR_JUROS = Convert.ToDecimal(txtJuros.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                        _drParcela.VALOR_MULTA = Convert.ToDecimal(txtMulta.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                        _drParcela.CORRECAO = Convert.ToDecimal(txtCorrecao.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                        _drParcela.TOTAL = valorParcela + (Convert.ToDecimal(txtJuros.Text) + Convert.ToDecimal(txtMulta.Text) + Convert.ToDecimal(txtCorrecao.Text)) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                        _drParcela.EXCLUIDO = false;
                        _drParcela.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                        _drParcela.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);

                        _dtNotificacaoParcela.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow(_drParcela);

                        if (issConstrucao > 0 || issDemolicao > 0 || issReforma > 0 || issEngenharia > 0 || issDemolicao > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = ((issConstrucao + issDemolicao + issReforma + issEngenharia) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "01";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao;
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }
                        if (licencaConstrucao > 0 || licencaReformaDemo > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = ((licencaConstrucao + licencaReformaDemo) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "07";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao;
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }
                        if (alinhamento > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = ((alinhamento) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "13";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao;
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }
                        if (alvara > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = ((alvara) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "09";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao;
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }
                        if (penalidade > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = ((penalidade - Convert.ToDecimal(txtDescontoPenalidade.Text)) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "11";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = (valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao);
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }
                        if (numerocaopredial > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = ((numerocaopredial) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "33";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = (valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao);
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }
                        if (Convert.ToDecimal(txtExpediente.Text) > 0)
                        {
                            _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                            valorConvertido = (Convert.ToDecimal(txtExpediente.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela)) / drUFV.VALOR;

                            if (status == "R" || status == "A")
                                valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtVencimento.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);
                            else
                                valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                            _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i;
                            _drParcelaDetalhe.TRIBUTO = "24";
                            _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                            _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                            _drParcelaDetalhe.VALOR_TOTAL = valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao;
                            _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                            _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                            _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                            _drParcelaDetalhe.DATA_DEBITO = Convert.ToDateTime(txtVencimento.Text);
                            _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);

                            _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                        }

                        if (status == "R")
                        {
                            _dtNotificacaoParcelamentoAtualizado = blNotificacao.ObterParcelamentoAtualizado(_drNotificacao.ID_NOTIFICACAO);

                            if (_dtNotificacaoParcelamentoAtualizado.Rows.Count > 0)
                            {
                                List<DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow> dtrAtualizado = _dtNotificacaoParcelamentoAtualizado.OrderByDescending(x => x["ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO"]).ToList();

                                foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow dtr in dtrAtualizado)
                                {
                                    if (trocarExigibilidade)
                                    {
                                        dtr.DATA_DEBITO = Convert.ToDateTime(txtExigibilidade.Text);
                                    }

                                    _drParcelaDetalhe = _dtNotificacaoParcelaDetalhe.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow();

                                    if (dtr.TRIBUTO == "11")
                                    {
                                        valorConvertido = qtdeParcela == 99 ? ((penalidadeReparcelamento - Convert.ToDecimal(txtDescontoPenalidade.Text)) / 1) / drUFV.VALOR : ((penalidadeReparcelamento - Convert.ToDecimal(txtDescontoPenalidade.Text)) / qtdeParcela) / drUFV.VALOR;
                                    }
                                    else
                                    {
                                        valorConvertido = qtdeParcela == 99 ? dtr.VALOR_UFM : dtr.VALOR_UFM / qtdeParcela;
                                    }

                                    valorCalculado = Geral.CorrigirValor(Math.Round(valorConvertido, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                                    _drParcelaDetalhe.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = qtdeParcela == 99 ? -99 : (i * -1);
                                    _drParcelaDetalhe.PARCELA = qtdeParcela == 99 ? 99 : i; 
                                    _drParcelaDetalhe.TRIBUTO = dtr.TRIBUTO;
                                    _drParcelaDetalhe.VALOR = valorCalculado.Principal;
                                    _drParcelaDetalhe.VALOR_UFM = valorCalculado.Principal / valorTabela;
                                    _drParcelaDetalhe.VALOR_TOTAL = valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao;
                                    _drParcelaDetalhe.VALOR_JUROS = valorCalculado.Juros;
                                    _drParcelaDetalhe.VALOR_MULTA = valorCalculado.Multa;
                                    _drParcelaDetalhe.VALOR_CORRECAO = valorCalculado.Correcao;
                                    _drParcelaDetalhe.JUROS_COMPENSATORIO = Convert.ToDecimal(txtJurosCompensatorios.Text) / (qtdeParcela == 99 ? 1 : qtdeParcela);
                                    _drParcelaDetalhe.DATA_DEBITO = dtr.DATA_DEBITO;

                                    _dtNotificacaoParcelaDetalhe.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHERow(_drParcelaDetalhe);
                                }
                            }
                        }

                        if (qtdeParcela == 99)
                        {
                            //processo para incluir as demais parcelas após a inclusão da unica.
                            qtdeParcela = Convert.ToInt32(txtQtdeParcela.Text);

                            //carrega os dados com o numero de parcelas.

                            CalcularExpedienteAnterior();
                            CalcularParcelamento();
                            goto parcelamento;
                        }
                    }
                }

                if (status == "R")
                {
                    #region INCLUSAO DE UM NOVO EXPEDIENTE NO VALORES ATUALIZADOS.

                    if (Convert.ToDecimal(txtExpediente.Text) > 0)
                    {
                        _drParcelamentoAtualizado = _dtNotificacaoParcelamentoAtualizado.NewMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow();

                        _drParcelamentoAtualizado.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO = -1;
                        _drParcelamentoAtualizado.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;
                        _drParcelamentoAtualizado.TRIBUTO = "24";
                        _drParcelamentoAtualizado.VALOR = (Convert.ToDecimal(txtExpediente.Text));
                        _drParcelamentoAtualizado.VALOR_UFM = (Convert.ToDecimal(txtExpediente.Text)) / valorTabela;
                        _drParcelamentoAtualizado.VALOR_ABATIMENTO = 0;
                        _drParcelamentoAtualizado.DATA_DEBITO = Convert.ToDateTime(txtVencimento.Text);

                        _dtNotificacaoParcelamentoAtualizado.AddMO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow(_drParcelamentoAtualizado);
                    }

                    #endregion
                }

                blNotificacao.IncluirParcelamento(_drParcelamento, _dtNotificacaoParcela, _dtNotificacaoParcelaDetalhe, _dtNotificacaoParcelamentoComplemento, _dtNotificacaoParcelamentoAtualizado);

                _dtNotificacaoParcelamento.Clear();
                _dtNotificacaoParcela.Clear();
                _dtNotificacaoParcelamentoAtualizado.Clear();
                _dtNotificacaoParcelaDetalhe.Clear();
                _dtNotificacaoParcelamentoComplemento.Clear();
            }
            catch (Exception ex)
            {
                _dtNotificacaoParcelamento.Clear();
                _dtNotificacaoParcelamentoComplemento.Clear();
                _dtNotificacaoParcelamentoAtualizado.Clear();
                _dtNotificacaoParcelaDetalhe.Clear();
                _dtNotificacaoParcela.Clear();
                throw ex;

            }
        }

        private void CalcularExpedienteAnterior()
        {
            try
            {
                txtJuros.Text = "0";
                txtMulta.Text = "0";
                txtCorrecao.Text = "0";

                if (_drNotificacao != null && status == "R")
                {
                    decimal calculado = 0;
                    decimal juros = 0;
                    decimal multa = 0;
                    decimal correcao = 0;

                    Geral.ValorCorrecao valorCalculado;

                    UFV objUFV = new UFV();

                    _dtNotificacaoParcelamentoAtualizado = blNotificacao.ObterParcelamentoAtualizado(_drNotificacao.ID_NOTIFICACAO);

                    foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow dtrAtualizado in _dtNotificacaoParcelamentoAtualizado.Where(x => x.TRIBUTO == "24"))
                    {
                        switch (dtrAtualizado.TRIBUTO)
                        {
                            case "24":
                                DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(dtrAtualizado.DATA_DEBITO);
                                valorCalculado = Geral.CorrigirValor(Math.Round(dtrAtualizado.VALOR_UFM, 4), dtrAtualizado.DATA_DEBITO, Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                                juros += valorCalculado.Juros;
                                multa += valorCalculado.Multa;
                                correcao += valorCalculado.Correcao;
                                calculado += Math.Round(dtrAtualizado.VALOR_UFM, 4) * drUFV.VALOR;
                                break;
                        }
                    }

                    lblExpedienteAnterior.Visible = true;
                    txtExpedienteAnterior.Visible = true;
                    txtExpedienteAnterior.Text = calculado.ToString("N2");
                    txtJuros.Text = (Convert.ToDecimal(txtJuros.Text) + juros).ToString("N2");
                    txtMulta.Text = (Convert.ToDecimal(txtMulta.Text) + multa).ToString("N2");
                    txtCorrecao.Text = (Convert.ToDecimal(txtCorrecao.Text) + correcao).ToString("N2");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void AtualizarAgrupamento()
        {
            try
            {
                UFV objUFV = new UFV();

                DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(Convert.ToDateTime(txtExigibilidade.Text));

                _dtNotificacaoParcelamentoComplemento.Clear();

                if (_drNotificacao != null)
                {
                    if (_dtNotificacaoParcelamento.Rows.Count == 0)
                    {
                        _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);
                    }

                    DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                    if (dtr == null)
                    {
                        if (_dtNotificacaoParcelamento.Rows.Count > 0)
                        {
                            dtr = _dtNotificacaoParcelamento.OrderByDescending(x => x.ID_NOTIFICACAO_PARCELAMENTO).First();

                            _dtNotificacaoParcelamentoAtualizado = blNotificacao.ObterParcelamentoAtualizado(_drNotificacao.ID_NOTIFICACAO);

                            _dtNotificacaoParcelamentoComplemento = blNotificacao.ObterParcelamentoComplemento(dtr.ID_NOTIFICACAO_PARCELAMENTO);
                        }
                    }
                    else
                    {
                        _dtNotificacaoParcelamentoAtualizado = blNotificacao.ObterParcelamentoAtualizado(_drNotificacao.ID_NOTIFICACAO);

                        _dtNotificacaoParcelamentoComplemento = blNotificacao.ObterParcelamentoComplemento(dtr.ID_NOTIFICACAO_PARCELAMENTO);
                    }

                    for (int i = 0; i < _dtNotificacaoParcelamentoComplemento.Rows.Count; i++)
                    {
                        Geral.ValorCorrecao valorCalculado;

                        if (_dtNotificacaoParcelamentoComplemento.Rows[i]["TRIBUTO"].ToString() == "11")
                        {
                            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow dtrAtualizado = _dtNotificacaoParcelamentoAtualizado.Where(x => x.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO == Convert.ToInt32(_dtNotificacaoParcelamentoComplemento.Rows[i]["ID_NOTIFICACACAO_PARCELAMENTO_ATUALIZADO"])).FirstOrDefault();

                            decimal penalidade = Convert.ToDecimal(dtrAtualizado.VALOR);

                            penalidade -= Convert.ToDecimal(txtDescontoPenalidade.Text);

                            valorCalculado = Geral.CorrigirValor(Math.Round(penalidade / drUFV.VALOR, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR"] = dtrAtualizado.VALOR;
                            _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_UFM"] = dtrAtualizado.VALOR_UFM;
                            _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_ABATIMENTO"] = (Convert.ToDecimal(txtDescontoPenalidade.Text) / drUFV.VALOR).ToString("N4");
                            _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_JUROS"] = valorCalculado.Juros.ToString("N2");
                            _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_MULTA"] = valorCalculado.Multa.ToString("N2");
                            _dtNotificacaoParcelamentoComplemento.Rows[i]["CORRECAO"] = valorCalculado.Correcao.ToString("N2");
                            _dtNotificacaoParcelamentoComplemento.Rows[i]["TOTAL"] = (valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao).ToString("N2");
                        }
                        else
                        {
                            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_ATUALIZADORow dtrAtualizado = _dtNotificacaoParcelamentoAtualizado.Where(x => x.ID_NOTIFICACAO_PARCELAMENTO_ATUALIZADO == Convert.ToInt32(_dtNotificacaoParcelamentoComplemento.Rows[i]["ID_NOTIFICACACAO_PARCELAMENTO_ATUALIZADO"])).FirstOrDefault();

                            valorCalculado = Geral.CorrigirValor(Math.Round(dtrAtualizado.VALOR / drUFV.VALOR, 4), Convert.ToDateTime(txtExigibilidade.Text), Convert.ToDateTime(txtVencimento.Text), 0, "U", 0, 0);

                            if (status == "A" && dtrAtualizado.TRIBUTO == "24")
                            {
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR"] = dtrAtualizado.VALOR;
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_UFM"] = dtrAtualizado.VALOR_UFM;
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_JUROS"] = "0,00";
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_MULTA"] = "0,00";
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["CORRECAO"] = "0,00";
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["TOTAL"] = dtrAtualizado.VALOR;
                            }
                            else
                            {
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR"] = dtrAtualizado.VALOR;
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_UFM"] = dtrAtualizado.VALOR_UFM;
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_JUROS"] = valorCalculado.Juros.ToString("N2");
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["VALOR_MULTA"] = valorCalculado.Multa.ToString("N2");
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["CORRECAO"] = valorCalculado.Correcao.ToString("N2");
                                _dtNotificacaoParcelamentoComplemento.Rows[i]["TOTAL"] = (valorCalculado.Principal + valorCalculado.Juros + valorCalculado.Multa + valorCalculado.Correcao).ToString("N2");
                            }


                        }
                    }

                    mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource.DataSource = _dtNotificacaoParcelamentoComplemento;
                    dgvParcelamantoComplemento.DataSource = _dtNotificacaoParcelamentoComplemento;
                }
            }
            catch (Exception)
            {
                // Mensagem.MsgAlert("Verifique a data de vencimento senão está muito longa.");
            }
        }

        private static bool IsCpf(string cpf)
        {
            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            cpf = cpf.Trim().Replace(".", "").Replace("-", "");
            if (cpf.Length != 11)
                return false;

            for (int j = 0; j < 10; j++)
                if (j.ToString().PadLeft(11, char.Parse(j.ToString())) == cpf)
                    return false;

            string tempCpf = cpf.Substring(0, 9);
            int soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];

            int resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            string digito = resto.ToString();
            tempCpf = tempCpf + digito;
            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cpf.EndsWith(digito);
        }

        private static bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            cnpj = cnpj.Trim().Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;

            string tempCnpj = cnpj.Substring(0, 12);
            int soma = 0;

            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];

            int resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            string digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];

            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cnpj.EndsWith(digito);
        }

        #endregion

        #region Eventos Grids
        private void dgvNotificacao_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvNotificacao.SelectedCells.Count > 0)
            {
                if (dgvNotificacao.SelectedCells[0].RowIndex >= 0)
                {
                    var id = dgvNotificacao.Rows[dgvNotificacao.SelectedCells[0].RowIndex].Cells["ID_NOTIFICACAO"].Value.ToString();

                    txtID_NOTIFICACAO.Text = id;

                    CarregarDados();
                }
            }
        }

        private void dgvContribuinte_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (edicaoSujeicao && lblId.Text != dgvContribuinte.Rows[e.RowIndex].Cells["ID_NOTIFICACAO_CONTRIBUINTE"].Value.ToString())
            if (modoTabelaContribuinte == Geral.ModoTabela.MODO_EDICAO || modoTabelaContribuinte == Geral.ModoTabela.MODO_INCLUSAO)
            {
                if (Mensagem.MsgYesNo("Deseja descartar alterações do registro atual?", "Fechar Janela"))
                {
                    //edicaoSujeicao = false;
                    modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;

                    LimparPastaContrib(false);
                }
                else
                {
                    return;
                }
            }

            for (int i = 0; i < ckbQualificacao.Items.Count; i++)
            {
                ckbQualificacao.SetItemChecked(i, false);
            }
            if (e.RowIndex >= 0)
            {
                if (modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                {
                    edicaoSujeicao = true;
                }

                string qualificacao = dgvContribuinte.Rows[e.RowIndex].Cells["QUALIFICACAO"].Value.ToString();

                txtCPFCNPJ.Text = dgvContribuinte.Rows[e.RowIndex].Cells["CPFCNPJ"].Value.ToString();
                txtNOME_RAZAO.Text = dgvContribuinte.Rows[e.RowIndex].Cells["NOME_RAZAO"].Value.ToString();
                txtCONTRIBUINTE.Text = dgvContribuinte.Rows[e.RowIndex].Cells["CONTRIBUINTE"].Value.ToString();
                txtComoResponsavel.Text = dgvContribuinte.Rows[e.RowIndex].Cells["COMO_RESPONSAVEL"].Value.ToString();
                txtResponsavel.Text = dgvContribuinte.Rows[e.RowIndex].Cells["RESPONSAVEL"].Value.ToString();
                txtCPFResponsavel.Text = dgvContribuinte.Rows[e.RowIndex].Cells["CPF_RESPONSAVEL"].Value.ToString();
                txtOBSERVACAO_P.Text = dgvContribuinte.Rows[e.RowIndex].Cells["OBSERVACAO"].Value.ToString();
                txtLogradouroResp.Text = dgvContribuinte.Rows[e.RowIndex].Cells["LOGRADOURO"].Value.ToString();
                txtBairroResp.Text = dgvContribuinte.Rows[e.RowIndex].Cells["BAIRRO"].Value.ToString();
                txtNumeroResp.Text = dgvContribuinte.Rows[e.RowIndex].Cells["NUMERO"].Value.ToString();
                txtCepResp.Text = dgvContribuinte.Rows[e.RowIndex].Cells["CEP"].Value.ToString();
                txtComplResp.Text = dgvContribuinte.Rows[e.RowIndex].Cells["COMPLEMENTO"].Value.ToString();
                cbxUFResp.SelectedValue = dgvContribuinte.Rows[e.RowIndex].Cells["UF"].Value.ToString();
                cbxCidadeResp.SelectedValue = dgvContribuinte.Rows[e.RowIndex].Cells["CIDADE"].Value.ToString();
                txtDocProfissional.Text = dgvContribuinte.Rows[e.RowIndex].Cells["DOCUMENTO"].Value.ToString();

                if (dgvContribuinte.Rows[e.RowIndex].Cells["INSCRICAO_MUNICIPAL"].Value.ToString() != string.Empty)
                {
                    txtCPFCNPJ.Enabled = false;
                    rblSim.Checked = false;
                    rblNao.Checked = true;
                    txtInscriMun.Enabled = true;
                    txtInscriMun.Text = dgvContribuinte.Rows[e.RowIndex].Cells["INSCRICAO_MUNICIPAL"].Value.ToString();
                }
                else
                {
                    rblSim.Checked = true;
                    rblNao.Checked = false;
                    txtInscriMun.Enabled = false;
                }
                lblId.Text = dgvContribuinte.Rows[e.RowIndex].Cells["ID_NOTIFICACAO_CONTRIBUINTE"].Value.ToString();

                bool subNivel = false;

                string descProprietarioPossuidor = dgvContribuinte.Rows[e.RowIndex].Cells["QUALIFICACAO_DESCRICAO"].Value.ToString();

                foreach (var item in qualificacao.Split('-'))
                {
                    if (!subNivel)
                    {
                        foreach (var id in item.Split(','))
                        {
                            for (int i = 0; i < ckbQualificacao.Items.Count; i++)
                            {
                                if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[i]).ID.ToString() == id)
                                {
                                    if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[i]).QUALIFICACAO == "Proprietário/Possuidor")
                                    {
                                        ckbQualificacao.SetItemChecked(i, false);
                                        ckbQualificacao.SetItemChecked(i, true);

                                        foreach (var selecionado in descProprietarioPossuidor.Split('-'))
                                        {
                                            if (selecionado.ToString().Trim() == "Proprietário")
                                            {
                                                ckbSubnivelProp.SetItemChecked(0, false);
                                                ckbSubnivelProp.SetItemChecked(0, true);
                                            }
                                            else if (selecionado.ToString().Trim() == "Possuidor")
                                            {
                                                ckbSubnivelProp.SetItemChecked(1, false);
                                                ckbSubnivelProp.SetItemChecked(1, true);
                                            }
                                        }

                                        break;
                                    }
                                    else
                                    {
                                        ckbQualificacao.SetItemChecked(i, false);
                                        ckbQualificacao.SetItemChecked(i, true);
                                        break;
                                    }
                                }

                            }
                        }
                    }
                    else
                    {

                        foreach (var id in item.Split(','))
                        {
                            for (int i = 0; i < ckbSubnivel.Items.Count; i++)
                            {
                                ckbSubnivel.SetItemChecked(i, false);//First uncheck the old value!

                                if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbSubnivel.Items[i]).ID.ToString() == id)
                                {
                                    //Check only if they match! 
                                    ckbSubnivel.SetItemChecked(i, true);
                                }

                            }
                        }
                    }

                    subNivel = true;
                }

                chkPRINCIPAL.Checked = Convert.ToBoolean(dgvContribuinte.Rows[e.RowIndex].Cells["PRINCIPAL"].Value.ToString());
            }
        }

        private void dgvLancamentoConstrucao_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (bloquearAtualizacaoUFM)
                {
                    GroupBox4.Enabled = false;
                    groupBox2.Enabled = false;

                    lblAreaBaseISSEngenharia.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_BASE_ISS_ENGENHARIA"].ToString();
                    lblAreaBaseIssConstr.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_BASE_ISS_CONSTRUCAO"].ToString();
                    lblAreaBaseIssDemol.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_PENALIDADE_CONSTRUCAO"].ToString();
                    lblAreaBaseIssRefor.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_BASE_ISS_DEMOLICAO"].ToString();
                    lblPenalidade.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_PENALIDADE_CONSTRUCAO"].ToString();
                    lblAreaBaseIssRefor.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_BASE_ISS_REFORMA"].ToString();
                    lblBaseISSConstrucao.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["BASE_ISS_CONSTRUCAO"].ToString();
                    lblBaseISSDemolicao.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["BASE_ISS_DEMOLICAO"].ToString();
                    lblBaseISSReforma.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["BASE_ISS_REFORMA"].ToString();
                    lblImpostoISSConstrucao.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_CONSTRUCAO"].ToString();
                    lblImpostoISSDemolicao.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_DEMOLICAO"].ToString();
                    lblImpostoISSReforma.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_REFORMA"].ToString();
                    lblBaseISSEngenharia.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["BASE_ISS_ENGENHARIA"].ToString();
                    lblImpostoSSEngenharia.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_ENGENHARIA"].ToString();
                    ImpostoISSConstrucaoSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_CONSTRUCAO_SECUNDARIO"].ToString());
                    ImpostoISSDemolicaoSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_DEMOLICAO_SECUNDARIO"].ToString());
                    ImpostoISSReformaSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_REFORMA_SECUNDARIO"].ToString());
                    ImpostoISSEngenhariaSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["IMPOSTO_ISS_ENGENHARIA_SECUNDARIO"].ToString());
                    TaxaConstrucaoSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["TX_LICENCA_CONSTRUCAO_SECUNDARIO"].ToString());
                    TaxaReformaSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["TX_LICENCA_REFORMA_DEMOLICAO_SECUNDARIO"].ToString());
                    TaxaAlinhamentoSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["TX_ALINHAMENTO_SECUNDARIO"].ToString());
                    TaxaAlvaraSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["TX_ALVARA_SECUNDARIO"].ToString());
                    TaxaPenalidadeSecundario = Convert.ToDecimal(_dtNotificacaoLancamento.Rows[e.RowIndex]["TX_PENALIDADES_SECUNDARIO"].ToString());
                    lblTaxaConstrucao.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["TX_LICENCA_CONSTRUCAO"].ToString();
                    lblTaxaLicenca.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["TX_LICENCA_REFORMA_DEMOLICAO"].ToString();
                    lblTaxaAlinhamento.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["TX_ALINHAMENTO"].ToString();
                    lblTaxaAlvara.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["TX_ALVARA"].ToString();
                    lblTaxaPenalidades.Text = "R$ " + _dtNotificacaoLancamento.Rows[e.RowIndex]["TX_PENALIDADES"].ToString();
                }
                else
                {
                    cbxSubtipoImovel_SelectedIndexChanged(null, null);
                }
                //txtCPFCNPJ.Text = dgvContribuinte.Rows[e.RowIndex].Cells["CPFCNPJ"].Value.ToString();

                cbxTipoConstr.Text = dgvLancamentoConstrucao.Rows[e.RowIndex].Cells["TIPO"].Value.ToString();
                cbxTipoImovel.Text = dgvLancamentoConstrucao.Rows[e.RowIndex].Cells["TIPO_IMOVEL"].Value.ToString();
                cbxSubtipoImovel.Text = dgvLancamentoConstrucao.Rows[e.RowIndex].Cells["SUBTIPO_IMOVEL"].Value.ToString();
                txtAREA_TERRENO.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_TERRENO"].ToString();
                txtTESTADA_PRINCIPAL.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_TERRENO_TESTADO"].ToString();
                txtAreaConstruir.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_CONSTRUIR"].ToString();
                txtAreaReformar.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_REFORMAR"].ToString();
                txtAreaLegalConstr.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_LEGAL_CONSTRUCAO"].ToString();
                txtAreaLegalReformar.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_LEGAL_REFORMA"].ToString();
                txtAreaExistenteLegalConst.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_LEGAL_EXISTENTE_CONSTRUCAO"].ToString();
                txtAreaDemolir.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_DEMOLIR"].ToString();
                txtAreaLegalDemolir.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_DEMOLIR_LEGAL"].ToString();
                txtAreaDecadConstr.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_DECADENCIA_CONSTRUCAO"].ToString();
                txtAreaDecadDemolir.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_DECADENCIA_DEMOLICAO"].ToString();
                txtUnidades.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["NUMERO_UNIDADES"].ToString();
                ckbImplantada.Checked = Convert.ToBoolean(_dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_IMPLANTADA_LEGALIZAR"].ToString());
                txtDesmontavelLegalizar.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["ABRIGO_DESMONTAVEL_LEGALIZAR"].ToString();
                txtDesmontavelLegalizado.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["ABRIGO_DESMONTAVEL_EXISTENTE"].ToString();
                txtNumeroUnidAutonomas.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["NUMERO_ABRIGO_DESMONTAVEL"].ToString();
                txtAreaTerrenoDeduzir.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_DEDUZIR"].ToString();
                txtAreaTerrenoAumentar.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_AUMENTAR"].ToString();
                txtTestadaDeduzir.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_TESTADA_DEDUZIR"].ToString();
                txtTestadaAumentar.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_TESTADA_AUMENTAR"].ToString();
                ckbElevador.Checked = Convert.ToBoolean(_dtNotificacaoLancamento.Rows[e.RowIndex]["ELEVADOR"].ToString());
                txtAreaTotal.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_TOTAL"].ToString();
                txtAreaEdicula.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_EDICULA"].ToString();
                txtEnquadramento.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_ENQUADRAMENTO"].ToString();
                txtEnquadramentoDemolicao.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_ENQUADRAMENTO_DEMOLICAO"].ToString();
                txtEnquadramentoReforma.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_ENQUADRAMENTO_REFORMA"].ToString();
                txtEnquadramentoPenalidade.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["AREA_ENQUADRAMENTO_PENALIDADE"].ToString();

                lblIdLancamento.Text = _dtNotificacaoLancamento.Rows[e.RowIndex]["ID_NOTIFICACAO_LANCAMENTO"].ToString();

                if (!bloquearAtualizacaoUFM)
                {
                    txtAREA_TERRENO_TextChanged(null, null);
                }

                if (modoTabela == Geral.ModoTabela.MODO_PESQUISA || modoTabela == Geral.ModoTabela.MODO_CONSULTA)
                {
                    GroupBox4.Enabled = false;
                    groupBox2.Enabled = false;
                }
            }
        }
        private void dgvUnificacao_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (dgvUnificacao.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
                    {
                        if (dgvUnificacao.Columns[e.ColumnIndex].Name == "ExcluirUnificacao")
                        {
                            if (dgvLancamentoConstrucao.Rows.Count == 0)
                            {
                                if (Mensagem.MsgYesNo("Confirma exclusão ?", "Exclusão"))
                                {
                                    areaTerreno = Convert.ToDecimal(areaTerreno) - Convert.ToDecimal(dgvUnificacao.Rows[e.RowIndex].Cells["AREA_TERRENO_UNIFICACAO"].Value.ToString());
                                    areaTestado = areaTestado - Convert.ToDecimal(dgvUnificacao.Rows[e.RowIndex].Cells["AREA_TERRENO_TESTADO_UNIFICACAO"].Value.ToString());

                                    txtAREA_TERRENO.Text = areaTerreno.ToString();
                                    txtTESTADA_PRINCIPAL.Text = areaTestado.ToString();

                                    mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource.RemoveCurrent();
                                }
                            }
                            else
                            {
                                Mensagem.MsgAlert("Exclua todos os lançamentos antes de excluir a unificação.", "Alerta");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Mensagem.MsgExcecao("Erro ao excluir a unificação.", "Erro", ex);
                }
            }
        }

        private void dgvLancamentoConstrucao_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (modoTabelaConstrucao == Geral.ModoTabela.MODO_EDICAO || modoTabelaConstrucao == Geral.ModoTabela.MODO_INCLUSAO)
            {
                if (Mensagem.MsgYesNo("Deseja descartar alterações do registro atual?", "Fechar Janela"))
                {
                    //edicaoSujeicao = false;
                    modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;

                    LimparPastaLancamentoConstrucao();
                }
                else
                {
                    return;
                }
            }

            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (dgvLancamentoConstrucao.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
                    {
                        if (dgvLancamentoConstrucao.Columns[e.ColumnIndex].Name == "Excluir")
                        {
                            if (Mensagem.MsgYesNo("Confirma exclusão ?", "Exclusão"))
                            {
                                mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.RemoveCurrent();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Mensagem.MsgExcecao("Erro ao excluir o lançamento.", "Erro", ex);
                }
            }
        }

        private void dgvParcela_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e != null && e.ColumnIndex != 1)
                {
                    _dtNotificacaoParcelaDetalhe = blNotificacao.ObterParcelaDetalhe(Convert.ToInt32(dgvParcela.Rows[e.RowIndex].Cells["idParcela"].Value));

                    mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource.DataSource = _dtNotificacaoParcelaDetalhe;
                    dgvParcelaDetalhe.DataSource = mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource;
                }
                else
                {
                    dgvParcelaDetalhe.DataSource = null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void dgvParcelamentoAnterior_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex != 0)
                {
                    _dtNotificacaoParcela = blNotificacao.ObterParcela(Convert.ToInt32(dgvParcelamentoAnterior.Rows[e.RowIndex].Cells["ID_NOTIFICACAO_PARCELAMENTO"].Value));

                    mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource.DataSource = _dtNotificacaoParcela;
                    dgvParcelasAnterior.DataSource = mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource;
                }
                else
                {
                    RelVisualizador objRel = new RelVisualizador();

                    objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "DP", dgvParcelamentoAnterior.Rows[e.RowIndex].Cells["ID_NOTIFICACAO_PARCELAMENTO"].Value.ToString());
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void dgvParcelasAnterior_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                _dtNotificacaoParcelaDetalhe = blNotificacao.ObterParcelaDetalhe(Convert.ToInt32(dgvParcelasAnterior.Rows[e.RowIndex].Cells["ID_NOTIFICACAO_PARCELAMENTO_PARCELA"].Value));

                mOParcelaDetalheAnterior.DataSource = _dtNotificacaoParcelaDetalhe;
                dgvParcelaDetalheAnterior.DataSource = mOParcelaDetalheAnterior;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void dgvParcelaDetalhe_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvParcela_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvParcela.IsCurrentCellDirty)
            {
                dgvParcela.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        #endregion

        #region Eventos Gerais

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Se for edição apenas aborta edição e continua no modo consulta
            if (modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
            {
                modoTabela = Geral.ModoTabela.MODO_CONSULTA;
                modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
                modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;
            }
            else
            {
                modoTabela = Geral.ModoTabela.MODO_PESQUISA;
                LimparCampos(this);
                LimparPastaLancamentoConstrucao();
                LimparPastaContrib(true);
                LimparPastaUnificacao();
            }


            //DesabilitarCampos(false);
            tbcCadastro.SelectedTab = tbpCadastro;
        }

        private void Close(bool Forcado)
        {
            this.fechaForcado = Forcado;
            this.Close();
        }

        private void tbcCadastro_Selecting(object sender, TabControlCancelEventArgs e)
        {
            //if (edicaoSujeicao)
            if (modoTabelaContribuinte == Geral.ModoTabela.MODO_EDICAO || modoTabelaContribuinte == Geral.ModoTabela.MODO_INCLUSAO)
            {
                if (Mensagem.MsgYesNo("Deseja descartar alterações do registro atual?", "Fechar Janela"))
                {
                    //edicaoSujeicao = false;
                    modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;

                    LimparPastaContrib(false);
                }
                else
                {
                    e.Cancel = true;
                    return;
                }
            }

            if ((modoTabela == Geral.ModoTabela.MODO_INCLUSAO || modoTabela == Geral.ModoTabela.MODO_EDICAO) && tbcCadastro.SelectedTab == tbpPesquisa)
            {
                tbcCadastro.SelectedTab = tbpCadastro;
            }
            else if (tbcCadastro.SelectedTab == tbpParcelamento)
            {
                CarregarDadosParcela();

                if (status == "A" || status == "R")
                {
                    CalcularExpedienteAnterior();
                    CalcularParcelamento();
                    AtualizarAgrupamento();
                }
            }
            else if (tbcCadastro.SelectedTab == tbpParcelas)
            {
                CarregarGridParcela();
            }
            else if (tbcCadastro.SelectedTab == tbpLancamento)
            {
                if (cbxTipo.Text == "Planta")
                {
                    if (_dtNotificacaoLancamento.Rows.Count > 0)
                    {
                        var args = new DataGridViewCellEventArgs(0, 0);

                        dgvLancamentoConstrucao_CellDoubleClick(dgvLancamentoConstrucao, args);
                    }
                }
            }
            //else if (tbcCadastro.SelectedTab == tbpContribuinte)
            //{
            //    if (cbxTipo.Text == "Planta")
            //    {
            //        if (_dtNotificacaoContribuinte.Rows.Count > 0)
            //        {
            //            var args = new DataGridViewCellEventArgs(0, 0);

            //            dgvContribuinte_CellDoubleClick(dgvContribuinte, args);

            //            edicaoSujeicao = false;
            //        }
            //    }
            //}
        }

        private void btnBuscarInscricao_Click(object sender, EventArgs e)
        {
            try
            {
                string tipoTributo = (rdbImob.Checked ? "I" : "M");

                if (txtINSCRICAO.TextLength != 0 && modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                {
                    CarregarInscricao(txtINSCRICAO.Text.Trim(), tipoTributo, false);
                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Erro", ex);
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            Pesquisar();
            //DesabilitarCampos(true);

            Cursor = Cursors.Default;

            modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
            modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;
        }

        private void NotificacaoLancamento_Load(object sender, EventArgs e)
        {
            // Formata campos
            FormatarCampos();
            // Bind no navigator
            bindingNavigator.BindingSource = mO_NOTIFICACAO_LANCAMENTOBindingSource;
            //Carrega dados do grid

            //Move tabPage Pesquisa pro final
            tbcCadastro.TabPages.Remove(tbpPesquisa);
            tbcCadastro.TabPages.Add(tbpPesquisa);

            dgvContribuinte.AutoGenerateColumns = false;
            dgvNotificacao.AutoGenerateColumns = false;
            dgvParcela.AutoGenerateColumns = false;
            dgvParcelasAnterior.AutoGenerateColumns = false;
            dgvParcelaDetalhe.AutoGenerateColumns = false;
            dgvParcelaDetalheAnterior.AutoGenerateColumns = false;
            dgvParcelamentoAnterior.AutoGenerateColumns = false;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NotificacaoLancamento_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!this.fechaForcado & (modoTabela == Geral.ModoTabela.MODO_EDICAO || modoTabela == Geral.ModoTabela.MODO_INCLUSAO))
            {
                string modo = modoTabela == Geral.ModoTabela.MODO_EDICAO ? "edição." : "inclusão.";
                if (!Mensagem.MsgYesNo("Deseja fechar a janela de Certidao?\nTabela está em modo " + modo, "Fechar Janela"))
                    e.Cancel = true;
            }
        }

        private void cbxUF_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Geral.CarregarCombo(cbxCIDADE, blEndereco.ListarCidade((string)cbxUF.SelectedValue), "CIDADE", "CIDADE", true);
            }
            catch (Exception)
            {
            }
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoIncluir))
            {
                if (modoTabela == Geral.ModoTabela.MODO_INCLUSAO)
                    return;

                Incluir();
                modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
                modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;


                txtANO_NOTIFICACAO.Text = DateTime.Now.Year.ToString();
            }
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if(1 == 1)// (ValidacaoAba1() && ValidacaoAba2())
            {
                Gravar();
                modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
                modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;

            }
            else
            {
                Mensagem.MsgAlert("Preencha todos os campos obrigatórios e complete ou inclua um responsável na sujeição passiva.", "Campos obrigatórios");
            }
        }

        private void btnGravarContribuinte_Click_1(object sender, EventArgs e)
        {
            bool validado = true;

            if (lblId.Text == string.Empty)
            {
                if (_dtNotificacaoContribuinte.Count(x => x.CPFCNPJ == txtCPFCNPJ.Text) > 0)
                {
                    Mensagem.MsgAlert("CPNJ/CPF Já incluído.");
                    return;
                }
            }

            //if (Biblioteca.Validacao.ValidaCNPJ(txtCPFCNPJ.Text))
            //{
            //    if (string.IsNullOrEmpty(txtResponsavel.Text))
            //    {
            //        errorProvider.SetError(txtResponsavel, "Campo obrigatório");

            //        validado = false;
            //    }

            //    if (string.IsNullOrEmpty(txtCPFResponsavel.Text))
            //    {
            //        errorProvider.SetError(txtCPFResponsavel, "Campo obrigatório");

            //        validado = false;
            //    }
            //}

            string qualificacao = string.Empty;
            string qualificacaoDesc = string.Empty;
            string qualificacaoTec = string.Empty;
            bool ResponsavelSelecionado = false;
            bool ProprietarioSelecionado = false;
            bool SubProprietarioSelecionado = false;

            foreach (object i in ckbQualificacao.CheckedItems)
            {
                qualificacao += ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).ID.ToString() + ",";

                if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).QUALIFICACAO.ToString() == "Proprietário/Possuidor")
                {
                    ProprietarioSelecionado = true;

                    foreach (object x in ckbSubnivelProp.CheckedItems)
                    {
                        qualificacaoDesc += ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)x).QUALIFICACAO.ToString() + " - ";
                        SubProprietarioSelecionado = true;
                    }
                }
                else
                {
                    qualificacaoDesc += ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).QUALIFICACAO.ToString() + " - ";
                }

                if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).ID.ToString() == "3")
                    ResponsavelSelecionado = true;
            }

            if (qualificacao != string.Empty)
            {
                qualificacao = qualificacao.Substring(0, qualificacao.Length - 1);
            }
            else
            {
                validado = false;
                Mensagem.MsgAlert("È necessário selecionar uma qualificação.");
            }

            foreach (object i in ckbSubnivel.CheckedItems)
            {
                qualificacaoTec += ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).ID.ToString() + ",";
                qualificacaoDesc += ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).QUALIFICACAO.ToString() + " - ";
            }

            if (ResponsavelSelecionado)
            {
                if (qualificacaoTec != string.Empty)
                {
                    qualificacaoTec = qualificacaoTec.Substring(0, qualificacaoTec.Length - 1);
                }
                else
                {
                    validado = false;
                    Mensagem.MsgAlert("È necessário selecionar um tipo de responsável técnico.");
                }
            }

            //APENAS PARA RESPONSAVEL TECNICO NÃO É NECESSARIO INCLUIR TODAS AS INFORMAÇÕES
            if (ResponsavelSelecionado)
            {
                if (string.IsNullOrEmpty(txtDocProfissional.Text))
                {
                    errorProvider.SetError(txtDocProfissional, "Campo obrigatório");
                    validado = false;
                }

                if (string.IsNullOrEmpty(txtInscriMun.Text) && rblNao.Checked)
                {
                    errorProvider.SetError(txtInscriMun, "Campo obrigatório");
                    validado = false;
                }

                if (string.IsNullOrEmpty(txtCPFCNPJ.Text))
                {
                    errorProvider.SetError(txtCPFCNPJ, "Campo obrigatório");
                    validado = false;
                }

                if (string.IsNullOrEmpty(txtNOME_RAZAO.Text))
                {
                    errorProvider.SetError(txtNOME_RAZAO, "Campo obrigatório");
                    validado = false;
                }
            }
            else
            {
                if (ProprietarioSelecionado && !SubProprietarioSelecionado)
                {
                    validado = false;
                    Mensagem.MsgAlert("È necessário selecionar um tipo Proprietário/Possuidor");
                }

                if (string.IsNullOrEmpty(txtCPFCNPJ.Text))
                {
                    errorProvider.SetError(txtCPFCNPJ, "Campo obrigatório");
                    validado = false;
                }

                if (string.IsNullOrEmpty(txtNOME_RAZAO.Text))
                {
                    errorProvider.SetError(txtNOME_RAZAO, "Campo obrigatório");
                    validado = false;
                }

                if (string.IsNullOrEmpty(txtCepResp.Text))
                {
                    errorProvider.SetError(txtCepResp, "Campo obrigatório");
                    validado = false;
                }
                if (string.IsNullOrEmpty(txtLogradouroResp.Text))
                {
                    errorProvider.SetError(txtLogradouroResp, "Campo obrigatório");
                    validado = false;
                }
                if (string.IsNullOrEmpty(txtNumeroResp.Text))
                {
                    errorProvider.SetError(txtNumeroResp, "Campo obrigatório");
                    validado = false;
                }
                if (string.IsNullOrEmpty(txtBairroResp.Text))
                {
                    errorProvider.SetError(txtBairroResp, "Campo obrigatório");
                    validado = false;
                }
                if (string.IsNullOrEmpty(txtNOME_RAZAO.Text))
                {
                    errorProvider.SetError(txtNOME_RAZAO, "Campo obrigatório");
                    validado = false;
                }
                if (string.IsNullOrEmpty(cbxUFResp.Text))
                {
                    errorProvider.SetError(cbxUFResp, "Campo obrigatório");

                    validado = false;
                }
                if (string.IsNullOrEmpty(cbxCidadeResp.Text))
                {
                    errorProvider.SetError(cbxCidadeResp, "Campo obrigatório");

                    validado = false;
                }
            }

            qualificacao = qualificacao + "-" + qualificacaoTec;

            if (validado)
            {
                //bool principal = false;

                if (chkPRINCIPAL.Checked)
                {
                    //PARA VERIFICAÇÃO SE É O REGISTRO PRINCIPAL
                    for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
                    {
                        if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted)
                        {
                            _dtNotificacaoContribuinte.Rows[i]["PRINCIPAL"] = "False";
                        }
                    }
                }

                AdicionarContribuinte(qualificacao, qualificacaoDesc);

                cobrarIssEngenharia = true;
                edicaoSujeicao = false;

                //PARA VERIFICAÇÃO SE SERÁ COBRADO ISS ENGENHARIA.
                for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
                {
                    if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted)
                    {
                        if (_dtNotificacaoContribuinte.Rows[i]["QUALIFICACAO"].ToString().Contains("3-"))
                        {
                            string INSCRICAO_MUNICIPAL = _dtNotificacaoContribuinte.Rows[i]["INSCRICAO_MUNICIPAL"].ToString();

                            if (INSCRICAO_MUNICIPAL != string.Empty)
                            {
                                cobrarIssEngenharia = false;
                            }
                            else
                            {
                                cobrarIssEngenharia = true;
                                break;
                            }
                        }
                    }
                }

                if (_dtNotificacaoLancamento.Rows.Count > 0)
                {
                    foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow item in _dtNotificacaoLancamento)
                    {
                        if (item.RowState != DataRowState.Deleted)
                        {
                            if (cobrarIssEngenharia)
                                item.IMPOSTO_ISS_ENGENHARIA = item.IMPOSTO_ISS_ENGENHARIA_SECUNDARIO;
                            else
                                item.IMPOSTO_ISS_ENGENHARIA = 0;
                        }
                    }
                }

                modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;
                CarregarGridContribuinte();
                CarregarGridLancamentoConstrucao();
                //LimparPastaContrib();
            }
        }

        private void txtCEP_Validating(object sender, CancelEventArgs e)
        {
            TextBox txtCampo = (sender as TextBox);

            if (!string.IsNullOrEmpty(txtCampo.Text))
                errorProvider.SetError(txtCampo, "");
        }

        private void cbxCIDADE_Validating(object sender, CancelEventArgs e)
        {
            ComboBox cbxCampo = (sender as ComboBox);

            if (!string.IsNullOrEmpty(cbxCampo.Text))
                errorProvider.SetError(cbxCampo, "");
        }

        private void txtCPFCNPJ_Validating(object sender, CancelEventArgs e)
        {
            if (!(IsCpf(txtCPFCNPJ.Text) || IsCnpj(txtCPFCNPJ.Text)))
            {
                Mensagem.MsgAlert("CPF/CNPJ Inválido");

                txtCPFCNPJ.Focus();
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoEditar))
            {
                this.Editar();
                modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
                modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;

            }
        }

        private void cbxUFResp_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Geral.CarregarCombo(cbxCidadeResp, blEndereco.ListarCidade((string)cbxUFResp.SelectedValue), "CIDADE", "CIDADE", true);
            }
            catch (Exception)
            {
            }
        }

        private void btnPessoa_Click(object sender, EventArgs e)
        {
            if (txtCPFCNPJ.Text != string.Empty)
            {
                try
                {
                    blPessoa.BuscarCpfCnpj(txtCPFCNPJ.Text);

                    //if (Permissao.VerAcesso(EnumDLL.Permissao.IM_ImobiliárioPessoa_Editar))
                    VerPessoa("E");
                }
                catch (Biblioteca.Exceptions.LNE)
                {
                    //if (Permissao.VerAcesso(EnumDLL.Permissao.IM_ImobiliárioPessoa_Incluir))
                    VerPessoa("I");
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                Mensagem.MsgAlert("Informe o CPF/CNPJ do proprietário.", "Atenção");
                txtCPFCNPJ.Focus();
            }
        }

        private void txtCPFCNPJ_Leave(object sender, EventArgs e)
        {
            if (edicaoSujeicao)
            {
                if (Mensagem.MsgYesNo("Deseja descartar alterações do registro atual?", "Fechar Janela"))
                {
                    string cnpj = txtCPFCNPJ.Text;

                    LimparPastaContrib(false);

                    txtCPFCNPJ.Text = cnpj;
                    BuscarPessoa();
                    edicaoSujeicao = true;
                }
                else
                {
                    return;
                }
            }
            else
            {
                BuscarPessoa();
                edicaoSujeicao = true;
            }
        }

        private void ckbQualificacao_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).NIVEL.ToString() == "S" && e.NewValue == CheckState.Checked)
            {
                if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).QUALIFICACAO == "Responsável Técnico")
                {
                    _dtQualificacao = blNotificacao.ListarQualificacao(cbxTipo.SelectedValue.ToString());

                    var checkBoxList = (ListBox)ckbSubnivel;

                    int id = ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).ID;

                    checkBoxList.DataSource = _dtQualificacao.Where(x => !x.IsSUBNIVELNull() && x.SUBNIVEL == id.ToString()).ToList();
                    checkBoxList.DisplayMember = "qualificacao";
                    checkBoxList.ValueMember = "ID";

                    ckbSubnivelProp.Visible = false;
                    chkPRINCIPAL.Visible = false;

                    ckbSubnivel.Visible = true;
                    lblInscricaoMun.Visible = true;
                    txtInscriMun.Visible = true;
                    lblInscrito.Visible = true;
                    rblSim.Visible = true;
                    rblNao.Visible = true;
                }
                else
                {
                    _dtQualificacao = blNotificacao.ListarQualificacao(cbxTipo.SelectedValue.ToString());

                    var checkBoxList = (ListBox)ckbSubnivelProp;

                    int id = ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).ID;

                    checkBoxList.DataSource = _dtQualificacao.Where(x => !x.IsSUBNIVELNull() && x.SUBNIVEL == id.ToString()).ToList();
                    checkBoxList.DisplayMember = "qualificacao";
                    checkBoxList.ValueMember = "ID";

                    ckbSubnivelProp.Visible = true;
                    chkPRINCIPAL.Visible = true;

                    ckbSubnivel.Visible = false;
                    lblInscricaoMun.Visible = false;
                    txtInscriMun.Visible = false;
                    lblInscrito.Visible = false;
                    rblSim.Visible = false;
                    rblNao.Visible = false;
                }
            }
            else if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).NIVEL.ToString() == "N" && e.NewValue == CheckState.Checked)
            {
                if (((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).QUALIFICACAO == "Responsável Técnico")
                {
                    txtInscriMun.Text = "";

                }

                var checkBoxList = (ListBox)ckbSubnivel;

                checkBoxList.DataSource = null;
                checkBoxList.DisplayMember = "qualificacao";
                checkBoxList.ValueMember = "ID";

                ckbSubnivel.Visible = false;
                ckbSubnivelProp.Visible = false;
                lblInscricaoMun.Visible = false;
                txtInscriMun.Visible = false;
                lblInscrito.Visible = false;
                rblSim.Visible = false;
                rblNao.Visible = false;
            }

            //if (((PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)ckbQualificacao.Items[e.Index]).QUALIFICACAO == "Proprietário/Possuidor")
            //{
            bool principal = false;
            //PARA VERIFICAÇÃO SE É O REGISTRO PRINCIPAL
            for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
            {
                if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted && _dtNotificacaoContribuinte.Rows[i]["ID_NOTIFICACAO_CONTRIBUINTE"].ToString() != lblId.Text)
                {
                    if (_dtNotificacaoContribuinte.Rows[i]["PRINCIPAL"].ToString() == "True")
                    {
                        principal = true;
                    }
                }
            }

            if (!principal)
            {
                chkPRINCIPAL.Checked = true;
            }
            else
            {
                chkPRINCIPAL.Checked = false;
            }
            //}
            //else
            //{
            //    chkPRINCIPAL.Checked = false;
            //}
        }

        private void ckbQualificacao_SelectedValueChanged(object sender, EventArgs e)
        {
            int val = ckbQualificacao.SelectedIndex;
            if (val >= 0)
            {
                ckbQualificacao.ItemCheck -= ckbQualificacao_ItemCheck;
                for (int i = 0; i <= ckbQualificacao.Items.Count - 1; i++)
                {
                    ckbQualificacao.SetItemChecked(i, false);
                }
                ckbQualificacao.ItemCheck += ckbQualificacao_ItemCheck;
                ckbQualificacao.SetItemChecked(val, true);
            }
            Cursor.Current = Cursors.WaitCursor;
            string filtroSujeicao = string.Empty;

            Thread.Sleep(100);
            foreach (object i in ckbQualificacao.CheckedItems)
            {
                filtroSujeicao += ((DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_QUALIFICACAORow)i).ID.ToString() + ",";
            }

            if (filtroSujeicao != string.Empty)
            {
                filtroSujeicao = filtroSujeicao.Substring(0, filtroSujeicao.Length - 1);

                _dtQualificacaoSujeicao = blNotificacao.ListarQualificacaoSujeicao(filtroSujeicao);

                if (_dtQualificacaoSujeicao.Rows.Count > 0)
                {
                    txtCONTRIBUINTE.Text = _dtQualificacaoSujeicao.Rows[0]["CONTRIBUINTE"].ToString();
                    txtComoResponsavel.Text = _dtQualificacaoSujeicao.Rows[0]["RESPONSAVEL"].ToString();
                }
                else
                {
                    txtCONTRIBUINTE.Text = string.Empty;
                    txtComoResponsavel.Text = string.Empty;
                }
            }
            else
            {
                txtCONTRIBUINTE.Text = string.Empty;
                txtComoResponsavel.Text = string.Empty;
            }

            Cursor.Current = Cursors.Default;
        }

        private void cbxTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxTipo.SelectedValue != null && cbxTipo.SelectedValue.ToString() != string.Empty)
            {
                this.CarregarQualificacao();
                this.CarregarTipoLancamento();

                if (cbxTipo.SelectedValue.ToString() == "P")
                {
                    grpDiferimento.Visible = true;
                    grpIncidencia.Visible = true;
                }
                else
                {
                    grpDiferimento.Visible = false;
                    grpIncidencia.Visible = false;
                }
            }
        }

        private void tbcCadastro_Click(object sender, EventArgs e)
        {
            if (tbcCadastro.SelectedIndex >= 0)
            {
                if (modoTabela != Geral.ModoTabela.MODO_PESQUISA)
                {
                    if (cbxTipo.SelectedValue == null || cbxTipo.SelectedValue.ToString() == string.Empty || cbxTipo.SelectedValue.ToString() == "Selecione..")
                    {
                        tbcCadastro.SelectTab(0);

                        Mensagem.MsgAlert("Selecione o tipo antes de prosseguir para as próximas abas!", "Aviso");
                    }
                    else
                    {
                        if (!ValidacaoAba1() && tbcCadastro.SelectedIndex != 0)
                        {
                            Mensagem.MsgAlert("Preencha todos os campos obrigatórios da primeira aba.", "Campos obrigatórios");

                            tbcCadastro.SelectTab(0);
                            return;
                        }
                        if (!ValidacaoAba2() && tbcCadastro.SelectedIndex != 1)
                        {
                            Mensagem.MsgAlert("Preencha todos os campos obrigatórios da segunda aba.", "Campos obrigatórios");

                            tbcCadastro.SelectTab(1);
                            return;
                        }
                    }
                }
            }
        }

        private void ckbSubnivel_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (e.NewValue == CheckState.Checked)
            {
                if (ckbSubnivel.CheckedItems.Count > 0)
                {
                    for (int i = 0; i < ckbSubnivel.Items.Count; i++)
                    {
                        ckbSubnivel.SetItemChecked(i, false);//First uncheck the old value!
                    }

                    ckbSubnivel.SetItemChecked(e.Index, true);
                }
            }
        }

        private void ckbSubnivelProp_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (e.NewValue == CheckState.Checked)
            {
                if (ckbSubnivelProp.CheckedItems.Count > 0)
                {
                    for (int i = 0; i < ckbSubnivelProp.Items.Count; i++)
                    {
                        ckbSubnivelProp.SetItemChecked(i, false);//First uncheck the old value!
                    }

                    ckbSubnivelProp.SetItemChecked(e.Index, true);
                }
            }
        }

        private void btnOpcoes_Click(object sender, EventArgs e)
        {
            Rectangle r = btnOpcoes.DisplayRectangle;

            btnOpcoes.ContextMenuStrip = cmsOpcoes;
            btnOpcoes.ContextMenuStrip.Show((Control)sender, new Point(r.Right / 2, r.Bottom));
        }

        private void cbxSubtipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxTipoConstr.SelectedValue != null && cbxTipoConstr.SelectedValue.ToString() != string.Empty)
            {
                if (cbxTipoConstr.SelectedValue.ToString().Split('-')[1] == "U")
                {
                    if (_dtNotificacaoUnificacao.Rows.Count > 0)
                    {
                        foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow drLancamento in _dtNotificacaoLancamento.Rows)
                        {
                            if (drLancamento.SUBTIPO_IMOVEL.ToString() != "UNIFICAÇÃO" && drLancamento.SUBTIPO_IMOVEL.ToString() != "DESMEMBRAMENTO")
                            {
                                Mensagem.MsgAlert("Unificação/Desmembramento deverá ser o primeiro tipo de lançamento a ser efetuado.");
                                cbxTipoConstr.SelectedIndex = 0;
                                return;
                            }
                        }
                    }
                    else
                    {
                        Mensagem.MsgAlert("Não é possível unificar com apenas uma inscrição cadastral, insira uma nova inscrição na aba correspondente.");
                        cbxTipoConstr.SelectedIndex = 0;
                        return;
                    }
                }

                _dtTipoNotificacaoTipoImovel = blNotificacao.ListarSubTipoPorIdaPai(Convert.ToInt32(cbxTipoConstr.SelectedValue.ToString().Split('-')[0]), cbxTipoConstr.SelectedValue.ToString().Split('-')[1]);

                DataRow dr = _dtTipoNotificacaoTipoImovel.NewMO_NOTIFICACAO_SUBTIPORow();

                dr["DESCRICAO"] = "SELECIONE...";
                dr["SUBTIPO"] = "";

                _dtTipoNotificacaoTipoImovel.Rows.InsertAt(dr, 0);

                cbxTipoImovel.DataSource = _dtTipoNotificacaoTipoImovel;
                cbxTipoImovel.DisplayMember = "DESCRICAO";
                cbxTipoImovel.ValueMember = "SUBTIPO";

                if (cbxTipoConstr.SelectedValue.ToString().Split('-')[1] == "U")
                {
                    cbxTipoImovel.SelectedIndex = 1;
                    cbxSubtipoImovel.SelectedIndex = 1;
                }
                else if (cbxTipoConstr.SelectedValue.ToString().Split('-')[1] == "D")
                {
                    cbxTipoImovel.SelectedIndex = 1;
                    cbxSubtipoImovel.SelectedIndex = 1;
                }
            }
            else
            {
                cbxTipoImovel.DataSource = null;
                cbxTipoImovel.DisplayMember = "DESCRICAO";
                cbxTipoImovel.ValueMember = "SUBTIPO";
            }
        }

        private void cbxTipoImovel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxTipoImovel.SelectedValue != null && cbxTipoImovel.SelectedValue.ToString() != string.Empty)
            {
                _dtTipoNotificacaoSubNivel = blNotificacao.ListarSubTipoPorIdaPai(Convert.ToInt32(cbxTipoImovel.SelectedValue.ToString().Split('-')[0]), cbxTipoImovel.SelectedValue.ToString().Split('-')[1]);

                DataRow dr = _dtTipoNotificacaoSubNivel.NewMO_NOTIFICACAO_SUBTIPORow();

                dr["DESCRICAO"] = "SELECIONE...";
                dr["ID_INTERNO"] = 0;

                _dtTipoNotificacaoSubNivel.Rows.InsertAt(dr, 0);

                cbxSubtipoImovel.SelectedIndexChanged -= cbxSubtipoImovel_SelectedIndexChanged;

                cbxSubtipoImovel.DataSource = _dtTipoNotificacaoSubNivel;
                cbxSubtipoImovel.DisplayMember = "DESCRICAO";
                cbxSubtipoImovel.ValueMember = "ID_INTERNO";

                cbxSubtipoImovel.SelectedIndexChanged += cbxSubtipoImovel_SelectedIndexChanged;

                int val;

                if (Int32.TryParse(cbxTipoImovel.SelectedValue.ToString().Split('-')[0], out val))
                {
                    if (val == 6)
                    {
                        ckbMista.Visible = true;
                    }
                    else
                    {
                        ckbMista.Visible = false;
                        ckbMista.Checked = false;
                    }
                }
            }
            else
            {
                cbxSubtipoImovel.DataSource = null;
                cbxSubtipoImovel.DisplayMember = "DESCRICAO";
                cbxSubtipoImovel.ValueMember = "ID_INTERNO";
            }
        }

        private void rblSim_Click(object sender, EventArgs e)
        {
            RadioButton rbl = (RadioButton)sender;

            if (rbl.Text == "Não" && rbl.Checked)
            {
                txtInscriMun.Enabled = true;
            }
            else
            {
                txtInscriMun.Text = "";
                txtInscriMun.Enabled = false;
                txtCPFCNPJ.Enabled = true;

                errorProvider.SetError(txtInscriMun, "");
            }
        }

        private void cbxSubtipoImovel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSubtipoImovel.SelectedIndex == -1 || cbxSubtipoImovel.SelectedIndex == 0) { return; }
            LimparPastaLancamentoConstrucao();

            label74.Text = "Área a Construir:";
            label73.Text = "Área a Reformar:";

            grpAreas.Text = "Áreas utilizadas para apuração: (m²)";
            lblAreaBaseISSConstrucao.Text = "Área base de cáculo do ISS construção:";
            lblAreaBaseISSDemolicao.Text = "Área base de cálculo do ISS demolição:";
            lblAreaBaseISSReforma.Text = "Área base de cálculo do ISS reforma:";
            lblAreaBaseISSEng.Text = "Área base de cálculo ISS engenharia:";

            FormatarMedidas("m²");

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "12"))
            {
                ckbElevador.Enabled = true;
                ckbElevador.Visible = true;
                GroupBox4.Enabled = true;

                ckbImplantada.Visible = false;
                ckbImplantada.Enabled = false;

                label65.Enabled = false;
                txtDesmontavelLegalizar.Enabled = false;

                label66.Enabled = false;
                txtDesmontavelLegalizado.Enabled = false;

                label89.Enabled = false;
                txtNumeroUnidAutonomas.Enabled = false;

                label91.Enabled = false;
                txtAreaTerrenoDeduzir.Enabled = false;

                label97.Enabled = false;
                txtAreaTerrenoAumentar.Enabled = false;

                label95.Enabled = false;
                txtTestadaDeduzir.Enabled = false;

                label93.Enabled = false;
                txtTestadaAumentar.Enabled = false;

                label87.Enabled = false;
                txtAreaEdicula.Enabled = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "15" || cbxSubtipoImovel.SelectedValue.ToString() == "16" || cbxSubtipoImovel.SelectedValue.ToString() == "17" || cbxSubtipoImovel.SelectedValue.ToString() == "18" || cbxSubtipoImovel.SelectedValue.ToString() == "19" || cbxSubtipoImovel.SelectedValue.ToString() == "20" || cbxSubtipoImovel.SelectedValue.ToString() == "21" || cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26" || cbxSubtipoImovel.SelectedValue.ToString() == "27" || cbxSubtipoImovel.SelectedValue.ToString() == "28" || cbxSubtipoImovel.SelectedValue.ToString() == "38"))
            {
                ckbElevador.Enabled = true;
                ckbElevador.Visible = true;
                GroupBox4.Enabled = true;

                label63.Enabled = false;
                txtUnidades.Enabled = false;

                ckbImplantada.Visible = false;
                ckbImplantada.Enabled = false;

                label65.Enabled = false;
                txtDesmontavelLegalizar.Enabled = false;

                label66.Enabled = false;
                txtDesmontavelLegalizado.Enabled = false;

                label89.Enabled = false;
                txtNumeroUnidAutonomas.Enabled = false;

                label91.Enabled = false;
                txtAreaTerrenoDeduzir.Enabled = false;

                label97.Enabled = false;
                txtAreaTerrenoAumentar.Enabled = false;

                label95.Enabled = false;
                txtTestadaDeduzir.Enabled = false;

                label93.Enabled = false;
                txtTestadaAumentar.Enabled = false;

                label87.Enabled = false;
                txtAreaEdicula.Enabled = false;

                //label99.Enabled = false;
                //txtEnquadramento.Enabled = false;

                //label6.Enabled = false;
                //txtEnquadramentoReforma.Enabled = false;

                //label7.Enabled = false;
                //txtEnquadramentoDemolicao.Enabled = false;

                //label14.Enabled = false;
                //txtEnquadramentoPenalidade.Enabled = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14"))
            {
                ckbElevador.Enabled = true;
                ckbElevador.Visible = true;
                GroupBox4.Enabled = true;

                label63.Enabled = false;
                txtUnidades.Enabled = false;

                ckbImplantada.Visible = false;
                ckbImplantada.Enabled = false;

                label65.Enabled = false;
                txtDesmontavelLegalizar.Enabled = false;

                label66.Enabled = false;
                txtDesmontavelLegalizado.Enabled = false;

                label89.Enabled = false;
                txtNumeroUnidAutonomas.Enabled = false;

                label91.Enabled = false;
                txtAreaTerrenoDeduzir.Enabled = false;

                label97.Enabled = false;
                txtAreaTerrenoAumentar.Enabled = false;

                label95.Enabled = false;
                txtTestadaDeduzir.Enabled = false;

                label93.Enabled = false;
                txtTestadaAumentar.Enabled = false;

                label87.Enabled = false;
                txtAreaEdicula.Enabled = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33"))
            {
                FormatarMedidas("un");

                ckbElevador.Enabled = false;
                ckbElevador.Visible = false;
                GroupBox4.Enabled = true;

                label68.Enabled = false;
                txtAREA_TERRENO.Enabled = false;
                txtAREA_TERRENO.Text = "0";

                label67.Enabled = false;
                txtTESTADA_PRINCIPAL.Enabled = false;
                txtTESTADA_PRINCIPAL.Text = "0";

                label74.Enabled = false;
                txtAreaConstruir.Enabled = false;

                label70.Enabled = false;
                txtAreaLegalConstr.Enabled = false;

                label76.Enabled = false;
                txtAreaExistenteLegalConst.Enabled = false;

                label75.Enabled = false;
                txtAreaDemolir.Enabled = false;

                label72.Enabled = false;
                txtAreaLegalDemolir.Enabled = false;

                label73.Enabled = false;
                txtAreaReformar.Enabled = false;

                label69.Enabled = false;
                txtAreaLegalReformar.Enabled = false;

                label71.Enabled = false;
                txtAreaDecadConstr.Enabled = false;

                label82.Enabled = false;
                txtAreaDecadDemolir.Enabled = false;

                label87.Enabled = false;
                txtAreaEdicula.Enabled = false;

                ckbImplantada.Visible = false;
                ckbImplantada.Enabled = false;

                label65.Enabled = false;
                txtDesmontavelLegalizar.Enabled = false;

                label66.Enabled = false;
                txtDesmontavelLegalizado.Enabled = false;

                label91.Enabled = false;
                txtAreaTerrenoDeduzir.Enabled = false;

                label97.Enabled = false;
                txtAreaTerrenoAumentar.Enabled = false;

                label95.Enabled = false;
                txtTestadaDeduzir.Enabled = false;

                label93.Enabled = false;
                txtTestadaAumentar.Enabled = false;

                label77.Enabled = false;
                txtAreaTotal.Enabled = false;

                label99.Enabled = false;
                txtEnquadramento.Enabled = false;

                label6.Enabled = false;
                txtEnquadramentoReforma.Enabled = false;

                label7.Enabled = false;
                txtEnquadramentoDemolicao.Enabled = false;

                label14.Enabled = false;
                txtEnquadramentoPenalidade.Enabled = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36"))
            {
                ckbElevador.Enabled = false;
                ckbElevador.Visible = false;
                ckbImplantada.Visible = true;
                ckbImplantada.Enabled = true;

                GroupBox4.Enabled = true;

                label68.Enabled = false;
                txtAREA_TERRENO.Enabled = false;

                label67.Enabled = false;
                txtTESTADA_PRINCIPAL.Enabled = false;

                label74.Enabled = false;
                txtAreaConstruir.Enabled = false;

                label70.Enabled = false;
                txtAreaLegalConstr.Enabled = false;

                label76.Enabled = false;
                txtAreaExistenteLegalConst.Enabled = false;

                label75.Enabled = false;
                txtAreaDemolir.Enabled = false;

                label72.Enabled = false;
                txtAreaLegalDemolir.Enabled = false;

                label73.Enabled = false;
                txtAreaReformar.Enabled = false;

                label69.Enabled = false;
                txtAreaLegalReformar.Enabled = false;

                label71.Enabled = false;
                txtAreaDecadConstr.Enabled = false;

                label82.Enabled = false;
                txtAreaDecadDemolir.Enabled = false;

                label63.Enabled = false;
                txtUnidades.Enabled = false;

                label89.Enabled = false;
                txtNumeroUnidAutonomas.Enabled = false;

                label87.Enabled = false;
                txtAreaEdicula.Enabled = false;

                label65.Enabled = false;
                txtDesmontavelLegalizar.Enabled = false;

                label66.Enabled = false;
                txtDesmontavelLegalizado.Enabled = false;

                label91.Enabled = true;
                txtAreaTerrenoDeduzir.Enabled = true;

                label97.Enabled = true;
                txtAreaTerrenoAumentar.Enabled = true;

                label95.Enabled = true;
                txtTestadaDeduzir.Enabled = true;

                label93.Enabled = true;
                txtTestadaAumentar.Enabled = true;

                label77.Enabled = false;
                txtAreaTotal.Enabled = false;

                //label99.Enabled = false;
                //txtEnquadramento.Enabled = false;

                //label6.Enabled = false;
                //txtEnquadramentoReforma.Enabled = false;

                //label7.Enabled = false;
                //txtEnquadramentoDemolicao.Enabled = false;

                //label14.Enabled = false;
                //txtEnquadramentoPenalidade.Enabled = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42"))
            {
                ckbElevador.Enabled = false;
                ckbElevador.Visible = false;
                ckbImplantada.Visible = false;
                ckbImplantada.Enabled = false;

                GroupBox4.Enabled = true;

                label68.Enabled = false;
                txtAREA_TERRENO.Enabled = false;

                label67.Enabled = false;
                txtTESTADA_PRINCIPAL.Enabled = false;

                label74.Enabled = false;
                txtAreaConstruir.Enabled = false;

                label70.Enabled = false;
                txtAreaLegalConstr.Enabled = false;

                label76.Enabled = false;
                txtAreaExistenteLegalConst.Enabled = false;

                label75.Enabled = false;
                txtAreaDemolir.Enabled = false;

                label72.Enabled = false;
                txtAreaLegalDemolir.Enabled = false;

                label73.Enabled = false;
                txtAreaReformar.Enabled = false;

                label69.Enabled = false;
                txtAreaLegalReformar.Enabled = false;

                label71.Enabled = false;
                txtAreaDecadConstr.Enabled = false;

                label82.Enabled = false;
                txtAreaDecadDemolir.Enabled = false;

                label63.Enabled = false;
                txtUnidades.Enabled = false;

                label89.Enabled = false;
                txtNumeroUnidAutonomas.Enabled = false;

                label87.Enabled = false;
                txtAreaEdicula.Enabled = false;

                label65.Enabled = false;
                txtDesmontavelLegalizar.Enabled = false;

                label66.Enabled = false;
                txtDesmontavelLegalizado.Enabled = false;

                label91.Enabled = true;
                txtAreaTerrenoDeduzir.Enabled = true;

                label97.Enabled = true;
                txtAreaTerrenoAumentar.Enabled = true;

                label95.Enabled = true;
                txtTestadaDeduzir.Enabled = true;

                label93.Enabled = true;
                txtTestadaAumentar.Enabled = true;

                label77.Enabled = false;
                txtAreaTotal.Enabled = false;

                //label99.Enabled = false;
                //txtEnquadramento.Enabled = false;

                //label6.Enabled = false;
                //txtEnquadramentoReforma.Enabled = false;

                //label7.Enabled = false;
                //txtEnquadramentoDemolicao.Enabled = false;

                //label14.Enabled = false;
                //txtEnquadramentoPenalidade.Enabled = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && cbxSubtipoImovel.SelectedValue.ToString() == "12")
            {
                ckbElevador.Enabled = false;
                ckbElevador.Visible = false;
                GroupBox4.Enabled = true;

                label74.Text = "Área do Abrigo:";
                label73.Text = "Área a Reformar do Abrigo:";
            }

            else if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "16" || cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26" || cbxSubtipoImovel.SelectedValue.ToString() == "27" || cbxSubtipoImovel.SelectedValue.ToString() == "28" || cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33"))
            {
                ckbElevador.Enabled = false;
                ckbElevador.Visible = false;
            }

            if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26" || cbxSubtipoImovel.SelectedValue.ToString() == "27"))
            {
                FormatarMedidas("m");

                grpAreas.Text = "Metragem utilizadas para apuração: (m)";
                //lblAreaBaseISSConstrucao.Text = "Metragem base de cáculo do ISS construção:";
                //lblAreaBaseISSDemolicao.Text = "Metragem base de cálculo do ISS demolição:";
                //lblAreaBaseISSReforma.Text = "Metragem base de cálculo do ISS reforma:";
                //lblAreaBaseISSEng.Text = "Metragem base de cálculo ISS engenharia:";
            }
            else if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33"))
            {
                FormatarMedidas("un");

                grpAreas.Text = "Unidade utilizadas para apuração: (un)";
                //lblAreaBaseISSConstrucao.Text = "Unidade base de cáculo do ISS construção:";
                //lblAreaBaseISSDemolicao.Text = "Unidade base de cálculo do ISS demolição:";
                //lblAreaBaseISSReforma.Text = "Unidade base de cálculo do ISS reforma:";
                //lblAreaBaseISSEng.Text = "Unidade base de cálculo ISS engenharia:";
            }

            txtAREA_TERRENO_TextChanged(null, null);
        }

        private void btnBuscarUnificacao_Click(object sender, EventArgs e)
        {
            try
            {
                string tipoTributo = (rdbImob.Checked ? "I" : "M");

                CarregarInscricao(txtInscricaoUnificacao.Text.Trim(), tipoTributo, true);

            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Erro", ex);
            }
        }

        private void btnAdicionarUnificacao_Click(object sender, EventArgs e)
        {
            AdicionarUnificacao();

            txtAREA_TERRENO_TextChanged(null, null);
        }

        private void txtTestadaDeduzir_Validating(object sender, CancelEventArgs e)
        {
            if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36" || cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
            {
                if (Convert.ToDecimal(txtTestadaDeduzir.Text) >= Convert.ToDecimal(txtTESTADA_PRINCIPAL.Text))
                {
                    Mensagem.MsgAlert("Valor não pode ser maior ou igual ao Testada Principal.", "Aviso");

                    txtTestadaDeduzir.Text = "0";
                    txtTestadaDeduzir.Focus();
                }
            }
        }

        private void txtAreaTerrenoDeduzir_Validating(object sender, CancelEventArgs e)
        {
            if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36" || cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
            {
                if (Convert.ToDecimal(txtAreaTerrenoDeduzir.Text) >= Convert.ToDecimal(txtAREA_TERRENO.Text))
                {
                    Mensagem.MsgAlert("Valor não pode ser maior ou igual ao Área do Terreno.", "Aviso");

                    txtAreaTerrenoDeduzir.Text = "0";
                    txtAreaTerrenoDeduzir.Focus();
                }
            }
        }

        private void txtInscriMun_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                BL.Fiscalizacao.Certidao.ConsultaDebito blConsultaDebito = new BL.Fiscalizacao.Certidao.ConsultaDebito();

                if (txtInscriMun.Text != "")
                {
                    _dtDebito = blConsultaDebito.ObterDadosInscricao(txtInscriMun.Text);

                    if (_dtDebito.Rows.Count > 0)
                    {
                        if (IsCpf(_dtDebito.Rows[0]["CAD_MOBI_CNPJ"].ToString()))
                        {
                            string encerramento = _dtDebito.Rows[0]["CAD_MOBI_ENCERRAMENTO"].ToString();
                            string cancelamento = _dtDebito.Rows[0]["CAD_MOBI_CANCEL"].ToString();
                            string cassacao = _dtDebito.Rows[0]["CAD_MOBI_CASSACAO"].ToString();
                            string bloqueio = _dtDebito.Rows[0]["CAD_MOBI_BLOQUEIO"].ToString();

                            if (encerramento != string.Empty || cancelamento != string.Empty || cassacao != string.Empty || bloqueio != string.Empty)
                            {
                                Mensagem.MsgAlert("Inscrição municipal inativa.", "Aviso");
                                txtInscriMun.Text = "";
                            }
                            else
                            {
                                if (Mensagem.MsgYesNo("Atividade princial da inscrição : " + _dtDebito.Rows[0]["CAD_MOBI_DESC_ATIV1"].ToString() + ". Continuar? "))
                                {
                                    txtCPFCNPJ.Text = _dtDebito.Rows[0]["CAD_MOBI_CNPJ"].ToString().Replace(".", "").Replace("-", "").Replace("/", "");
                                    txtCPFCNPJ_Leave(null, null);
                                    txtCPFCNPJ.Enabled = false;
                                }
                                else
                                {
                                    txtInscriMun.Text = "";
                                }
                            }
                        }
                        else
                        {
                            Mensagem.MsgAlert("Permitido apenas pessoa física.");
                            txtInscriMun.Text = "";
                        }
                    }
                    else
                    {
                        Mensagem.MsgAlert("Inscrição municipal inválida.", "Aviso");
                        txtInscriMun.Text = "";
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void txtCPFResponsavel_Leave(object sender, EventArgs e)
        {
            if (txtCPFResponsavel.Text != string.Empty)
            {
                if (!Validacao.ValidaCPF(txtCPFResponsavel.Text))
                {
                    Mensagem.MsgAlert("CPF não é válido.", "Atenção");

                    txtCPFResponsavel.Text = "";
                    txtCPFResponsavel.Focus();
                }
            }
        }

        private void txtQtdeParcela_Validating(object sender, CancelEventArgs e)
        {
            if (status == "A" || status == "R" && txtQtdeParcela.Text != string.Empty)
            {
                if (tbcCadastro.SelectedTab == tbpParcelamento)
                {
                    drParametro = blTbParametro.BuscarAno(DateTime.Now.Year);

                    if (Convert.ToInt32(txtQtdeParcela.Text) > drParametro.MAXIMO_PARCELA)
                    {
                        Mensagem.MsgAlert("Número máximo de parcela permitido de " + drParametro.MAXIMO_PARCELA + " parcelas.");

                        txtQtdeParcela.Focus();
                    }
                    else
                    {
                        CalcularExpedienteAnterior();
                        CalcularParcelamento();
                        AtualizarAgrupamento();
                    }
                }
            }
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            if (modoTabela != Geral.ModoTabela.MODO_EDICAO && modoTabela != Geral.ModoTabela.MODO_INCLUSAO)
            {
                Mensagem.MsgAlert("Tabela deve estar no modo \"inclusão\" ou \"edição\".", "Gravação");
                return;
            }

            if (Mensagem.MsgYesNo("Deseja finalizar a notificação? Não será possivel voltar em edição e será gerado o parcelamento."))
            {
                try
                {
                    txtExigibilidade.Text = DateTime.Now.AddDays(32).ToShortDateString();
                    txtVencimento.Text = DateTime.Now.AddDays(32).ToShortDateString();
                    txtCiencia.Text = DateTime.Now.AddDays(2).ToShortDateString();

                    txtQtdeParcela_Validating(null, null);
                    TimeSpan date = Convert.ToDateTime(txtExigibilidade.Text) - Convert.ToDateTime(txtCiencia.Text);

                    int totalDias = date.Days;

                    if (totalDias > 45 || totalDias < 30)
                    {
                        Mensagem.MsgAlert("A data da exigibilidade não pode ser menor que 30 dias da data da ciência ou maior que 45 dias da data da ciência!");

                        return;
                    }

                    var valid = ValidacaoObrigatoriedadeParcelamento();
                    if (valid.Item1)
                    {
                        status = "F";

                        btnGravar_Click(null, null);
                    }
                    else
                    {
                        Mensagem.MsgAlert($"Complete ou inclua um responsável na {valid.Item2}", "Campos obrigatórios");
                    }
                }
                catch (Exception ex)
                {
                    Mensagem.MsgAlert("Ocorreu um erro na finalização da notificação. " + ex.Message);

                    _drNotificacao.SetDATA_NOTIFICACAONull();
                }
            }
        }

        private void tsmCalcular_Click(object sender, EventArgs e)
        {
            try
            {                
                UFV objUFV = new UFV();

                DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(DateTime.Now);

                drParametro = blTbParametro.BuscarAno(DateTime.Now.Year);

                txtExpediente.Text = (drParametro.EXPEDIENTE_UFV * drUFV.VALOR).ToString("N2");

                status = "R";

                txtExpediente.ReadOnly = false;
                txtQtdeParcela.Enabled = true;
                txtExigibilidade.Enabled = false;
                txtCiencia.Enabled = false;
                txtVencimento.Enabled = true;
                // pnlParcelamentoParcela.Enabled = true;

                txtQtdeParcela.ReadOnly = false;
                txtExigibilidade.ReadOnly = false;
                txtCiencia.ReadOnly = false;
                txtVencimento.ReadOnly = false;

                btnEfetivarReparcelar.Visible = true;
                btnCancelarOperacao.Visible = true;

                CarregarDadosParcela();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnCancelarOperacao_Click(object sender, EventArgs e)
        {
            try
            {
                status = "F";

                txtExpediente.ReadOnly = true;
                txtQtdeParcela.Enabled = false;
                txtExigibilidade.Enabled = false;
                txtCiencia.Enabled = false;
                txtVencimento.Enabled = false;
                txtExpedienteAnterior.Visible = false;
                txtExpedienteAnterior.Text = "0";
                lblExpedienteAnterior.Visible = false;
                //pnlParcelamentoParcela.Enabled = false;

                txtQtdeParcela.ReadOnly = true;
                txtExigibilidade.ReadOnly = true;
                txtCiencia.ReadOnly = true;
                txtVencimento.ReadOnly = true;

                penalidadeReparcelamento = 0;
                trocarExigibilidade = false;

                btnCancelarOperacao.Visible = false;
                btnEfetivarReparcelar.Visible = false;

                CarregarDadosParcela();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void btnOpcoesParcelamento_Click(object sender, EventArgs e)
        {
            if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoCancelarParcelamento))
            {

                Rectangle r = btnOpcoes.DisplayRectangle;

                btnOpcoesParcelamento.ContextMenuStrip = cmdParcelamento;
                btnOpcoesParcelamento.ContextMenuStrip.Show((Control)sender, new Point(r.Right / 2, r.Bottom));
            }
        }

        private void tsmCancelar_Click(object sender, EventArgs e)
        {
            try
            {
                if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault() != null)
                {
                    frmCancelamento frmCancelamento = new frmCancelamento
                    {
                        tipo = "P",
                        id = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().AVISO
                    };

                    frmCancelamento.ShowDialog();

                    string motivo = frmCancelamento.motivo;
                    string processo = frmCancelamento.processo;
                    string ano = frmCancelamento.ano;

                    DateTime data = frmCancelamento.data;

                    if (!string.IsNullOrEmpty(motivo))
                    {
                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                        dtr.CANCELAMENTO_DATA = data;
                        dtr.CANCELAMENTO_MOTIVO = motivo;
                        dtr.CANCELAMENTO_PROCESSO = processo;
                        dtr.CANCELAMENTO_PROCESSO_ANO = Convert.ToInt32(ano);
                        dtr.ATIVO = false;

                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICORow dtrHistorico = _dtNotificacaoHistorico.NewMO_NOTIFICACAO_LANCAMENTO_HISTORICORow();

                        dtrHistorico.DATA = data;
                        dtrHistorico.MOTIVO = motivo;
                        dtrHistorico.PROCESSO = processo;
                        dtrHistorico.PROCESSO_ANO = Convert.ToInt32(ano);
                        dtrHistorico.TIPO = "CANCELAMENTO DO PARCELAMENTO";
                        dtrHistorico.USUARIO_INCLUSAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;
                        dtrHistorico.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;

                        blNotificacao.CancelarParcelamento(dtr, dtrHistorico);

                        blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "CANCELAMENTO DO PARCELAMENTO Nº " + frmCancelamento.id + " REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO + "  Processo Cancelamento: " + processo + "  Motivo do Cancelamento: " + motivo, 0, 0, 97);

                        CarregarDadosParcela();

                        Mensagem.MsgInfo("Parcelamento cancelado.");
                    }
                }
                else
                {
                    Mensagem.MsgInfo("Não existe parcelamento ativo");
                }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Ocorreu um erro no processo de cancelar o parcelamento.");
            }
        }

        private void btnEfetivarReparcelar_Click(object sender, EventArgs e)
        {
            try
            {
                IncluirParcelamento();

                status = "F";

                if (trocarExigibilidade)
                {
                    _drNotificacao.DATA_EXIGIBILIDADE_ALTERADA = true;

                    blNotificacao.GravarNotificacao(_drNotificacao);

                    blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "ALTERAÇÃO DA DATA DE EXIGIBILIDADE REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO, 0, 0, 97);
                }

                blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "REPARCELAMENTO Nº " + "25" + txtCodParcelamento.Text.PadLeft(8, '0') + " REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO, 0, 0, 97);

                txtExpediente.ReadOnly = true;
                txtQtdeParcela.Enabled = false;
                txtExigibilidade.Enabled = false;
                txtCiencia.Enabled = false;
                txtVencimento.Enabled = false;
                txtExpedienteAnterior.Visible = false;
                txtExpedienteAnterior.Text = "0";
                lblExpedienteAnterior.Visible = false;

                penalidadeReparcelamento = 0;
                trocarExigibilidade = false;

                btnCancelarOperacao.Visible = false;
                btnEfetivarReparcelar.Visible = false;

                CarregarDados();
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Ocorreu um erro no processo reparcelamento da notificação.");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoCancelar))
                {
                    if (Mensagem.MsgYesNo("Deseja realmente cancelar a notificação?"))
                    {
                        if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault() == null)
                        {
                            frmCancelamento frmCancelamento = new frmCancelamento
                            {
                                tipo = "C",
                                id = txtNUMERO_NOTIFICACAO.Text
                            };

                            frmCancelamento.ShowDialog();

                            string motivo = frmCancelamento.motivo;
                            string processo = frmCancelamento.processo;

                            if (!string.IsNullOrEmpty(motivo))
                            {
                                _drNotificacao.CANCELAMENTO_DATA = Servidor.GetDataServidor();
                                _drNotificacao.CANCELAMENTO_MOTIVO = motivo;
                                _drNotificacao.CANCELAMENTO_PROCESSO = processo;
                                _drNotificacao.CANCELAMENTO_PROCESSO_ANO = Convert.ToInt32(frmCancelamento.ano);
                                _drNotificacao.STATUS = "C";
                                _drNotificacao.USUARIO_ALTERACAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;

                                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICORow dtrHistorico = _dtNotificacaoHistorico.NewMO_NOTIFICACAO_LANCAMENTO_HISTORICORow();

                                dtrHistorico.DATA = Servidor.GetDataServidor();
                                dtrHistorico.MOTIVO = motivo;
                                dtrHistorico.PROCESSO_ANO = Convert.ToInt32(frmCancelamento.ano);
                                dtrHistorico.PROCESSO = processo;
                                dtrHistorico.TIPO = "CANCELAMENTO";
                                dtrHistorico.USUARIO_INCLUSAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;
                                dtrHistorico.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;

                                blNotificacao.CancelarNotificacao(_drNotificacao, dtrHistorico);

                                blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "CANCELAMENTO REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO + "  Processo Cancelamento: " + processo + "  Motivo do Cancelamento: " + motivo, 0, 0, 97);

                                Mensagem.MsgAlert("Cancelamento efetuado com sucesso!");
                            }
                        }
                        else
                        {
                            Mensagem.MsgAlert("Efetue o cancelamento do parcelamento antes de prosseguir!");
                        }
                    }
                }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Ocorreu um erro no processo de cancelar a notificação.");
            }
        }

        private void btnSuspender_Click(object sender, EventArgs e)
        {
            try
            {
                if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoSuspender))
                {
                    if (btnSuspender.Text == "Suspender")
                    {
                        if (Mensagem.MsgYesNo("Deseja realmente suspender a notificação e o parcelamento ativo?"))
                        {
                            frmCancelamento frmCancelamento = new frmCancelamento
                            {
                                tipo = "S",
                                id = txtNUMERO_NOTIFICACAO.Text
                            };

                            frmCancelamento.ShowDialog();

                            string motivo = frmCancelamento.motivo;
                            string processo = frmCancelamento.processo;
                            string ano = frmCancelamento.ano;

                            DateTime data = frmCancelamento.data;

                            if (!string.IsNullOrEmpty(motivo))
                            {
                                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICORow dtrHistorico = _dtNotificacaoHistorico.NewMO_NOTIFICACAO_LANCAMENTO_HISTORICORow();

                                dtrHistorico.DATA = data;
                                dtrHistorico.MOTIVO = motivo;
                                dtrHistorico.PROCESSO = processo;
                                dtrHistorico.PROCESSO_ANO = Convert.ToInt32(ano);
                                dtrHistorico.TIPO = "SUSPENSÃO";
                                dtrHistorico.USUARIO_INCLUSAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;
                                dtrHistorico.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;

                                _drNotificacao.SUSPENSO = true;

                                blNotificacao.SuspenderNotificacao(_drNotificacao, dtrHistorico);

                                if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault() != null)
                                {
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().SUSPENSO = true;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().SUSPENSO_MOTIVO = motivo;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().SUSPENSO_PROCESSO = processo;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().SUSPENSO_PROCESSO = processo;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().SUSPENSO_DATA = Servidor.GetDataServidor();

                                    blNotificacao.SuspenderParcelamento(_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault());
                                }

                                Mensagem.MsgInfo("Notificação suspendida com sucesso!");

                                blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "SUSPENSÃO REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO + "  Processo Suspensão: " + processo + "  Motivo da Suspensão: " + motivo, 0, 0, 97);

                                CarregarDados();
                            }
                        }
                    }
                    else
                    {
                        if (Mensagem.MsgYesNo("Deseja realmente ativar a notificação?"))
                        {
                            frmCancelamento frmCancelamento = new frmCancelamento
                            {
                                tipo = "A",
                                id = txtNUMERO_NOTIFICACAO.Text
                            };

                            frmCancelamento.ShowDialog();

                            string motivo = frmCancelamento.motivo;
                            string processo = frmCancelamento.processo;
                            string ano = frmCancelamento.ano;
                            DateTime data = frmCancelamento.data;

                            if (!string.IsNullOrEmpty(motivo))
                            {
                                DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICORow dtrHistorico = _dtNotificacaoHistorico.NewMO_NOTIFICACAO_LANCAMENTO_HISTORICORow();

                                dtrHistorico.DATA = data;
                                dtrHistorico.MOTIVO = motivo;
                                dtrHistorico.PROCESSO = processo;
                                dtrHistorico.PROCESSO_ANO = Convert.ToInt32(ano);
                                dtrHistorico.TIPO = "ATIVAÇÃO";
                                dtrHistorico.USUARIO_INCLUSAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;
                                dtrHistorico.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;

                                _drNotificacao.SUSPENSO = false;

                                blNotificacao.SuspenderNotificacao(_drNotificacao, dtrHistorico);

                                if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault() != null)
                                {
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().SUSPENSO = false;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().ATIVACAO_MOTIVO = motivo;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().ATIVACAO_PROCESSO = processo;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().ATIVACAO_PROCESSO = processo;
                                    _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().ATIVACAO_DATA = Servidor.GetDataServidor();

                                    blNotificacao.SuspenderParcelamento(_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault());
                                }

                                blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "ATIVAÇÃO REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO + "  Processo Ativação: " + processo + "  Motivo da Ativação: " + motivo, 0, 0, 97);

                                Mensagem.MsgInfo("Notificação ativada com sucesso!");
                                CarregarDados();
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Ocorreu um erro no processo de Suspender/Ativar a notificação.");
            }
        }

        private void btnRerratificar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoRerratificar))
                {
                    if (Mensagem.MsgYesNo("Deseja realmente rerratificar a notificação?"))
                    {
                        if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault() == null)
                        {
                            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICORow dtrHistorico = _dtNotificacaoHistorico.NewMO_NOTIFICACAO_LANCAMENTO_HISTORICORow();

                            dtrHistorico.DATA = Servidor.GetDataServidor();
                            dtrHistorico.MOTIVO = "Notificação retificada";
                            dtrHistorico.PROCESSO = "";
                            dtrHistorico.PROCESSO_ANO = 0;
                            dtrHistorico.TIPO = "RETIFICAÇÃO";
                            dtrHistorico.USUARIO_INCLUSAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;
                            dtrHistorico.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;

                            blNotificacao.Retificar(_drNotificacao, _dtNotificacaoContribuinte, _dtNotificacaoLancamento, _dtNotificacaoUnificacao, dtrHistorico);

                            blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "RERRATIFICAÇÃO REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO, 0, 0, 97);

                            Mensagem.MsgAlert("Notificação rerratificada!");
                            CarregarDados();
                        }
                        else
                        {
                            Mensagem.MsgAlert("Efetue o cancelamento do parcelamento antes de prosseguir!");

                        }
                    }
                }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Ocorreu um erro no processo de rerratificação.");
            }
        }

        private void pcbData_Click(object sender, EventArgs e)
        {
            if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoDataExigibilidade))
            {

                if (Mensagem.MsgYesNo("Deseja alterar a data de exigibilidade da notificação?"))
                {
                    if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault() == null)
                    {
                        frmData objData = new frmData
                        {
                            idNotificacao = _drNotificacao.ID_NOTIFICACAO
                        };

                        objData.ShowDialog();

                        CarregarDados();
                    }
                    else
                    {
                        Mensagem.MsgAlert("Efetue o cancelamento do parcelamento antes de prosseguir!");
                    }
                }
            }
        }

        private void pcbDataCiencia_Click(object sender, EventArgs e)
        {
            if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoDataCiencia))
            {
                if (Mensagem.MsgYesNo("Deseja alterar a data da ciência da notificação?"))
                {
                    if (_dtNotificacaoParcelamento.Where(x => x.ATIVO == true).Count() > 0)
                    {
                        _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                        dtr.DATA_CIENCIA = Convert.ToDateTime(txtCiencia.Text);

                        blNotificacao.GravarParcelamento(dtr);
                    }
                    else
                    {
                        Mensagem.MsgAlert("Não existe parcelamento para alterar a data!");
                    }
                }
            }
        }

        private void demoonstrativoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RelVisualizador objRel = new RelVisualizador();

            objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "DP");
        }

        private void imprimirDemonstrativoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RelVisualizador objRel = new RelVisualizador();

            objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "D");
        }

        private void tsmEvento_Click(object sender, EventArgs e)
        {
            if (ValidacaoAba1() && ValidacaoAba2())
            {
                RelVisualizador objRel = new RelVisualizador();

                objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "C");
            }
            else
            {
                Mensagem.MsgAlert("Preencha todos os campos obrigatórios e complete ou inclua um responsável na sujeição passiva.", "Campos obrigatórios");
            }
        }

        private void carnêDeParcelamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RelVisualizador objRel = new RelVisualizador();

            objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "G");
        }

        private void termoDeConfissãoDeDivídaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RelVisualizador objRel = new RelVisualizador();

            objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "TC");
        }

        private void saldoDevedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RelVisualizador objRel = new RelVisualizador();

            objRel.ShowDialog(Convert.ToInt32(txtID_NOTIFICACAO.Text), "SD");
        }

        private void btnDa_Click(object sender, EventArgs e)
        {
            try
            {
                if (!_drNotificacao.SUSPENSO)
                {
                    _dtNotificacaoParcelamento = blNotificacao.ObterParcelamento(_drNotificacao.ID_NOTIFICACAO);

                    DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTORow dtr = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault();

                    if (dtr == null)
                    {
                        if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoTermoRemessa))
                        {
                            frmTermoRemessa frmTermo = new frmTermoRemessa
                            {
                                idNotificacao = _drNotificacao.ID_NOTIFICACAO,
                                numeroNotificacao = txtNUMERO_NOTIFICACAO.Text + "/" + txtANO_NOTIFICACAO.Text
                            };

                            frmTermo.ShowDialog();
                        }
                    }
                    else
                    {
                        Mensagem.MsgAlert("Não é possível encaminhar para D.A enquanto houver um parcelamento ativo.");
                    }
                }
                else
                {
                    Mensagem.MsgAlert("Não é possível encaminhar para D.A enquanto a notificação estiver suspensa.");
                }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Ocorreu um erro no processo do termo de remessa. ");
            }
        }

        private void txtCiencia_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                Convert.ToDateTime((sender as TextBox).Text);

                //if ((sender as TextBox).Name == "txtCiencia")
                //{
                TimeSpan date = Convert.ToDateTime(txtExigibilidade.Text) - Convert.ToDateTime(txtCiencia.Text);

                int totalDias = date.Days;

                if (totalDias > 45 || totalDias < 30)
                {
                    Mensagem.MsgAlert("A data da exigibilidade não pode ser menor que 30 dias da data da ciência ou mais que 45 dias da data da ciência!");
                    (sender as TextBox).Focus();
                }
                // }
            }
            catch (Exception)
            {
                Mensagem.MsgAlert("Informe uma data válida");
                (sender as TextBox).Focus();
            }

        }

        private void ckbQualificacao_Click(object sender, EventArgs e)
        {
            if (ckbQualificacao.Text == "Proprietário/Possuidor")
            {
                ckbSubnivelProp.Visible = true;
                ckbSubnivel.Visible = false;
            }
            if (ckbQualificacao.Text == "Responsável Técnico")
            {
                ckbSubnivelProp.Visible = false;
                ckbSubnivel.Visible = true;
            }
        }

        private void rdbIncidenciaSim_Click(object sender, EventArgs e)
        {
            RadioButton rbl = (RadioButton)sender;

            if (rbl.Text == "Sim" && rbl.Checked)
            {
                cobrarIssconstrucao = true;
                txtIncidencia.Enabled = false;
                txtIncidencia.Text = "";
            }
            else if (rbl.Text == "Não" && rdbDiferimentoNao.Checked)
            {
                cobrarIssconstrucao = false;
                txtIncidencia.Enabled = true;
            }
            else if (rbl.Text == "Não" && rdbDiferimentoSim.Checked)
            {
                rdbIncidenciaSim.Checked = true;
                cobrarIssconstrucao = true;
                txtIncidencia.Enabled = false;
                Mensagem.MsgAlert("Selecione NÃO para 'Diferimento' para não incidir o ISS Construção.");
            }

            if (_dtNotificacaoLancamento.Rows.Count > 0)
            {
                foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow item in _dtNotificacaoLancamento)
                {
                    if (item.RowState != DataRowState.Deleted)
                    {
                        if (cobrarIssconstrucao)
                            item.IMPOSTO_ISS_CONSTRUCAO = item.IMPOSTO_ISS_CONSTRUCAO_SECUNDARIO;
                        else
                            item.IMPOSTO_ISS_CONSTRUCAO = 0;
                    }
                }
            }
        }

        private void rdbDiferimentoSim_Click(object sender, EventArgs e)
        {
            RadioButton rbl = (RadioButton)sender;

            if (rbl.Text == "Sim" && rbl.Checked && rdbIncidenciaSim.Checked)
            {
                txtDiferimento.Enabled = true;
                diferimento = true;

                txtExigibilidade.Text = DateTime.Now.AddDays(182).ToShortDateString();
                txtVencimento.Text = DateTime.Now.AddDays(182).ToShortDateString();
            }
            if (rbl.Text == "Sim" && rbl.Checked && !rdbIncidenciaSim.Checked)
            {
                Mensagem.MsgAlert("Selecione SIM para 'Incidência do ISS da Construção' para utilizar o diferimento");
                rdbDiferimentoSim.Checked = false;
                return;
            }
            if (rbl.Text == "Não" && rbl.Checked)
            {
                txtDiferimento.Enabled = false;
                txtDiferimento.Text = "";
                diferimento = false;

                txtExigibilidade.Text = DateTime.Now.AddDays(32).ToShortDateString();
                txtVencimento.Text = DateTime.Now.AddDays(32).ToShortDateString();
            }

            if (_dtNotificacaoLancamento.Rows.Count > 0)
            {
                foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow item in _dtNotificacaoLancamento)
                {
                    if (item.RowState != DataRowState.Deleted)
                    {
                        if (diferimento)
                        {
                            item.IMPOSTO_ISS_ENGENHARIA = 0;
                            item.IMPOSTO_ISS_REFORMA = 0;
                            item.IMPOSTO_ISS_DEMOLICAO = 0;
                            item.TX_ALINHAMENTO = 0;
                            item.TX_ALVARA = 0;
                            item.TX_PENALIDADES = 0;
                            item.TX_LICENCA_CONSTRUCAO = 0;
                            item.TX_LICENCA_REFORMA_DEMOLICAO = 0;
                        }
                        else
                        {
                            item.IMPOSTO_ISS_ENGENHARIA = item.IMPOSTO_ISS_ENGENHARIA_SECUNDARIO;
                            item.IMPOSTO_ISS_REFORMA = item.IMPOSTO_ISS_REFORMA_SECUNDARIO;
                            item.IMPOSTO_ISS_DEMOLICAO = item.IMPOSTO_ISS_DEMOLICAO_SECUNDARIO;
                            item.TX_ALINHAMENTO = item.TX_ALINHAMENTO_SECUNDARIO;
                            item.TX_ALVARA = item.TX_ALVARA_SECUNDARIO;
                            item.TX_PENALIDADES = item.TX_PENALIDADES_SECUNDARIO;
                            item.TX_LICENCA_CONSTRUCAO = item.TX_LICENCA_CONSTRUCAO_SECUNDARIO;
                            item.TX_LICENCA_REFORMA_DEMOLICAO = item.TX_LICENCA_REFORMA_DEMOLICAO_SECUNDARIO;
                        }
                    }
                }
            }

            txtAREA_TERRENO_TextChanged(null, null);
        }
        
        private void btnExcluirContribuinte_Click(object sender, EventArgs e)
        {
            DataGridViewRow linha = dgvContribuinte.Rows[dgvContribuinte.CurrentRow.Index];
            if (Mensagem.MsgYesNo($"{linha.Cells[2].Value} - {linha.Cells[4].Value} \n \n Confirma exclusão?", "Exclusão"))
            {
                mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.RemoveCurrent();

                LimparPastaContrib(true);

                cobrarIssEngenharia = true;

                for (int i = 0; i < _dtNotificacaoContribuinte.Rows.Count; i++)
                {
                    if (_dtNotificacaoContribuinte.Rows[i].RowState != DataRowState.Deleted)
                    {
                        if (_dtNotificacaoContribuinte.Rows[i]["QUALIFICACAO"].ToString().Contains("3-"))
                        {
                            string INSCRICAO_MUNICIPAL = _dtNotificacaoContribuinte.Rows[i]["INSCRICAO_MUNICIPAL"].ToString();

                            if (INSCRICAO_MUNICIPAL != string.Empty)
                            {
                                cobrarIssEngenharia = false;
                            }
                            else
                            {
                                cobrarIssEngenharia = true;
                                break;
                            }
                        }
                    }
                }

                if (_dtNotificacaoLancamento.Rows.Count > 0)
                {
                    foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_LANCAMENTORow item in _dtNotificacaoLancamento)
                    {
                        if (item.RowState != DataRowState.Deleted)
                        {
                            if (cobrarIssEngenharia)
                                item.IMPOSTO_ISS_ENGENHARIA = item.IMPOSTO_ISS_ENGENHARIA_SECUNDARIO;
                            else
                                item.IMPOSTO_ISS_ENGENHARIA = 0;
                        }
                    }
                }
            }
        }

        private void btnIncluirContribuinte_Click(object sender, EventArgs e)
        {
            modoTabelaContribuinte = Geral.ModoTabela.MODO_INCLUSAO;
            LimparPastaContrib(true);
        }

        private void btnEditarContribuinte_Click(object sender, EventArgs e)
        {
            modoTabelaContribuinte = Geral.ModoTabela.MODO_EDICAO;
            //DesabilitarCampos(false);
        }

        private void DesabilitarContribuinte(bool isDesabilitado)
        {
            btnGravarContribuinte.Enabled = false;

            grpSujeicao.Enabled = false;
            btnIncluirContribuinte.Enabled = isDesabilitado;
            btnEditarContribuinte.Enabled = isDesabilitado;
            btnExcluirContribuinte.Enabled = isDesabilitado;

            grpConstrucao.Enabled = false;
            btnIncluirConstrucao.Enabled = isDesabilitado;
            btnEditarConstrucao.Enabled = isDesabilitado;
            btnExcluirConstrucao.Enabled = isDesabilitado;
        }

        private void btnLimparContribuinte_Click(object sender, EventArgs e)
        {
            modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;
        }

        private void btnGravarContribuinte_Click(object sender, EventArgs e)
        {
            modoTabelaContribuinte = Geral.ModoTabela.MODO_CONSULTA;

        }

        private void rdbAvisoRecebimento_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rdbExigibilidade_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rdbExigibilidade_Click(object sender, EventArgs e)
        {
            txtDataIntimacao.Visible = false;
            pcbData.Visible = false;
            label5.Visible = false;
            if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoDataExigibilidade))
            {
                DateTime dt;
                if(DateTime.TryParse(txtDATA_NOTIFICACAO.Text, out dt))
                //if (Mensagem.MsgYesNo("Deseja alterar a data de exigibilidade da notificação?"))
                {
                    //lblDataIntimacao.Visible = false;
                    DateTime dti = BL.Shared.Utilitario.Geral.ProximoDiaUtil(Convert.ToDateTime(txtDATA_NOTIFICACAO.Text).AddDays(1));
                    DateTime dta = dti.AddDays(7);
                    DateTime dtb = BL.Shared.Utilitario.Geral.ProximoDiaUtil(dta);
                    txtCiencia.Text = dtb.ToString("d");
                    dta = dtb.AddDays(30);
                    dtb = BL.Shared.Utilitario.Geral.ProximoDiaUtil(dta);
                    txtExigibilidade.Text = dtb.ToString("d");
                }
            }
        }

        private void rdbAvisoRecebimento_Click(object sender, EventArgs e)
        {
            txtDataIntimacao.Visible = true;
            pcbData.Visible = true;
            label5.Visible = true;
            if (!String.IsNullOrEmpty(txtDataIntimacao.Text))
            {
                if (Permissao.VerAcesso(EnumDLL.Permissao.NL_NotificacaoLancamentoDataExigibilidade))
                {
                    CalculoDataCiencia();
                }
            }
        }

        private void CalculoDataCiencia()
        {
            {
                //lblDataIntimacao.Visible = true;
                txtCiencia.Text = Convert.ToDateTime(txtDataIntimacao.Text).ToString("d");
                DateTime dta = Convert.ToDateTime(txtCiencia.Text).AddDays(30);
                DateTime dtb = BL.Shared.Utilitario.Geral.ProximoDiaUtil(dta);
                txtExigibilidade.Text = dtb.ToString("d");
            }

        }

        private void btnIncluirConstrucao_Click(object sender, EventArgs e)
        {
            modoTabelaConstrucao = Geral.ModoTabela.MODO_INCLUSAO;
            LimparPastaLancamentoConstrucao();
        }

        private void btnEditarConstrucao_Click(object sender, EventArgs e)
        {
            modoTabelaConstrucao = Geral.ModoTabela.MODO_EDICAO;
        }

        private void btnExcluirConstrucao_Click(object sender, EventArgs e)
        {
            DataGridViewRow linha = dgvLancamentoConstrucao.Rows[dgvLancamentoConstrucao.CurrentRow.Index];
            if (Mensagem.MsgYesNo($"{linha.Cells[2].Value} - {linha.Cells[4].Value} \n \n Confirma exclusão?", "Exclusão"))
            {
                mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.RemoveCurrent();

                LimparPastaLancamentoConstrucao();
            }

        }

        private void btnLimparConstrucao_Click(object sender, EventArgs e)
        {
            modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
        }

        private void btnGravarConstrucao_Click(object sender, EventArgs e)
        {
            bool validado = true;

            #region Validação campos obrigatórios primeira aba

            if (Decimal.Parse(txtAreaConstruir.Text) != 0 && Decimal.Parse(txtEnquadramento.Text) <= 0)
            {
                errorProvider.SetError(txtEnquadramento, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaLegalConstr.Text) != 0 && Decimal.Parse(txtEnquadramento.Text) <= 0)
            {
                errorProvider.SetError(txtEnquadramento, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaLegalConstr.Text) != 0 && Decimal.Parse(txtEnquadramentoPenalidade.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoPenalidade, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaReformar.Text) != 0 && Decimal.Parse(txtEnquadramentoReforma.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoReforma, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaLegalReformar.Text) != 0 && Decimal.Parse(txtEnquadramentoReforma.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoReforma, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaLegalReformar.Text) != 0 && Decimal.Parse(txtEnquadramentoPenalidade.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoPenalidade, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaDemolir.Text) != 0 && Decimal.Parse(txtEnquadramentoDemolicao.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoDemolicao, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaLegalDemolir.Text) != 0 && Decimal.Parse(txtEnquadramentoDemolicao.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoDemolicao, "Campo obrigatório");
                validado = false;
            }
            if (Decimal.Parse(txtAreaLegalDemolir.Text) != 0 && Decimal.Parse(txtEnquadramentoPenalidade.Text) == 0)
            {
                errorProvider.SetError(txtEnquadramentoPenalidade, "Campo obrigatório");
                validado = false;
            }

            #endregion

            if (validado)
            {
                AdicionarLancamentoConstrucao();

                txtQtdeParcela.ReadOnly = false;
                txtExigibilidade.ReadOnly = false;
                txtCiencia.ReadOnly = false;
                txtVencimento.ReadOnly = false;

                modoTabelaConstrucao = Geral.ModoTabela.MODO_CONSULTA;
                CarregarGridLancamentoConstrucao();
            }

        }

        private void txtEnquadramento_Leave(object sender, EventArgs e)
        {
            /*chkEnquadramentoConstrucao.Checked = true;
            Int32 val;
            if (Int32.TryParse(txtEnquadramento.Text, out val))
            {
                decimal areatotal = Decimal.Parse(txtAreaTotal.Text);
                decimal numeroUnidades = decimal.Parse(txtUnidades.Text);
                Decimal areaFinsEnquadramento = areatotal / (numeroUnidades == 0 ? 1 : numeroUnidades);
                if (val <= 0 || areaFinsEnquadramento == val)
                {
                    chkEnquadramentoConstrucao.Checked = false;
                    txtEnquadramento.Text = "";
                }
                else
                {
                    txtEnquadramento.Text = val.ToString("N2");
                }
            }*/
            txtAREA_TERRENO_TextChanged(sender, e);
        }

        private void txtDataIntimacao_Leave(object sender, EventArgs e)
        {
            if(rdbAvisoRecebimento.Checked)
            {
                rdbAvisoRecebimento_Click(null, null);
            }
        }

        private void txtEnquadramentoBaseISS_Leave(object sender, EventArgs e)
        {
            /*
            if (chkEnquadramentoBaseISS.Checked)
            {
                decimal val;
                if (decimal.TryParse(txtEnquadramentoBaseISS.Text, out val))
                {
                    if (val <= 0)
                    {
                        chkEnquadramentoBaseISS.Checked = false;
                        txtEnquadramentoBaseISS.Text = "";
                    }
                }
            }*/

            txtAREA_TERRENO_TextChanged(sender, e);

        }

        private void txtCamposDecimal(object sender, EventArgs e)
        {
            decimal valor;
            if(decimal.TryParse((sender as TextBox).Text, out valor))
            {
                (sender as TextBox).Text = valor.ToString("N2");

            }
            txtAREA_TERRENO_TextChanged(sender, e);
        }

        private void chkEnquadramentoBaseISS_CheckStateChanged(object sender, EventArgs e)
        {
            if (!(sender as CheckBox).Checked)
            {
                txtAREA_TERRENO_TextChanged(sender, e);
            }

        }

        private void txtAreaTotal_TextChanged(object sender, EventArgs e)
        {
            if(Convert.ToDouble((sender as TextBox).Text) < 0 )
            {
                (sender as TextBox).BackColor = Color.Red;
            }
            else
            {
                (sender as TextBox).BackColor = Color.White;
            }
        }

        private void txtEnquadramentoDemolicao_Leave(object sender, EventArgs e)
        {
            txtAREA_TERRENO_TextChanged(sender, e);
        }

        private void btnBaixaManual_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvParcela.SelectedCells.Count > 0 && dgvParcela.Rows[dgvParcela.SelectedCells[0].RowIndex].Cells["DATA_BAIXA"].Value.ToString() == string.Empty)
                {
                    frmBaixa objBaixa = new frmBaixa();

                    //                    DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow dtrParcela = _dtNotificacaoParcela.Where(x => x.ID_NOTIFICACAO_PARCELAMENTO_PARCELA == Convert.ToInt32(dgvParcela.Rows[e.RowIndex].Cells["idParcela"].Value)).FirstOrDefault();
                    DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow dtrParcela = _dtNotificacaoParcela.Where(x => x.ID_NOTIFICACAO_PARCELAMENTO_PARCELA == Convert.ToInt32(dgvParcela.Rows[dgvParcela.SelectedCells[0].RowIndex].Cells["idParcela"].Value)).FirstOrDefault();
                    objBaixa.id = _dtNotificacaoParcelamento.Where(x => x.ATIVO == true).FirstOrDefault().AVISO;
                    objBaixa.valor = dtrParcela.TOTAL;
                    objBaixa.parcela = dtrParcela.PARCELA.ToString();

                    objBaixa.ShowDialog();

                    if (objBaixa.efetuado)
                    {
                        if (dtrParcela.PARCELA == 99)
                        {
                            //dtrParcela.VALOR_PAGO = objBaixa.valor;
                            dtrParcela.DATA_BAIXA = objBaixa.dtBaixa;
                            dtrParcela.DATA_PAGAMENTO = objBaixa.dtPago;

                            blNotificacao.IncluirParcela(dtrParcela);

                            //EFETUAR A BAIXA EM TODAS AS PARCELAS PELO FATO DE PAGAR A PARCELA UNICA.
                            foreach (DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow item in _dtNotificacaoParcela.Where(x => x.PARCELA != 99).ToList())
                            {
                                item.DATA_BAIXA = objBaixa.dtBaixa;
                                item.DATA_PAGAMENTO = objBaixa.dtPago;

                                blNotificacao.IncluirParcela(item);
                            }
                        }
                        else
                        {
                            //dtrParcela.VALOR_PAGO = objBaixa.valor;
                            dtrParcela.DATA_BAIXA = objBaixa.dtBaixa;
                            dtrParcela.DATA_PAGAMENTO = objBaixa.dtPago;

                            blNotificacao.IncluirParcela(dtrParcela);

                            //PARA EXCLUIR A PARCELA UNICA SE AINDA NÃO BAIXA

                            DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELARow dtrParcelaUnica = _dtNotificacaoParcela.Where(x => x.PARCELA == 99).FirstOrDefault();

                            if (dtrParcelaUnica != null)
                            {
                                dtrParcelaUnica.EXCLUIDO = true;

                                blNotificacao.IncluirParcela(dtrParcelaUnica);
                            }
                        }

                        blEventoImobiliario.IncluirEventoImobiliario(_drNotificacao.INSCRICAO, DateTime.Now, (tipoNotificacao == "NL" ? "BAIXA DA PARCELA Nº " + dtrParcela.PARCELA + " DO PARCELAMENTO Nº " + objBaixa.id + " REFERENTE A NOTIFICAÇÃO Nº " : "AUTO DE INFRAÇÃO Nº ") + "  " + _drNotificacao.NUMERO_NOTIFICACAO.ToString() + "/" + _drNotificacao.ANO_NOTIFICACAO.ToString(), "Código: " + _drNotificacao.ID_NOTIFICACAO.ToString() + "  Processo: " + _drNotificacao.NUMERO_PROCESSO + " data da baixa " + objBaixa.dtBaixa + "Motivo " + objBaixa.motivo, 0, 0, 97);

                        DSNotificacaoLancamento.MO_NOTIFICACAO_LANCAMENTO_HISTORICORow dtrHistorico = _dtNotificacaoHistorico.NewMO_NOTIFICACAO_LANCAMENTO_HISTORICORow();

                        dtrHistorico.DATA = Servidor.GetDataServidor();
                        dtrHistorico.MOTIVO = "BAIXA DA PARCELA Nº " + objBaixa.parcela + " DO PARCELAMENTO Nº " + objBaixa.id + " data da baixa " + objBaixa.dtBaixa.ToShortDateString() + " Motivo " + objBaixa.motivo;
                        dtrHistorico.PROCESSO = objBaixa.processo;

                        if (objBaixa.ano == "")
                        {
                            dtrHistorico.SetPROCESSO_ANONull();
                        }
                        else
                        {
                            dtrHistorico.PROCESSO_ANO = Convert.ToInt32(objBaixa.ano);
                        }

                        dtrHistorico.TIPO = "BAIXA DE PARCELA";
                        dtrHistorico.USUARIO_INCLUSAO = UsuarioLogado.drUsuarioLogado.NOME_LOGIN;
                        dtrHistorico.ID_NOTIFICACAO = _drNotificacao.ID_NOTIFICACAO;

                        blNotificacao.IncluirHistorico(dtrHistorico);

                        Mensagem.MsgInfo("Baixa manual efetivada com sucesso!");

                        CarregarDadosParcela();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        #endregion
        #region "Eventos Calculos"
        private void txtAREA_TERRENO_TextChanged(object sender, EventArgs e)
        {
            errorProvider.Clear();
            try
            {
                #region "Preencher Valores"

                decimal baseIssConstrucao = 0;
                decimal baseIssDemolicao = 0;
                decimal baseIssReforma = 0;
                decimal areaTotal = 0;
                decimal areaTerreno = Convert.ToDecimal(txtAREA_TERRENO.Text); // 1
                decimal testadaPrincipal = Convert.ToDecimal(txtTESTADA_PRINCIPAL.Text); // 2
                decimal areaConstruir = Convert.ToDecimal(txtAreaConstruir.Text); // 3
                decimal areaLegalConstr = Convert.ToDecimal(txtAreaLegalConstr.Text);// 5
                decimal areaExistenteLegalConst = Convert.ToDecimal(txtAreaExistenteLegalConst.Text);// 7
                decimal areaDemolir = Convert.ToDecimal(txtAreaDemolir.Text);// 8
                decimal areaReformar = Convert.ToDecimal(txtAreaReformar.Text);// 4
                decimal areaLegalDemolir = Convert.ToDecimal(txtAreaLegalDemolir.Text);// 9
                decimal areaLegalReformar = Convert.ToDecimal(txtAreaLegalReformar.Text);// 6
                decimal areaDecadConstr = Convert.ToDecimal(txtAreaDecadConstr.Text);// 10
                decimal areaDecadDemolir = Convert.ToDecimal(txtAreaDecadDemolir.Text);// 11
                decimal areaEdicula = Convert.ToDecimal(txtAreaEdicula.Text);// 21
                decimal areaTestadaAumentar = Convert.ToDecimal(txtTestadaAumentar.Text);// 20
                decimal areaTestadaDeduzir = Convert.ToDecimal(txtTestadaDeduzir.Text);// 19
                decimal areaTerrenoAumentar = Convert.ToDecimal(txtAreaTerrenoAumentar.Text);// 18
                decimal areaTerrenoDeduzir = Convert.ToDecimal(txtAreaTerrenoDeduzir.Text);// 17
                decimal areaFinsEnquadramento = 0;
                decimal areaFinsEnquadramentoDemolicao = 0;
                decimal valorUFM = 0;
                decimal valorUFMConstrucao = 0;
                decimal valorUFMReforma = 0;
                decimal valorUFMDemolicao = 0;
                decimal valorTabela = 0;
                decimal aliquota = 0;
                decimal totalizado = 0;
                int numeroUnidades = Convert.ToInt32(txtUnidades.Text); //12
                int numeroUnidadesAutonomaas = Convert.ToInt32(txtNumeroUnidAutonomas.Text); //12

                ISSdemolicaoDescricaoUFM = string.Empty;
                ISSreformaDescricaoUFM = string.Empty;
                ISSconstrucaoDescricaoUFM = string.Empty;
                ISSengenhariaDescricaoUFM = string.Empty;
                TXlicencaDescricaoUFM = string.Empty;
                TXconstrucaoDescricaoUFM = string.Empty;
                TXalinhamentoDescricaoUFM = string.Empty;
                TXalvaraDescricaoUFM = string.Empty;
                TXnumeracaoPredialDescricaoUFM = string.Empty;
                TXpenalidadeDescricaoUFM = string.Empty;
                aliquotaConstrucao = 0;
                aliquotaEngenharia = 0;

                UFV objUFV = new UFV();

                DL.Shared.DS.DSShared.SH_UFVRow drUFV = objUFV.BuscarData(DateTime.Now);

                valorTabela = drUFV.VALOR;

                #endregion

                _dtParametro = blNotificacao.ObterParametro();

                #region Area Utilizada para apuração

                //areaTotal = areaConstruir + areaLegalConstr + areaExistenteLegalConst - areaDemolir - areaLegalDemolir;                
                areaTotal = areaConstruir + areaLegalConstr + areaDecadConstr + areaExistenteLegalConst - areaDemolir - areaLegalDemolir;

                txtAreaTotal.Text = areaTotal.ToString("N2"); // 22

                //blNotificacao.ListarSubTipoPorIdaPai(Convert.ToInt32(cbxTipoImovel.SelectedValue.ToString().Split('-')[0]), cbxTipoImovel.SelectedValue.ToString().Split('-')[1]);

                //if (cbxSubtipoImovel.SelectedValue != null && (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "13"))
                //{
                //    areaFinsEnquadramento = areaTotal / (numeroUnidades == 0 ? 1 : numeroUnidades);
                //    txtEnquadramento.Text = areaFinsEnquadramento.ToString("N2"); //23
                //}

                #endregion

                #region Base Calculo ISS Construção e Imposto

                #region Obter UFM
                if (!chkEnquadramentoConstrucao.Checked)
                {
                    areaFinsEnquadramento = areaTotal / (numeroUnidades == 0 ? 1 : numeroUnidades);
                }
                else
                {
                    areaFinsEnquadramento = decimal.Parse(txtEnquadramento.Text) / (numeroUnidades == 0 ? 1 : numeroUnidades);
                }
                txtEnquadramento.Text = areaFinsEnquadramento.ToString("N2"); //23
                if (!chkEnquadramentoDemolicao.Checked)
                {
                    areaFinsEnquadramentoDemolicao = decimal.Parse(txtAreaDemolir.Text) + decimal.Parse(txtAreaLegalDemolir.Text) - decimal.Parse(txtAreaDecadDemolir.Text);
                }
                else
                {
                    areaFinsEnquadramentoDemolicao = decimal.Parse(txtEnquadramentoDemolicao.Text);
                }
                txtEnquadramentoDemolicao.Text = areaFinsEnquadramentoDemolicao.ToString("N2");
                if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "12")
                {
                    _dtUFM = blNotificacao.ObterEnquadramento("ISSC", cbxSubtipoImovel.SelectedValue.ToString(), Convert.ToDecimal(txtEnquadramento.Text));

                    valorUFMConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                    aliquotaConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                    ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                    tipEnquadramento.SetToolTip(label99, $"O Valor da UFM Construção é {valorUFMConstrucao}");

                    _dtUFM = blNotificacao.ObterEnquadramento("ISSC", cbxSubtipoImovel.SelectedValue.ToString(), Convert.ToDecimal(txtEnquadramentoReforma.Text));

                    valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                    aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                    ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();

                    _dtUFM = blNotificacao.ObterEnquadramento("ISSC", cbxSubtipoImovel.SelectedValue.ToString(), Convert.ToDecimal(txtEnquadramentoDemolicao.Text));

                    valorUFMDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                    aliquotaDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                    ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_DEMOLICAO"].ToString();
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "13")
                {
                    if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramento.Text) > 200)
                    {
                        //OBTER DADOS DO RESIDENCIAL CASA/SOBRADO
                        _dtUFM = blNotificacao.ObterEnquadramento("ISSC", "11", Convert.ToDecimal(txtEnquadramento.Text));

                        valorUFMConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(4);

                        valorUFMConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                    }
                    if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoDemolicao.Text) > 200)
                    {
                        //OBTER DADOS DO RESIDENCIAL CASA/SOBRADO
                        _dtUFM = blNotificacao.ObterEnquadramento("ISSC", "11", Convert.ToDecimal(txtEnquadramentoDemolicao.Text));

                        valorUFMDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_DEMOLICAO"].ToString();
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(4);

                        valorUFMDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                    if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoReforma.Text) > 200)
                    {
                        _dtUFM = blNotificacao.ObterEnquadramento("ISSC", "11", Convert.ToDecimal(txtEnquadramentoReforma.Text));

                        //OBTER DADOS DO RESIDENCIAL CASA/SOBRADO
                        valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(4);

                        valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "14")
                {
                    if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramento.Text) > 200)
                    {
                        //OBTER DADOS DO RESIDENCIAL CASA/SOBRADO
                        _dtUFM = blNotificacao.ObterEnquadramento("ISSC", "11", Convert.ToDecimal(txtEnquadramento.Text));

                        valorUFMConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(5);

                        if (_dtUFM.Rows.Count > 0)
                        {
                            valorUFMConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                            aliquotaConstrucao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                            ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                        }
                    }
                    if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoDemolicao.Text) > 200)
                    {
                        //OBTER DADOS DO RESIDENCIAL CASA/SOBRADO
                        _dtUFM = blNotificacao.ObterEnquadramento("ISSC", "11", Convert.ToDecimal(txtEnquadramentoDemolicao.Text));

                        valorUFMDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_DEMOLICAO"].ToString();
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(5);

                        if (_dtUFM.Rows.Count > 0)
                        {
                            valorUFMDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                            aliquotaDemolicao = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                            ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_DEMOLICAO"].ToString();
                        }
                    }
                    if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoReforma.Text) > 200)
                    {
                        _dtUFM = blNotificacao.ObterEnquadramento("ISSC", "11", Convert.ToDecimal(txtEnquadramentoReforma.Text));

                        //OBTER DADOS DO RESIDENCIAL CASA/SOBRADO
                        valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(5);

                        if (_dtUFM.Rows.Count > 0)
                        {
                            valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                            aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                            ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();
                        }
                    }


                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "15")
                {
                    _dtUFM = blNotificacao.ObterUFM(8);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "16")
                {
                    _dtUFM = blNotificacao.ObterUFM(9);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "17")
                {
                    _dtUFM = blNotificacao.ObterUFM(10);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "18")
                {
                    _dtUFM = blNotificacao.ObterUFM(13);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "19")
                {
                    _dtUFM = blNotificacao.ObterUFM(14);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "20")
                {
                    _dtUFM = blNotificacao.ObterUFM(11);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "21")
                {
                    _dtUFM = blNotificacao.ObterUFM(12);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "25")
                {
                    _dtUFM = blNotificacao.ObterUFM(67);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "26")
                {
                    _dtUFM = blNotificacao.ObterUFM(68);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "27")
                {
                    _dtUFM = blNotificacao.ObterUFM(69);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "28")
                {
                    _dtUFM = blNotificacao.ObterUFM(70);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "29")
                {
                    _dtUFM = blNotificacao.ObterUFM(71);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "30")
                {
                    _dtUFM = blNotificacao.ObterUFM(72);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "31")
                {
                    _dtUFM = blNotificacao.ObterUFM(73);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "32")
                {
                    _dtUFM = blNotificacao.ObterUFM(74);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "33")
                {
                    _dtUFM = blNotificacao.ObterUFM(75);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "38")
                {
                    _dtUFM = blNotificacao.ObterUFM(76);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "35")
                {
                    _dtUFM = blNotificacao.ObterUFM(15);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "36")
                {
                    _dtUFM = blNotificacao.ObterUFM(16);

                    if (_dtUFM.Rows.Count > 0)
                    {
                        valorUFMConstrucao = valorUFMDemolicao = valorUFMReforma = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                        aliquotaConstrucao = aliquotaDemolicao = aliquotaReforma = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                        ISSconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                    }
                }

                #endregion

                //Termina
                decimal TX_ISS_CON_DEMOLICAO = 0;
                decimal TX_ISS_CON_REFORMA = 0;
                decimal TX_ISS_CON_CONSTRUCAO_ELEVADOR = 0;
                decimal TX_ISS_CON_DEMOLICAO_ELEVADOR = 0;
                decimal TX_ISS_CON_REFORMA_ELEVADOR = 0;

                TX_ISS_CON_DEMOLICAO = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_DEMOLICAO'")[0]["VALOR"]);
                TX_ISS_CON_REFORMA = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_REFORMA'")[0]["VALOR"]);

                if (!ckbElevador.Checked)
                {
                    if (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33")
                    {
                        //grpAreas.Visible = false;

                        baseIssConstrucao = ((numeroUnidades + numeroUnidadesAutonomaas)) * (valorTabela * valorUFMConstrucao);

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao).ToString("N2"); // 24

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + (baseIssConstrucao * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        ImpostoISSConstrucaoSecundario = baseIssConstrucao * aliquotaConstrucao;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36")
                    {
                        //grpAreas.Visible = true;

                        baseIssConstrucao = areaTerreno + areaTerrenoAumentar - areaTerrenoDeduzir;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2");//24
                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * valorUFMConstrucao)).ToString("N2"); // 24

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao;

                        ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();

                        if (ckbImplantada.Checked)
                        {
                            lblPenalidade.Text = baseIssConstrucao.ToString("N2");
                        }
                        else
                        {
                            lblPenalidade.Text = "0,00";
                        }
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "12")
                    {
                        //grpAreas.Visible = true;

                        //baseIssConstrucao = areaConstruir + areaLegalConstr - areaDecadConstr;
                        baseIssConstrucao = areaConstruir + areaLegalConstr;
                        baseIssDemolicao = areaDemolir + areaLegalDemolir - areaDecadDemolir;
                        baseIssReforma = areaReformar + areaLegalReformar;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2"); ;
                        lblAreaBaseIssDemol.Text = baseIssDemolicao.ToString("N2"); ;
                        lblAreaBaseIssRefor.Text = baseIssReforma.ToString("N2"); ;
                        lblPenalidade.Text = (areaLegalConstr + areaLegalReformar + areaLegalDemolir).ToString("N2");

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * valorUFMConstrucao)).ToString("N2"); // 24
                        lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO).ToString("N2"); //25
                        lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA).ToString("N2");//26

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao).ToString("N2");
                        lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma).ToString("N2");

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao;
                        ImpostoISSDemolicaoSecundario = ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao;
                        ImpostoISSReformaSecundario = ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14")
                    {
                        //grpAreas.Visible = true;

                        //baseIssConstrucao = areaConstruir + areaLegalConstr - areaDecadConstr;
                        baseIssConstrucao = areaConstruir + areaLegalConstr;
                        baseIssDemolicao = areaDemolir + areaLegalDemolir - areaDecadDemolir;
                        baseIssReforma = areaReformar + areaLegalReformar;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2"); ;
                        lblAreaBaseIssDemol.Text = baseIssDemolicao.ToString("N2"); ;
                        lblAreaBaseIssRefor.Text = baseIssReforma.ToString("N2"); ;
                        lblPenalidade.Text = (areaLegalConstr + areaLegalReformar + areaLegalDemolir).ToString("N2");

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * valorUFMConstrucao)).ToString("N2"); // 24
                        lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO).ToString("N2"); //25
                        lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA).ToString("N2");//26

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao).ToString("N2");
                        lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma).ToString("N2");

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao;
                        ImpostoISSDemolicaoSecundario = ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao;
                        ImpostoISSReformaSecundario = ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma;

                        ////FAÇO A CHECAGEM NO PASSO ABAIXO POR ENQUANDRAMENTO E SUBSTITUO VALOR ORIGINAL.

                        //if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramento.Text) > 200)
                        //{
                        //    lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * valorUFMConstrucao)).ToString("N2"); // 24

                        //    if (cobrarIssconstrucao)
                        //    {
                        //        lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao).ToString("N2");
                        //        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao;
                        //    }
                        //    else
                        //        lblImpostoISSConstrucao.Text = "R$ 0,00";
                        //}
                        //if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoDemolicao.Text) > 200)
                        //{
                        //    lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO).ToString("N2"); //25
                        //    lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao).ToString("N2");
                        //}
                        //if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoReforma.Text) > 200)
                        //{
                        //    lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA).ToString("N2");//26                                                
                        //    lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma).ToString("N2");
                        //}
                    }
                    else
                    {
                        //grpAreas.Visible = true;

                        //baseIssConstrucao = areaConstruir + areaLegalConstr - areaDecadConstr;
                        baseIssConstrucao = areaConstruir + areaLegalConstr;
                        baseIssDemolicao = areaDemolir + areaLegalDemolir - areaDecadDemolir;
                        baseIssReforma = areaReformar + areaLegalReformar;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2"); ;
                        lblAreaBaseIssDemol.Text = baseIssDemolicao.ToString("N2"); ;
                        lblAreaBaseIssRefor.Text = baseIssReforma.ToString("N2"); ;
                        lblPenalidade.Text = (areaLegalConstr + areaLegalReformar + areaLegalDemolir).ToString("N2");

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * valorUFMConstrucao)).ToString("N2"); // 24
                        lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO).ToString("N2"); //25
                        lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA).ToString("N2");//26

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao).ToString("N2");
                        lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma).ToString("N2");

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * valorUFMConstrucao)) * aliquotaConstrucao;
                        ImpostoISSDemolicaoSecundario = ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao;
                        ImpostoISSReformaSecundario = ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA) * aliquotaReforma;

                        if (_dtUFM.Rows.Count > 0)
                        {
                            ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_DEMOLICAO"].ToString();
                            ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();
                        }
                    }
                }
                else
                {
                    if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "12")
                    {
                        //grpAreas.Visible = true;

                        //baseIssConstrucao = areaConstruir + areaLegalConstr - areaDecadConstr;
                        baseIssConstrucao = areaConstruir + areaLegalConstr;
                        baseIssDemolicao = areaDemolir + areaLegalDemolir - areaDecadDemolir;
                        baseIssReforma = areaReformar + areaLegalReformar;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2"); ;
                        lblAreaBaseIssDemol.Text = baseIssDemolicao.ToString("N2"); ;
                        lblAreaBaseIssRefor.Text = baseIssReforma.ToString("N2"); ;
                        lblPenalidade.Text = (areaLegalConstr + areaLegalReformar + areaLegalDemolir).ToString("N2");

                        TX_ISS_CON_CONSTRUCAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_CONSTRUCAO_ELEVADOR'")[0]["VALOR"]);
                        TX_ISS_CON_DEMOLICAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_DEMOLICAO_ELEVADOR'")[0]["VALOR"]);
                        TX_ISS_CON_REFORMA_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_REFORMA_ELEVADOR'")[0]["VALOR"]);

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))).ToString("N2");//24
                        lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR).ToString("N2");//25
                        lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR).ToString("N2");//26

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR) * aliquotaDemolicao).ToString("N2");
                        lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR) * aliquotaReforma).ToString("N2");

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaConstrucao;
                        ImpostoISSDemolicaoSecundario = ((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR) * aliquotaDemolicao;
                        ImpostoISSReformaSecundario = ((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR) * aliquotaReforma;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14")
                    {
                        //grpAreas.Visible = true;

                        //baseIssConstrucao = areaConstruir + areaLegalConstr - areaDecadConstr;
                        baseIssConstrucao = areaConstruir + areaLegalConstr;
                        baseIssDemolicao = areaDemolir + areaLegalDemolir - areaDecadDemolir;
                        baseIssReforma = areaReformar + areaLegalReformar;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2"); ;
                        lblAreaBaseIssDemol.Text = baseIssDemolicao.ToString("N2"); ;
                        lblAreaBaseIssRefor.Text = baseIssReforma.ToString("N2"); ;
                        lblPenalidade.Text = (areaLegalConstr + areaLegalReformar + areaLegalDemolir).ToString("N2");

                        TX_ISS_CON_CONSTRUCAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_CONSTRUCAO_ELEVADOR'")[0]["VALOR"]);
                        TX_ISS_CON_DEMOLICAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_DEMOLICAO_ELEVADOR'")[0]["VALOR"]);
                        TX_ISS_CON_REFORMA_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_REFORMA_ELEVADOR'")[0]["VALOR"]);

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))).ToString("N2");//24
                        lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR).ToString("N2");//25
                        lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR).ToString("N2");//26

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR) * aliquotaDemolicao).ToString("N2");
                        lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR) * aliquotaReforma).ToString("N2");

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaConstrucao;
                        ImpostoISSDemolicaoSecundario = ((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR) * aliquotaDemolicao;
                        ImpostoISSReformaSecundario = ((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR) * aliquotaReforma;
                        ////FAÇO A CHECAGEM NO PASSO ABAIXO POR ENQUANDRAMENTO E SUBSTITUO VALOR ORIGINAL.

                        //if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramento.Text) > 200)
                        //{
                        //    lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * valorUFMConstrucao)).ToString("N2"); // 24

                        //    if (cobrarIssconstrucao)
                        //        lblImpostoISSConstrucao.Text = "R$ " + (((baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * TX_ISS_CON_CONSTRUCAO_ELEVADOR) * aliquotaConstrucao).ToString("N2");
                        //    else
                        //        lblImpostoISSConstrucao.Text = "R$ 0,00";
                        //}
                        //if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoDemolicao.Text) > 200)
                        //{
                        //    lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * valorUFMDemolicao)) * TX_ISS_CON_DEMOLICAO_ELEVADOR).ToString("N2"); //25
                        //    lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO) * aliquotaDemolicao).ToString("N2");
                        //}
                        //if (ckbMista.Checked && Convert.ToDecimal(txtEnquadramentoReforma.Text) > 200)
                        //{
                        //    lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * valorUFMReforma)) * TX_ISS_CON_REFORMA_ELEVADOR).ToString("N2");//26                                                
                        //    lblImpostoISSReforma.Text = "R$ " + ((baseIssConstrucao * (valorTabela * (valorUFMReforma + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaReforma).ToString("N2");
                        //}
                    }
                    else
                    {
                        //grpAreas.Visible = true;

                        //baseIssConstrucao = areaConstruir + areaLegalConstr - areaDecadConstr;
                        baseIssConstrucao = areaConstruir + areaLegalConstr;
                        baseIssDemolicao = areaDemolir + areaLegalDemolir - areaDecadDemolir;
                        baseIssReforma = areaReformar + areaLegalReformar;

                        lblAreaBaseIssConstr.Text = baseIssConstrucao.ToString("N2"); ;
                        lblAreaBaseIssDemol.Text = baseIssDemolicao.ToString("N2"); ;
                        lblAreaBaseIssRefor.Text = baseIssReforma.ToString("N2"); ;
                        lblPenalidade.Text = (areaLegalConstr + areaLegalReformar + areaLegalDemolir).ToString("N2");

                        TX_ISS_CON_CONSTRUCAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_CONSTRUCAO_ELEVADOR'")[0]["VALOR"]);
                        TX_ISS_CON_DEMOLICAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_DEMOLICAO_ELEVADOR'")[0]["VALOR"]);
                        TX_ISS_CON_REFORMA_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_CON_REFORMA_ELEVADOR'")[0]["VALOR"]);

                        lblBaseISSConstrucao.Text = "R$ " + (baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))).ToString("N2");//24
                        lblBaseISSDemolicao.Text = "R$ " + ((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR).ToString("N2");//25
                        lblBaseISSReforma.Text = "R$ " + ((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR).ToString("N2");//26

                        if (cobrarIssconstrucao)
                            lblImpostoISSConstrucao.Text = "R$ " + ((baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaConstrucao).ToString("N2");
                        else
                            lblImpostoISSConstrucao.Text = "R$ 0,00";

                        lblImpostoISSDemolicao.Text = "R$ " + (((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR) * aliquotaDemolicao).ToString("N2");
                        lblImpostoISSReforma.Text = "R$ " + (((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR) * aliquotaReforma).ToString("N2");

                        ImpostoISSConstrucaoSecundario = (baseIssConstrucao * (valorTabela * (valorUFMConstrucao + TX_ISS_CON_CONSTRUCAO_ELEVADOR))) * aliquotaConstrucao;
                        ImpostoISSDemolicaoSecundario = ((baseIssDemolicao * (valorTabela * (valorUFMDemolicao + TX_ISS_CON_DEMOLICAO_ELEVADOR))) * TX_ISS_CON_DEMOLICAO_ELEVADOR) * aliquotaDemolicao;
                        ImpostoISSReformaSecundario = ((baseIssReforma * (valorTabela * (valorUFMReforma + TX_ISS_CON_REFORMA_ELEVADOR))) * TX_ISS_CON_REFORMA_ELEVADOR) * aliquotaReforma;

                        ISSdemolicaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_DEMOLICAO"].ToString();
                        ISSreformaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO_REFORMA"].ToString();
                    }
                }

                #endregion

                #region Base Calculo ISS Engenharia e Imposto

                #region Obter UFM

                if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "12")
                {
                    _dtUFM = blNotificacao.ObterUFM(88);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14" || cbxSubtipoImovel.SelectedValue.ToString() == "38")
                {
                    _dtUFM = blNotificacao.ObterUFM(89);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "15" || cbxSubtipoImovel.SelectedValue.ToString() == "16" || cbxSubtipoImovel.SelectedValue.ToString() == "17")
                {
                    _dtUFM = blNotificacao.ObterUFM(90);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "18" || cbxSubtipoImovel.SelectedValue.ToString() == "19")
                {
                    _dtUFM = blNotificacao.ObterUFM(92);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "20" || cbxSubtipoImovel.SelectedValue.ToString() == "21")
                {
                    _dtUFM = blNotificacao.ObterUFM(91);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26")
                {
                    _dtUFM = blNotificacao.ObterUFM(94);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "27")
                {
                    _dtUFM = blNotificacao.ObterUFM(98);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "28")
                {
                    _dtUFM = blNotificacao.ObterUFM(95);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "30")
                {
                    _dtUFM = blNotificacao.ObterUFM(97);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33")
                {
                    _dtUFM = blNotificacao.ObterUFM(96);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36")
                {
                    _dtUFM = blNotificacao.ObterUFM(93);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "40")
                {
                    _dtUFM = blNotificacao.ObterUFM(124);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "42")
                {
                    _dtUFM = blNotificacao.ObterUFM(123);
                }

                valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);
                aliquotaEngenharia = Convert.ToDecimal(_dtUFM.Rows[0]["ALIQUOTA"]);
                ISSengenhariaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                #endregion

                if (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33")
                {
                    totalizado = (numeroUnidades + numeroUnidadesAutonomaas);

                    lblAreaBaseISSEngenharia.Text = (totalizado).ToString("N2");

                    totalizado = (numeroUnidades + numeroUnidadesAutonomaas) * (valorTabela * valorUFM);

                    lblBaseISSEngenharia.Text = "R$ " + (totalizado).ToString("N2");

                    if (cobrarIssEngenharia)
                        lblImpostoSSEngenharia.Text = "R$ " + (totalizado * aliquotaEngenharia).ToString("N2");
                    else
                        lblImpostoSSEngenharia.Text = "R$ 0,00";

                    ImpostoISSEngenhariaSecundario = (totalizado * aliquotaEngenharia);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36")
                {
                    totalizado = areaTerreno + areaTerrenoAumentar;

                    lblAreaBaseISSEngenharia.Text = (totalizado).ToString("N2"); ;

                    totalizado = (areaTerreno + areaTerrenoAumentar) * (valorTabela * valorUFM);

                    lblBaseISSEngenharia.Text = "R$ " + (totalizado).ToString("N2");

                    if (cobrarIssEngenharia)
                        lblImpostoSSEngenharia.Text = "R$ " + (totalizado * aliquotaEngenharia).ToString("N2");
                    else
                        lblImpostoSSEngenharia.Text = "R$ 0,00";

                    ImpostoISSEngenhariaSecundario = (totalizado * aliquotaEngenharia);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
                {
                    totalizado = areaTerreno + areaTerrenoAumentar - areaTerrenoDeduzir;

                    lblAreaBaseISSEngenharia.Text = (totalizado).ToString("N2");

                    totalizado = (areaTerreno + areaTerrenoAumentar - areaTerrenoDeduzir) * (valorTabela * valorUFM);

                    lblBaseISSEngenharia.Text = "R$ " + (totalizado).ToString("N2");

                    if (cobrarIssEngenharia)
                        lblImpostoSSEngenharia.Text = "R$ " + (totalizado * aliquotaEngenharia).ToString("N2");
                    else
                        lblImpostoSSEngenharia.Text = "R$ 0,00";

                    ImpostoISSEngenhariaSecundario = (totalizado * aliquotaEngenharia);
                }
                else
                {
                    decimal val;
                    decimal.TryParse(txtEnquadramentoBaseISS.Text, out val);
                    if (!chkEnquadramentoBaseISS.Checked)
                    {
                        totalizado = areaConstruir + areaLegalConstr + areaDecadConstr + areaReformar + areaLegalReformar + areaDemolir + areaLegalDemolir;
                    }
                    else
                    {
                        if (val > 0)
                        {
                            totalizado = val;
                        }
                        else
                        {
                            totalizado = areaConstruir + areaReformar + areaLegalConstr + areaLegalReformar + areaDemolir + areaLegalDemolir;
                        }
                    }
                    txtEnquadramentoBaseISS.Text = totalizado.ToString("N2");
                    decimal TX_ISS_ENG_ELEVADOR = 0;

                    lblAreaBaseISSEngenharia.Text = totalizado.ToString("N2");

                    TX_ISS_ENG_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_ENG_ELEVADOR'")[0]["VALOR"]);

                    if (!ckbElevador.Checked)
                    {
                        lblBaseISSEngenharia.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");
                    }
                    else
                    {
                        lblBaseISSEngenharia.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_ISS_ENG_ELEVADOR))).ToString("N2");
                    }

                    if (cobrarIssEngenharia)
                        lblImpostoSSEngenharia.Text = "R$ " + ((totalizado * (valorTabela * valorUFM)) * aliquotaEngenharia).ToString("N2");
                    else
                        lblImpostoSSEngenharia.Text = "R$ 0,00";

                    ImpostoISSEngenhariaSecundario = ((totalizado * (valorTabela * valorUFM)) * aliquotaEngenharia);
                }


                #endregion

                #region Taxas

                decimal TX_CONSTRUCAO_ELEVADOR = 0;

                TX_CONSTRUCAO_ELEVADOR = Convert.ToDecimal(_dtParametro.Select("CHAVE = 'TX_ISS_ENG_ELEVADOR'")[0]["VALOR"]);

                if (!ckbElevador.Checked)
                {
                    if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "12")
                    {
                        _dtUFM = blNotificacao.ObterUFM(99);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "11")
                    {
                        _dtUFM = blNotificacao.ObterUFM(99);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr - areaEdicula;

                        totalizado = (totalizado * (valorTabela * valorUFM));

                        if (areaEdicula > 0)
                        {
                            _dtUFM = blNotificacao.ObterUFM(100);

                            valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                            totalizado = totalizado + (areaEdicula * (valorTabela * valorUFM));
                        }

                        lblTaxaConstrucao.Text = "R$ " + totalizado.ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14")
                    {
                        _dtUFM = blNotificacao.ObterUFM(104);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "15" || cbxSubtipoImovel.SelectedValue.ToString() == "16" || cbxSubtipoImovel.SelectedValue.ToString() == "17" || cbxSubtipoImovel.SelectedValue.ToString() == "20" || cbxSubtipoImovel.SelectedValue.ToString() == "21")
                    {
                        _dtUFM = blNotificacao.ObterUFM(106);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "18" || cbxSubtipoImovel.SelectedValue.ToString() == "19")
                    {
                        _dtUFM = blNotificacao.ObterUFM(105);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26" || cbxSubtipoImovel.SelectedValue.ToString() == "27" || cbxSubtipoImovel.SelectedValue.ToString() == "28")
                    {
                        _dtUFM = blNotificacao.ObterUFM(107);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33")
                    {
                        _dtUFM = blNotificacao.ObterUFM(108);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = (numeroUnidades + numeroUnidadesAutonomaas) * (valorTabela * valorUFM);

                        lblTaxaConstrucao.Text = "R$ " + (totalizado).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "38")
                    {
                        _dtUFM = blNotificacao.ObterUFM(113);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36")
                    {
                        _dtUFM = blNotificacao.ObterUFM(110);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = baseIssConstrucao;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
                    {
                        _dtUFM = blNotificacao.ObterUFM(110);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaTerreno + areaTerrenoAumentar - areaTerrenoDeduzir;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");//38

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * valorUFM);
                    }

                    //TAXA DE LICENCA
                    if (cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26" || cbxSubtipoImovel.SelectedValue.ToString() == "27" || cbxSubtipoImovel.SelectedValue.ToString() == "28")
                    {
                        _dtUFM = blNotificacao.ObterUFM(107);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaReformar + areaLegalReformar + areaDemolir + areaLegalDemolir;

                        lblTaxaLicenca.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");

                        TXlicencaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaReformaSecundario = totalizado * (valorTabela * valorUFM);
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33" || cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36" || cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
                    {
                        lblTaxaLicenca.Text = "R$ 0.00";

                        TXlicencaDescricaoUFM = "";
                    }
                    else
                    {
                        _dtUFM = blNotificacao.ObterUFM(109);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaReformar + areaLegalReformar + areaDemolir + areaLegalDemolir;

                        lblTaxaLicenca.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");

                        TXlicencaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaReformaSecundario = totalizado * (valorTabela * valorUFM);
                    }
                }
                else
                {
                    if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11")
                    {
                        _dtUFM = blNotificacao.ObterUFM(99);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR))).ToString("N2");

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR));
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14")
                    {
                        _dtUFM = blNotificacao.ObterUFM(104);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR))).ToString("N2");

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR));
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "15" || cbxSubtipoImovel.SelectedValue.ToString() == "17" || cbxSubtipoImovel.SelectedValue.ToString() == "20" || cbxSubtipoImovel.SelectedValue.ToString() == "21")
                    {
                        _dtUFM = blNotificacao.ObterUFM(106);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR))).ToString("N2");

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR));
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "18" || cbxSubtipoImovel.SelectedValue.ToString() == "19")
                    {
                        _dtUFM = blNotificacao.ObterUFM(105);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR))).ToString("N2");

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR));
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "38")
                    {
                        _dtUFM = blNotificacao.ObterUFM(113);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        totalizado = areaConstruir + areaLegalConstr;

                        lblTaxaConstrucao.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR))).ToString("N2");

                        TXconstrucaoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaConstrucaoSecundario = totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR));
                    }

                    _dtUFM = blNotificacao.ObterUFM(109);

                    valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                    totalizado = areaReformar + areaLegalReformar + areaDemolir + areaLegalDemolir;

                    lblTaxaLicenca.Text = "R$ " + (totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR))).ToString("N2");

                    TXlicencaDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                    TaxaReformaSecundario = totalizado * (valorTabela * (valorUFM + TX_CONSTRUCAO_ELEVADOR));
                }

                #endregion

                #region Preço Publico 

                if (cbxSubtipoImovel.SelectedValue.ToString() == "35")
                {
                    _dtUFM = blNotificacao.ObterUFM(125);

                    valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                    totalizado = testadaPrincipal + areaTestadaAumentar - areaTestadaDeduzir;

                    lblTaxaAlinhamento.Text = "R$ " + (totalizado * (valorTabela * valorUFM)).ToString("N2");

                    TXalinhamentoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                    TaxaAlinhamentoSecundario = totalizado * (valorTabela * valorUFM);
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "36" || cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
                {
                    lblTaxaAlinhamento.Text = "R$ 0,00";
                    TXalinhamentoDescricaoUFM = "";
                    TaxaAlinhamentoSecundario = 0;
                }
                else
                {
                    if ((areaConstruir > 0 || areaLegalConstr > 0) && areaExistenteLegalConst == 0)
                    {
                        _dtUFM = blNotificacao.ObterUFM(125);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        lblTaxaAlinhamento.Text = "R$ " + (testadaPrincipal * (valorTabela * valorUFM)).ToString("N2");

                        TXalinhamentoDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                        TaxaAlinhamentoSecundario = testadaPrincipal * (valorTabela * valorUFM);
                    }
                    else
                    {
                        lblTaxaAlinhamento.Text = "R$ 0,00";
                        TXalinhamentoDescricaoUFM = "";
                        TaxaAlinhamentoSecundario = 0;
                    }
                }

                _dtUFM = blNotificacao.ObterUFM(126);

                valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                lblTaxaAlvara.Text = "R$ " + ((valorTabela * valorUFM)).ToString("N2");

                TXalvaraDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();

                TaxaAlvaraSecundario = (valorTabela * valorUFM);

                lblTaxaNumPredial.Visible = ckbNumeracaoPredial.Checked;
                label10.Visible = ckbNumeracaoPredial.Checked;
                if (ckbNumeracaoPredial.Checked)
                {
                    _dtUFM = blNotificacao.ObterUFM(130);

                    lblTaxaNumPredial.Text = "R$ " + ((valorTabela * valorUFM)).ToString("N2");
                    TXnumeracaoPredialDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                }
                else
                {
                    lblTaxaNumPredial.Text = "R$ " + ((0)).ToString("N2");
                    TXnumeracaoPredialDescricaoUFM = "";
                }
                #endregion

                #region Penalidades

                if (cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33")
                {
                    totalizado = numeroUnidadesAutonomaas;
                }
                else if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36" || cbxSubtipoImovel.SelectedValue.ToString() == "40" || cbxSubtipoImovel.SelectedValue.ToString() == "42")
                {
                    if (ckbImplantada.Checked)
                    {
                        totalizado = baseIssConstrucao;
                    }
                    else
                    {
                        totalizado = 0;
                    }
                }
                else
                {
                    //COMENTANDO PARA PEGAR O VALOR DO NOVO TEXTBOX
                    //totalizado = areaLegalConstr + areaLegalReformar + areaLegalDemolir;

                    totalizado = Convert.ToDecimal(txtEnquadramentoPenalidade.Text);
                }

                if (totalizado > 0)
                {
                    if (cbxSubtipoImovel.SelectedValue.ToString() == "10" || cbxSubtipoImovel.SelectedValue.ToString() == "11" || cbxSubtipoImovel.SelectedValue.ToString() == "12")
                    {
                        _dtUFM = blNotificacao.ObterEnquadramento("MU", "5", totalizado);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        lblTaxaPenalidades.Text = "R$ " + (valorTabela * valorUFM).ToString("N2");

                        TaxaPenalidadeSecundario = valorTabela * valorUFM;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "13" || cbxSubtipoImovel.SelectedValue.ToString() == "14" || cbxSubtipoImovel.SelectedValue.ToString() == "15" || cbxSubtipoImovel.SelectedValue.ToString() == "16" || cbxSubtipoImovel.SelectedValue.ToString() == "17" || cbxSubtipoImovel.SelectedValue.ToString() == "18" || cbxSubtipoImovel.SelectedValue.ToString() == "19" || cbxSubtipoImovel.SelectedValue.ToString() == "20" || cbxSubtipoImovel.SelectedValue.ToString() == "21" || cbxSubtipoImovel.SelectedValue.ToString() == "38")
                    {
                        _dtUFM = blNotificacao.ObterEnquadramento("MU", "6;7;8;9;38;36", totalizado);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        lblTaxaPenalidades.Text = "R$ " + (valorTabela * valorUFM).ToString("N2");

                        TaxaPenalidadeSecundario = valorTabela * valorUFM;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "25" || cbxSubtipoImovel.SelectedValue.ToString() == "26" || cbxSubtipoImovel.SelectedValue.ToString() == "27" || cbxSubtipoImovel.SelectedValue.ToString() == "28" || cbxSubtipoImovel.SelectedValue.ToString() == "29" || cbxSubtipoImovel.SelectedValue.ToString() == "30" || cbxSubtipoImovel.SelectedValue.ToString() == "31" || cbxSubtipoImovel.SelectedValue.ToString() == "32" || cbxSubtipoImovel.SelectedValue.ToString() == "33")
                    {
                        _dtUFM = blNotificacao.ObterUFM(129);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        lblTaxaPenalidades.Text = "R$ " + (valorTabela * valorUFM).ToString("N2");

                        TaxaPenalidadeSecundario = valorTabela * valorUFM;
                    }
                    else if (cbxSubtipoImovel.SelectedValue.ToString() == "35" || cbxSubtipoImovel.SelectedValue.ToString() == "36")
                    {
                        _dtUFM = blNotificacao.ObterEnquadramento("MU", "6;7;8;9;38;36", totalizado);

                        valorUFM = Convert.ToDecimal(_dtUFM.Rows[0]["VALOR"]);

                        lblTaxaPenalidades.Text = "R$ " + (valorTabela * valorUFM).ToString("N2");

                        TaxaPenalidadeSecundario = valorTabela * valorUFM;
                    }

                    TXpenalidadeDescricaoUFM = _dtUFM.Rows[0]["DESCRICAO"].ToString();
                }
                else
                {
                    lblTaxaPenalidades.Text = "R$ 0,00";
                    TXpenalidadeDescricaoUFM = "";
                    TaxaPenalidadeSecundario = 0; ;
                }
                #endregion

                if (diferimento)
                {
                    lblImpostoISSDemolicao.Text = "R$ 0,00";
                    lblImpostoISSReforma.Text = "R$ 0,00";
                    lblImpostoSSEngenharia.Text = "R$ 0,00";
                    lblTaxaPenalidades.Text = "R$ 0,00";
                    lblTaxaAlinhamento.Text = "R$ 0,00";
                    lblTaxaConstrucao.Text = "R$ 0,00";
                    lblTaxaLicenca.Text = "R$ 0,00";
                    lblTaxaAlvara.Text = "R$ 0,00";
                }
            }
            catch (Exception)
            {

            }
        }
        #endregion

        private void btnDocDigProcurar_Click(object sender, EventArgs e)
        {
            ProcurarDocumentoDigital();
        }

        /// <summary>
        /// Procura arquivo de documento digital
        /// </summary>
        private void ProcurarDocumentoDigital()
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                Title = "Selecione o arquivo"
            };

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtDocDigCAMINHO_ARQUIVO.Text = dlg.FileName;
            }
        }

        private void btnDocDigNovo_Click(object sender, EventArgs e)
        {
            NovoDocumentoDigital();
        }

        /// <summary>
        /// Novo Documento Digital
        /// </summary>
        private void NovoDocumentoDigital()
        {
            cbxDocDigID_TIPO_DOC_DIGITAL.Enabled = true;
            //txtDocDigCAMINHO_ARQUIVO.ReadOnly = false;

            LimparCamposDocumentoDigital();

            btnDocDigAdicionar.Enabled = true;
            btnDocDigDescartar.Enabled = true;
            btnDocDigEditar.Enabled = false;
            btnDocDigNovo.Enabled = false;
            btnDocDigRemover.Enabled = false;
            dgvDocDigital.Enabled = false;
            btnDocDigProcurar.Enabled = true;

            cbxDocDigID_TIPO_DOC_DIGITAL.Focus();

            _modoDocDigital = BL.Shared.Utilitario.Geral.ModoTabela.MODO_INCLUSAO;
        }
        private void LimparCamposDocumentoDigital()
        {
            cbxDocDigID_TIPO_DOC_DIGITAL.SelectedValue = -1;
            txtDocDigCAMINHO_ARQUIVO.Text = string.Empty;
        }

        private void btnDocDigEditar_Click(object sender, EventArgs e)
        {
            EditarDocumentoDigital();
        }

        /// <summary>
        /// Edita dados do Documento Digital
        /// </summary>
        private void EditarDocumentoDigital()
        {
            if (Biblioteca.Geral.ValidaApenasUm(dgvDocDigital.SelectedRows.Count))
            {
                CarregarCamposDocumentoDigital();

                btnDocDigAdicionar.Enabled = true;
                btnDocDigDescartar.Enabled = true;
                btnDocDigEditar.Enabled = false;
                btnDocDigNovo.Enabled = false;
                btnDocDigRemover.Enabled = false;
                dgvDocDigital.Enabled = false;
                btnDocDigProcurar.Enabled = true;

                //btnDocDigProcurar.Enabled = false;

                cbxDocDigID_TIPO_DOC_DIGITAL.Enabled = true;
                //txtDocDigCAMINHO_ARQUIVO.ReadOnly = false;

                _modoDocDigital = BL.Shared.Utilitario.Geral.ModoTabela.MODO_EDICAO;
            }
        }

        private void dgvDocDigital_SelectionChanged(object sender, EventArgs e)
        {
            CarregarCamposDocumentoDigital();
        }

        /// <summary>
        /// Carrega campos do Documento Digital. Carrega campos da base de dados.
        /// </summary>
        private void CarregarCamposDocumentoDigital()
        {
            /*
            try
            {
                if (mO_MOBILIARIO_DOC_DIGITALBindingSource.Current != null)
                {
                    // Dados do doc digital sempre pega do grid.
                    DSCadastro.MO_MOBILIARIO_DOC_DIGITALRow drDocDigital = (DSCadastro.MO_MOBILIARIO_DOC_DIGITALRow)((DataRowView)mO_MOBILIARIO_DOC_DIGITALBindingSource.Current).Row;

                    // Dados somente do documento digital
                    cbxDocDigID_TIPO_DOC_DIGITAL.SelectedValue = drDocDigital.ID_TIPO_DOC_DIGITAL;
                    txtDocDigCAMINHO_ARQUIVO.Text = drDocDigital.CAMINHO_ARQUIVO;

                }
            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Problema ao carregar dados do documento digital", "Atenção", ex);
                LimparCamposDocumentoDigital();
            }
            */
        }

    }
}