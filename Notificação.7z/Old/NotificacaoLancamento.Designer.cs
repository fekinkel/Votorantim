﻿namespace PMV.Tributario.Fiscalizacao.Notificacao
{
    partial class NotificacaoLancamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblNumeroProcesso;
            System.Windows.Forms.Label lblEmail;
            System.Windows.Forms.Label lblObsGeral;
            System.Windows.Forms.Label label83;
            System.Windows.Forms.Label label84;
            System.Windows.Forms.Label label85;
            System.Windows.Forms.Label label81;
            System.Windows.Forms.Label label78;
            System.Windows.Forms.Label label79;
            System.Windows.Forms.Label label80;
            System.Windows.Forms.Label label23;
            System.Windows.Forms.Label label21;
            System.Windows.Forms.Label label17;
            System.Windows.Forms.Label label19;
            System.Windows.Forms.Label inscMunicipalLabel;
            System.Windows.Forms.Label label46;
            System.Windows.Forms.Label label47;
            System.Windows.Forms.Label label48;
            System.Windows.Forms.Label label49;
            System.Windows.Forms.Label label50;
            System.Windows.Forms.Label label52;
            System.Windows.Forms.Label label53;
            System.Windows.Forms.Label label61;
            System.Windows.Forms.Label nomeRazaoLabel1;
            System.Windows.Forms.Label label15;
            System.Windows.Forms.Label label51;
            System.Windows.Forms.Label label54;
            System.Windows.Forms.Label label86;
            System.Windows.Forms.Label label62;
            System.Windows.Forms.Label label59;
            System.Windows.Forms.Label label60;
            System.Windows.Forms.Label label88;
            System.Windows.Forms.Label label64;
            System.Windows.Forms.Label label90;
            System.Windows.Forms.Label label100;
            System.Windows.Forms.Label label104;
            System.Windows.Forms.Label label108;
            System.Windows.Forms.Label label110;
            System.Windows.Forms.Label label112;
            System.Windows.Forms.Label label113;
            System.Windows.Forms.Label label114;
            System.Windows.Forms.Label label116;
            System.Windows.Forms.Label label118;
            System.Windows.Forms.Label label106;
            System.Windows.Forms.Label label115;
            System.Windows.Forms.Label label119;
            System.Windows.Forms.Label label120;
            System.Windows.Forms.Label label122;
            System.Windows.Forms.Label label41;
            System.Windows.Forms.Label label37;
            System.Windows.Forms.Label label39;
            System.Windows.Forms.Label label42;
            System.Windows.Forms.Label label45;
            System.Windows.Forms.Label label44;
            System.Windows.Forms.Label label121;
            System.Windows.Forms.Label label124;
            System.Windows.Forms.Label label125;
            System.Windows.Forms.Label label126;
            System.Windows.Forms.Label label128;
            System.Windows.Forms.Label label130;
            System.Windows.Forms.Label label136;
            System.Windows.Forms.Label label137;
            System.Windows.Forms.Label label138;
            System.Windows.Forms.Label label139;
            System.Windows.Forms.Label label140;
            System.Windows.Forms.Label label142;
            System.Windows.Forms.Label label143;
            System.Windows.Forms.Label label144;
            System.Windows.Forms.Label label145;
            System.Windows.Forms.Label label151;
            System.Windows.Forms.Label label153;
            System.Windows.Forms.Label label154;
            System.Windows.Forms.Label lblDataCiencia;
            System.Windows.Forms.Label lblDataExigibilidade;
            System.Windows.Forms.Label label57;
            System.Windows.Forms.Label label56;
            System.Windows.Forms.Label label55;
            System.Windows.Forms.Label label127;
            System.Windows.Forms.Label label129;
            System.Windows.Forms.Label label131;
            System.Windows.Forms.Label label133;
            System.Windows.Forms.Label label135;
            System.Windows.Forms.Label label101;
            System.Windows.Forms.Label label103;
            System.Windows.Forms.Label label117;
            System.Windows.Forms.Label label107;
            System.Windows.Forms.Label label105;
            System.Windows.Forms.Label label109;
            System.Windows.Forms.Label label111;
            System.Windows.Forms.Label label123;
            System.Windows.Forms.Label label92;
            System.Windows.Forms.Label lblFatoJuridico;
            System.Windows.Forms.Label label11;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label18;
            System.Windows.Forms.Label label20;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NotificacaoLancamento));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label24 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblDescontoPenalidade = new System.Windows.Forms.Label();
            this.dgvNotificacao = new System.Windows.Forms.DataGridView();
            this.ID_NOTIFICACAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INSCRICAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mO_NOTIFICACAO_LANCAMENTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dSNotificacaoLancamento = new PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento();
            this.tbpAssunto = new System.Windows.Forms.TabPage();
            this.txtFATO_JURIDICO = new PMV.Tributario.Componentes.rtfEditor();
            this.txtASSUNTO = new PMV.Tributario.Componentes.rtfEditor();
            this.txtANO_NOTIFICACAO = new AMS.TextBox.IntegerTextBox();
            this.txtID_NOTIFICACAO = new System.Windows.Forms.TextBox();
            this.txtNUMERO_NOTIFICACAO = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblNumero = new System.Windows.Forms.Label();
            this.tbpContribuinte = new System.Windows.Forms.TabPage();
            this.gbxSujeitoPassivo = new System.Windows.Forms.GroupBox();
            this.pnl_Botoes_Contribuinte = new System.Windows.Forms.Panel();
            this.btnLimparContribuinte = new System.Windows.Forms.Button();
            this.btnGravarContribuinte = new System.Windows.Forms.Button();
            this.btnExcluirContribuinte = new System.Windows.Forms.Button();
            this.btnEditarContribuinte = new System.Windows.Forms.Button();
            this.btnIncluirContribuinte = new System.Windows.Forms.Button();
            this.dgvContribuinte = new System.Windows.Forms.DataGridView();
            this.ID_NOTIFICACAO_CONTRIBUINTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QUALIFICACAO_DESCRICAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CPFCNPJ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NOME_RAZAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOCUMENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INSCRICAO_MUNICIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RESPONSAVEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CPF_RESPONSAVEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OBSERVACAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRINCIPAL = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CONTRIBUINTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COMO_RESPONSAVEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LOGRADOURO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NUMERO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COMPLEMENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UF = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CIDADE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BAIRRO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CEP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QUALIFICACAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grpSujeicao = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.ckbSubnivelProp = new System.Windows.Forms.CheckedListBox();
            this.txtInscriMun = new System.Windows.Forms.TextBox();
            this.txtCPFResponsavel = new AMS.TextBox.MaskedTextBox();
            this.txtResponsavel = new System.Windows.Forms.TextBox();
            this.lblInscrito = new System.Windows.Forms.Label();
            this.rblNao = new System.Windows.Forms.RadioButton();
            this.rblSim = new System.Windows.Forms.RadioButton();
            this.txtNOME_RAZAO = new System.Windows.Forms.TextBox();
            this.lblInscricaoMun = new System.Windows.Forms.Label();
            this.txtDocProfissional = new AMS.TextBox.MaskedTextBox();
            this.txtCPFCNPJ = new AMS.TextBox.MaskedTextBox();
            this.ckbSubnivel = new System.Windows.Forms.CheckedListBox();
            this.chkPRINCIPAL = new System.Windows.Forms.CheckBox();
            this.ckbQualificacao = new System.Windows.Forms.CheckedListBox();
            this.pnlDescricao = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCONTRIBUINTE = new System.Windows.Forms.TextBox();
            this.txtComoResponsavel = new System.Windows.Forms.TextBox();
            this.btnPessoa = new System.Windows.Forms.Button();
            this.txtOBSERVACAO_P = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.pnlEndereco = new System.Windows.Forms.Panel();
            this.txtNumeroResp = new AMS.TextBox.MaskedTextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtLogradouroResp = new System.Windows.Forms.TextBox();
            this.cbxCidadeResp = new System.Windows.Forms.ComboBox();
            this.txtBairroResp = new System.Windows.Forms.TextBox();
            this.cbxUFResp = new System.Windows.Forms.ComboBox();
            this.txtCepResp = new AMS.TextBox.MaskedTextBox();
            this.txtComplResp = new System.Windows.Forms.TextBox();
            this.txtNUMERO_PROCESSO = new System.Windows.Forms.TextBox();
            this.txtEMAIL = new System.Windows.Forms.TextBox();
            this.txtOBSERVACAO = new System.Windows.Forms.TextBox();
            this.pnlCanceladoRemessa = new System.Windows.Forms.Panel();
            this.lblSuspCanc = new System.Windows.Forms.Label();
            this.txtMOTIVO_CANCELAMENTO = new AMS.TextBox.AlphanumericTextBox();
            this.txtPROCESSO_CANCELAMENTO = new AMS.TextBox.AlphanumericTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtDATA_CANCELAMENTO = new AMS.TextBox.MaskedTextBox();
            this.lblDataCancela = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtTestadaOriginal = new System.Windows.Forms.TextBox();
            this.txtAreaOriginal = new System.Windows.Forms.TextBox();
            this.txtLOTE_IMOVEL = new System.Windows.Forms.TextBox();
            this.txtQUADRA_IMOVEL = new System.Windows.Forms.TextBox();
            this.cbxCONDOMINIO = new SearchComboBox.SearchComboBox();
            this.cbxLOTEAMENTO = new SearchComboBox.SearchComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtLOGRADOURO = new System.Windows.Forms.TextBox();
            this.cbxCIDADE = new System.Windows.Forms.ComboBox();
            this.txtBAIRRO = new System.Windows.Forms.TextBox();
            this.cbxUF = new System.Windows.Forms.ComboBox();
            this.txtCEP = new AMS.TextBox.MaskedTextBox();
            this.txtCOMPLEMENTO = new System.Windows.Forms.TextBox();
            this.txtNUMERO = new AMS.TextBox.IntegerTextBox();
            this.lblRetificada = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnBuscarInscricao = new System.Windows.Forms.Button();
            this.cbxTipo = new System.Windows.Forms.ComboBox();
            this.txtINSCRICAO = new AMS.TextBox.IntegerTextBox();
            this.rdbMob = new System.Windows.Forms.RadioButton();
            this.rdbImob = new System.Windows.Forms.RadioButton();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtEnquadramentoPenalidade = new AMS.TextBox.NumericTextBox();
            this.txtEnquadramentoDemolicao = new AMS.TextBox.NumericTextBox();
            this.txtEnquadramentoReforma = new AMS.TextBox.NumericTextBox();
            this.txtEnquadramento = new AMS.TextBox.NumericTextBox();
            this.txtEnquadramentoBaseISS = new AMS.TextBox.NumericTextBox();
            this.btnOpcoes = new System.Windows.Forms.Button();
            this.txtDATA_NOTIFICACAO = new AMS.TextBox.DateTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbpParcelamento = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgvParcelamantoComplemento = new System.Windows.Forms.DataGridView();
            this.TRIBUTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DATA_DEBITO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALOR_ABATIMENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALOR_UFM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALOR_JUROS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALOR_MULTA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label152 = new System.Windows.Forms.Label();
            this.btnCancelarOperacao = new System.Windows.Forms.Button();
            this.btnEfetivarReparcelar = new System.Windows.Forms.Button();
            this.pnlParcelamentoParcela = new System.Windows.Forms.Panel();
            this.txtValorParcela = new AMS.TextBox.IntegerTextBox();
            this.txtExpedienteAnterior = new AMS.TextBox.IntegerTextBox();
            this.lblExpedienteAnterior = new System.Windows.Forms.Label();
            this.txtCorrecao = new AMS.TextBox.IntegerTextBox();
            this.txtMulta = new AMS.TextBox.IntegerTextBox();
            this.txtJuros = new AMS.TextBox.IntegerTextBox();
            this.txtVencimento = new AMS.TextBox.DateTextBox();
            this.label141 = new System.Windows.Forms.Label();
            this.txtJurosCompensatorios = new AMS.TextBox.IntegerTextBox();
            this.txtTotalDevido = new AMS.TextBox.IntegerTextBox();
            this.txtExpediente = new AMS.TextBox.IntegerTextBox();
            this.txtDescontoPenalidade = new AMS.TextBox.IntegerTextBox();
            this.txtValorTotal = new AMS.TextBox.IntegerTextBox();
            this.txtValor = new AMS.TextBox.IntegerTextBox();
            this.txtQtdeParcela = new AMS.TextBox.IntegerTextBox();
            this.pnlParcelamentoDados = new System.Windows.Forms.Panel();
            this.lblCodParcelamento = new System.Windows.Forms.Label();
            this.txtCodParcelamento = new AMS.TextBox.MaskedTextBox();
            this.txtParcCancelado = new System.Windows.Forms.TextBox();
            this.txtUFParcelamento = new System.Windows.Forms.TextBox();
            this.txtCidadeParcelamento = new System.Windows.Forms.TextBox();
            this.txtAssuntoParcelamento = new System.Windows.Forms.TextBox();
            this.txtProcurador = new System.Windows.Forms.TextBox();
            this.txtCPFProcurador = new AMS.TextBox.MaskedTextBox();
            this.txtCPFResponsavelParcelamento = new AMS.TextBox.MaskedTextBox();
            this.txtResponsavelParcelamento = new System.Windows.Forms.TextBox();
            this.txtNOME_RAZAOParcelamento = new System.Windows.Forms.TextBox();
            this.txtCPFCNPJParcelamento = new AMS.TextBox.MaskedTextBox();
            this.txtNumeroRespParcelamento = new AMS.TextBox.MaskedTextBox();
            this.txtLogradouroRespParcelamento = new System.Windows.Forms.TextBox();
            this.txtBairroRespParcelamento = new System.Windows.Forms.TextBox();
            this.txtCepRespParcelamento = new AMS.TextBox.MaskedTextBox();
            this.txtComplRespParcelamento = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cmsOpcoes = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmEvento = new System.Windows.Forms.ToolStripMenuItem();
            this.imprimirDemonstrativoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCarne = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDemonstrativoParc = new System.Windows.Forms.ToolStripMenuItem();
            this.mnutermoConfissao = new System.Windows.Forms.ToolStripMenuItem();
            this.saldoDevedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbpLancamento = new System.Windows.Forms.TabPage();
            this.tblLancamentos = new System.Windows.Forms.TabControl();
            this.tbgConstrucao = new System.Windows.Forms.TabPage();
            this.pnl_Botoes_Construcao = new System.Windows.Forms.Panel();
            this.btnLimparConstrucao = new System.Windows.Forms.Button();
            this.btnGravarConstrucao = new System.Windows.Forms.Button();
            this.btnExcluirConstrucao = new System.Windows.Forms.Button();
            this.btnEditarConstrucao = new System.Windows.Forms.Button();
            this.btnIncluirConstrucao = new System.Windows.Forms.Button();
            this.grpConstrucao = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblTaxaNumPredial = new System.Windows.Forms.Label();
            this.lblTaxaAlvara = new System.Windows.Forms.Label();
            this.lblTaxaLicenca = new System.Windows.Forms.Label();
            this.lblTaxaPenalidades = new System.Windows.Forms.Label();
            this.lblTaxaAlinhamento = new System.Windows.Forms.Label();
            this.lblTaxaConstrucao = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblImpostoISSReforma = new System.Windows.Forms.Label();
            this.lblImpostoISSConstrucao = new System.Windows.Forms.Label();
            this.lblImpostoSSEngenharia = new System.Windows.Forms.Label();
            this.lblImpostoISSDemolicao = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblBaseISSDemolicao = new System.Windows.Forms.Label();
            this.lblBaseISSReforma = new System.Windows.Forms.Label();
            this.lblBaseISSConstrucao = new System.Windows.Forms.Label();
            this.lblBaseISSEngenharia = new System.Windows.Forms.Label();
            this.grpAreas = new System.Windows.Forms.GroupBox();
            this.lblMedidaPenalidade = new System.Windows.Forms.Label();
            this.lblMedidaISSEngenharia = new System.Windows.Forms.Label();
            this.lblMedidaISSReforma = new System.Windows.Forms.Label();
            this.lblMedidaISSDemolicao = new System.Windows.Forms.Label();
            this.lblMedidaISSConstrucao = new System.Windows.Forms.Label();
            this.lblAreaBaseISSEngenharia = new System.Windows.Forms.Label();
            this.lblPenalidade = new System.Windows.Forms.Label();
            this.lblAreaBaseIssRefor = new System.Windows.Forms.Label();
            this.lblAreaBaseISSEng = new System.Windows.Forms.Label();
            this.lblAreaBaseISSReforma = new System.Windows.Forms.Label();
            this.lblAreaBaseIssDemol = new System.Windows.Forms.Label();
            this.lblAreaBaseISSDemolicao = new System.Windows.Forms.Label();
            this.lblAreaBaseIssConstr = new System.Windows.Forms.Label();
            this.lblAreaBaseISSConstrucao = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ckbMista = new System.Windows.Forms.CheckBox();
            this.cbxSubtipoImovel = new System.Windows.Forms.ComboBox();
            this.cbxTipoImovel = new System.Windows.Forms.ComboBox();
            this.cbxTipoConstr = new System.Windows.Forms.ComboBox();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.ckbNumeracaoPredial = new System.Windows.Forms.CheckBox();
            this.chkEnquadramentoDemolicao = new System.Windows.Forms.CheckBox();
            this.chkEnquadramentoReforma = new System.Windows.Forms.CheckBox();
            this.chkEnquadramentoPenalidade = new System.Windows.Forms.CheckBox();
            this.chkEnquadramentoBaseISS = new System.Windows.Forms.CheckBox();
            this.lblEnquadramento_Base_ISS = new System.Windows.Forms.Label();
            this.chkEnquadramentoConstrucao = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ckbImplantada = new System.Windows.Forms.CheckBox();
            this.label99 = new System.Windows.Forms.Label();
            this.txtAreaEdicula = new AMS.TextBox.NumericTextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.lblIdLancamento = new System.Windows.Forms.Label();
            this.ckbElevador = new System.Windows.Forms.CheckBox();
            this.label97 = new System.Windows.Forms.Label();
            this.txtAreaTerrenoAumentar = new AMS.TextBox.NumericTextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.txtTestadaAumentar = new AMS.TextBox.NumericTextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.txtTestadaDeduzir = new AMS.TextBox.NumericTextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.txtAreaTerrenoDeduzir = new AMS.TextBox.NumericTextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.txtNumeroUnidAutonomas = new AMS.TextBox.NumericTextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.txtDesmontavelLegalizado = new AMS.TextBox.NumericTextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtDesmontavelLegalizar = new AMS.TextBox.NumericTextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txtUnidades = new AMS.TextBox.NumericTextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.txtAreaTotal = new AMS.TextBox.NumericTextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtAreaDecadDemolir = new AMS.TextBox.NumericTextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.txtAreaDemolir = new AMS.TextBox.NumericTextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txtAreaExistenteLegalConst = new AMS.TextBox.NumericTextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.txtAreaReformar = new AMS.TextBox.NumericTextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.txtAreaConstruir = new AMS.TextBox.NumericTextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtAreaDecadConstr = new AMS.TextBox.NumericTextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.txtAreaLegalDemolir = new AMS.TextBox.NumericTextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.txtAreaLegalReformar = new AMS.TextBox.NumericTextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txtAreaLegalConstr = new AMS.TextBox.NumericTextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtTESTADA_PRINCIPAL = new AMS.TextBox.NumericTextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtAREA_TERRENO = new AMS.TextBox.NumericTextBox();
            this.gbxDadosLancamento = new System.Windows.Forms.GroupBox();
            this.dgvLancamentoConstrucao = new System.Windows.Forms.DataGridView();
            this.ID_NOTIFICACAOC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIPO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AREA_TERRENO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AREA_TERRENO_TESTADO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIPO_IMOVEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SUBTIPO_IMOVEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ELEVADOR = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbgInscricao = new System.Windows.Forms.TabPage();
            this.grpUnificacao = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbxLOTEAMENTOUNI = new SearchComboBox.SearchComboBox();
            this.cbxCONDOMINIOUNI = new SearchComboBox.SearchComboBox();
            this.TXTCIDADEUNI = new System.Windows.Forms.TextBox();
            this.TXTUFUNI = new AMS.TextBox.MaskedTextBox();
            this.TXTLOTEUNI = new System.Windows.Forms.TextBox();
            this.btnBuscarUnificacao = new System.Windows.Forms.Button();
            this.btnAdicionarUnificacao = new System.Windows.Forms.Button();
            this.txtInscricaoUnificacao = new AMS.TextBox.IntegerTextBox();
            this.TXTQUADRAUNI = new System.Windows.Forms.TextBox();
            this.label132 = new System.Windows.Forms.Label();
            this.txtTestadaUnificacao = new AMS.TextBox.NumericTextBox();
            this.label134 = new System.Windows.Forms.Label();
            this.TXTLOGRADOUROUNI = new System.Windows.Forms.TextBox();
            this.txtAreaTerrenoUnificacao = new AMS.TextBox.NumericTextBox();
            this.TXTBAIRROUNI = new System.Windows.Forms.TextBox();
            this.TXTCEPUNI = new AMS.TextBox.MaskedTextBox();
            this.TXTCOMPLEMENTOUNI = new System.Windows.Forms.TextBox();
            this.TXTNUMEROUNI = new AMS.TextBox.IntegerTextBox();
            this.lblIdUnificacao = new System.Windows.Forms.Label();
            this.dgvUnificacao = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AREA_TERRENO_UNIFICACAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AREA_TERRENO_TESTADO_UNIFICACAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cEPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOGRADOURODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMERODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMPLEMENTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bAIRRODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDADEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qUADRADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOTEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cONDOMINIODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOTEAMENTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExcluirUnificacao = new System.Windows.Forms.DataGridViewButtonColumn();
            this.mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbgIptu = new System.Windows.Forms.TabPage();
            this.tbpParcelas = new System.Windows.Forms.TabPage();
            this.label147 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.dgvParcelaDetalhe = new System.Windows.Forms.DataGridView();
            this.tRIBUTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORJUROSDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORMULTADataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORCORRECAODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JUROS_COMP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORTOTALDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvParcela = new System.Windows.Forms.DataGridView();
            this.idParcela = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PARCELA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AVISO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DATA_VENCIMENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALOR_PARCELA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORMULTADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORJUROSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correcao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JUROS_COMPENSATORIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALORTOTAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VALOR_PAGO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DATA_PAGAMENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DATA_BAIXA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BAIXA_OBSERVACAO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BAIXAR = new System.Windows.Forms.DataGridViewLinkColumn();
            this.mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.btnRerratificar = new System.Windows.Forms.Button();
            this.tbpParcelamentoAnterior = new System.Windows.Forms.TabPage();
            this.dgvParcelamentoAnterior = new System.Windows.Forms.DataGridView();
            this.ID_NOTIFICACAO_PARCELAMENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aSSUNTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rESPONSAVELDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rESPONSAVELCPFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOGRADOURODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bAIRRODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDADEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMERODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cEPDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uFDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROCURADORDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROCURADORCPFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Imprimir = new System.Windows.Forms.DataGridViewImageColumn();
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label148 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.dgvParcelaDetalheAnterior = new System.Windows.Forms.DataGridView();
            this.tRIBUTODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORJUROSDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORMULTADataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORCORRECAODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vALORTOTALDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mOParcelaDetalheAnterior = new System.Windows.Forms.BindingSource(this.components);
            this.dgvParcelasAnterior = new System.Windows.Forms.DataGridView();
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnOpcoesParcelamento = new System.Windows.Forms.Button();
            this.cmdParcelamento = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmCancelar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmCalcular = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSuspender = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtMATRICULA_CARTORIO = new AMS.TextBox.IntegerTextBox();
            this.txtMATRICULA_CARTORIO_CIDADE = new System.Windows.Forms.TextBox();
            this.txtMATRICULA_DATA_REGISTRO = new AMS.TextBox.DateTextBox();
            this.txtMATRICULA_NUMERO = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDataIntimacao = new AMS.TextBox.DateTextBox();
            this.grpTipoCiencia = new System.Windows.Forms.GroupBox();
            this.rdbExigibilidade = new System.Windows.Forms.RadioButton();
            this.rdbAvisoRecebimento = new System.Windows.Forms.RadioButton();
            this.grpIncidencia = new System.Windows.Forms.GroupBox();
            this.txtIncidencia = new System.Windows.Forms.TextBox();
            this.rdbIncidenciaSim = new System.Windows.Forms.RadioButton();
            this.rdbIncidenciaNao = new System.Windows.Forms.RadioButton();
            this.grpDiferimento = new System.Windows.Forms.GroupBox();
            this.txtDiferimento = new System.Windows.Forms.TextBox();
            this.rdbDiferimentoNao = new System.Windows.Forms.RadioButton();
            this.rdbDiferimentoSim = new System.Windows.Forms.RadioButton();
            this.label27 = new System.Windows.Forms.Label();
            this.txtCiencia = new AMS.TextBox.DateTextBox();
            this.label155 = new System.Windows.Forms.Label();
            this.pcbData = new System.Windows.Forms.PictureBox();
            this.txtExigibilidade = new AMS.TextBox.DateTextBox();
            this.lblStatusNotificacao = new System.Windows.Forms.Label();
            this.dA_TB_TRIBUTOTableAdapter1 = new PMV.Tributario.DL.DividaAtiva.DS.DSTabelaTableAdapters.DA_TB_TRIBUTOTableAdapter();
            this.tbpHistorico = new System.Windows.Forms.TabPage();
            this.dgvHistorico = new System.Windows.Forms.DataGridView();
            this.mOTIVODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROCESSODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PROCESSO_ANO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tIPODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSUARIOINCLUSAODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSourceHistorico = new System.Windows.Forms.BindingSource(this.components);
            this.label156 = new System.Windows.Forms.Label();
            this.btnDa = new System.Windows.Forms.Button();
            this.pnlRemessa = new System.Windows.Forms.Panel();
            this.txtControleLegalidade = new AMS.TextBox.AlphanumericTextBox();
            this.txtProcessoRemessa = new AMS.TextBox.AlphanumericTextBox();
            this.txtDataRemessa = new AMS.TextBox.MaskedTextBox();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            lblNumeroProcesso = new System.Windows.Forms.Label();
            lblEmail = new System.Windows.Forms.Label();
            lblObsGeral = new System.Windows.Forms.Label();
            label83 = new System.Windows.Forms.Label();
            label84 = new System.Windows.Forms.Label();
            label85 = new System.Windows.Forms.Label();
            label81 = new System.Windows.Forms.Label();
            label78 = new System.Windows.Forms.Label();
            label79 = new System.Windows.Forms.Label();
            label80 = new System.Windows.Forms.Label();
            label23 = new System.Windows.Forms.Label();
            label21 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            inscMunicipalLabel = new System.Windows.Forms.Label();
            label46 = new System.Windows.Forms.Label();
            label47 = new System.Windows.Forms.Label();
            label48 = new System.Windows.Forms.Label();
            label49 = new System.Windows.Forms.Label();
            label50 = new System.Windows.Forms.Label();
            label52 = new System.Windows.Forms.Label();
            label53 = new System.Windows.Forms.Label();
            label61 = new System.Windows.Forms.Label();
            nomeRazaoLabel1 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label51 = new System.Windows.Forms.Label();
            label54 = new System.Windows.Forms.Label();
            label86 = new System.Windows.Forms.Label();
            label62 = new System.Windows.Forms.Label();
            label59 = new System.Windows.Forms.Label();
            label60 = new System.Windows.Forms.Label();
            label88 = new System.Windows.Forms.Label();
            label64 = new System.Windows.Forms.Label();
            label90 = new System.Windows.Forms.Label();
            label100 = new System.Windows.Forms.Label();
            label104 = new System.Windows.Forms.Label();
            label108 = new System.Windows.Forms.Label();
            label110 = new System.Windows.Forms.Label();
            label112 = new System.Windows.Forms.Label();
            label113 = new System.Windows.Forms.Label();
            label114 = new System.Windows.Forms.Label();
            label116 = new System.Windows.Forms.Label();
            label118 = new System.Windows.Forms.Label();
            label106 = new System.Windows.Forms.Label();
            label115 = new System.Windows.Forms.Label();
            label119 = new System.Windows.Forms.Label();
            label120 = new System.Windows.Forms.Label();
            label122 = new System.Windows.Forms.Label();
            label41 = new System.Windows.Forms.Label();
            label37 = new System.Windows.Forms.Label();
            label39 = new System.Windows.Forms.Label();
            label42 = new System.Windows.Forms.Label();
            label45 = new System.Windows.Forms.Label();
            label44 = new System.Windows.Forms.Label();
            label121 = new System.Windows.Forms.Label();
            label124 = new System.Windows.Forms.Label();
            label125 = new System.Windows.Forms.Label();
            label126 = new System.Windows.Forms.Label();
            label128 = new System.Windows.Forms.Label();
            label130 = new System.Windows.Forms.Label();
            label136 = new System.Windows.Forms.Label();
            label137 = new System.Windows.Forms.Label();
            label138 = new System.Windows.Forms.Label();
            label139 = new System.Windows.Forms.Label();
            label140 = new System.Windows.Forms.Label();
            label142 = new System.Windows.Forms.Label();
            label143 = new System.Windows.Forms.Label();
            label144 = new System.Windows.Forms.Label();
            label145 = new System.Windows.Forms.Label();
            label151 = new System.Windows.Forms.Label();
            label153 = new System.Windows.Forms.Label();
            label154 = new System.Windows.Forms.Label();
            lblDataCiencia = new System.Windows.Forms.Label();
            lblDataExigibilidade = new System.Windows.Forms.Label();
            label57 = new System.Windows.Forms.Label();
            label56 = new System.Windows.Forms.Label();
            label55 = new System.Windows.Forms.Label();
            label127 = new System.Windows.Forms.Label();
            label129 = new System.Windows.Forms.Label();
            label131 = new System.Windows.Forms.Label();
            label133 = new System.Windows.Forms.Label();
            label135 = new System.Windows.Forms.Label();
            label101 = new System.Windows.Forms.Label();
            label103 = new System.Windows.Forms.Label();
            label117 = new System.Windows.Forms.Label();
            label107 = new System.Windows.Forms.Label();
            label105 = new System.Windows.Forms.Label();
            label109 = new System.Windows.Forms.Label();
            label111 = new System.Windows.Forms.Label();
            label123 = new System.Windows.Forms.Label();
            label92 = new System.Windows.Forms.Label();
            lblFatoJuridico = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label20 = new System.Windows.Forms.Label();
            this.tbcCadastro.SuspendLayout();
            this.tbpCadastro.SuspendLayout();
            this.tbpPesquisa.SuspendLayout();
            this.pnlBotoes_02.SuspendLayout();
            this.pnlBotoes_01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotificacao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSNotificacaoLancamento)).BeginInit();
            this.tbpAssunto.SuspendLayout();
            this.tbpContribuinte.SuspendLayout();
            this.gbxSujeitoPassivo.SuspendLayout();
            this.pnl_Botoes_Contribuinte.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContribuinte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource)).BeginInit();
            this.grpSujeicao.SuspendLayout();
            this.pnlDescricao.SuspendLayout();
            this.pnlEndereco.SuspendLayout();
            this.pnlCanceladoRemessa.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.tbpParcelamento.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelamantoComplemento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource)).BeginInit();
            this.pnlParcelamentoParcela.SuspendLayout();
            this.pnlParcelamentoDados.SuspendLayout();
            this.cmsOpcoes.SuspendLayout();
            this.tbpLancamento.SuspendLayout();
            this.tblLancamentos.SuspendLayout();
            this.tbgConstrucao.SuspendLayout();
            this.pnl_Botoes_Construcao.SuspendLayout();
            this.grpConstrucao.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grpAreas.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.gbxDadosLancamento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLancamentoConstrucao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource)).BeginInit();
            this.tbgInscricao.SuspendLayout();
            this.grpUnificacao.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUnificacao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource)).BeginInit();
            this.tbpParcelas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelaDetalhe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcela)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource)).BeginInit();
            this.tbpParcelamentoAnterior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelamentoAnterior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelaDetalheAnterior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOParcelaDetalheAnterior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelasAnterior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource)).BeginInit();
            this.cmdParcelamento.SuspendLayout();
            this.panel6.SuspendLayout();
            this.grpTipoCiencia.SuspendLayout();
            this.grpIncidencia.SuspendLayout();
            this.grpDiferimento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbData)).BeginInit();
            this.tbpHistorico.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistorico)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceHistorico)).BeginInit();
            this.pnlRemessa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tbcCadastro
            // 
            this.tbcCadastro.Controls.Add(this.tbpContribuinte);
            this.tbcCadastro.Controls.Add(this.tbpAssunto);
            this.tbcCadastro.Controls.Add(this.tbpLancamento);
            this.tbcCadastro.Controls.Add(this.tbpParcelamento);
            this.tbcCadastro.Controls.Add(this.tbpParcelas);
            this.tbcCadastro.Controls.Add(this.tbpParcelamentoAnterior);
            this.tbcCadastro.Controls.Add(this.tbpHistorico);
            this.tbcCadastro.Size = new System.Drawing.Size(1010, 717);
            this.tbcCadastro.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tbcCadastro_Selecting);
            this.tbcCadastro.Click += new System.EventHandler(this.tbcCadastro_Click);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpHistorico, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpParcelamentoAnterior, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpParcelas, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpParcelamento, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpLancamento, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpAssunto, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpContribuinte, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpPesquisa, 0);
            this.tbcCadastro.Controls.SetChildIndex(this.tbpCadastro, 0);
            // 
            // tbpCadastro
            // 
            this.tbpCadastro.Controls.Add(this.pnlRemessa);
            this.tbpCadastro.Controls.Add(this.panel6);
            this.tbpCadastro.Controls.Add(this.txtDATA_NOTIFICACAO);
            this.tbpCadastro.Controls.Add(this.label22);
            this.tbpCadastro.Controls.Add(this.groupBox1);
            this.tbpCadastro.Controls.Add(this.pnlCanceladoRemessa);
            this.tbpCadastro.Controls.Add(this.txtANO_NOTIFICACAO);
            this.tbpCadastro.Controls.Add(this.txtNUMERO_NOTIFICACAO);
            this.tbpCadastro.Controls.Add(this.label9);
            this.tbpCadastro.Controls.Add(this.lblNumero);
            this.tbpCadastro.Controls.Add(this.panel2);
            this.tbpCadastro.Size = new System.Drawing.Size(1002, 691);
            this.tbpCadastro.Text = "Notificação";
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(932, 3);
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnIncluir
            // 
            this.btnIncluir.Click += new System.EventHandler(this.btnIncluir_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Enabled = false;
            this.btnEditar.Location = new System.Drawing.Point(153, 3);
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Enabled = false;
            this.btnExcluir.Location = new System.Drawing.Point(303, 3);
            this.btnExcluir.Text = "&Cancelar ";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnGravar
            // 
            this.btnGravar.Location = new System.Drawing.Point(78, 3);
            this.btnGravar.Click += new System.EventHandler(this.btnGravar_Click);
            // 
            // tbpPesquisa
            // 
            this.tbpPesquisa.Controls.Add(this.dgvNotificacao);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // pnlBotoes_02
            // 
            this.pnlBotoes_02.Controls.Add(this.btnDa);
            this.pnlBotoes_02.Controls.Add(this.btnOpcoesParcelamento);
            this.pnlBotoes_02.Controls.Add(this.btnOpcoes);
            this.pnlBotoes_02.Controls.Add(this.btnRerratificar);
            this.pnlBotoes_02.Controls.Add(this.btnSuspender);
            this.pnlBotoes_02.Controls.Add(this.btnFinalizar);
            this.pnlBotoes_02.Location = new System.Drawing.Point(0, 746);
            this.pnlBotoes_02.Size = new System.Drawing.Size(1010, 29);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnIncluir, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnGravar, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnEditar, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnFinalizar, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnExcluir, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnSuspender, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnRerratificar, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnOpcoes, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnOpcoesParcelamento, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnDa, 0);
            this.pnlBotoes_02.Controls.SetChildIndex(this.btnFechar, 0);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(932, 3);
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // pnlBotoes_01
            // 
            this.pnlBotoes_01.Location = new System.Drawing.Point(0, 717);
            this.pnlBotoes_01.Size = new System.Drawing.Size(1010, 29);
            // 
            // lblNumeroProcesso
            // 
            lblNumeroProcesso.AutoSize = true;
            lblNumeroProcesso.Location = new System.Drawing.Point(20, 103);
            lblNumeroProcesso.Name = "lblNumeroProcesso";
            lblNumeroProcesso.Size = new System.Drawing.Size(94, 13);
            lblNumeroProcesso.TabIndex = 238;
            lblNumeroProcesso.Text = "Número Processo:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new System.Drawing.Point(77, 79);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new System.Drawing.Size(37, 13);
            lblEmail.TabIndex = 240;
            lblEmail.Text = "e-mail:";
            // 
            // lblObsGeral
            // 
            lblObsGeral.AutoSize = true;
            lblObsGeral.Location = new System.Drawing.Point(8, 125);
            lblObsGeral.Name = "lblObsGeral";
            lblObsGeral.Size = new System.Drawing.Size(106, 13);
            lblObsGeral.TabIndex = 242;
            lblObsGeral.Text = "Observações Gerais:";
            // 
            // label83
            // 
            label83.AutoSize = true;
            label83.Location = new System.Drawing.Point(396, 89);
            label83.Name = "label83";
            label83.Size = new System.Drawing.Size(43, 13);
            label83.TabIndex = 230;
            label83.Text = "Cidade:";
            // 
            // label84
            // 
            label84.AutoSize = true;
            label84.Location = new System.Drawing.Point(90, 89);
            label84.Name = "label84";
            label84.Size = new System.Drawing.Size(24, 13);
            label84.TabIndex = 229;
            label84.Text = "UF:";
            // 
            // label85
            // 
            label85.AutoSize = true;
            label85.Location = new System.Drawing.Point(402, 65);
            label85.Name = "label85";
            label85.Size = new System.Drawing.Size(37, 13);
            label85.TabIndex = 228;
            label85.Text = "Bairro:";
            // 
            // label81
            // 
            label81.AutoSize = true;
            label81.Location = new System.Drawing.Point(83, 15);
            label81.Name = "label81";
            label81.Size = new System.Drawing.Size(31, 13);
            label81.TabIndex = 227;
            label81.Text = "CEP:";
            // 
            // label78
            // 
            label78.AutoSize = true;
            label78.Location = new System.Drawing.Point(40, 65);
            label78.Name = "label78";
            label78.Size = new System.Drawing.Size(74, 13);
            label78.TabIndex = 226;
            label78.Text = "Complemento:";
            // 
            // label79
            // 
            label79.AutoSize = true;
            label79.Location = new System.Drawing.Point(642, 39);
            label79.Name = "label79";
            label79.Size = new System.Drawing.Size(47, 13);
            label79.TabIndex = 225;
            label79.Text = "Número:";
            // 
            // label80
            // 
            label80.AutoSize = true;
            label80.Location = new System.Drawing.Point(50, 39);
            label80.Name = "label80";
            label80.Size = new System.Drawing.Size(64, 13);
            label80.TabIndex = 224;
            label80.Text = "Logradouro:";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new System.Drawing.Point(56, 30);
            label23.Name = "label23";
            label23.Size = new System.Drawing.Size(66, 13);
            label23.TabIndex = 224;
            label23.Text = "Contribuinte:";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new System.Drawing.Point(3, 55);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(119, 13);
            label21.TabIndex = 226;
            label21.Text = "Responsável Tributário:";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new System.Drawing.Point(11, 364);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(106, 13);
            label17.TabIndex = 247;
            label17.Text = "Observações Gerais:";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new System.Drawing.Point(24, 16);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(48, 13);
            label19.TabIndex = 251;
            label19.Text = "Assunto:";
            // 
            // inscMunicipalLabel
            // 
            inscMunicipalLabel.AutoSize = true;
            inscMunicipalLabel.Location = new System.Drawing.Point(150, 21);
            inscMunicipalLabel.Name = "inscMunicipalLabel";
            inscMunicipalLabel.Size = new System.Drawing.Size(53, 13);
            inscMunicipalLabel.TabIndex = 248;
            inscMunicipalLabel.Text = "Inscrição:";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Location = new System.Drawing.Point(396, 89);
            label46.Name = "label46";
            label46.Size = new System.Drawing.Size(43, 13);
            label46.TabIndex = 230;
            label46.Text = "Cidade:";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Location = new System.Drawing.Point(93, 87);
            label47.Name = "label47";
            label47.Size = new System.Drawing.Size(24, 13);
            label47.TabIndex = 229;
            label47.Text = "UF:";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Location = new System.Drawing.Point(402, 65);
            label48.Name = "label48";
            label48.Size = new System.Drawing.Size(37, 13);
            label48.TabIndex = 228;
            label48.Text = "Bairro:";
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.Location = new System.Drawing.Point(86, 15);
            label49.Name = "label49";
            label49.Size = new System.Drawing.Size(31, 13);
            label49.TabIndex = 227;
            label49.Text = "CEP:";
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Location = new System.Drawing.Point(43, 63);
            label50.Name = "label50";
            label50.Size = new System.Drawing.Size(74, 13);
            label50.TabIndex = 226;
            label50.Text = "Complemento:";
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Location = new System.Drawing.Point(634, 39);
            label52.Name = "label52";
            label52.Size = new System.Drawing.Size(47, 13);
            label52.TabIndex = 225;
            label52.Text = "Número:";
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.Location = new System.Drawing.Point(53, 39);
            label53.Name = "label53";
            label53.Size = new System.Drawing.Size(64, 13);
            label53.TabIndex = 224;
            label53.Text = "Logradouro:";
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.Location = new System.Drawing.Point(61, 76);
            label61.Name = "label61";
            label61.Size = new System.Drawing.Size(62, 13);
            label61.TabIndex = 196;
            label61.Text = "CPF/CNPJ:";
            // 
            // nomeRazaoLabel1
            // 
            nomeRazaoLabel1.AutoSize = true;
            nomeRazaoLabel1.Location = new System.Drawing.Point(17, 99);
            nomeRazaoLabel1.Name = "nomeRazaoLabel1";
            nomeRazaoLabel1.Size = new System.Drawing.Size(106, 13);
            nomeRazaoLabel1.TabIndex = 197;
            nomeRazaoLabel1.Text = "Nome/Razão Social:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new System.Drawing.Point(54, 23);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(69, 13);
            label15.TabIndex = 200;
            label15.Text = "Qualificação:";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Location = new System.Drawing.Point(342, 79);
            label51.Name = "label51";
            label51.Size = new System.Drawing.Size(73, 13);
            label51.TabIndex = 261;
            label51.Text = "Nº Reg. Prof.:";
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Location = new System.Drawing.Point(439, 21);
            label54.Name = "label54";
            label54.Size = new System.Drawing.Size(31, 13);
            label54.TabIndex = 249;
            label54.Text = "Tipo:";
            // 
            // label86
            // 
            label86.AutoSize = true;
            label86.Location = new System.Drawing.Point(6, 142);
            label86.Name = "label86";
            label86.Size = new System.Drawing.Size(108, 13);
            label86.TabIndex = 254;
            label86.Text = "Condomínio/Edifício:";
            // 
            // label62
            // 
            label62.AutoSize = true;
            label62.Location = new System.Drawing.Point(48, 115);
            label62.Name = "label62";
            label62.Size = new System.Drawing.Size(66, 13);
            label62.TabIndex = 251;
            label62.Text = "Loteamento:";
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.Location = new System.Drawing.Point(408, 142);
            label59.Name = "label59";
            label59.Size = new System.Drawing.Size(31, 13);
            label59.TabIndex = 258;
            label59.Text = "Lote:";
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.Location = new System.Drawing.Point(394, 115);
            label60.Name = "label60";
            label60.Size = new System.Drawing.Size(45, 13);
            label60.TabIndex = 257;
            label60.Text = "Quadra:";
            // 
            // label88
            // 
            label88.AutoSize = true;
            label88.Location = new System.Drawing.Point(62, 13);
            label88.Name = "label88";
            label88.Size = new System.Drawing.Size(53, 13);
            label88.TabIndex = 253;
            label88.Text = "Inscrição:";
            // 
            // label64
            // 
            label64.AutoSize = true;
            label64.Location = new System.Drawing.Point(408, 142);
            label64.Name = "label64";
            label64.Size = new System.Drawing.Size(31, 13);
            label64.TabIndex = 258;
            label64.Text = "Lote:";
            // 
            // label90
            // 
            label90.AutoSize = true;
            label90.Location = new System.Drawing.Point(394, 115);
            label90.Name = "label90";
            label90.Size = new System.Drawing.Size(45, 13);
            label90.TabIndex = 257;
            label90.Text = "Quadra:";
            // 
            // label100
            // 
            label100.AutoSize = true;
            label100.Location = new System.Drawing.Point(6, 142);
            label100.Name = "label100";
            label100.Size = new System.Drawing.Size(108, 13);
            label100.TabIndex = 254;
            label100.Text = "Condomínio/Edifício:";
            // 
            // label104
            // 
            label104.AutoSize = true;
            label104.Location = new System.Drawing.Point(48, 115);
            label104.Name = "label104";
            label104.Size = new System.Drawing.Size(66, 13);
            label104.TabIndex = 251;
            label104.Text = "Loteamento:";
            // 
            // label108
            // 
            label108.AutoSize = true;
            label108.Location = new System.Drawing.Point(396, 89);
            label108.Name = "label108";
            label108.Size = new System.Drawing.Size(43, 13);
            label108.TabIndex = 230;
            label108.Text = "Cidade:";
            // 
            // label110
            // 
            label110.AutoSize = true;
            label110.Location = new System.Drawing.Point(90, 89);
            label110.Name = "label110";
            label110.Size = new System.Drawing.Size(24, 13);
            label110.TabIndex = 229;
            label110.Text = "UF:";
            // 
            // label112
            // 
            label112.AutoSize = true;
            label112.Location = new System.Drawing.Point(402, 65);
            label112.Name = "label112";
            label112.Size = new System.Drawing.Size(37, 13);
            label112.TabIndex = 228;
            label112.Text = "Bairro:";
            // 
            // label113
            // 
            label113.AutoSize = true;
            label113.Location = new System.Drawing.Point(631, 39);
            label113.Name = "label113";
            label113.Size = new System.Drawing.Size(31, 13);
            label113.TabIndex = 227;
            label113.Text = "CEP:";
            // 
            // label114
            // 
            label114.AutoSize = true;
            label114.Location = new System.Drawing.Point(40, 65);
            label114.Name = "label114";
            label114.Size = new System.Drawing.Size(74, 13);
            label114.TabIndex = 226;
            label114.Text = "Complemento:";
            // 
            // label116
            // 
            label116.AutoSize = true;
            label116.Location = new System.Drawing.Point(519, 39);
            label116.Name = "label116";
            label116.Size = new System.Drawing.Size(47, 13);
            label116.TabIndex = 225;
            label116.Text = "Número:";
            // 
            // label118
            // 
            label118.AutoSize = true;
            label118.Location = new System.Drawing.Point(50, 39);
            label118.Name = "label118";
            label118.Size = new System.Drawing.Size(64, 13);
            label118.TabIndex = 224;
            label118.Text = "Logradouro:";
            // 
            // label106
            // 
            label106.AutoSize = true;
            label106.Location = new System.Drawing.Point(566, 115);
            label106.Name = "label106";
            label106.Size = new System.Drawing.Size(72, 13);
            label106.TabIndex = 260;
            label106.Text = "Área Terreno:";
            // 
            // label115
            // 
            label115.AutoSize = true;
            label115.Location = new System.Drawing.Point(564, 142);
            label115.Name = "label115";
            label115.Size = new System.Drawing.Size(74, 13);
            label115.TabIndex = 261;
            label115.Text = "Área Testada:";
            // 
            // label119
            // 
            label119.AutoSize = true;
            label119.Location = new System.Drawing.Point(18, 124);
            label119.Name = "label119";
            label119.Size = new System.Drawing.Size(104, 13);
            label119.TabIndex = 272;
            label119.Text = "Repres./Procurador:";
            // 
            // label120
            // 
            label120.AutoSize = true;
            label120.Location = new System.Drawing.Point(717, 127);
            label120.Name = "label120";
            label120.Size = new System.Drawing.Size(30, 13);
            label120.TabIndex = 274;
            label120.Text = "CPF:";
            // 
            // label122
            // 
            label122.AutoSize = true;
            label122.Location = new System.Drawing.Point(235, 79);
            label122.Name = "label122";
            label122.Size = new System.Drawing.Size(71, 13);
            label122.TabIndex = 272;
            label122.Text = "Total Devido:";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new System.Drawing.Point(272, 25);
            label41.Name = "label41";
            label41.Size = new System.Drawing.Size(34, 13);
            label41.TabIndex = 267;
            label41.Text = "Valor:";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new System.Drawing.Point(780, 52);
            label37.Name = "label37";
            label37.Size = new System.Drawing.Size(46, 13);
            label37.TabIndex = 230;
            label37.Text = "Parcela:";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new System.Drawing.Point(765, 25);
            label39.Name = "label39";
            label39.Size = new System.Drawing.Size(61, 13);
            label39.TabIndex = 228;
            label39.Text = "Valor Total:";
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Location = new System.Drawing.Point(442, 52);
            label42.Name = "label42";
            label42.Size = new System.Drawing.Size(63, 13);
            label42.TabIndex = 226;
            label42.Text = "Expediente:";
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Location = new System.Drawing.Point(440, 25);
            label45.Name = "label45";
            label45.Size = new System.Drawing.Size(65, 13);
            label45.TabIndex = 224;
            label45.Text = "Juros Comp:";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Location = new System.Drawing.Point(10, 56);
            label44.Name = "label44";
            label44.Size = new System.Drawing.Size(109, 13);
            label44.TabIndex = 225;
            label44.Text = "Quantidade Parcelas:";
            // 
            // label121
            // 
            label121.AutoSize = true;
            label121.Location = new System.Drawing.Point(424, 156);
            label121.Name = "label121";
            label121.Size = new System.Drawing.Size(43, 13);
            label121.TabIndex = 260;
            label121.Text = "Cidade:";
            // 
            // label124
            // 
            label124.AutoSize = true;
            label124.Location = new System.Drawing.Point(100, 156);
            label124.Name = "label124";
            label124.Size = new System.Drawing.Size(24, 13);
            label124.TabIndex = 259;
            label124.Text = "UF:";
            // 
            // label125
            // 
            label125.AutoSize = true;
            label125.Location = new System.Drawing.Point(430, 132);
            label125.Name = "label125";
            label125.Size = new System.Drawing.Size(37, 13);
            label125.TabIndex = 258;
            label125.Text = "Bairro:";
            // 
            // label126
            // 
            label126.AutoSize = true;
            label126.Location = new System.Drawing.Point(93, 106);
            label126.Name = "label126";
            label126.Size = new System.Drawing.Size(31, 13);
            label126.TabIndex = 257;
            label126.Text = "CEP:";
            // 
            // label128
            // 
            label128.AutoSize = true;
            label128.Location = new System.Drawing.Point(50, 132);
            label128.Name = "label128";
            label128.Size = new System.Drawing.Size(74, 13);
            label128.TabIndex = 256;
            label128.Text = "Complemento:";
            // 
            // label130
            // 
            label130.AutoSize = true;
            label130.Location = new System.Drawing.Point(593, 105);
            label130.Name = "label130";
            label130.Size = new System.Drawing.Size(47, 13);
            label130.TabIndex = 255;
            label130.Text = "Número:";
            // 
            // label136
            // 
            label136.AutoSize = true;
            label136.Location = new System.Drawing.Point(241, 105);
            label136.Name = "label136";
            label136.Size = new System.Drawing.Size(64, 13);
            label136.TabIndex = 254;
            label136.Text = "Logradouro:";
            // 
            // label137
            // 
            label137.AutoSize = true;
            label137.Location = new System.Drawing.Point(437, 79);
            label137.Name = "label137";
            label137.Size = new System.Drawing.Size(30, 13);
            label137.TabIndex = 282;
            label137.Text = "CPF:";
            // 
            // label138
            // 
            label138.AutoSize = true;
            label138.Location = new System.Drawing.Point(48, 78);
            label138.Name = "label138";
            label138.Size = new System.Drawing.Size(72, 13);
            label138.TabIndex = 280;
            label138.Text = "Responsável:";
            // 
            // label139
            // 
            label139.AutoSize = true;
            label139.Location = new System.Drawing.Point(59, 29);
            label139.Name = "label139";
            label139.Size = new System.Drawing.Size(62, 13);
            label139.TabIndex = 277;
            label139.Text = "CPF/CNPJ:";
            // 
            // label140
            // 
            label140.AutoSize = true;
            label140.Location = new System.Drawing.Point(15, 52);
            label140.Name = "label140";
            label140.Size = new System.Drawing.Size(106, 13);
            label140.TabIndex = 278;
            label140.Text = "Nome/Razão Social:";
            // 
            // label142
            // 
            label142.AutoSize = true;
            label142.Location = new System.Drawing.Point(437, 184);
            label142.Name = "label142";
            label142.Size = new System.Drawing.Size(30, 13);
            label142.TabIndex = 286;
            label142.Text = "CPF:";
            // 
            // label143
            // 
            label143.AutoSize = true;
            label143.Location = new System.Drawing.Point(62, 184);
            label143.Name = "label143";
            label143.Size = new System.Drawing.Size(62, 13);
            label143.TabIndex = 288;
            label143.Text = "Procurador:";
            // 
            // label144
            // 
            label144.AutoSize = true;
            label144.Location = new System.Drawing.Point(76, 210);
            label144.Name = "label144";
            label144.Size = new System.Drawing.Size(48, 13);
            label144.TabIndex = 290;
            label144.Text = "Assunto:";
            // 
            // label145
            // 
            label145.AutoSize = true;
            label145.Location = new System.Drawing.Point(15, 27);
            label145.Name = "label145";
            label145.Size = new System.Drawing.Size(107, 13);
            label145.TabIndex = 284;
            label145.Text = "Data de Vencimento:";
            // 
            // label151
            // 
            label151.AutoSize = true;
            label151.Location = new System.Drawing.Point(627, 25);
            label151.Name = "label151";
            label151.Size = new System.Drawing.Size(35, 13);
            label151.TabIndex = 297;
            label151.Text = "Juros:";
            // 
            // label153
            // 
            label153.AutoSize = true;
            label153.Location = new System.Drawing.Point(626, 52);
            label153.Name = "label153";
            label153.Size = new System.Drawing.Size(36, 13);
            label153.TabIndex = 299;
            label153.Text = "Multa:";
            // 
            // label154
            // 
            label154.AutoSize = true;
            label154.Location = new System.Drawing.Point(609, 79);
            label154.Name = "label154";
            label154.Size = new System.Drawing.Size(53, 13);
            label154.TabIndex = 301;
            label154.Text = "Correção:";
            // 
            // lblDataCiencia
            // 
            lblDataCiencia.AutoSize = true;
            lblDataCiencia.Location = new System.Drawing.Point(28, 31);
            lblDataCiencia.Name = "lblDataCiencia";
            lblDataCiencia.Size = new System.Drawing.Size(86, 13);
            lblDataCiencia.TabIndex = 310;
            lblDataCiencia.Text = "Data da Ciência:";
            // 
            // lblDataExigibilidade
            // 
            lblDataExigibilidade.AutoSize = true;
            lblDataExigibilidade.Location = new System.Drawing.Point(5, 55);
            lblDataExigibilidade.Name = "lblDataExigibilidade";
            lblDataExigibilidade.Size = new System.Drawing.Size(109, 13);
            lblDataExigibilidade.TabIndex = 307;
            lblDataExigibilidade.Text = "Data da Exigibilidade:";
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.Location = new System.Drawing.Point(553, 17);
            label57.Name = "label57";
            label57.Size = new System.Drawing.Size(46, 13);
            label57.TabIndex = 249;
            label57.Text = "Subtipo:";
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.Location = new System.Drawing.Point(265, 17);
            label56.Name = "label56";
            label56.Size = new System.Drawing.Size(65, 13);
            label56.TabIndex = 249;
            label56.Text = "Tipo Imóvel:";
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.Location = new System.Drawing.Point(6, 17);
            label55.Name = "label55";
            label55.Size = new System.Drawing.Size(31, 13);
            label55.TabIndex = 249;
            label55.Text = "Tipo:";
            // 
            // label127
            // 
            label127.AutoSize = true;
            label127.Location = new System.Drawing.Point(23, 129);
            label127.Name = "label127";
            label127.Size = new System.Drawing.Size(37, 13);
            label127.TabIndex = 125;
            label127.Text = "Alvará";
            // 
            // label129
            // 
            label129.AutoSize = true;
            label129.Location = new System.Drawing.Point(23, 56);
            label129.Name = "label129";
            label129.Size = new System.Drawing.Size(206, 13);
            label129.TabIndex = 123;
            label129.Text = "Licença/Fiscalização Reforma/Demolição";
            // 
            // label131
            // 
            label131.AutoSize = true;
            label131.Location = new System.Drawing.Point(23, 166);
            label131.Name = "label131";
            label131.Size = new System.Drawing.Size(65, 13);
            label131.TabIndex = 121;
            label131.Text = "Penalidades";
            // 
            // label133
            // 
            label133.AutoSize = true;
            label133.Location = new System.Drawing.Point(23, 93);
            label133.Name = "label133";
            label133.Size = new System.Drawing.Size(65, 13);
            label133.TabIndex = 117;
            label133.Text = "Alinhamento";
            // 
            // label135
            // 
            label135.AutoSize = true;
            label135.Location = new System.Drawing.Point(23, 20);
            label135.Name = "label135";
            label135.Size = new System.Drawing.Size(165, 13);
            label135.TabIndex = 113;
            label135.Text = "Licença/Fiscalização Construção";
            // 
            // label101
            // 
            label101.AutoSize = true;
            label101.Location = new System.Drawing.Point(20, 93);
            label101.Name = "label101";
            label101.Size = new System.Drawing.Size(47, 13);
            label101.TabIndex = 127;
            label101.Text = "Reforma";
            // 
            // label103
            // 
            label103.AutoSize = true;
            label103.Location = new System.Drawing.Point(20, 20);
            label103.Name = "label103";
            label103.Size = new System.Drawing.Size(61, 13);
            label103.TabIndex = 125;
            label103.Text = "Construção";
            // 
            // label117
            // 
            label117.AutoSize = true;
            label117.Location = new System.Drawing.Point(20, 129);
            label117.Name = "label117";
            label117.Size = new System.Drawing.Size(61, 13);
            label117.TabIndex = 123;
            label117.Text = "Engenharia";
            // 
            // label107
            // 
            label107.AutoSize = true;
            label107.Location = new System.Drawing.Point(20, 57);
            label107.Name = "label107";
            label107.Size = new System.Drawing.Size(57, 13);
            label107.TabIndex = 121;
            label107.Text = "Demolição";
            // 
            // label105
            // 
            label105.AutoSize = true;
            label105.Location = new System.Drawing.Point(23, 56);
            label105.Name = "label105";
            label105.Size = new System.Drawing.Size(57, 13);
            label105.TabIndex = 123;
            label105.Text = "Demolição";
            // 
            // label109
            // 
            label109.AutoSize = true;
            label109.Location = new System.Drawing.Point(23, 93);
            label109.Name = "label109";
            label109.Size = new System.Drawing.Size(47, 13);
            label109.TabIndex = 117;
            label109.Text = "Reforma";
            // 
            // label111
            // 
            label111.AutoSize = true;
            label111.Location = new System.Drawing.Point(23, 20);
            label111.Name = "label111";
            label111.Size = new System.Drawing.Size(61, 13);
            label111.TabIndex = 113;
            label111.Text = "Construção";
            // 
            // label123
            // 
            label123.AutoSize = true;
            label123.Location = new System.Drawing.Point(23, 129);
            label123.Name = "label123";
            label123.Size = new System.Drawing.Size(61, 13);
            label123.TabIndex = 113;
            label123.Text = "Engenharia";
            // 
            // label92
            // 
            label92.AutoSize = true;
            label92.Location = new System.Drawing.Point(24, 165);
            label92.Name = "label92";
            label92.Size = new System.Drawing.Size(63, 13);
            label92.TabIndex = 123;
            label92.Text = "Penalidade:";
            // 
            // lblFatoJuridico
            // 
            lblFatoJuridico.AutoSize = true;
            lblFatoJuridico.Location = new System.Drawing.Point(24, 379);
            lblFatoJuridico.Name = "lblFatoJuridico";
            lblFatoJuridico.Size = new System.Drawing.Size(72, 13);
            lblFatoJuridico.TabIndex = 253;
            lblFatoJuridico.Text = "Fato Jurídico:";
            lblFatoJuridico.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(68, 331);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(46, 13);
            label11.TabIndex = 330;
            label11.Text = "Cartório:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(318, 308);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(90, 13);
            label12.TabIndex = 329;
            label12.Text = "Data do Registro:";
            label12.Visible = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new System.Drawing.Point(4, 307);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(110, 13);
            label18.TabIndex = 328;
            label18.Text = "Número da Matrícula:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label20.Location = new System.Drawing.Point(8, 283);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(61, 15);
            label20.TabIndex = 327;
            label20.Text = "Registro";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 38);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 311;
            this.label24.Text = "Obs.:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(4, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 16);
            this.label1.TabIndex = 249;
            this.label1.Text = "Remessa em Dívida Ativa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(269, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 182;
            this.label2.Text = "Controle de Legalidade :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(113, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 181;
            this.label3.Text = "Processo Nº:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 180;
            this.label4.Text = "Data Remessa:";
            // 
            // lblDescontoPenalidade
            // 
            this.lblDescontoPenalidade.AutoSize = true;
            this.lblDescontoPenalidade.Location = new System.Drawing.Point(212, 52);
            this.lblDescontoPenalidade.Name = "lblDescontoPenalidade";
            this.lblDescontoPenalidade.Size = new System.Drawing.Size(94, 13);
            this.lblDescontoPenalidade.TabIndex = 270;
            this.lblDescontoPenalidade.Text = "Desc. Penalidade:";
            // 
            // dgvNotificacao
            // 
            this.dgvNotificacao.AllowUserToAddRows = false;
            this.dgvNotificacao.AllowUserToDeleteRows = false;
            this.dgvNotificacao.AutoGenerateColumns = false;
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle56.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvNotificacao.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle56;
            this.dgvNotificacao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNotificacao.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_NOTIFICACAO,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.INSCRICAO,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn27});
            this.dgvNotificacao.DataSource = this.mO_NOTIFICACAO_LANCAMENTOBindingSource;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNotificacao.DefaultCellStyle = dataGridViewCellStyle57;
            this.dgvNotificacao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNotificacao.Location = new System.Drawing.Point(3, 3);
            this.dgvNotificacao.Name = "dgvNotificacao";
            this.dgvNotificacao.ReadOnly = true;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvNotificacao.RowHeadersDefaultCellStyle = dataGridViewCellStyle58;
            this.dgvNotificacao.RowHeadersWidth = 11;
            this.dgvNotificacao.Size = new System.Drawing.Size(538, 232);
            this.dgvNotificacao.TabIndex = 2;
            this.dgvNotificacao.SelectionChanged += new System.EventHandler(this.dgvNotificacao_SelectionChanged);
            // 
            // ID_NOTIFICACAO
            // 
            this.ID_NOTIFICACAO.DataPropertyName = "ID_NOTIFICACAO";
            this.ID_NOTIFICACAO.HeaderText = "Código";
            this.ID_NOTIFICACAO.Name = "ID_NOTIFICACAO";
            this.ID_NOTIFICACAO.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TIPO";
            this.dataGridViewTextBoxColumn2.HeaderText = "TIPO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ANO_NOTIFICACAO";
            this.dataGridViewTextBoxColumn3.HeaderText = "Ano";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NUMERO_NOTIFICACAO";
            this.dataGridViewTextBoxColumn4.HeaderText = "Número";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "DATA_NOTIFICACAO";
            this.dataGridViewTextBoxColumn5.HeaderText = "Data";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // INSCRICAO
            // 
            this.INSCRICAO.DataPropertyName = "INSCRICAO";
            this.INSCRICAO.HeaderText = "Inscrição";
            this.INSCRICAO.Name = "INSCRICAO";
            this.INSCRICAO.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "FATO_JURIDICO";
            this.dataGridViewTextBoxColumn21.HeaderText = "Fato Jurídico";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "ASSUNTO";
            this.dataGridViewTextBoxColumn22.HeaderText = "Assunto";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "DATA_VENCIMENTO";
            this.dataGridViewTextBoxColumn24.HeaderText = "Data Vencimento";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "VALOR_TOTAL";
            this.dataGridViewTextBoxColumn25.HeaderText = "Valor Total";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "OBSERVACAO";
            this.dataGridViewTextBoxColumn27.HeaderText = "Observação";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // mO_NOTIFICACAO_LANCAMENTOBindingSource
            // 
            this.mO_NOTIFICACAO_LANCAMENTOBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO";
            this.mO_NOTIFICACAO_LANCAMENTOBindingSource.DataSource = this.dSNotificacaoLancamento;
            // 
            // dSNotificacaoLancamento
            // 
            this.dSNotificacaoLancamento.DataSetName = "DSNotificacaoLancamento";
            this.dSNotificacaoLancamento.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbpAssunto
            // 
            this.tbpAssunto.Controls.Add(this.txtFATO_JURIDICO);
            this.tbpAssunto.Controls.Add(lblFatoJuridico);
            this.tbpAssunto.Controls.Add(label19);
            this.tbpAssunto.Controls.Add(this.txtASSUNTO);
            this.tbpAssunto.Location = new System.Drawing.Point(4, 22);
            this.tbpAssunto.Name = "tbpAssunto";
            this.tbpAssunto.Padding = new System.Windows.Forms.Padding(3);
            this.tbpAssunto.Size = new System.Drawing.Size(544, 238);
            this.tbpAssunto.TabIndex = 2;
            this.tbpAssunto.Text = "Assunto";
            this.tbpAssunto.UseVisualStyleBackColor = true;
            // 
            // txtFATO_JURIDICO
            // 
            this.txtFATO_JURIDICO.Location = new System.Drawing.Point(27, 395);
            this.txtFATO_JURIDICO.Name = "txtFATO_JURIDICO";
            this.txtFATO_JURIDICO.Size = new System.Drawing.Size(942, 227);
            this.txtFATO_JURIDICO.TabIndex = 254;
            this.txtFATO_JURIDICO.Visible = false;
            // 
            // txtASSUNTO
            // 
            this.txtASSUNTO.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtASSUNTO.Location = new System.Drawing.Point(27, 37);
            this.txtASSUNTO.Name = "txtASSUNTO";
            this.txtASSUNTO.Size = new System.Drawing.Size(484, 331);
            this.txtASSUNTO.TabIndex = 252;
            // 
            // txtANO_NOTIFICACAO
            // 
            this.txtANO_NOTIFICACAO.AllowNegative = true;
            this.txtANO_NOTIFICACAO.BackColor = System.Drawing.Color.White;
            this.txtANO_NOTIFICACAO.DigitsInGroup = 0;
            this.txtANO_NOTIFICACAO.Flags = 0;
            this.txtANO_NOTIFICACAO.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtANO_NOTIFICACAO.Location = new System.Drawing.Point(750, 22);
            this.txtANO_NOTIFICACAO.MaxDecimalPlaces = 0;
            this.txtANO_NOTIFICACAO.MaxWholeDigits = 9;
            this.txtANO_NOTIFICACAO.Name = "txtANO_NOTIFICACAO";
            this.txtANO_NOTIFICACAO.Prefix = "";
            this.txtANO_NOTIFICACAO.RangeMax = 2147483647D;
            this.txtANO_NOTIFICACAO.RangeMin = -2147483648D;
            this.txtANO_NOTIFICACAO.ReadOnly = true;
            this.txtANO_NOTIFICACAO.Size = new System.Drawing.Size(67, 22);
            this.txtANO_NOTIFICACAO.TabIndex = 232;
            this.txtANO_NOTIFICACAO.TabStop = false;
            // 
            // txtID_NOTIFICACAO
            // 
            this.txtID_NOTIFICACAO.BackColor = System.Drawing.Color.White;
            this.txtID_NOTIFICACAO.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID_NOTIFICACAO.Location = new System.Drawing.Point(887, 137);
            this.txtID_NOTIFICACAO.Name = "txtID_NOTIFICACAO";
            this.txtID_NOTIFICACAO.ReadOnly = true;
            this.txtID_NOTIFICACAO.Size = new System.Drawing.Size(50, 22);
            this.txtID_NOTIFICACAO.TabIndex = 233;
            this.txtID_NOTIFICACAO.TabStop = false;
            this.txtID_NOTIFICACAO.Visible = false;
            // 
            // txtNUMERO_NOTIFICACAO
            // 
            this.txtNUMERO_NOTIFICACAO.BackColor = System.Drawing.Color.White;
            this.txtNUMERO_NOTIFICACAO.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUMERO_NOTIFICACAO.Location = new System.Drawing.Point(624, 22);
            this.txtNUMERO_NOTIFICACAO.Name = "txtNUMERO_NOTIFICACAO";
            this.txtNUMERO_NOTIFICACAO.ReadOnly = true;
            this.txtNUMERO_NOTIFICACAO.Size = new System.Drawing.Size(100, 22);
            this.txtNUMERO_NOTIFICACAO.TabIndex = 231;
            this.txtNUMERO_NOTIFICACAO.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(884, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 16);
            this.label8.TabIndex = 234;
            this.label8.Text = "Código";
            this.label8.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(747, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 235;
            this.label9.Text = "Ano Notificação";
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero.Location = new System.Drawing.Point(625, 6);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(119, 13);
            this.lblNumero.TabIndex = 236;
            this.lblNumero.Text = "Número Notificação";
            // 
            // tbpContribuinte
            // 
            this.tbpContribuinte.Controls.Add(this.gbxSujeitoPassivo);
            this.tbpContribuinte.Controls.Add(this.grpSujeicao);
            this.tbpContribuinte.Location = new System.Drawing.Point(4, 22);
            this.tbpContribuinte.Name = "tbpContribuinte";
            this.tbpContribuinte.Padding = new System.Windows.Forms.Padding(3);
            this.tbpContribuinte.Size = new System.Drawing.Size(544, 238);
            this.tbpContribuinte.TabIndex = 4;
            this.tbpContribuinte.Text = "Sujeição Passiva";
            this.tbpContribuinte.UseVisualStyleBackColor = true;
            // 
            // gbxSujeitoPassivo
            // 
            this.gbxSujeitoPassivo.Controls.Add(this.pnl_Botoes_Contribuinte);
            this.gbxSujeitoPassivo.Controls.Add(this.dgvContribuinte);
            this.gbxSujeitoPassivo.Location = new System.Drawing.Point(3, 443);
            this.gbxSujeitoPassivo.Name = "gbxSujeitoPassivo";
            this.gbxSujeitoPassivo.Size = new System.Drawing.Size(974, 188);
            this.gbxSujeitoPassivo.TabIndex = 271;
            this.gbxSujeitoPassivo.TabStop = false;
            // 
            // pnl_Botoes_Contribuinte
            // 
            this.pnl_Botoes_Contribuinte.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnl_Botoes_Contribuinte.Controls.Add(this.btnLimparContribuinte);
            this.pnl_Botoes_Contribuinte.Controls.Add(this.btnGravarContribuinte);
            this.pnl_Botoes_Contribuinte.Controls.Add(this.btnExcluirContribuinte);
            this.pnl_Botoes_Contribuinte.Controls.Add(this.btnEditarContribuinte);
            this.pnl_Botoes_Contribuinte.Controls.Add(this.btnIncluirContribuinte);
            this.pnl_Botoes_Contribuinte.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_Botoes_Contribuinte.Location = new System.Drawing.Point(3, 156);
            this.pnl_Botoes_Contribuinte.Name = "pnl_Botoes_Contribuinte";
            this.pnl_Botoes_Contribuinte.Padding = new System.Windows.Forms.Padding(3);
            this.pnl_Botoes_Contribuinte.Size = new System.Drawing.Size(968, 29);
            this.pnl_Botoes_Contribuinte.TabIndex = 4;
            // 
            // btnLimparContribuinte
            // 
            this.btnLimparContribuinte.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnLimparContribuinte.Location = new System.Drawing.Point(890, 3);
            this.btnLimparContribuinte.Name = "btnLimparContribuinte";
            this.btnLimparContribuinte.Size = new System.Drawing.Size(75, 23);
            this.btnLimparContribuinte.TabIndex = 4;
            this.btnLimparContribuinte.Text = "&Limpar";
            this.btnLimparContribuinte.UseVisualStyleBackColor = true;
            this.btnLimparContribuinte.Click += new System.EventHandler(this.btnLimparContribuinte_Click);
            // 
            // btnGravarContribuinte
            // 
            this.btnGravarContribuinte.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnGravarContribuinte.Enabled = false;
            this.btnGravarContribuinte.Location = new System.Drawing.Point(228, 3);
            this.btnGravarContribuinte.Name = "btnGravarContribuinte";
            this.btnGravarContribuinte.Size = new System.Drawing.Size(75, 23);
            this.btnGravarContribuinte.TabIndex = 3;
            this.btnGravarContribuinte.Text = "&Gravar";
            this.btnGravarContribuinte.UseVisualStyleBackColor = true;
            this.btnGravarContribuinte.Click += new System.EventHandler(this.btnGravarContribuinte_Click_1);
            // 
            // btnExcluirContribuinte
            // 
            this.btnExcluirContribuinte.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnExcluirContribuinte.Location = new System.Drawing.Point(153, 3);
            this.btnExcluirContribuinte.Name = "btnExcluirContribuinte";
            this.btnExcluirContribuinte.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirContribuinte.TabIndex = 2;
            this.btnExcluirContribuinte.Text = "&Excluir";
            this.btnExcluirContribuinte.UseVisualStyleBackColor = true;
            this.btnExcluirContribuinte.Click += new System.EventHandler(this.btnExcluirContribuinte_Click);
            // 
            // btnEditarContribuinte
            // 
            this.btnEditarContribuinte.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEditarContribuinte.Location = new System.Drawing.Point(78, 3);
            this.btnEditarContribuinte.Name = "btnEditarContribuinte";
            this.btnEditarContribuinte.Size = new System.Drawing.Size(75, 23);
            this.btnEditarContribuinte.TabIndex = 1;
            this.btnEditarContribuinte.Text = "E&ditar";
            this.btnEditarContribuinte.UseVisualStyleBackColor = true;
            this.btnEditarContribuinte.Click += new System.EventHandler(this.btnEditarContribuinte_Click);
            // 
            // btnIncluirContribuinte
            // 
            this.btnIncluirContribuinte.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnIncluirContribuinte.Location = new System.Drawing.Point(3, 3);
            this.btnIncluirContribuinte.Name = "btnIncluirContribuinte";
            this.btnIncluirContribuinte.Size = new System.Drawing.Size(75, 23);
            this.btnIncluirContribuinte.TabIndex = 0;
            this.btnIncluirContribuinte.Text = "&Incluir";
            this.btnIncluirContribuinte.UseVisualStyleBackColor = true;
            this.btnIncluirContribuinte.Click += new System.EventHandler(this.btnIncluirContribuinte_Click);
            // 
            // dgvContribuinte
            // 
            this.dgvContribuinte.AllowUserToAddRows = false;
            this.dgvContribuinte.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContribuinte.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvContribuinte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContribuinte.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_NOTIFICACAO_CONTRIBUINTE,
            this.dataGridViewTextBoxColumn8,
            this.QUALIFICACAO_DESCRICAO,
            this.CPFCNPJ,
            this.NOME_RAZAO,
            this.DOCUMENTO,
            this.INSCRICAO_MUNICIPAL,
            this.RESPONSAVEL,
            this.CPF_RESPONSAVEL,
            this.OBSERVACAO,
            this.PRINCIPAL,
            this.CONTRIBUINTE,
            this.COMO_RESPONSAVEL,
            this.LOGRADOURO,
            this.NUMERO,
            this.COMPLEMENTO,
            this.UF,
            this.CIDADE,
            this.BAIRRO,
            this.CEP,
            this.QUALIFICACAO});
            this.dgvContribuinte.DataSource = this.mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvContribuinte.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvContribuinte.Location = new System.Drawing.Point(1, 14);
            this.dgvContribuinte.Name = "dgvContribuinte";
            this.dgvContribuinte.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContribuinte.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvContribuinte.RowHeadersVisible = false;
            this.dgvContribuinte.Size = new System.Drawing.Size(973, 143);
            this.dgvContribuinte.TabIndex = 1;
            this.dgvContribuinte.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContribuinte_CellDoubleClick);
            // 
            // ID_NOTIFICACAO_CONTRIBUINTE
            // 
            this.ID_NOTIFICACAO_CONTRIBUINTE.DataPropertyName = "ID_NOTIFICACAO_CONTRIBUINTE";
            this.ID_NOTIFICACAO_CONTRIBUINTE.HeaderText = "ID_NOTIFICACAO_CONTRIBUINTE";
            this.ID_NOTIFICACAO_CONTRIBUINTE.Name = "ID_NOTIFICACAO_CONTRIBUINTE";
            this.ID_NOTIFICACAO_CONTRIBUINTE.ReadOnly = true;
            this.ID_NOTIFICACAO_CONTRIBUINTE.Visible = false;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ID_NOTIFICACAO";
            this.dataGridViewTextBoxColumn8.HeaderText = "ID_NOTIFICACAO";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // QUALIFICACAO_DESCRICAO
            // 
            this.QUALIFICACAO_DESCRICAO.DataPropertyName = "QUALIFICACAO_DESCRICAO";
            this.QUALIFICACAO_DESCRICAO.FillWeight = 250F;
            this.QUALIFICACAO_DESCRICAO.HeaderText = "Qualificação";
            this.QUALIFICACAO_DESCRICAO.Name = "QUALIFICACAO_DESCRICAO";
            this.QUALIFICACAO_DESCRICAO.ReadOnly = true;
            this.QUALIFICACAO_DESCRICAO.Width = 250;
            // 
            // CPFCNPJ
            // 
            this.CPFCNPJ.DataPropertyName = "CPFCNPJ";
            this.CPFCNPJ.HeaderText = "CPF/CNPJ";
            this.CPFCNPJ.Name = "CPFCNPJ";
            this.CPFCNPJ.ReadOnly = true;
            // 
            // NOME_RAZAO
            // 
            this.NOME_RAZAO.DataPropertyName = "NOME_RAZAO";
            this.NOME_RAZAO.FillWeight = 200F;
            this.NOME_RAZAO.HeaderText = "Nome/Razão Social";
            this.NOME_RAZAO.Name = "NOME_RAZAO";
            this.NOME_RAZAO.ReadOnly = true;
            this.NOME_RAZAO.Width = 200;
            // 
            // DOCUMENTO
            // 
            this.DOCUMENTO.DataPropertyName = "DOCUMENTO";
            this.DOCUMENTO.HeaderText = "Reg. Prof.";
            this.DOCUMENTO.Name = "DOCUMENTO";
            this.DOCUMENTO.ReadOnly = true;
            // 
            // INSCRICAO_MUNICIPAL
            // 
            this.INSCRICAO_MUNICIPAL.DataPropertyName = "INSCRICAO_MUNICIPAL";
            this.INSCRICAO_MUNICIPAL.HeaderText = "Obs.";
            this.INSCRICAO_MUNICIPAL.Name = "INSCRICAO_MUNICIPAL";
            this.INSCRICAO_MUNICIPAL.ReadOnly = true;
            this.INSCRICAO_MUNICIPAL.Width = 150;
            // 
            // RESPONSAVEL
            // 
            this.RESPONSAVEL.DataPropertyName = "RESPONSAVEL";
            this.RESPONSAVEL.FillWeight = 150F;
            this.RESPONSAVEL.HeaderText = "Responsável";
            this.RESPONSAVEL.Name = "RESPONSAVEL";
            this.RESPONSAVEL.ReadOnly = true;
            this.RESPONSAVEL.Width = 150;
            // 
            // CPF_RESPONSAVEL
            // 
            this.CPF_RESPONSAVEL.DataPropertyName = "CPF_RESPONSAVEL";
            this.CPF_RESPONSAVEL.HeaderText = "CPF Resp.";
            this.CPF_RESPONSAVEL.Name = "CPF_RESPONSAVEL";
            this.CPF_RESPONSAVEL.ReadOnly = true;
            // 
            // OBSERVACAO
            // 
            this.OBSERVACAO.DataPropertyName = "OBSERVACAO";
            this.OBSERVACAO.HeaderText = "Obs. Geral.";
            this.OBSERVACAO.Name = "OBSERVACAO";
            this.OBSERVACAO.ReadOnly = true;
            // 
            // PRINCIPAL
            // 
            this.PRINCIPAL.DataPropertyName = "PRINCIPAL";
            this.PRINCIPAL.HeaderText = "Principal";
            this.PRINCIPAL.Name = "PRINCIPAL";
            this.PRINCIPAL.ReadOnly = true;
            // 
            // CONTRIBUINTE
            // 
            this.CONTRIBUINTE.DataPropertyName = "CONTRIBUINTE";
            this.CONTRIBUINTE.HeaderText = "CONTRIBUINTE";
            this.CONTRIBUINTE.Name = "CONTRIBUINTE";
            this.CONTRIBUINTE.ReadOnly = true;
            this.CONTRIBUINTE.Visible = false;
            // 
            // COMO_RESPONSAVEL
            // 
            this.COMO_RESPONSAVEL.DataPropertyName = "COMO_RESPONSAVEL";
            this.COMO_RESPONSAVEL.HeaderText = "COMO_RESPONSAVEL";
            this.COMO_RESPONSAVEL.Name = "COMO_RESPONSAVEL";
            this.COMO_RESPONSAVEL.ReadOnly = true;
            this.COMO_RESPONSAVEL.Visible = false;
            // 
            // LOGRADOURO
            // 
            this.LOGRADOURO.DataPropertyName = "LOGRADOURO";
            this.LOGRADOURO.HeaderText = "Logradouro";
            this.LOGRADOURO.Name = "LOGRADOURO";
            this.LOGRADOURO.ReadOnly = true;
            this.LOGRADOURO.Visible = false;
            // 
            // NUMERO
            // 
            this.NUMERO.DataPropertyName = "NUMERO";
            this.NUMERO.HeaderText = "NUMERO";
            this.NUMERO.Name = "NUMERO";
            this.NUMERO.ReadOnly = true;
            this.NUMERO.Visible = false;
            // 
            // COMPLEMENTO
            // 
            this.COMPLEMENTO.DataPropertyName = "COMPLEMENTO";
            this.COMPLEMENTO.HeaderText = "COMPLEMENTO";
            this.COMPLEMENTO.Name = "COMPLEMENTO";
            this.COMPLEMENTO.ReadOnly = true;
            this.COMPLEMENTO.Visible = false;
            // 
            // UF
            // 
            this.UF.DataPropertyName = "UF";
            this.UF.HeaderText = "UF";
            this.UF.Name = "UF";
            this.UF.ReadOnly = true;
            this.UF.Visible = false;
            // 
            // CIDADE
            // 
            this.CIDADE.DataPropertyName = "CIDADE";
            this.CIDADE.HeaderText = "CIDADE";
            this.CIDADE.Name = "CIDADE";
            this.CIDADE.ReadOnly = true;
            this.CIDADE.Visible = false;
            // 
            // BAIRRO
            // 
            this.BAIRRO.DataPropertyName = "BAIRRO";
            this.BAIRRO.HeaderText = "BAIRRO";
            this.BAIRRO.Name = "BAIRRO";
            this.BAIRRO.ReadOnly = true;
            this.BAIRRO.Visible = false;
            // 
            // CEP
            // 
            this.CEP.DataPropertyName = "CEP";
            this.CEP.HeaderText = "CEP";
            this.CEP.Name = "CEP";
            this.CEP.ReadOnly = true;
            this.CEP.Visible = false;
            // 
            // QUALIFICACAO
            // 
            this.QUALIFICACAO.DataPropertyName = "QUALIFICACAO";
            this.QUALIFICACAO.HeaderText = "QUALIFICACAO";
            this.QUALIFICACAO.Name = "QUALIFICACAO";
            this.QUALIFICACAO.ReadOnly = true;
            this.QUALIFICACAO.Visible = false;
            // 
            // mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource
            // 
            this.mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTE";
            this.mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource.DataSource = this.dSNotificacaoLancamento;
            // 
            // grpSujeicao
            // 
            this.grpSujeicao.Controls.Add(this.label25);
            this.grpSujeicao.Controls.Add(this.ckbSubnivelProp);
            this.grpSujeicao.Controls.Add(this.txtInscriMun);
            this.grpSujeicao.Controls.Add(label120);
            this.grpSujeicao.Controls.Add(this.txtCPFResponsavel);
            this.grpSujeicao.Controls.Add(this.txtResponsavel);
            this.grpSujeicao.Controls.Add(label119);
            this.grpSujeicao.Controls.Add(label15);
            this.grpSujeicao.Controls.Add(this.lblInscrito);
            this.grpSujeicao.Controls.Add(this.rblNao);
            this.grpSujeicao.Controls.Add(this.rblSim);
            this.grpSujeicao.Controls.Add(this.txtNOME_RAZAO);
            this.grpSujeicao.Controls.Add(this.lblInscricaoMun);
            this.grpSujeicao.Controls.Add(label61);
            this.grpSujeicao.Controls.Add(this.txtDocProfissional);
            this.grpSujeicao.Controls.Add(nomeRazaoLabel1);
            this.grpSujeicao.Controls.Add(label51);
            this.grpSujeicao.Controls.Add(this.txtCPFCNPJ);
            this.grpSujeicao.Controls.Add(this.ckbSubnivel);
            this.grpSujeicao.Controls.Add(this.chkPRINCIPAL);
            this.grpSujeicao.Controls.Add(this.ckbQualificacao);
            this.grpSujeicao.Controls.Add(this.pnlDescricao);
            this.grpSujeicao.Controls.Add(this.btnPessoa);
            this.grpSujeicao.Controls.Add(this.txtOBSERVACAO_P);
            this.grpSujeicao.Controls.Add(this.lblId);
            this.grpSujeicao.Controls.Add(label17);
            this.grpSujeicao.Controls.Add(this.pnlEndereco);
            this.grpSujeicao.Location = new System.Drawing.Point(3, 3);
            this.grpSujeicao.Name = "grpSujeicao";
            this.grpSujeicao.Size = new System.Drawing.Size(974, 434);
            this.grpSujeicao.TabIndex = 270;
            this.grpSujeicao.TabStop = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(965, 33);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 16);
            this.label25.TabIndex = 277;
            this.label25.Visible = false;
            // 
            // ckbSubnivelProp
            // 
            this.ckbSubnivelProp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ckbSubnivelProp.CheckOnClick = true;
            this.ckbSubnivelProp.FormattingEnabled = true;
            this.ckbSubnivelProp.Location = new System.Drawing.Point(338, 23);
            this.ckbSubnivelProp.MultiColumn = true;
            this.ckbSubnivelProp.Name = "ckbSubnivelProp";
            this.ckbSubnivelProp.Size = new System.Drawing.Size(153, 47);
            this.ckbSubnivelProp.TabIndex = 276;
            this.ckbSubnivelProp.Visible = false;
            this.ckbSubnivelProp.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.ckbSubnivelProp_ItemCheck);
            // 
            // txtInscriMun
            // 
            this.txtInscriMun.Location = new System.Drawing.Point(637, 74);
            this.txtInscriMun.Name = "txtInscriMun";
            this.txtInscriMun.Size = new System.Drawing.Size(226, 20);
            this.txtInscriMun.TabIndex = 275;
            this.txtInscriMun.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtCPFResponsavel
            // 
            this.txtCPFResponsavel.Flags = 0;
            this.txtCPFResponsavel.Location = new System.Drawing.Point(753, 123);
            this.txtCPFResponsavel.Mask = "##############";
            this.txtCPFResponsavel.Name = "txtCPFResponsavel";
            this.txtCPFResponsavel.Size = new System.Drawing.Size(175, 20);
            this.txtCPFResponsavel.TabIndex = 273;
            this.txtCPFResponsavel.Leave += new System.EventHandler(this.txtCPFResponsavel_Leave);
            this.txtCPFResponsavel.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtResponsavel
            // 
            this.txtResponsavel.Location = new System.Drawing.Point(126, 124);
            this.txtResponsavel.Name = "txtResponsavel";
            this.txtResponsavel.Size = new System.Drawing.Size(566, 20);
            this.txtResponsavel.TabIndex = 271;
            this.txtResponsavel.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // lblInscrito
            // 
            this.lblInscrito.AutoSize = true;
            this.lblInscrito.Location = new System.Drawing.Point(634, 36);
            this.lblInscrito.Name = "lblInscrito";
            this.lblInscrito.Size = new System.Drawing.Size(154, 13);
            this.lblInscrito.TabIndex = 269;
            this.lblInscrito.Text = "Incidência do ISS Engenharia?";
            this.lblInscrito.Visible = false;
            // 
            // rblNao
            // 
            this.rblNao.AutoSize = true;
            this.rblNao.Location = new System.Drawing.Point(685, 52);
            this.rblNao.Name = "rblNao";
            this.rblNao.Size = new System.Drawing.Size(45, 17);
            this.rblNao.TabIndex = 268;
            this.rblNao.TabStop = true;
            this.rblNao.Text = "Não";
            this.rblNao.UseVisualStyleBackColor = true;
            this.rblNao.Visible = false;
            this.rblNao.Click += new System.EventHandler(this.rblSim_Click);
            // 
            // rblSim
            // 
            this.rblSim.AutoSize = true;
            this.rblSim.Checked = true;
            this.rblSim.Location = new System.Drawing.Point(637, 52);
            this.rblSim.Name = "rblSim";
            this.rblSim.Size = new System.Drawing.Size(42, 17);
            this.rblSim.TabIndex = 267;
            this.rblSim.TabStop = true;
            this.rblSim.Text = "Sim";
            this.rblSim.UseVisualStyleBackColor = true;
            this.rblSim.Visible = false;
            this.rblSim.Click += new System.EventHandler(this.rblSim_Click);
            // 
            // txtNOME_RAZAO
            // 
            this.txtNOME_RAZAO.Location = new System.Drawing.Point(126, 99);
            this.txtNOME_RAZAO.Name = "txtNOME_RAZAO";
            this.txtNOME_RAZAO.Size = new System.Drawing.Size(802, 20);
            this.txtNOME_RAZAO.TabIndex = 190;
            this.txtNOME_RAZAO.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // lblInscricaoMun
            // 
            this.lblInscricaoMun.AutoSize = true;
            this.lblInscricaoMun.Location = new System.Drawing.Point(605, 76);
            this.lblInscricaoMun.Name = "lblInscricaoMun";
            this.lblInscricaoMun.Size = new System.Drawing.Size(32, 13);
            this.lblInscricaoMun.TabIndex = 266;
            this.lblInscricaoMun.Text = "Obs.:";
            this.lblInscricaoMun.Visible = false;
            // 
            // txtDocProfissional
            // 
            this.txtDocProfissional.Flags = 0;
            this.txtDocProfissional.Location = new System.Drawing.Point(418, 75);
            this.txtDocProfissional.Mask = "##############";
            this.txtDocProfissional.Name = "txtDocProfissional";
            this.txtDocProfissional.Size = new System.Drawing.Size(172, 20);
            this.txtDocProfissional.TabIndex = 189;
            this.txtDocProfissional.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtCPFCNPJ
            // 
            this.txtCPFCNPJ.Flags = 0;
            this.txtCPFCNPJ.Location = new System.Drawing.Point(126, 75);
            this.txtCPFCNPJ.Mask = "##############";
            this.txtCPFCNPJ.Name = "txtCPFCNPJ";
            this.txtCPFCNPJ.Size = new System.Drawing.Size(172, 20);
            this.txtCPFCNPJ.TabIndex = 189;
            this.txtCPFCNPJ.Leave += new System.EventHandler(this.txtCPFCNPJ_Leave);
            this.txtCPFCNPJ.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // ckbSubnivel
            // 
            this.ckbSubnivel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ckbSubnivel.CheckOnClick = true;
            this.ckbSubnivel.FormattingEnabled = true;
            this.ckbSubnivel.Location = new System.Drawing.Point(338, 23);
            this.ckbSubnivel.MultiColumn = true;
            this.ckbSubnivel.Name = "ckbSubnivel";
            this.ckbSubnivel.Size = new System.Drawing.Size(153, 47);
            this.ckbSubnivel.TabIndex = 259;
            this.ckbSubnivel.Visible = false;
            this.ckbSubnivel.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.ckbSubnivel_ItemCheck);
            // 
            // chkPRINCIPAL
            // 
            this.chkPRINCIPAL.AutoSize = true;
            this.chkPRINCIPAL.Location = new System.Drawing.Point(637, 404);
            this.chkPRINCIPAL.Name = "chkPRINCIPAL";
            this.chkPRINCIPAL.Size = new System.Drawing.Size(66, 17);
            this.chkPRINCIPAL.TabIndex = 194;
            this.chkPRINCIPAL.Text = "Principal";
            this.chkPRINCIPAL.UseVisualStyleBackColor = true;
            // 
            // ckbQualificacao
            // 
            this.ckbQualificacao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ckbQualificacao.CheckOnClick = true;
            this.ckbQualificacao.FormattingEnabled = true;
            this.ckbQualificacao.Location = new System.Drawing.Point(126, 23);
            this.ckbQualificacao.Name = "ckbQualificacao";
            this.ckbQualificacao.Size = new System.Drawing.Size(206, 47);
            this.ckbQualificacao.TabIndex = 258;
            this.ckbQualificacao.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.ckbQualificacao_ItemCheck);
            this.ckbQualificacao.Click += new System.EventHandler(this.ckbQualificacao_Click);
            this.ckbQualificacao.SelectedValueChanged += new System.EventHandler(this.ckbQualificacao_SelectedValueChanged);
            // 
            // pnlDescricao
            // 
            this.pnlDescricao.Controls.Add(this.label16);
            this.pnlDescricao.Controls.Add(this.txtCONTRIBUINTE);
            this.pnlDescricao.Controls.Add(label21);
            this.pnlDescricao.Controls.Add(this.txtComoResponsavel);
            this.pnlDescricao.Controls.Add(label23);
            this.pnlDescricao.Location = new System.Drawing.Point(2, 148);
            this.pnlDescricao.Name = "pnlDescricao";
            this.pnlDescricao.Size = new System.Drawing.Size(940, 82);
            this.pnlDescricao.TabIndex = 245;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 16);
            this.label16.TabIndex = 246;
            this.label16.Text = "Enquadramento";
            // 
            // txtCONTRIBUINTE
            // 
            this.txtCONTRIBUINTE.Location = new System.Drawing.Point(124, 27);
            this.txtCONTRIBUINTE.Name = "txtCONTRIBUINTE";
            this.txtCONTRIBUINTE.Size = new System.Drawing.Size(802, 20);
            this.txtCONTRIBUINTE.TabIndex = 191;
            this.txtCONTRIBUINTE.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtComoResponsavel
            // 
            this.txtComoResponsavel.Location = new System.Drawing.Point(124, 52);
            this.txtComoResponsavel.Name = "txtComoResponsavel";
            this.txtComoResponsavel.Size = new System.Drawing.Size(802, 20);
            this.txtComoResponsavel.TabIndex = 192;
            this.txtComoResponsavel.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // btnPessoa
            // 
            this.btnPessoa.Location = new System.Drawing.Point(300, 74);
            this.btnPessoa.Name = "btnPessoa";
            this.btnPessoa.Size = new System.Drawing.Size(32, 22);
            this.btnPessoa.TabIndex = 257;
            this.btnPessoa.Text = "...";
            this.btnPessoa.UseVisualStyleBackColor = true;
            this.btnPessoa.Click += new System.EventHandler(this.btnPessoa_Click);
            // 
            // txtOBSERVACAO_P
            // 
            this.txtOBSERVACAO_P.Location = new System.Drawing.Point(123, 361);
            this.txtOBSERVACAO_P.Multiline = true;
            this.txtOBSERVACAO_P.Name = "txtOBSERVACAO_P";
            this.txtOBSERVACAO_P.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOBSERVACAO_P.Size = new System.Drawing.Size(509, 63);
            this.txtOBSERVACAO_P.TabIndex = 193;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(784, -3);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(0, 16);
            this.lblId.TabIndex = 247;
            this.lblId.Visible = false;
            // 
            // pnlEndereco
            // 
            this.pnlEndereco.Controls.Add(this.txtNumeroResp);
            this.pnlEndereco.Controls.Add(this.label43);
            this.pnlEndereco.Controls.Add(this.txtLogradouroResp);
            this.pnlEndereco.Controls.Add(this.cbxCidadeResp);
            this.pnlEndereco.Controls.Add(label46);
            this.pnlEndereco.Controls.Add(label47);
            this.pnlEndereco.Controls.Add(this.txtBairroResp);
            this.pnlEndereco.Controls.Add(this.cbxUFResp);
            this.pnlEndereco.Controls.Add(label48);
            this.pnlEndereco.Controls.Add(this.txtCepResp);
            this.pnlEndereco.Controls.Add(label49);
            this.pnlEndereco.Controls.Add(label50);
            this.pnlEndereco.Controls.Add(this.txtComplResp);
            this.pnlEndereco.Controls.Add(label52);
            this.pnlEndereco.Controls.Add(label53);
            this.pnlEndereco.Location = new System.Drawing.Point(2, 237);
            this.pnlEndereco.Name = "pnlEndereco";
            this.pnlEndereco.Size = new System.Drawing.Size(940, 117);
            this.pnlEndereco.TabIndex = 248;
            // 
            // txtNumeroResp
            // 
            this.txtNumeroResp.Flags = 0;
            this.txtNumeroResp.Location = new System.Drawing.Point(683, 36);
            this.txtNumeroResp.Mask = "";
            this.txtNumeroResp.Name = "txtNumeroResp";
            this.txtNumeroResp.Size = new System.Drawing.Size(65, 20);
            this.txtNumeroResp.TabIndex = 247;
            this.txtNumeroResp.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(3, 5);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(68, 16);
            this.label43.TabIndex = 246;
            this.label43.Text = "Endereço";
            // 
            // txtLogradouroResp
            // 
            this.txtLogradouroResp.Location = new System.Drawing.Point(120, 36);
            this.txtLogradouroResp.Name = "txtLogradouroResp";
            this.txtLogradouroResp.Size = new System.Drawing.Size(507, 20);
            this.txtLogradouroResp.TabIndex = 218;
            this.txtLogradouroResp.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // cbxCidadeResp
            // 
            this.cbxCidadeResp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCidadeResp.FormattingEnabled = true;
            this.cbxCidadeResp.Location = new System.Drawing.Point(445, 85);
            this.cbxCidadeResp.Name = "cbxCidadeResp";
            this.cbxCidadeResp.Size = new System.Drawing.Size(303, 21);
            this.cbxCidadeResp.TabIndex = 223;
            this.cbxCidadeResp.Validating += new System.ComponentModel.CancelEventHandler(this.cbxCIDADE_Validating);
            // 
            // txtBairroResp
            // 
            this.txtBairroResp.Location = new System.Drawing.Point(445, 61);
            this.txtBairroResp.MaxLength = 75;
            this.txtBairroResp.Name = "txtBairroResp";
            this.txtBairroResp.Size = new System.Drawing.Size(303, 20);
            this.txtBairroResp.TabIndex = 221;
            this.txtBairroResp.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // cbxUFResp
            // 
            this.cbxUFResp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxUFResp.FormattingEnabled = true;
            this.cbxUFResp.Location = new System.Drawing.Point(120, 85);
            this.cbxUFResp.Name = "cbxUFResp";
            this.cbxUFResp.Size = new System.Drawing.Size(73, 21);
            this.cbxUFResp.TabIndex = 222;
            this.cbxUFResp.SelectedIndexChanged += new System.EventHandler(this.cbxUFResp_SelectedIndexChanged);
            this.cbxUFResp.Validating += new System.ComponentModel.CancelEventHandler(this.cbxCIDADE_Validating);
            // 
            // txtCepResp
            // 
            this.txtCepResp.Flags = 0;
            this.txtCepResp.Location = new System.Drawing.Point(120, 11);
            this.txtCepResp.Mask = "#####-###";
            this.txtCepResp.Name = "txtCepResp";
            this.txtCepResp.Size = new System.Drawing.Size(88, 20);
            this.txtCepResp.TabIndex = 217;
            this.txtCepResp.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtComplResp
            // 
            this.txtComplResp.Location = new System.Drawing.Point(120, 61);
            this.txtComplResp.MaxLength = 30;
            this.txtComplResp.Name = "txtComplResp";
            this.txtComplResp.Size = new System.Drawing.Size(269, 20);
            this.txtComplResp.TabIndex = 220;
            this.txtComplResp.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtNUMERO_PROCESSO
            // 
            this.txtNUMERO_PROCESSO.Location = new System.Drawing.Point(120, 99);
            this.txtNUMERO_PROCESSO.MaxLength = 30;
            this.txtNUMERO_PROCESSO.Name = "txtNUMERO_PROCESSO";
            this.txtNUMERO_PROCESSO.Size = new System.Drawing.Size(269, 20);
            this.txtNUMERO_PROCESSO.TabIndex = 260;
            this.txtNUMERO_PROCESSO.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtEMAIL
            // 
            this.txtEMAIL.Location = new System.Drawing.Point(120, 76);
            this.txtEMAIL.Name = "txtEMAIL";
            this.txtEMAIL.Size = new System.Drawing.Size(746, 20);
            this.txtEMAIL.TabIndex = 259;
            // 
            // txtOBSERVACAO
            // 
            this.txtOBSERVACAO.Location = new System.Drawing.Point(120, 122);
            this.txtOBSERVACAO.Multiline = true;
            this.txtOBSERVACAO.Name = "txtOBSERVACAO";
            this.txtOBSERVACAO.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOBSERVACAO.Size = new System.Drawing.Size(746, 75);
            this.txtOBSERVACAO.TabIndex = 261;
            // 
            // pnlCanceladoRemessa
            // 
            this.pnlCanceladoRemessa.Controls.Add(this.lblSuspCanc);
            this.pnlCanceladoRemessa.Controls.Add(this.txtMOTIVO_CANCELAMENTO);
            this.pnlCanceladoRemessa.Controls.Add(this.txtPROCESSO_CANCELAMENTO);
            this.pnlCanceladoRemessa.Controls.Add(this.label28);
            this.pnlCanceladoRemessa.Controls.Add(this.label29);
            this.pnlCanceladoRemessa.Controls.Add(this.txtDATA_CANCELAMENTO);
            this.pnlCanceladoRemessa.Controls.Add(this.lblDataCancela);
            this.pnlCanceladoRemessa.Location = new System.Drawing.Point(9, 582);
            this.pnlCanceladoRemessa.Name = "pnlCanceladoRemessa";
            this.pnlCanceladoRemessa.Size = new System.Drawing.Size(940, 75);
            this.pnlCanceladoRemessa.TabIndex = 243;
            this.pnlCanceladoRemessa.Visible = false;
            // 
            // lblSuspCanc
            // 
            this.lblSuspCanc.AutoSize = true;
            this.lblSuspCanc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuspCanc.ForeColor = System.Drawing.Color.Red;
            this.lblSuspCanc.Location = new System.Drawing.Point(4, 2);
            this.lblSuspCanc.Name = "lblSuspCanc";
            this.lblSuspCanc.Size = new System.Drawing.Size(143, 16);
            this.lblSuspCanc.TabIndex = 249;
            this.lblSuspCanc.Text = "Dados Cancelamento";
            // 
            // txtMOTIVO_CANCELAMENTO
            // 
            this.txtMOTIVO_CANCELAMENTO.Flags = 0;
            this.txtMOTIVO_CANCELAMENTO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMOTIVO_CANCELAMENTO.ForeColor = System.Drawing.Color.Red;
            this.txtMOTIVO_CANCELAMENTO.InvalidChars = new char[] {
        '%',
        '\'',
        '*',
        '\"',
        '+',
        '?',
        '>',
        '<',
        ':',
        '\\'};
            this.txtMOTIVO_CANCELAMENTO.Location = new System.Drawing.Point(272, 50);
            this.txtMOTIVO_CANCELAMENTO.Multiline = true;
            this.txtMOTIVO_CANCELAMENTO.Name = "txtMOTIVO_CANCELAMENTO";
            this.txtMOTIVO_CANCELAMENTO.ReadOnly = true;
            this.txtMOTIVO_CANCELAMENTO.Size = new System.Drawing.Size(594, 20);
            this.txtMOTIVO_CANCELAMENTO.TabIndex = 184;
            // 
            // txtPROCESSO_CANCELAMENTO
            // 
            this.txtPROCESSO_CANCELAMENTO.Flags = 0;
            this.txtPROCESSO_CANCELAMENTO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPROCESSO_CANCELAMENTO.ForeColor = System.Drawing.Color.Red;
            this.txtPROCESSO_CANCELAMENTO.InvalidChars = new char[] {
        '%',
        '\'',
        '*',
        '\"',
        '+',
        '?',
        '>',
        '<',
        ':',
        '\\'};
            this.txtPROCESSO_CANCELAMENTO.Location = new System.Drawing.Point(116, 50);
            this.txtPROCESSO_CANCELAMENTO.Name = "txtPROCESSO_CANCELAMENTO";
            this.txtPROCESSO_CANCELAMENTO.ReadOnly = true;
            this.txtPROCESSO_CANCELAMENTO.Size = new System.Drawing.Size(145, 20);
            this.txtPROCESSO_CANCELAMENTO.TabIndex = 183;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(269, 32);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 13);
            this.label28.TabIndex = 182;
            this.label28.Text = "Descrição:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(113, 32);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 13);
            this.label29.TabIndex = 181;
            this.label29.Text = "Processo Nº:";
            // 
            // txtDATA_CANCELAMENTO
            // 
            this.txtDATA_CANCELAMENTO.Flags = 0;
            this.txtDATA_CANCELAMENTO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDATA_CANCELAMENTO.ForeColor = System.Drawing.Color.Red;
            this.txtDATA_CANCELAMENTO.Location = new System.Drawing.Point(6, 50);
            this.txtDATA_CANCELAMENTO.Mask = "##/##/####";
            this.txtDATA_CANCELAMENTO.Name = "txtDATA_CANCELAMENTO";
            this.txtDATA_CANCELAMENTO.ReadOnly = true;
            this.txtDATA_CANCELAMENTO.Size = new System.Drawing.Size(100, 20);
            this.txtDATA_CANCELAMENTO.TabIndex = 179;
            // 
            // lblDataCancela
            // 
            this.lblDataCancela.AutoSize = true;
            this.lblDataCancela.ForeColor = System.Drawing.Color.Black;
            this.lblDataCancela.Location = new System.Drawing.Point(3, 32);
            this.lblDataCancela.Name = "lblDataCancela";
            this.lblDataCancela.Size = new System.Drawing.Size(104, 13);
            this.lblDataCancela.TabIndex = 180;
            this.lblDataCancela.Text = "Data Cancelamento:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtTestadaOriginal);
            this.panel2.Controls.Add(label115);
            this.panel2.Controls.Add(label106);
            this.panel2.Controls.Add(this.txtAreaOriginal);
            this.panel2.Controls.Add(label59);
            this.panel2.Controls.Add(this.txtLOTE_IMOVEL);
            this.panel2.Controls.Add(label60);
            this.panel2.Controls.Add(this.txtQUADRA_IMOVEL);
            this.panel2.Controls.Add(this.cbxCONDOMINIO);
            this.panel2.Controls.Add(label86);
            this.panel2.Controls.Add(this.cbxLOTEAMENTO);
            this.panel2.Controls.Add(label62);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtLOGRADOURO);
            this.panel2.Controls.Add(this.cbxCIDADE);
            this.panel2.Controls.Add(label83);
            this.panel2.Controls.Add(label84);
            this.panel2.Controls.Add(this.txtBAIRRO);
            this.panel2.Controls.Add(this.cbxUF);
            this.panel2.Controls.Add(label85);
            this.panel2.Controls.Add(this.txtCEP);
            this.panel2.Controls.Add(label81);
            this.panel2.Controls.Add(this.txtID_NOTIFICACAO);
            this.panel2.Controls.Add(label78);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtCOMPLEMENTO);
            this.panel2.Controls.Add(label79);
            this.panel2.Controls.Add(this.txtNUMERO);
            this.panel2.Controls.Add(label80);
            this.panel2.Location = new System.Drawing.Point(9, 54);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 164);
            this.panel2.TabIndex = 244;
            // 
            // txtTestadaOriginal
            // 
            this.txtTestadaOriginal.Location = new System.Drawing.Point(641, 139);
            this.txtTestadaOriginal.Name = "txtTestadaOriginal";
            this.txtTestadaOriginal.ReadOnly = true;
            this.txtTestadaOriginal.Size = new System.Drawing.Size(110, 20);
            this.txtTestadaOriginal.TabIndex = 262;
            // 
            // txtAreaOriginal
            // 
            this.txtAreaOriginal.Location = new System.Drawing.Point(641, 112);
            this.txtAreaOriginal.Name = "txtAreaOriginal";
            this.txtAreaOriginal.ReadOnly = true;
            this.txtAreaOriginal.Size = new System.Drawing.Size(110, 20);
            this.txtAreaOriginal.TabIndex = 259;
            // 
            // txtLOTE_IMOVEL
            // 
            this.txtLOTE_IMOVEL.Location = new System.Drawing.Point(444, 139);
            this.txtLOTE_IMOVEL.Name = "txtLOTE_IMOVEL";
            this.txtLOTE_IMOVEL.Size = new System.Drawing.Size(111, 20);
            this.txtLOTE_IMOVEL.TabIndex = 256;
            // 
            // txtQUADRA_IMOVEL
            // 
            this.txtQUADRA_IMOVEL.Location = new System.Drawing.Point(445, 112);
            this.txtQUADRA_IMOVEL.Name = "txtQUADRA_IMOVEL";
            this.txtQUADRA_IMOVEL.Size = new System.Drawing.Size(110, 20);
            this.txtQUADRA_IMOVEL.TabIndex = 255;
            // 
            // cbxCONDOMINIO
            // 
            this.cbxCONDOMINIO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCONDOMINIO.FormattingEnabled = true;
            this.cbxCONDOMINIO.Location = new System.Drawing.Point(120, 139);
            this.cbxCONDOMINIO.Name = "cbxCONDOMINIO";
            this.cbxCONDOMINIO.Size = new System.Drawing.Size(269, 21);
            this.cbxCONDOMINIO.TabIndex = 250;
            // 
            // cbxLOTEAMENTO
            // 
            this.cbxLOTEAMENTO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxLOTEAMENTO.FormattingEnabled = true;
            this.cbxLOTEAMENTO.Location = new System.Drawing.Point(120, 112);
            this.cbxLOTEAMENTO.Name = "cbxLOTEAMENTO";
            this.cbxLOTEAMENTO.Size = new System.Drawing.Size(269, 21);
            this.cbxLOTEAMENTO.TabIndex = 247;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 16);
            this.label13.TabIndex = 246;
            this.label13.Text = "Endereço";
            // 
            // txtLOGRADOURO
            // 
            this.txtLOGRADOURO.Location = new System.Drawing.Point(120, 36);
            this.txtLOGRADOURO.Name = "txtLOGRADOURO";
            this.txtLOGRADOURO.Size = new System.Drawing.Size(507, 20);
            this.txtLOGRADOURO.TabIndex = 218;
            this.txtLOGRADOURO.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // cbxCIDADE
            // 
            this.cbxCIDADE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCIDADE.FormattingEnabled = true;
            this.cbxCIDADE.Location = new System.Drawing.Point(445, 85);
            this.cbxCIDADE.Name = "cbxCIDADE";
            this.cbxCIDADE.Size = new System.Drawing.Size(303, 21);
            this.cbxCIDADE.TabIndex = 223;
            this.cbxCIDADE.Validating += new System.ComponentModel.CancelEventHandler(this.cbxCIDADE_Validating);
            // 
            // txtBAIRRO
            // 
            this.txtBAIRRO.Location = new System.Drawing.Point(445, 61);
            this.txtBAIRRO.MaxLength = 75;
            this.txtBAIRRO.Name = "txtBAIRRO";
            this.txtBAIRRO.Size = new System.Drawing.Size(303, 20);
            this.txtBAIRRO.TabIndex = 221;
            this.txtBAIRRO.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // cbxUF
            // 
            this.cbxUF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxUF.FormattingEnabled = true;
            this.cbxUF.Location = new System.Drawing.Point(120, 85);
            this.cbxUF.Name = "cbxUF";
            this.cbxUF.Size = new System.Drawing.Size(73, 21);
            this.cbxUF.TabIndex = 222;
            this.cbxUF.SelectedIndexChanged += new System.EventHandler(this.cbxUF_SelectedIndexChanged);
            this.cbxUF.Validating += new System.ComponentModel.CancelEventHandler(this.cbxCIDADE_Validating);
            // 
            // txtCEP
            // 
            this.txtCEP.Flags = 0;
            this.txtCEP.Location = new System.Drawing.Point(120, 11);
            this.txtCEP.Mask = "#####-###";
            this.txtCEP.Name = "txtCEP";
            this.txtCEP.Size = new System.Drawing.Size(88, 20);
            this.txtCEP.TabIndex = 217;
            this.txtCEP.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtCOMPLEMENTO
            // 
            this.txtCOMPLEMENTO.Location = new System.Drawing.Point(120, 61);
            this.txtCOMPLEMENTO.MaxLength = 30;
            this.txtCOMPLEMENTO.Name = "txtCOMPLEMENTO";
            this.txtCOMPLEMENTO.Size = new System.Drawing.Size(269, 20);
            this.txtCOMPLEMENTO.TabIndex = 220;
            this.txtCOMPLEMENTO.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // txtNUMERO
            // 
            this.txtNUMERO.AllowNegative = true;
            this.txtNUMERO.DigitsInGroup = 0;
            this.txtNUMERO.Flags = 0;
            this.txtNUMERO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUMERO.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNUMERO.Location = new System.Drawing.Point(695, 35);
            this.txtNUMERO.MaxDecimalPlaces = 0;
            this.txtNUMERO.MaxLength = 5;
            this.txtNUMERO.MaxWholeDigits = 5;
            this.txtNUMERO.Name = "txtNUMERO";
            this.txtNUMERO.Prefix = "";
            this.txtNUMERO.RangeMax = 2147483647D;
            this.txtNUMERO.RangeMin = -2147483648D;
            this.txtNUMERO.Size = new System.Drawing.Size(53, 20);
            this.txtNUMERO.TabIndex = 219;
            this.txtNUMERO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNUMERO.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // lblRetificada
            // 
            this.lblRetificada.AutoSize = true;
            this.lblRetificada.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRetificada.ForeColor = System.Drawing.Color.Red;
            this.lblRetificada.Location = new System.Drawing.Point(733, 3);
            this.lblRetificada.Name = "lblRetificada";
            this.lblRetificada.Size = new System.Drawing.Size(254, 19);
            this.lblRetificada.TabIndex = 296;
            this.lblRetificada.Text = "NOTIFICAÇÃO RERRATIFICADA";
            this.lblRetificada.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(label54);
            this.groupBox1.Controls.Add(this.btnBuscarInscricao);
            this.groupBox1.Controls.Add(this.cbxTipo);
            this.groupBox1.Controls.Add(this.txtINSCRICAO);
            this.groupBox1.Controls.Add(inscMunicipalLabel);
            this.groupBox1.Controls.Add(this.rdbMob);
            this.groupBox1.Controls.Add(this.rdbImob);
            this.groupBox1.Location = new System.Drawing.Point(9, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(609, 42);
            this.groupBox1.TabIndex = 247;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipo";
            // 
            // btnBuscarInscricao
            // 
            this.btnBuscarInscricao.Location = new System.Drawing.Point(348, 16);
            this.btnBuscarInscricao.Name = "btnBuscarInscricao";
            this.btnBuscarInscricao.Size = new System.Drawing.Size(85, 23);
            this.btnBuscarInscricao.TabIndex = 249;
            this.btnBuscarInscricao.Text = "Buscar";
            this.btnBuscarInscricao.UseVisualStyleBackColor = true;
            this.btnBuscarInscricao.Visible = false;
            this.btnBuscarInscricao.Click += new System.EventHandler(this.btnBuscarInscricao_Click);
            // 
            // cbxTipo
            // 
            this.cbxTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipo.FormattingEnabled = true;
            this.cbxTipo.Location = new System.Drawing.Point(473, 17);
            this.cbxTipo.Name = "cbxTipo";
            this.cbxTipo.Size = new System.Drawing.Size(130, 21);
            this.cbxTipo.TabIndex = 248;
            this.cbxTipo.SelectedIndexChanged += new System.EventHandler(this.cbxTipo_SelectedIndexChanged);
            // 
            // txtINSCRICAO
            // 
            this.txtINSCRICAO.AllowNegative = true;
            this.txtINSCRICAO.DigitsInGroup = 0;
            this.txtINSCRICAO.Flags = 0;
            this.txtINSCRICAO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtINSCRICAO.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtINSCRICAO.Location = new System.Drawing.Point(203, 18);
            this.txtINSCRICAO.MaxDecimalPlaces = 0;
            this.txtINSCRICAO.MaxLength = 18;
            this.txtINSCRICAO.MaxWholeDigits = 18;
            this.txtINSCRICAO.Name = "txtINSCRICAO";
            this.txtINSCRICAO.Prefix = "";
            this.txtINSCRICAO.RangeMax = 2147483647D;
            this.txtINSCRICAO.RangeMin = -2147483648D;
            this.txtINSCRICAO.Size = new System.Drawing.Size(142, 20);
            this.txtINSCRICAO.TabIndex = 247;
            this.txtINSCRICAO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtINSCRICAO.Leave += new System.EventHandler(this.btnBuscarInscricao_Click);
            // 
            // rdbMob
            // 
            this.rdbMob.AutoSize = true;
            this.rdbMob.Location = new System.Drawing.Point(79, 19);
            this.rdbMob.Name = "rdbMob";
            this.rdbMob.Size = new System.Drawing.Size(69, 17);
            this.rdbMob.TabIndex = 1;
            this.rdbMob.TabStop = true;
            this.rdbMob.Text = "Mobiliário";
            this.rdbMob.UseVisualStyleBackColor = true;
            // 
            // rdbImob
            // 
            this.rdbImob.AutoSize = true;
            this.rdbImob.Checked = true;
            this.rdbImob.Location = new System.Drawing.Point(7, 19);
            this.rdbImob.Name = "rdbImob";
            this.rdbImob.Size = new System.Drawing.Size(71, 17);
            this.rdbImob.TabIndex = 0;
            this.rdbImob.TabStop = true;
            this.rdbImob.Text = "Imobiliário";
            this.rdbImob.UseVisualStyleBackColor = true;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // txtEnquadramentoPenalidade
            // 
            this.txtEnquadramentoPenalidade.AllowNegative = false;
            this.txtEnquadramentoPenalidade.DigitsInGroup = 0;
            this.txtEnquadramentoPenalidade.Flags = 65536;
            this.txtEnquadramentoPenalidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnquadramentoPenalidade.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.errorProvider.SetIconAlignment(this.txtEnquadramentoPenalidade, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtEnquadramentoPenalidade.Location = new System.Drawing.Point(691, 222);
            this.txtEnquadramentoPenalidade.MaxDecimalPlaces = 2;
            this.txtEnquadramentoPenalidade.MaxLength = 10;
            this.txtEnquadramentoPenalidade.MaxWholeDigits = 8;
            this.txtEnquadramentoPenalidade.Name = "txtEnquadramentoPenalidade";
            this.txtEnquadramentoPenalidade.Prefix = "";
            this.txtEnquadramentoPenalidade.RangeMax = 2147483647D;
            this.txtEnquadramentoPenalidade.RangeMin = 0D;
            this.txtEnquadramentoPenalidade.Size = new System.Drawing.Size(150, 20);
            this.txtEnquadramentoPenalidade.TabIndex = 132;
            this.txtEnquadramentoPenalidade.Text = "0";
            this.txtEnquadramentoPenalidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEnquadramentoDemolicao
            // 
            this.txtEnquadramentoDemolicao.AllowNegative = false;
            this.txtEnquadramentoDemolicao.DigitsInGroup = 0;
            this.txtEnquadramentoDemolicao.Flags = 65536;
            this.txtEnquadramentoDemolicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnquadramentoDemolicao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.errorProvider.SetIconAlignment(this.txtEnquadramentoDemolicao, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtEnquadramentoDemolicao.Location = new System.Drawing.Point(466, 222);
            this.txtEnquadramentoDemolicao.MaxDecimalPlaces = 2;
            this.txtEnquadramentoDemolicao.MaxLength = 10;
            this.txtEnquadramentoDemolicao.MaxWholeDigits = 8;
            this.txtEnquadramentoDemolicao.Name = "txtEnquadramentoDemolicao";
            this.txtEnquadramentoDemolicao.Prefix = "";
            this.txtEnquadramentoDemolicao.RangeMax = 2147483647D;
            this.txtEnquadramentoDemolicao.RangeMin = 0D;
            this.txtEnquadramentoDemolicao.Size = new System.Drawing.Size(150, 20);
            this.txtEnquadramentoDemolicao.TabIndex = 131;
            this.txtEnquadramentoDemolicao.Text = "0";
            this.txtEnquadramentoDemolicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEnquadramentoDemolicao.Leave += new System.EventHandler(this.txtEnquadramentoDemolicao_Leave);
            // 
            // txtEnquadramentoReforma
            // 
            this.txtEnquadramentoReforma.AllowNegative = false;
            this.txtEnquadramentoReforma.DigitsInGroup = 0;
            this.txtEnquadramentoReforma.Flags = 65536;
            this.txtEnquadramentoReforma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnquadramentoReforma.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.errorProvider.SetIconAlignment(this.txtEnquadramentoReforma, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtEnquadramentoReforma.Location = new System.Drawing.Point(247, 260);
            this.txtEnquadramentoReforma.MaxDecimalPlaces = 2;
            this.txtEnquadramentoReforma.MaxLength = 10;
            this.txtEnquadramentoReforma.MaxWholeDigits = 8;
            this.txtEnquadramentoReforma.Name = "txtEnquadramentoReforma";
            this.txtEnquadramentoReforma.Prefix = "";
            this.txtEnquadramentoReforma.RangeMax = 2147483647D;
            this.txtEnquadramentoReforma.RangeMin = 0D;
            this.txtEnquadramentoReforma.Size = new System.Drawing.Size(150, 20);
            this.txtEnquadramentoReforma.TabIndex = 134;
            this.txtEnquadramentoReforma.Text = "0";
            this.txtEnquadramentoReforma.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEnquadramento
            // 
            this.txtEnquadramento.AllowNegative = true;
            this.txtEnquadramento.DigitsInGroup = 0;
            this.txtEnquadramento.Flags = 0;
            this.txtEnquadramento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnquadramento.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.errorProvider.SetIconAlignment(this.txtEnquadramento, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtEnquadramento.Location = new System.Drawing.Point(25, 260);
            this.txtEnquadramento.MaxDecimalPlaces = 2;
            this.txtEnquadramento.MaxLength = 10;
            this.txtEnquadramento.MaxWholeDigits = 8;
            this.txtEnquadramento.Name = "txtEnquadramento";
            this.txtEnquadramento.Prefix = "";
            this.txtEnquadramento.RangeMax = 2147483647D;
            this.txtEnquadramento.RangeMin = -2147483648D;
            this.txtEnquadramento.Size = new System.Drawing.Size(150, 20);
            this.txtEnquadramento.TabIndex = 133;
            this.txtEnquadramento.Text = "0";
            this.txtEnquadramento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEnquadramento.Leave += new System.EventHandler(this.txtEnquadramento_Leave);
            // 
            // txtEnquadramentoBaseISS
            // 
            this.txtEnquadramentoBaseISS.AllowNegative = false;
            this.txtEnquadramentoBaseISS.DigitsInGroup = 0;
            this.txtEnquadramentoBaseISS.Flags = 65536;
            this.txtEnquadramentoBaseISS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnquadramentoBaseISS.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.errorProvider.SetIconAlignment(this.txtEnquadramentoBaseISS, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtEnquadramentoBaseISS.Location = new System.Drawing.Point(466, 260);
            this.txtEnquadramentoBaseISS.MaxDecimalPlaces = 2;
            this.txtEnquadramentoBaseISS.MaxLength = 10;
            this.txtEnquadramentoBaseISS.MaxWholeDigits = 8;
            this.txtEnquadramentoBaseISS.Name = "txtEnquadramentoBaseISS";
            this.txtEnquadramentoBaseISS.Prefix = "";
            this.txtEnquadramentoBaseISS.RangeMax = 2147483647D;
            this.txtEnquadramentoBaseISS.RangeMin = 0D;
            this.txtEnquadramentoBaseISS.Size = new System.Drawing.Size(150, 20);
            this.txtEnquadramentoBaseISS.TabIndex = 135;
            this.txtEnquadramentoBaseISS.Text = "0";
            this.txtEnquadramentoBaseISS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEnquadramentoBaseISS.Leave += new System.EventHandler(this.txtEnquadramentoBaseISS_Leave);
            // 
            // btnOpcoes
            // 
            this.btnOpcoes.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnOpcoes.Enabled = false;
            this.btnOpcoes.Location = new System.Drawing.Point(528, 3);
            this.btnOpcoes.Name = "btnOpcoes";
            this.btnOpcoes.Size = new System.Drawing.Size(75, 23);
            this.btnOpcoes.TabIndex = 5;
            this.btnOpcoes.Text = "+ &Impressão";
            this.btnOpcoes.UseVisualStyleBackColor = true;
            this.btnOpcoes.Click += new System.EventHandler(this.btnOpcoes_Click);
            // 
            // txtDATA_NOTIFICACAO
            // 
            this.txtDATA_NOTIFICACAO.Flags = 65536;
            this.txtDATA_NOTIFICACAO.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtDATA_NOTIFICACAO.Location = new System.Drawing.Point(849, 22);
            this.txtDATA_NOTIFICACAO.Name = "txtDATA_NOTIFICACAO";
            this.txtDATA_NOTIFICACAO.RangeMax = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtDATA_NOTIFICACAO.RangeMin = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtDATA_NOTIFICACAO.Size = new System.Drawing.Size(100, 22);
            this.txtDATA_NOTIFICACAO.TabIndex = 262;
            this.txtDATA_NOTIFICACAO.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(846, 7);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(107, 13);
            this.label22.TabIndex = 263;
            this.label22.Text = "Data Notificação:";
            // 
            // tbpParcelamento
            // 
            this.tbpParcelamento.Controls.Add(this.panel5);
            this.tbpParcelamento.Controls.Add(this.pnlParcelamentoParcela);
            this.tbpParcelamento.Controls.Add(this.pnlParcelamentoDados);
            this.tbpParcelamento.Location = new System.Drawing.Point(4, 22);
            this.tbpParcelamento.Name = "tbpParcelamento";
            this.tbpParcelamento.Padding = new System.Windows.Forms.Padding(3);
            this.tbpParcelamento.Size = new System.Drawing.Size(544, 238);
            this.tbpParcelamento.TabIndex = 5;
            this.tbpParcelamento.Text = "Dados Parcelamento";
            this.tbpParcelamento.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dgvParcelamantoComplemento);
            this.panel5.Controls.Add(this.label152);
            this.panel5.Controls.Add(this.btnCancelarOperacao);
            this.panel5.Controls.Add(this.btnEfetivarReparcelar);
            this.panel5.Location = new System.Drawing.Point(16, 367);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(950, 225);
            this.panel5.TabIndex = 276;
            // 
            // dgvParcelamantoComplemento
            // 
            this.dgvParcelamantoComplemento.AllowUserToAddRows = false;
            this.dgvParcelamantoComplemento.AllowUserToDeleteRows = false;
            this.dgvParcelamantoComplemento.AllowUserToResizeRows = false;
            this.dgvParcelamantoComplemento.AutoGenerateColumns = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelamantoComplemento.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvParcelamantoComplemento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParcelamantoComplemento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TRIBUTO,
            this.DATA_DEBITO,
            this.dataGridViewTextBoxColumn11,
            this.VALOR_ABATIMENTO,
            this.VALOR_UFM,
            this.VALOR_JUROS,
            this.VALOR_MULTA,
            this.dataGridViewTextBoxColumn7,
            this.Total});
            this.dgvParcelamantoComplemento.DataSource = this.mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvParcelamantoComplemento.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvParcelamantoComplemento.Location = new System.Drawing.Point(3, 26);
            this.dgvParcelamantoComplemento.MultiSelect = false;
            this.dgvParcelamantoComplemento.Name = "dgvParcelamantoComplemento";
            this.dgvParcelamantoComplemento.ReadOnly = true;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelamantoComplemento.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvParcelamantoComplemento.RowHeadersWidth = 11;
            this.dgvParcelamantoComplemento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParcelamantoComplemento.Size = new System.Drawing.Size(941, 195);
            this.dgvParcelamantoComplemento.TabIndex = 284;
            // 
            // TRIBUTO
            // 
            this.TRIBUTO.DataPropertyName = "TRIBUTO";
            this.TRIBUTO.HeaderText = "Tributo";
            this.TRIBUTO.Name = "TRIBUTO";
            this.TRIBUTO.ReadOnly = true;
            // 
            // DATA_DEBITO
            // 
            this.DATA_DEBITO.DataPropertyName = "DATA_DEBITO";
            this.DATA_DEBITO.HeaderText = "Data";
            this.DATA_DEBITO.Name = "DATA_DEBITO";
            this.DATA_DEBITO.ReadOnly = true;
            this.DATA_DEBITO.Width = 80;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "VALOR";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn11.HeaderText = "Valor";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // VALOR_ABATIMENTO
            // 
            this.VALOR_ABATIMENTO.DataPropertyName = "VALOR_ABATIMENTO";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALOR_ABATIMENTO.DefaultCellStyle = dataGridViewCellStyle12;
            this.VALOR_ABATIMENTO.FillWeight = 150F;
            this.VALOR_ABATIMENTO.HeaderText = "Desc. Penalidade UFM";
            this.VALOR_ABATIMENTO.Name = "VALOR_ABATIMENTO";
            this.VALOR_ABATIMENTO.ReadOnly = true;
            this.VALOR_ABATIMENTO.Width = 140;
            // 
            // VALOR_UFM
            // 
            this.VALOR_UFM.DataPropertyName = "VALOR_UFM";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALOR_UFM.DefaultCellStyle = dataGridViewCellStyle13;
            this.VALOR_UFM.FillWeight = 150F;
            this.VALOR_UFM.HeaderText = "Valor Integral UFM";
            this.VALOR_UFM.Name = "VALOR_UFM";
            this.VALOR_UFM.ReadOnly = true;
            this.VALOR_UFM.Width = 120;
            // 
            // VALOR_JUROS
            // 
            this.VALOR_JUROS.DataPropertyName = "VALOR_JUROS";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALOR_JUROS.DefaultCellStyle = dataGridViewCellStyle14;
            this.VALOR_JUROS.HeaderText = "Valor Juros";
            this.VALOR_JUROS.Name = "VALOR_JUROS";
            this.VALOR_JUROS.ReadOnly = true;
            // 
            // VALOR_MULTA
            // 
            this.VALOR_MULTA.DataPropertyName = "VALOR_MULTA";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALOR_MULTA.DefaultCellStyle = dataGridViewCellStyle15;
            this.VALOR_MULTA.HeaderText = "Valor Multa";
            this.VALOR_MULTA.Name = "VALOR_MULTA";
            this.VALOR_MULTA.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "CORRECAO";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn7.HeaderText = "Correção";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 80;
            // 
            // Total
            // 
            this.Total.DataPropertyName = "TOTAL";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Total.DefaultCellStyle = dataGridViewCellStyle17;
            this.Total.HeaderText = "Total";
            this.Total.Name = "Total";
            this.Total.ReadOnly = true;
            // 
            // mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource
            // 
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_COMPLEMENTO";
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label152.Location = new System.Drawing.Point(6, 3);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(178, 16);
            this.label152.TabIndex = 283;
            this.label152.Text = "Parcelamento Dívida Atual";
            // 
            // btnCancelarOperacao
            // 
            this.btnCancelarOperacao.Location = new System.Drawing.Point(708, 2);
            this.btnCancelarOperacao.Name = "btnCancelarOperacao";
            this.btnCancelarOperacao.Size = new System.Drawing.Size(103, 23);
            this.btnCancelarOperacao.TabIndex = 296;
            this.btnCancelarOperacao.Text = "Cancelar Cálculo";
            this.btnCancelarOperacao.UseVisualStyleBackColor = true;
            this.btnCancelarOperacao.Visible = false;
            this.btnCancelarOperacao.Click += new System.EventHandler(this.btnCancelarOperacao_Click);
            // 
            // btnEfetivarReparcelar
            // 
            this.btnEfetivarReparcelar.Location = new System.Drawing.Point(814, 2);
            this.btnEfetivarReparcelar.Name = "btnEfetivarReparcelar";
            this.btnEfetivarReparcelar.Size = new System.Drawing.Size(131, 23);
            this.btnEfetivarReparcelar.TabIndex = 295;
            this.btnEfetivarReparcelar.Text = "Efetivar Parcelamento";
            this.btnEfetivarReparcelar.UseVisualStyleBackColor = true;
            this.btnEfetivarReparcelar.Visible = false;
            this.btnEfetivarReparcelar.Click += new System.EventHandler(this.btnEfetivarReparcelar_Click);
            // 
            // pnlParcelamentoParcela
            // 
            this.pnlParcelamentoParcela.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlParcelamentoParcela.Controls.Add(this.txtValorParcela);
            this.pnlParcelamentoParcela.Controls.Add(this.txtExpedienteAnterior);
            this.pnlParcelamentoParcela.Controls.Add(this.lblExpedienteAnterior);
            this.pnlParcelamentoParcela.Controls.Add(this.txtCorrecao);
            this.pnlParcelamentoParcela.Controls.Add(label154);
            this.pnlParcelamentoParcela.Controls.Add(this.txtMulta);
            this.pnlParcelamentoParcela.Controls.Add(label153);
            this.pnlParcelamentoParcela.Controls.Add(this.txtJuros);
            this.pnlParcelamentoParcela.Controls.Add(label151);
            this.pnlParcelamentoParcela.Controls.Add(this.txtVencimento);
            this.pnlParcelamentoParcela.Controls.Add(label145);
            this.pnlParcelamentoParcela.Controls.Add(this.label141);
            this.pnlParcelamentoParcela.Controls.Add(this.txtJurosCompensatorios);
            this.pnlParcelamentoParcela.Controls.Add(this.txtTotalDevido);
            this.pnlParcelamentoParcela.Controls.Add(label37);
            this.pnlParcelamentoParcela.Controls.Add(label122);
            this.pnlParcelamentoParcela.Controls.Add(this.txtExpediente);
            this.pnlParcelamentoParcela.Controls.Add(this.txtDescontoPenalidade);
            this.pnlParcelamentoParcela.Controls.Add(this.txtValorTotal);
            this.pnlParcelamentoParcela.Controls.Add(label44);
            this.pnlParcelamentoParcela.Controls.Add(label39);
            this.pnlParcelamentoParcela.Controls.Add(this.lblDescontoPenalidade);
            this.pnlParcelamentoParcela.Controls.Add(label45);
            this.pnlParcelamentoParcela.Controls.Add(label42);
            this.pnlParcelamentoParcela.Controls.Add(this.txtValor);
            this.pnlParcelamentoParcela.Controls.Add(label41);
            this.pnlParcelamentoParcela.Controls.Add(this.txtQtdeParcela);
            this.pnlParcelamentoParcela.Location = new System.Drawing.Point(16, 248);
            this.pnlParcelamentoParcela.Name = "pnlParcelamentoParcela";
            this.pnlParcelamentoParcela.Size = new System.Drawing.Size(950, 113);
            this.pnlParcelamentoParcela.TabIndex = 275;
            // 
            // txtValorParcela
            // 
            this.txtValorParcela.AllowNegative = true;
            this.txtValorParcela.DigitsInGroup = 0;
            this.txtValorParcela.Flags = 0;
            this.txtValorParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorParcela.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtValorParcela.Location = new System.Drawing.Point(825, 48);
            this.txtValorParcela.MaxDecimalPlaces = 2;
            this.txtValorParcela.MaxLength = 12;
            this.txtValorParcela.MaxWholeDigits = 10;
            this.txtValorParcela.Name = "txtValorParcela";
            this.txtValorParcela.Prefix = "";
            this.txtValorParcela.RangeMax = 2147483647D;
            this.txtValorParcela.RangeMin = 0D;
            this.txtValorParcela.ReadOnly = true;
            this.txtValorParcela.Size = new System.Drawing.Size(86, 20);
            this.txtValorParcela.TabIndex = 270;
            this.txtValorParcela.Text = "0";
            this.txtValorParcela.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtExpedienteAnterior
            // 
            this.txtExpedienteAnterior.AllowNegative = true;
            this.txtExpedienteAnterior.DigitsInGroup = 0;
            this.txtExpedienteAnterior.Flags = 0;
            this.txtExpedienteAnterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExpedienteAnterior.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtExpedienteAnterior.Location = new System.Drawing.Point(505, 75);
            this.txtExpedienteAnterior.MaxDecimalPlaces = 2;
            this.txtExpedienteAnterior.MaxLength = 12;
            this.txtExpedienteAnterior.MaxWholeDigits = 10;
            this.txtExpedienteAnterior.Name = "txtExpedienteAnterior";
            this.txtExpedienteAnterior.Prefix = "";
            this.txtExpedienteAnterior.RangeMax = 2147483647D;
            this.txtExpedienteAnterior.RangeMin = 0D;
            this.txtExpedienteAnterior.ReadOnly = true;
            this.txtExpedienteAnterior.Size = new System.Drawing.Size(86, 20);
            this.txtExpedienteAnterior.TabIndex = 303;
            this.txtExpedienteAnterior.Text = "0";
            this.txtExpedienteAnterior.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtExpedienteAnterior.Visible = false;
            // 
            // lblExpedienteAnterior
            // 
            this.lblExpedienteAnterior.AutoSize = true;
            this.lblExpedienteAnterior.Location = new System.Drawing.Point(402, 79);
            this.lblExpedienteAnterior.Name = "lblExpedienteAnterior";
            this.lblExpedienteAnterior.Size = new System.Drawing.Size(102, 13);
            this.lblExpedienteAnterior.TabIndex = 302;
            this.lblExpedienteAnterior.Text = "Expediente Anterior:";
            this.lblExpedienteAnterior.Visible = false;
            // 
            // txtCorrecao
            // 
            this.txtCorrecao.AllowNegative = true;
            this.txtCorrecao.DigitsInGroup = 0;
            this.txtCorrecao.Flags = 0;
            this.txtCorrecao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorrecao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCorrecao.Location = new System.Drawing.Point(661, 75);
            this.txtCorrecao.MaxDecimalPlaces = 2;
            this.txtCorrecao.MaxLength = 12;
            this.txtCorrecao.MaxWholeDigits = 10;
            this.txtCorrecao.Name = "txtCorrecao";
            this.txtCorrecao.Prefix = "";
            this.txtCorrecao.RangeMax = 2147483647D;
            this.txtCorrecao.RangeMin = 0D;
            this.txtCorrecao.ReadOnly = true;
            this.txtCorrecao.Size = new System.Drawing.Size(86, 20);
            this.txtCorrecao.TabIndex = 268;
            this.txtCorrecao.Text = "0";
            this.txtCorrecao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMulta
            // 
            this.txtMulta.AllowNegative = true;
            this.txtMulta.DigitsInGroup = 0;
            this.txtMulta.Flags = 0;
            this.txtMulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMulta.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtMulta.Location = new System.Drawing.Point(661, 48);
            this.txtMulta.MaxDecimalPlaces = 2;
            this.txtMulta.MaxLength = 12;
            this.txtMulta.MaxWholeDigits = 10;
            this.txtMulta.Name = "txtMulta";
            this.txtMulta.Prefix = "";
            this.txtMulta.RangeMax = 2147483647D;
            this.txtMulta.RangeMin = 0D;
            this.txtMulta.ReadOnly = true;
            this.txtMulta.Size = new System.Drawing.Size(86, 20);
            this.txtMulta.TabIndex = 267;
            this.txtMulta.Text = "0";
            this.txtMulta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtJuros
            // 
            this.txtJuros.AllowNegative = true;
            this.txtJuros.DigitsInGroup = 0;
            this.txtJuros.Flags = 0;
            this.txtJuros.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJuros.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtJuros.Location = new System.Drawing.Point(661, 21);
            this.txtJuros.MaxDecimalPlaces = 2;
            this.txtJuros.MaxLength = 12;
            this.txtJuros.MaxWholeDigits = 10;
            this.txtJuros.Name = "txtJuros";
            this.txtJuros.Prefix = "";
            this.txtJuros.RangeMax = 2147483647D;
            this.txtJuros.RangeMin = 0D;
            this.txtJuros.ReadOnly = true;
            this.txtJuros.Size = new System.Drawing.Size(86, 20);
            this.txtJuros.TabIndex = 266;
            this.txtJuros.Text = "0";
            this.txtJuros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtVencimento
            // 
            this.txtVencimento.Flags = 65536;
            this.txtVencimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVencimento.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtVencimento.Location = new System.Drawing.Point(120, 23);
            this.txtVencimento.Name = "txtVencimento";
            this.txtVencimento.RangeMax = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtVencimento.RangeMin = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtVencimento.Size = new System.Drawing.Size(86, 20);
            this.txtVencimento.TabIndex = 285;
            this.txtVencimento.Validating += new System.ComponentModel.CancelEventHandler(this.txtQtdeParcela_Validating);
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.Location = new System.Drawing.Point(6, 3);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(97, 16);
            this.label141.TabIndex = 283;
            this.label141.Text = "Parcelamento";
            // 
            // txtJurosCompensatorios
            // 
            this.txtJurosCompensatorios.AllowNegative = true;
            this.txtJurosCompensatorios.DigitsInGroup = 0;
            this.txtJurosCompensatorios.Flags = 0;
            this.txtJurosCompensatorios.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJurosCompensatorios.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtJurosCompensatorios.Location = new System.Drawing.Point(505, 21);
            this.txtJurosCompensatorios.MaxDecimalPlaces = 2;
            this.txtJurosCompensatorios.MaxLength = 12;
            this.txtJurosCompensatorios.MaxWholeDigits = 10;
            this.txtJurosCompensatorios.Name = "txtJurosCompensatorios";
            this.txtJurosCompensatorios.Prefix = "";
            this.txtJurosCompensatorios.RangeMax = 2147483647D;
            this.txtJurosCompensatorios.RangeMin = 0D;
            this.txtJurosCompensatorios.ReadOnly = true;
            this.txtJurosCompensatorios.Size = new System.Drawing.Size(86, 20);
            this.txtJurosCompensatorios.TabIndex = 264;
            this.txtJurosCompensatorios.Text = "0";
            this.txtJurosCompensatorios.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalDevido
            // 
            this.txtTotalDevido.AllowNegative = true;
            this.txtTotalDevido.DigitsInGroup = 0;
            this.txtTotalDevido.Flags = 0;
            this.txtTotalDevido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalDevido.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTotalDevido.Location = new System.Drawing.Point(305, 75);
            this.txtTotalDevido.MaxDecimalPlaces = 2;
            this.txtTotalDevido.MaxLength = 12;
            this.txtTotalDevido.MaxWholeDigits = 10;
            this.txtTotalDevido.Name = "txtTotalDevido";
            this.txtTotalDevido.Prefix = "";
            this.txtTotalDevido.RangeMax = 2147483647D;
            this.txtTotalDevido.RangeMin = 0D;
            this.txtTotalDevido.ReadOnly = true;
            this.txtTotalDevido.Size = new System.Drawing.Size(86, 20);
            this.txtTotalDevido.TabIndex = 263;
            this.txtTotalDevido.Text = "0";
            this.txtTotalDevido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtExpediente
            // 
            this.txtExpediente.AllowNegative = true;
            this.txtExpediente.DigitsInGroup = 0;
            this.txtExpediente.Flags = 0;
            this.txtExpediente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExpediente.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtExpediente.Location = new System.Drawing.Point(505, 48);
            this.txtExpediente.MaxDecimalPlaces = 2;
            this.txtExpediente.MaxLength = 12;
            this.txtExpediente.MaxWholeDigits = 10;
            this.txtExpediente.Name = "txtExpediente";
            this.txtExpediente.Prefix = "";
            this.txtExpediente.RangeMax = 2147483647D;
            this.txtExpediente.RangeMin = 0D;
            this.txtExpediente.ReadOnly = true;
            this.txtExpediente.Size = new System.Drawing.Size(86, 20);
            this.txtExpediente.TabIndex = 265;
            this.txtExpediente.Text = "0";
            this.txtExpediente.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtExpediente.Validating += new System.ComponentModel.CancelEventHandler(this.txtQtdeParcela_Validating);
            // 
            // txtDescontoPenalidade
            // 
            this.txtDescontoPenalidade.AllowNegative = true;
            this.txtDescontoPenalidade.DigitsInGroup = 0;
            this.txtDescontoPenalidade.Flags = 0;
            this.txtDescontoPenalidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescontoPenalidade.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDescontoPenalidade.Location = new System.Drawing.Point(305, 48);
            this.txtDescontoPenalidade.MaxDecimalPlaces = 2;
            this.txtDescontoPenalidade.MaxLength = 12;
            this.txtDescontoPenalidade.MaxWholeDigits = 10;
            this.txtDescontoPenalidade.Name = "txtDescontoPenalidade";
            this.txtDescontoPenalidade.Prefix = "";
            this.txtDescontoPenalidade.RangeMax = 2147483647D;
            this.txtDescontoPenalidade.RangeMin = 0D;
            this.txtDescontoPenalidade.ReadOnly = true;
            this.txtDescontoPenalidade.Size = new System.Drawing.Size(86, 20);
            this.txtDescontoPenalidade.TabIndex = 262;
            this.txtDescontoPenalidade.Text = "0";
            this.txtDescontoPenalidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtValorTotal
            // 
            this.txtValorTotal.AllowNegative = true;
            this.txtValorTotal.DigitsInGroup = 0;
            this.txtValorTotal.Flags = 0;
            this.txtValorTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorTotal.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtValorTotal.Location = new System.Drawing.Point(825, 21);
            this.txtValorTotal.MaxDecimalPlaces = 2;
            this.txtValorTotal.MaxLength = 12;
            this.txtValorTotal.MaxWholeDigits = 10;
            this.txtValorTotal.Name = "txtValorTotal";
            this.txtValorTotal.Prefix = "";
            this.txtValorTotal.RangeMax = 2147483647D;
            this.txtValorTotal.RangeMin = 0D;
            this.txtValorTotal.ReadOnly = true;
            this.txtValorTotal.Size = new System.Drawing.Size(86, 20);
            this.txtValorTotal.TabIndex = 269;
            this.txtValorTotal.Text = "0";
            this.txtValorTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtValor
            // 
            this.txtValor.AllowNegative = true;
            this.txtValor.DigitsInGroup = 0;
            this.txtValor.Flags = 0;
            this.txtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValor.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtValor.Location = new System.Drawing.Point(305, 21);
            this.txtValor.MaxDecimalPlaces = 2;
            this.txtValor.MaxLength = 12;
            this.txtValor.MaxWholeDigits = 10;
            this.txtValor.Name = "txtValor";
            this.txtValor.Prefix = "";
            this.txtValor.RangeMax = 2147483647D;
            this.txtValor.RangeMin = 0D;
            this.txtValor.ReadOnly = true;
            this.txtValor.Size = new System.Drawing.Size(86, 20);
            this.txtValor.TabIndex = 261;
            this.txtValor.Text = "0";
            this.txtValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQtdeParcela
            // 
            this.txtQtdeParcela.AllowNegative = true;
            this.txtQtdeParcela.DigitsInGroup = 0;
            this.txtQtdeParcela.Flags = 0;
            this.txtQtdeParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdeParcela.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtQtdeParcela.Location = new System.Drawing.Point(120, 52);
            this.txtQtdeParcela.MaxDecimalPlaces = 0;
            this.txtQtdeParcela.MaxLength = 5;
            this.txtQtdeParcela.MaxWholeDigits = 5;
            this.txtQtdeParcela.Name = "txtQtdeParcela";
            this.txtQtdeParcela.Prefix = "";
            this.txtQtdeParcela.RangeMax = 2147483647D;
            this.txtQtdeParcela.RangeMin = 1D;
            this.txtQtdeParcela.Size = new System.Drawing.Size(86, 20);
            this.txtQtdeParcela.TabIndex = 260;
            this.txtQtdeParcela.Text = "1";
            this.txtQtdeParcela.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQtdeParcela.Validating += new System.ComponentModel.CancelEventHandler(this.txtQtdeParcela_Validating);
            // 
            // pnlParcelamentoDados
            // 
            this.pnlParcelamentoDados.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlParcelamentoDados.Controls.Add(this.lblCodParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtCodParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtParcCancelado);
            this.pnlParcelamentoDados.Controls.Add(this.txtUFParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtCidadeParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtAssuntoParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label144);
            this.pnlParcelamentoDados.Controls.Add(this.txtProcurador);
            this.pnlParcelamentoDados.Controls.Add(label143);
            this.pnlParcelamentoDados.Controls.Add(label142);
            this.pnlParcelamentoDados.Controls.Add(this.txtCPFProcurador);
            this.pnlParcelamentoDados.Controls.Add(label137);
            this.pnlParcelamentoDados.Controls.Add(this.txtCPFResponsavelParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtResponsavelParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label138);
            this.pnlParcelamentoDados.Controls.Add(this.txtNOME_RAZAOParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label139);
            this.pnlParcelamentoDados.Controls.Add(label140);
            this.pnlParcelamentoDados.Controls.Add(this.txtCPFCNPJParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtNumeroRespParcelamento);
            this.pnlParcelamentoDados.Controls.Add(this.txtLogradouroRespParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label121);
            this.pnlParcelamentoDados.Controls.Add(label124);
            this.pnlParcelamentoDados.Controls.Add(this.txtBairroRespParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label125);
            this.pnlParcelamentoDados.Controls.Add(this.txtCepRespParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label126);
            this.pnlParcelamentoDados.Controls.Add(label128);
            this.pnlParcelamentoDados.Controls.Add(this.txtComplRespParcelamento);
            this.pnlParcelamentoDados.Controls.Add(label130);
            this.pnlParcelamentoDados.Controls.Add(label136);
            this.pnlParcelamentoDados.Controls.Add(this.label36);
            this.pnlParcelamentoDados.Location = new System.Drawing.Point(16, 6);
            this.pnlParcelamentoDados.Name = "pnlParcelamentoDados";
            this.pnlParcelamentoDados.Size = new System.Drawing.Size(950, 236);
            this.pnlParcelamentoDados.TabIndex = 246;
            // 
            // lblCodParcelamento
            // 
            this.lblCodParcelamento.AutoSize = true;
            this.lblCodParcelamento.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodParcelamento.ForeColor = System.Drawing.Color.Red;
            this.lblCodParcelamento.Location = new System.Drawing.Point(348, 22);
            this.lblCodParcelamento.Name = "lblCodParcelamento";
            this.lblCodParcelamento.Size = new System.Drawing.Size(124, 19);
            this.lblCodParcelamento.TabIndex = 299;
            this.lblCodParcelamento.Text = "Parcelamento :";
            // 
            // txtCodParcelamento
            // 
            this.txtCodParcelamento.Flags = 0;
            this.txtCodParcelamento.Location = new System.Drawing.Point(476, 22);
            this.txtCodParcelamento.Mask = "##############";
            this.txtCodParcelamento.Name = "txtCodParcelamento";
            this.txtCodParcelamento.Size = new System.Drawing.Size(172, 20);
            this.txtCodParcelamento.TabIndex = 298;
            // 
            // txtParcCancelado
            // 
            this.txtParcCancelado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParcCancelado.ForeColor = System.Drawing.Color.Red;
            this.txtParcCancelado.Location = new System.Drawing.Point(661, 2);
            this.txtParcCancelado.Multiline = true;
            this.txtParcCancelado.Name = "txtParcCancelado";
            this.txtParcCancelado.ReadOnly = true;
            this.txtParcCancelado.Size = new System.Drawing.Size(281, 94);
            this.txtParcCancelado.TabIndex = 297;
            this.txtParcCancelado.Visible = false;
            // 
            // txtUFParcelamento
            // 
            this.txtUFParcelamento.Location = new System.Drawing.Point(130, 153);
            this.txtUFParcelamento.MaxLength = 75;
            this.txtUFParcelamento.Name = "txtUFParcelamento";
            this.txtUFParcelamento.Size = new System.Drawing.Size(106, 20);
            this.txtUFParcelamento.TabIndex = 293;
            // 
            // txtCidadeParcelamento
            // 
            this.txtCidadeParcelamento.Location = new System.Drawing.Point(473, 155);
            this.txtCidadeParcelamento.MaxLength = 75;
            this.txtCidadeParcelamento.Name = "txtCidadeParcelamento";
            this.txtCidadeParcelamento.Size = new System.Drawing.Size(252, 20);
            this.txtCidadeParcelamento.TabIndex = 292;
            // 
            // txtAssuntoParcelamento
            // 
            this.txtAssuntoParcelamento.Location = new System.Drawing.Point(130, 207);
            this.txtAssuntoParcelamento.MaxLength = 129;
            this.txtAssuntoParcelamento.Name = "txtAssuntoParcelamento";
            this.txtAssuntoParcelamento.Size = new System.Drawing.Size(405, 20);
            this.txtAssuntoParcelamento.TabIndex = 291;
            this.txtAssuntoParcelamento.Text = "Aprovação de projeto e concessão de linceça para construir.";
            // 
            // txtProcurador
            // 
            this.txtProcurador.Location = new System.Drawing.Point(130, 181);
            this.txtProcurador.Name = "txtProcurador";
            this.txtProcurador.Size = new System.Drawing.Size(288, 20);
            this.txtProcurador.TabIndex = 287;
            // 
            // txtCPFProcurador
            // 
            this.txtCPFProcurador.Flags = 0;
            this.txtCPFProcurador.Location = new System.Drawing.Point(473, 181);
            this.txtCPFProcurador.Mask = "##############";
            this.txtCPFProcurador.Name = "txtCPFProcurador";
            this.txtCPFProcurador.Size = new System.Drawing.Size(172, 20);
            this.txtCPFProcurador.TabIndex = 285;
            // 
            // txtCPFResponsavelParcelamento
            // 
            this.txtCPFResponsavelParcelamento.Flags = 0;
            this.txtCPFResponsavelParcelamento.Location = new System.Drawing.Point(473, 75);
            this.txtCPFResponsavelParcelamento.Mask = "##############";
            this.txtCPFResponsavelParcelamento.Name = "txtCPFResponsavelParcelamento";
            this.txtCPFResponsavelParcelamento.Size = new System.Drawing.Size(175, 20);
            this.txtCPFResponsavelParcelamento.TabIndex = 281;
            // 
            // txtResponsavelParcelamento
            // 
            this.txtResponsavelParcelamento.Location = new System.Drawing.Point(130, 75);
            this.txtResponsavelParcelamento.Name = "txtResponsavelParcelamento";
            this.txtResponsavelParcelamento.Size = new System.Drawing.Size(288, 20);
            this.txtResponsavelParcelamento.TabIndex = 279;
            // 
            // txtNOME_RAZAOParcelamento
            // 
            this.txtNOME_RAZAOParcelamento.Location = new System.Drawing.Point(130, 49);
            this.txtNOME_RAZAOParcelamento.Name = "txtNOME_RAZAOParcelamento";
            this.txtNOME_RAZAOParcelamento.Size = new System.Drawing.Size(518, 20);
            this.txtNOME_RAZAOParcelamento.TabIndex = 276;
            // 
            // txtCPFCNPJParcelamento
            // 
            this.txtCPFCNPJParcelamento.Flags = 0;
            this.txtCPFCNPJParcelamento.Location = new System.Drawing.Point(130, 25);
            this.txtCPFCNPJParcelamento.Mask = "##############";
            this.txtCPFCNPJParcelamento.Name = "txtCPFCNPJParcelamento";
            this.txtCPFCNPJParcelamento.Size = new System.Drawing.Size(172, 20);
            this.txtCPFCNPJParcelamento.TabIndex = 275;
            // 
            // txtNumeroRespParcelamento
            // 
            this.txtNumeroRespParcelamento.Flags = 0;
            this.txtNumeroRespParcelamento.Location = new System.Drawing.Point(642, 102);
            this.txtNumeroRespParcelamento.Mask = "";
            this.txtNumeroRespParcelamento.Name = "txtNumeroRespParcelamento";
            this.txtNumeroRespParcelamento.Size = new System.Drawing.Size(83, 20);
            this.txtNumeroRespParcelamento.TabIndex = 261;
            // 
            // txtLogradouroRespParcelamento
            // 
            this.txtLogradouroRespParcelamento.Location = new System.Drawing.Point(305, 102);
            this.txtLogradouroRespParcelamento.Name = "txtLogradouroRespParcelamento";
            this.txtLogradouroRespParcelamento.Size = new System.Drawing.Size(279, 20);
            this.txtLogradouroRespParcelamento.TabIndex = 249;
            // 
            // txtBairroRespParcelamento
            // 
            this.txtBairroRespParcelamento.Location = new System.Drawing.Point(473, 128);
            this.txtBairroRespParcelamento.MaxLength = 75;
            this.txtBairroRespParcelamento.Name = "txtBairroRespParcelamento";
            this.txtBairroRespParcelamento.Size = new System.Drawing.Size(252, 20);
            this.txtBairroRespParcelamento.TabIndex = 251;
            // 
            // txtCepRespParcelamento
            // 
            this.txtCepRespParcelamento.Flags = 0;
            this.txtCepRespParcelamento.Location = new System.Drawing.Point(130, 102);
            this.txtCepRespParcelamento.Mask = "#####-###";
            this.txtCepRespParcelamento.Name = "txtCepRespParcelamento";
            this.txtCepRespParcelamento.Size = new System.Drawing.Size(106, 20);
            this.txtCepRespParcelamento.TabIndex = 248;
            // 
            // txtComplRespParcelamento
            // 
            this.txtComplRespParcelamento.Location = new System.Drawing.Point(130, 128);
            this.txtComplRespParcelamento.MaxLength = 30;
            this.txtComplRespParcelamento.Name = "txtComplRespParcelamento";
            this.txtComplRespParcelamento.Size = new System.Drawing.Size(288, 20);
            this.txtComplRespParcelamento.TabIndex = 250;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(3, 5);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(127, 16);
            this.label36.TabIndex = 246;
            this.label36.Text = "Dados Proprietário";
            // 
            // cmsOpcoes
            // 
            this.cmsOpcoes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmEvento,
            this.imprimirDemonstrativoToolStripMenuItem,
            this.mnuCarne,
            this.mnuDemonstrativoParc,
            this.mnutermoConfissao,
            this.saldoDevedorToolStripMenuItem});
            this.cmsOpcoes.Name = "cmsOpcoes";
            this.cmsOpcoes.Size = new System.Drawing.Size(245, 136);
            this.cmsOpcoes.Opening += new System.ComponentModel.CancelEventHandler(this.cmsOpcoes_Opening);
            // 
            // tsmEvento
            // 
            this.tsmEvento.Name = "tsmEvento";
            this.tsmEvento.Size = new System.Drawing.Size(244, 22);
            this.tsmEvento.Text = "Notificação";
            this.tsmEvento.Click += new System.EventHandler(this.tsmEvento_Click);
            // 
            // imprimirDemonstrativoToolStripMenuItem
            // 
            this.imprimirDemonstrativoToolStripMenuItem.Name = "imprimirDemonstrativoToolStripMenuItem";
            this.imprimirDemonstrativoToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.imprimirDemonstrativoToolStripMenuItem.Text = "Demonstrativo";
            this.imprimirDemonstrativoToolStripMenuItem.Click += new System.EventHandler(this.imprimirDemonstrativoToolStripMenuItem_Click);
            // 
            // mnuCarne
            // 
            this.mnuCarne.Name = "mnuCarne";
            this.mnuCarne.Size = new System.Drawing.Size(244, 22);
            this.mnuCarne.Text = "Carnê de Parcelamento";
            this.mnuCarne.Visible = false;
            this.mnuCarne.Click += new System.EventHandler(this.carnêDeParcelamentoToolStripMenuItem_Click);
            // 
            // mnuDemonstrativoParc
            // 
            this.mnuDemonstrativoParc.Name = "mnuDemonstrativoParc";
            this.mnuDemonstrativoParc.Size = new System.Drawing.Size(244, 22);
            this.mnuDemonstrativoParc.Text = "Demonstrativo de Parcelamento";
            this.mnuDemonstrativoParc.Click += new System.EventHandler(this.demoonstrativoToolStripMenuItem_Click);
            // 
            // mnutermoConfissao
            // 
            this.mnutermoConfissao.Name = "mnutermoConfissao";
            this.mnutermoConfissao.Size = new System.Drawing.Size(244, 22);
            this.mnutermoConfissao.Text = "Termo de Confissão de Divída";
            this.mnutermoConfissao.Visible = false;
            this.mnutermoConfissao.Click += new System.EventHandler(this.termoDeConfissãoDeDivídaToolStripMenuItem_Click);
            // 
            // saldoDevedorToolStripMenuItem
            // 
            this.saldoDevedorToolStripMenuItem.Name = "saldoDevedorToolStripMenuItem";
            this.saldoDevedorToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.saldoDevedorToolStripMenuItem.Text = "Saldo Remanescente";
            this.saldoDevedorToolStripMenuItem.Click += new System.EventHandler(this.saldoDevedorToolStripMenuItem_Click);
            // 
            // tbpLancamento
            // 
            this.tbpLancamento.Controls.Add(this.tblLancamentos);
            this.tbpLancamento.Location = new System.Drawing.Point(4, 22);
            this.tbpLancamento.Name = "tbpLancamento";
            this.tbpLancamento.Padding = new System.Windows.Forms.Padding(3);
            this.tbpLancamento.Size = new System.Drawing.Size(1002, 691);
            this.tbpLancamento.TabIndex = 3;
            this.tbpLancamento.Text = "Dados do Lançamento";
            this.tbpLancamento.UseVisualStyleBackColor = true;
            // 
            // tblLancamentos
            // 
            this.tblLancamentos.Controls.Add(this.tbgInscricao);
            this.tblLancamentos.Controls.Add(this.tbgIptu);
            this.tblLancamentos.Controls.Add(this.tbgConstrucao);
            this.tblLancamentos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLancamentos.Location = new System.Drawing.Point(3, 3);
            this.tblLancamentos.Name = "tblLancamentos";
            this.tblLancamentos.SelectedIndex = 0;
            this.tblLancamentos.Size = new System.Drawing.Size(996, 685);
            this.tblLancamentos.TabIndex = 0;
            // 
            // tbgConstrucao
            // 
            this.tbgConstrucao.AutoScroll = true;
            this.tbgConstrucao.Controls.Add(this.pnl_Botoes_Construcao);
            this.tbgConstrucao.Controls.Add(this.grpConstrucao);
            this.tbgConstrucao.Controls.Add(this.gbxDadosLancamento);
            this.tbgConstrucao.Location = new System.Drawing.Point(4, 22);
            this.tbgConstrucao.Name = "tbgConstrucao";
            this.tbgConstrucao.Padding = new System.Windows.Forms.Padding(3);
            this.tbgConstrucao.Size = new System.Drawing.Size(988, 659);
            this.tbgConstrucao.TabIndex = 0;
            this.tbgConstrucao.Text = "Construção";
            this.tbgConstrucao.UseVisualStyleBackColor = true;
            // 
            // pnl_Botoes_Construcao
            // 
            this.pnl_Botoes_Construcao.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnl_Botoes_Construcao.Controls.Add(this.btnLimparConstrucao);
            this.pnl_Botoes_Construcao.Controls.Add(this.btnGravarConstrucao);
            this.pnl_Botoes_Construcao.Controls.Add(this.btnExcluirConstrucao);
            this.pnl_Botoes_Construcao.Controls.Add(this.btnEditarConstrucao);
            this.pnl_Botoes_Construcao.Controls.Add(this.btnIncluirConstrucao);
            this.pnl_Botoes_Construcao.Location = new System.Drawing.Point(7, 570);
            this.pnl_Botoes_Construcao.Name = "pnl_Botoes_Construcao";
            this.pnl_Botoes_Construcao.Padding = new System.Windows.Forms.Padding(3);
            this.pnl_Botoes_Construcao.Size = new System.Drawing.Size(933, 29);
            this.pnl_Botoes_Construcao.TabIndex = 294;
            // 
            // btnLimparConstrucao
            // 
            this.btnLimparConstrucao.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnLimparConstrucao.Location = new System.Drawing.Point(855, 3);
            this.btnLimparConstrucao.Name = "btnLimparConstrucao";
            this.btnLimparConstrucao.Size = new System.Drawing.Size(75, 23);
            this.btnLimparConstrucao.TabIndex = 4;
            this.btnLimparConstrucao.Text = "&Limpar";
            this.btnLimparConstrucao.UseVisualStyleBackColor = true;
            this.btnLimparConstrucao.Click += new System.EventHandler(this.btnLimparConstrucao_Click);
            // 
            // btnGravarConstrucao
            // 
            this.btnGravarConstrucao.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnGravarConstrucao.Enabled = false;
            this.btnGravarConstrucao.Location = new System.Drawing.Point(228, 3);
            this.btnGravarConstrucao.Name = "btnGravarConstrucao";
            this.btnGravarConstrucao.Size = new System.Drawing.Size(75, 23);
            this.btnGravarConstrucao.TabIndex = 3;
            this.btnGravarConstrucao.Text = "&Atualizar";
            this.btnGravarConstrucao.UseVisualStyleBackColor = true;
            this.btnGravarConstrucao.Click += new System.EventHandler(this.btnGravarConstrucao_Click);
            // 
            // btnExcluirConstrucao
            // 
            this.btnExcluirConstrucao.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnExcluirConstrucao.Location = new System.Drawing.Point(153, 3);
            this.btnExcluirConstrucao.Name = "btnExcluirConstrucao";
            this.btnExcluirConstrucao.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirConstrucao.TabIndex = 2;
            this.btnExcluirConstrucao.Text = "&Excluir";
            this.btnExcluirConstrucao.UseVisualStyleBackColor = true;
            this.btnExcluirConstrucao.Click += new System.EventHandler(this.btnExcluirConstrucao_Click);
            // 
            // btnEditarConstrucao
            // 
            this.btnEditarConstrucao.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEditarConstrucao.Location = new System.Drawing.Point(78, 3);
            this.btnEditarConstrucao.Name = "btnEditarConstrucao";
            this.btnEditarConstrucao.Size = new System.Drawing.Size(75, 23);
            this.btnEditarConstrucao.TabIndex = 1;
            this.btnEditarConstrucao.Text = "E&ditar";
            this.btnEditarConstrucao.UseVisualStyleBackColor = true;
            this.btnEditarConstrucao.Click += new System.EventHandler(this.btnEditarConstrucao_Click);
            // 
            // btnIncluirConstrucao
            // 
            this.btnIncluirConstrucao.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnIncluirConstrucao.Location = new System.Drawing.Point(3, 3);
            this.btnIncluirConstrucao.Name = "btnIncluirConstrucao";
            this.btnIncluirConstrucao.Size = new System.Drawing.Size(75, 23);
            this.btnIncluirConstrucao.TabIndex = 0;
            this.btnIncluirConstrucao.Text = "&Incluir";
            this.btnIncluirConstrucao.UseVisualStyleBackColor = true;
            this.btnIncluirConstrucao.Click += new System.EventHandler(this.btnIncluirConstrucao_Click);
            // 
            // grpConstrucao
            // 
            this.grpConstrucao.Controls.Add(this.groupBox7);
            this.grpConstrucao.Controls.Add(this.groupBox6);
            this.grpConstrucao.Controls.Add(this.groupBox3);
            this.grpConstrucao.Controls.Add(this.grpAreas);
            this.grpConstrucao.Controls.Add(this.groupBox2);
            this.grpConstrucao.Controls.Add(this.GroupBox4);
            this.grpConstrucao.Location = new System.Drawing.Point(1, 11);
            this.grpConstrucao.Name = "grpConstrucao";
            this.grpConstrucao.Size = new System.Drawing.Size(953, 556);
            this.grpConstrucao.TabIndex = 293;
            this.grpConstrucao.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.lblTaxaNumPredial);
            this.groupBox7.Controls.Add(this.lblTaxaAlvara);
            this.groupBox7.Controls.Add(label127);
            this.groupBox7.Controls.Add(this.lblTaxaLicenca);
            this.groupBox7.Controls.Add(label129);
            this.groupBox7.Controls.Add(this.lblTaxaPenalidades);
            this.groupBox7.Controls.Add(label131);
            this.groupBox7.Controls.Add(this.lblTaxaAlinhamento);
            this.groupBox7.Controls.Add(label133);
            this.groupBox7.Controls.Add(this.lblTaxaConstrucao);
            this.groupBox7.Controls.Add(label135);
            this.groupBox7.Location = new System.Drawing.Point(715, 346);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(231, 203);
            this.groupBox7.TabIndex = 297;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Taxas/Preço Publico/Penalidade :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(114, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 13);
            this.label10.TabIndex = 129;
            this.label10.Text = "Numeração Predial";
            // 
            // lblTaxaNumPredial
            // 
            this.lblTaxaNumPredial.AutoSize = true;
            this.lblTaxaNumPredial.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaNumPredial.Location = new System.Drawing.Point(115, 145);
            this.lblTaxaNumPredial.Name = "lblTaxaNumPredial";
            this.lblTaxaNumPredial.Size = new System.Drawing.Size(17, 17);
            this.lblTaxaNumPredial.TabIndex = 128;
            this.lblTaxaNumPredial.Text = "0";
            this.lblTaxaNumPredial.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTaxaAlvara
            // 
            this.lblTaxaAlvara.AutoSize = true;
            this.lblTaxaAlvara.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaAlvara.Location = new System.Drawing.Point(23, 145);
            this.lblTaxaAlvara.Name = "lblTaxaAlvara";
            this.lblTaxaAlvara.Size = new System.Drawing.Size(17, 17);
            this.lblTaxaAlvara.TabIndex = 126;
            this.lblTaxaAlvara.Text = "0";
            this.lblTaxaAlvara.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTaxaLicenca
            // 
            this.lblTaxaLicenca.AutoSize = true;
            this.lblTaxaLicenca.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaLicenca.Location = new System.Drawing.Point(23, 72);
            this.lblTaxaLicenca.Name = "lblTaxaLicenca";
            this.lblTaxaLicenca.Size = new System.Drawing.Size(17, 17);
            this.lblTaxaLicenca.TabIndex = 124;
            this.lblTaxaLicenca.Text = "0";
            this.lblTaxaLicenca.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTaxaPenalidades
            // 
            this.lblTaxaPenalidades.AutoSize = true;
            this.lblTaxaPenalidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaPenalidades.Location = new System.Drawing.Point(23, 182);
            this.lblTaxaPenalidades.Name = "lblTaxaPenalidades";
            this.lblTaxaPenalidades.Size = new System.Drawing.Size(17, 17);
            this.lblTaxaPenalidades.TabIndex = 122;
            this.lblTaxaPenalidades.Text = "0";
            this.lblTaxaPenalidades.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTaxaAlinhamento
            // 
            this.lblTaxaAlinhamento.AutoSize = true;
            this.lblTaxaAlinhamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaAlinhamento.Location = new System.Drawing.Point(23, 109);
            this.lblTaxaAlinhamento.Name = "lblTaxaAlinhamento";
            this.lblTaxaAlinhamento.Size = new System.Drawing.Size(17, 17);
            this.lblTaxaAlinhamento.TabIndex = 118;
            this.lblTaxaAlinhamento.Text = "0";
            this.lblTaxaAlinhamento.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTaxaConstrucao
            // 
            this.lblTaxaConstrucao.AutoSize = true;
            this.lblTaxaConstrucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaConstrucao.Location = new System.Drawing.Point(23, 36);
            this.lblTaxaConstrucao.Name = "lblTaxaConstrucao";
            this.lblTaxaConstrucao.Size = new System.Drawing.Size(17, 17);
            this.lblTaxaConstrucao.TabIndex = 114;
            this.lblTaxaConstrucao.Text = "0";
            this.lblTaxaConstrucao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lblImpostoISSReforma);
            this.groupBox6.Controls.Add(label101);
            this.groupBox6.Controls.Add(this.lblImpostoISSConstrucao);
            this.groupBox6.Controls.Add(label103);
            this.groupBox6.Controls.Add(this.lblImpostoSSEngenharia);
            this.groupBox6.Controls.Add(label117);
            this.groupBox6.Controls.Add(this.lblImpostoISSDemolicao);
            this.groupBox6.Controls.Add(label107);
            this.groupBox6.Location = new System.Drawing.Point(478, 346);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(222, 203);
            this.groupBox6.TabIndex = 296;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Imposto ISS :";
            // 
            // lblImpostoISSReforma
            // 
            this.lblImpostoISSReforma.AutoSize = true;
            this.lblImpostoISSReforma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpostoISSReforma.Location = new System.Drawing.Point(20, 109);
            this.lblImpostoISSReforma.Name = "lblImpostoISSReforma";
            this.lblImpostoISSReforma.Size = new System.Drawing.Size(17, 17);
            this.lblImpostoISSReforma.TabIndex = 128;
            this.lblImpostoISSReforma.Text = "0";
            this.lblImpostoISSReforma.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblImpostoISSConstrucao
            // 
            this.lblImpostoISSConstrucao.AutoSize = true;
            this.lblImpostoISSConstrucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpostoISSConstrucao.Location = new System.Drawing.Point(20, 36);
            this.lblImpostoISSConstrucao.Name = "lblImpostoISSConstrucao";
            this.lblImpostoISSConstrucao.Size = new System.Drawing.Size(17, 17);
            this.lblImpostoISSConstrucao.TabIndex = 126;
            this.lblImpostoISSConstrucao.Text = "0";
            this.lblImpostoISSConstrucao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblImpostoSSEngenharia
            // 
            this.lblImpostoSSEngenharia.AutoSize = true;
            this.lblImpostoSSEngenharia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpostoSSEngenharia.Location = new System.Drawing.Point(20, 145);
            this.lblImpostoSSEngenharia.Name = "lblImpostoSSEngenharia";
            this.lblImpostoSSEngenharia.Size = new System.Drawing.Size(17, 17);
            this.lblImpostoSSEngenharia.TabIndex = 124;
            this.lblImpostoSSEngenharia.Text = "0";
            this.lblImpostoSSEngenharia.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblImpostoISSDemolicao
            // 
            this.lblImpostoISSDemolicao.AutoSize = true;
            this.lblImpostoISSDemolicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpostoISSDemolicao.Location = new System.Drawing.Point(20, 73);
            this.lblImpostoISSDemolicao.Name = "lblImpostoISSDemolicao";
            this.lblImpostoISSDemolicao.Size = new System.Drawing.Size(17, 17);
            this.lblImpostoISSDemolicao.TabIndex = 122;
            this.lblImpostoISSDemolicao.Text = "0";
            this.lblImpostoISSDemolicao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblBaseISSDemolicao);
            this.groupBox3.Controls.Add(label105);
            this.groupBox3.Controls.Add(this.lblBaseISSReforma);
            this.groupBox3.Controls.Add(label109);
            this.groupBox3.Controls.Add(this.lblBaseISSConstrucao);
            this.groupBox3.Controls.Add(label111);
            this.groupBox3.Controls.Add(this.lblBaseISSEngenharia);
            this.groupBox3.Controls.Add(label123);
            this.groupBox3.Location = new System.Drawing.Point(240, 346);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(222, 203);
            this.groupBox3.TabIndex = 295;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Base de Cálculo do ISS :";
            // 
            // lblBaseISSDemolicao
            // 
            this.lblBaseISSDemolicao.AutoSize = true;
            this.lblBaseISSDemolicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaseISSDemolicao.Location = new System.Drawing.Point(23, 72);
            this.lblBaseISSDemolicao.Name = "lblBaseISSDemolicao";
            this.lblBaseISSDemolicao.Size = new System.Drawing.Size(17, 17);
            this.lblBaseISSDemolicao.TabIndex = 124;
            this.lblBaseISSDemolicao.Text = "0";
            this.lblBaseISSDemolicao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblBaseISSReforma
            // 
            this.lblBaseISSReforma.AutoSize = true;
            this.lblBaseISSReforma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaseISSReforma.Location = new System.Drawing.Point(23, 109);
            this.lblBaseISSReforma.Name = "lblBaseISSReforma";
            this.lblBaseISSReforma.Size = new System.Drawing.Size(17, 17);
            this.lblBaseISSReforma.TabIndex = 118;
            this.lblBaseISSReforma.Text = "0";
            this.lblBaseISSReforma.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblBaseISSConstrucao
            // 
            this.lblBaseISSConstrucao.AutoSize = true;
            this.lblBaseISSConstrucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaseISSConstrucao.Location = new System.Drawing.Point(23, 36);
            this.lblBaseISSConstrucao.Name = "lblBaseISSConstrucao";
            this.lblBaseISSConstrucao.Size = new System.Drawing.Size(17, 17);
            this.lblBaseISSConstrucao.TabIndex = 114;
            this.lblBaseISSConstrucao.Text = "0";
            this.lblBaseISSConstrucao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblBaseISSEngenharia
            // 
            this.lblBaseISSEngenharia.AutoSize = true;
            this.lblBaseISSEngenharia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaseISSEngenharia.Location = new System.Drawing.Point(23, 145);
            this.lblBaseISSEngenharia.Name = "lblBaseISSEngenharia";
            this.lblBaseISSEngenharia.Size = new System.Drawing.Size(17, 17);
            this.lblBaseISSEngenharia.TabIndex = 114;
            this.lblBaseISSEngenharia.Text = "0";
            this.lblBaseISSEngenharia.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // grpAreas
            // 
            this.grpAreas.Controls.Add(this.lblMedidaPenalidade);
            this.grpAreas.Controls.Add(this.lblMedidaISSEngenharia);
            this.grpAreas.Controls.Add(this.lblMedidaISSReforma);
            this.grpAreas.Controls.Add(this.lblMedidaISSDemolicao);
            this.grpAreas.Controls.Add(this.lblMedidaISSConstrucao);
            this.grpAreas.Controls.Add(this.lblAreaBaseISSEngenharia);
            this.grpAreas.Controls.Add(this.lblPenalidade);
            this.grpAreas.Controls.Add(this.lblAreaBaseIssRefor);
            this.grpAreas.Controls.Add(this.lblAreaBaseISSEng);
            this.grpAreas.Controls.Add(label92);
            this.grpAreas.Controls.Add(this.lblAreaBaseISSReforma);
            this.grpAreas.Controls.Add(this.lblAreaBaseIssDemol);
            this.grpAreas.Controls.Add(this.lblAreaBaseISSDemolicao);
            this.grpAreas.Controls.Add(this.lblAreaBaseIssConstr);
            this.grpAreas.Controls.Add(this.lblAreaBaseISSConstrucao);
            this.grpAreas.Location = new System.Drawing.Point(6, 346);
            this.grpAreas.Name = "grpAreas";
            this.grpAreas.Size = new System.Drawing.Size(222, 203);
            this.grpAreas.TabIndex = 294;
            this.grpAreas.TabStop = false;
            this.grpAreas.Text = "Áreas utilizadas para apuração: (m²)";
            // 
            // lblMedidaPenalidade
            // 
            this.lblMedidaPenalidade.AutoSize = true;
            this.lblMedidaPenalidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedidaPenalidade.Location = new System.Drawing.Point(183, 181);
            this.lblMedidaPenalidade.Name = "lblMedidaPenalidade";
            this.lblMedidaPenalidade.Size = new System.Drawing.Size(26, 17);
            this.lblMedidaPenalidade.TabIndex = 131;
            this.lblMedidaPenalidade.Text = "m²";
            this.lblMedidaPenalidade.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMedidaISSEngenharia
            // 
            this.lblMedidaISSEngenharia.AutoSize = true;
            this.lblMedidaISSEngenharia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedidaISSEngenharia.Location = new System.Drawing.Point(183, 146);
            this.lblMedidaISSEngenharia.Name = "lblMedidaISSEngenharia";
            this.lblMedidaISSEngenharia.Size = new System.Drawing.Size(26, 17);
            this.lblMedidaISSEngenharia.TabIndex = 130;
            this.lblMedidaISSEngenharia.Text = "m²";
            this.lblMedidaISSEngenharia.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMedidaISSReforma
            // 
            this.lblMedidaISSReforma.AutoSize = true;
            this.lblMedidaISSReforma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedidaISSReforma.Location = new System.Drawing.Point(183, 110);
            this.lblMedidaISSReforma.Name = "lblMedidaISSReforma";
            this.lblMedidaISSReforma.Size = new System.Drawing.Size(26, 17);
            this.lblMedidaISSReforma.TabIndex = 129;
            this.lblMedidaISSReforma.Text = "m²";
            this.lblMedidaISSReforma.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMedidaISSDemolicao
            // 
            this.lblMedidaISSDemolicao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMedidaISSDemolicao.AutoSize = true;
            this.lblMedidaISSDemolicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedidaISSDemolicao.Location = new System.Drawing.Point(183, 72);
            this.lblMedidaISSDemolicao.Name = "lblMedidaISSDemolicao";
            this.lblMedidaISSDemolicao.Size = new System.Drawing.Size(26, 17);
            this.lblMedidaISSDemolicao.TabIndex = 128;
            this.lblMedidaISSDemolicao.Text = "m²";
            this.lblMedidaISSDemolicao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMedidaISSConstrucao
            // 
            this.lblMedidaISSConstrucao.AutoSize = true;
            this.lblMedidaISSConstrucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedidaISSConstrucao.Location = new System.Drawing.Point(183, 36);
            this.lblMedidaISSConstrucao.Name = "lblMedidaISSConstrucao";
            this.lblMedidaISSConstrucao.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblMedidaISSConstrucao.Size = new System.Drawing.Size(26, 17);
            this.lblMedidaISSConstrucao.TabIndex = 127;
            this.lblMedidaISSConstrucao.Text = "m²";
            this.lblMedidaISSConstrucao.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAreaBaseISSEngenharia
            // 
            this.lblAreaBaseISSEngenharia.AutoSize = true;
            this.lblAreaBaseISSEngenharia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaBaseISSEngenharia.Location = new System.Drawing.Point(23, 145);
            this.lblAreaBaseISSEngenharia.Name = "lblAreaBaseISSEngenharia";
            this.lblAreaBaseISSEngenharia.Size = new System.Drawing.Size(17, 17);
            this.lblAreaBaseISSEngenharia.TabIndex = 126;
            this.lblAreaBaseISSEngenharia.Text = "0";
            this.lblAreaBaseISSEngenharia.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblPenalidade
            // 
            this.lblPenalidade.AutoSize = true;
            this.lblPenalidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPenalidade.Location = new System.Drawing.Point(24, 181);
            this.lblPenalidade.Name = "lblPenalidade";
            this.lblPenalidade.Size = new System.Drawing.Size(17, 17);
            this.lblPenalidade.TabIndex = 124;
            this.lblPenalidade.Text = "0";
            this.lblPenalidade.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAreaBaseIssRefor
            // 
            this.lblAreaBaseIssRefor.AutoSize = true;
            this.lblAreaBaseIssRefor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaBaseIssRefor.Location = new System.Drawing.Point(23, 109);
            this.lblAreaBaseIssRefor.Name = "lblAreaBaseIssRefor";
            this.lblAreaBaseIssRefor.Size = new System.Drawing.Size(17, 17);
            this.lblAreaBaseIssRefor.TabIndex = 122;
            this.lblAreaBaseIssRefor.Text = "0";
            this.lblAreaBaseIssRefor.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAreaBaseISSEng
            // 
            this.lblAreaBaseISSEng.AutoSize = true;
            this.lblAreaBaseISSEng.Location = new System.Drawing.Point(23, 129);
            this.lblAreaBaseISSEng.Name = "lblAreaBaseISSEng";
            this.lblAreaBaseISSEng.Size = new System.Drawing.Size(162, 13);
            this.lblAreaBaseISSEng.TabIndex = 125;
            this.lblAreaBaseISSEng.Text = "Base de cálculo ISS engenharia:";
            // 
            // lblAreaBaseISSReforma
            // 
            this.lblAreaBaseISSReforma.AutoSize = true;
            this.lblAreaBaseISSReforma.Location = new System.Drawing.Point(23, 93);
            this.lblAreaBaseISSReforma.Name = "lblAreaBaseISSReforma";
            this.lblAreaBaseISSReforma.Size = new System.Drawing.Size(159, 13);
            this.lblAreaBaseISSReforma.TabIndex = 121;
            this.lblAreaBaseISSReforma.Text = "Base de cálculo do ISS reforma:";
            // 
            // lblAreaBaseIssDemol
            // 
            this.lblAreaBaseIssDemol.AutoSize = true;
            this.lblAreaBaseIssDemol.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaBaseIssDemol.Location = new System.Drawing.Point(23, 72);
            this.lblAreaBaseIssDemol.Name = "lblAreaBaseIssDemol";
            this.lblAreaBaseIssDemol.Size = new System.Drawing.Size(17, 17);
            this.lblAreaBaseIssDemol.TabIndex = 118;
            this.lblAreaBaseIssDemol.Text = "0";
            this.lblAreaBaseIssDemol.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAreaBaseISSDemolicao
            // 
            this.lblAreaBaseISSDemolicao.AutoSize = true;
            this.lblAreaBaseISSDemolicao.Location = new System.Drawing.Point(23, 56);
            this.lblAreaBaseISSDemolicao.Name = "lblAreaBaseISSDemolicao";
            this.lblAreaBaseISSDemolicao.Size = new System.Drawing.Size(172, 13);
            this.lblAreaBaseISSDemolicao.TabIndex = 117;
            this.lblAreaBaseISSDemolicao.Text = "Base de cálculo do ISS demolição:";
            // 
            // lblAreaBaseIssConstr
            // 
            this.lblAreaBaseIssConstr.AutoSize = true;
            this.lblAreaBaseIssConstr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaBaseIssConstr.Location = new System.Drawing.Point(23, 36);
            this.lblAreaBaseIssConstr.Name = "lblAreaBaseIssConstr";
            this.lblAreaBaseIssConstr.Size = new System.Drawing.Size(17, 17);
            this.lblAreaBaseIssConstr.TabIndex = 114;
            this.lblAreaBaseIssConstr.Text = "0";
            this.lblAreaBaseIssConstr.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAreaBaseISSConstrucao
            // 
            this.lblAreaBaseISSConstrucao.AutoSize = true;
            this.lblAreaBaseISSConstrucao.Location = new System.Drawing.Point(23, 20);
            this.lblAreaBaseISSConstrucao.Name = "lblAreaBaseISSConstrucao";
            this.lblAreaBaseISSConstrucao.Size = new System.Drawing.Size(175, 13);
            this.lblAreaBaseISSConstrucao.TabIndex = 113;
            this.lblAreaBaseISSConstrucao.Text = "Base de cáculo do ISS construção:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ckbMista);
            this.groupBox2.Controls.Add(label57);
            this.groupBox2.Controls.Add(label56);
            this.groupBox2.Controls.Add(label55);
            this.groupBox2.Controls.Add(this.cbxSubtipoImovel);
            this.groupBox2.Controls.Add(this.cbxTipoImovel);
            this.groupBox2.Controls.Add(this.cbxTipoConstr);
            this.groupBox2.Location = new System.Drawing.Point(8, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(937, 42);
            this.groupBox2.TabIndex = 293;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tipo";
            // 
            // ckbMista
            // 
            this.ckbMista.AutoSize = true;
            this.ckbMista.Location = new System.Drawing.Point(825, 17);
            this.ckbMista.Margin = new System.Windows.Forms.Padding(0);
            this.ckbMista.Name = "ckbMista";
            this.ckbMista.Size = new System.Drawing.Size(114, 17);
            this.ckbMista.TabIndex = 295;
            this.ckbMista.Text = "Construção Mista?";
            this.ckbMista.UseVisualStyleBackColor = true;
            this.ckbMista.Visible = false;
            // 
            // cbxSubtipoImovel
            // 
            this.cbxSubtipoImovel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubtipoImovel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxSubtipoImovel.FormattingEnabled = true;
            this.cbxSubtipoImovel.Location = new System.Drawing.Point(599, 13);
            this.cbxSubtipoImovel.Name = "cbxSubtipoImovel";
            this.cbxSubtipoImovel.Size = new System.Drawing.Size(220, 21);
            this.cbxSubtipoImovel.TabIndex = 248;
            this.cbxSubtipoImovel.SelectedIndexChanged += new System.EventHandler(this.cbxSubtipoImovel_SelectedIndexChanged);
            // 
            // cbxTipoImovel
            // 
            this.cbxTipoImovel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipoImovel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTipoImovel.FormattingEnabled = true;
            this.cbxTipoImovel.Location = new System.Drawing.Point(331, 13);
            this.cbxTipoImovel.Name = "cbxTipoImovel";
            this.cbxTipoImovel.Size = new System.Drawing.Size(216, 21);
            this.cbxTipoImovel.TabIndex = 248;
            this.cbxTipoImovel.SelectedIndexChanged += new System.EventHandler(this.cbxTipoImovel_SelectedIndexChanged);
            // 
            // cbxTipoConstr
            // 
            this.cbxTipoConstr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipoConstr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTipoConstr.FormattingEnabled = true;
            this.cbxTipoConstr.Location = new System.Drawing.Point(38, 13);
            this.cbxTipoConstr.Name = "cbxTipoConstr";
            this.cbxTipoConstr.Size = new System.Drawing.Size(223, 21);
            this.cbxTipoConstr.TabIndex = 248;
            this.cbxTipoConstr.SelectedIndexChanged += new System.EventHandler(this.cbxSubtipo_SelectedIndexChanged);
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.ckbNumeracaoPredial);
            this.GroupBox4.Controls.Add(this.chkEnquadramentoDemolicao);
            this.GroupBox4.Controls.Add(this.chkEnquadramentoReforma);
            this.GroupBox4.Controls.Add(this.chkEnquadramentoPenalidade);
            this.GroupBox4.Controls.Add(this.chkEnquadramentoBaseISS);
            this.GroupBox4.Controls.Add(this.lblEnquadramento_Base_ISS);
            this.GroupBox4.Controls.Add(this.txtEnquadramentoBaseISS);
            this.GroupBox4.Controls.Add(this.chkEnquadramentoConstrucao);
            this.GroupBox4.Controls.Add(this.label14);
            this.GroupBox4.Controls.Add(this.txtEnquadramentoPenalidade);
            this.GroupBox4.Controls.Add(this.label7);
            this.GroupBox4.Controls.Add(this.txtEnquadramentoDemolicao);
            this.GroupBox4.Controls.Add(this.label6);
            this.GroupBox4.Controls.Add(this.txtEnquadramentoReforma);
            this.GroupBox4.Controls.Add(this.ckbImplantada);
            this.GroupBox4.Controls.Add(this.label99);
            this.GroupBox4.Controls.Add(this.txtEnquadramento);
            this.GroupBox4.Controls.Add(this.txtAreaEdicula);
            this.GroupBox4.Controls.Add(this.label87);
            this.GroupBox4.Controls.Add(this.lblIdLancamento);
            this.GroupBox4.Controls.Add(this.ckbElevador);
            this.GroupBox4.Controls.Add(this.label97);
            this.GroupBox4.Controls.Add(this.txtAreaTerrenoAumentar);
            this.GroupBox4.Controls.Add(this.label95);
            this.GroupBox4.Controls.Add(this.txtTestadaAumentar);
            this.GroupBox4.Controls.Add(this.label93);
            this.GroupBox4.Controls.Add(this.txtTestadaDeduzir);
            this.GroupBox4.Controls.Add(this.label91);
            this.GroupBox4.Controls.Add(this.txtAreaTerrenoDeduzir);
            this.GroupBox4.Controls.Add(this.label89);
            this.GroupBox4.Controls.Add(this.txtNumeroUnidAutonomas);
            this.GroupBox4.Controls.Add(this.label66);
            this.GroupBox4.Controls.Add(this.txtDesmontavelLegalizado);
            this.GroupBox4.Controls.Add(this.label65);
            this.GroupBox4.Controls.Add(this.txtDesmontavelLegalizar);
            this.GroupBox4.Controls.Add(this.label63);
            this.GroupBox4.Controls.Add(this.txtUnidades);
            this.GroupBox4.Controls.Add(this.label77);
            this.GroupBox4.Controls.Add(this.txtAreaTotal);
            this.GroupBox4.Controls.Add(this.label82);
            this.GroupBox4.Controls.Add(this.txtAreaDecadDemolir);
            this.GroupBox4.Controls.Add(this.label75);
            this.GroupBox4.Controls.Add(this.txtAreaDemolir);
            this.GroupBox4.Controls.Add(this.label76);
            this.GroupBox4.Controls.Add(this.txtAreaExistenteLegalConst);
            this.GroupBox4.Controls.Add(this.label73);
            this.GroupBox4.Controls.Add(this.txtAreaReformar);
            this.GroupBox4.Controls.Add(this.label74);
            this.GroupBox4.Controls.Add(this.txtAreaConstruir);
            this.GroupBox4.Controls.Add(this.label71);
            this.GroupBox4.Controls.Add(this.txtAreaDecadConstr);
            this.GroupBox4.Controls.Add(this.label72);
            this.GroupBox4.Controls.Add(this.txtAreaLegalDemolir);
            this.GroupBox4.Controls.Add(this.label69);
            this.GroupBox4.Controls.Add(this.txtAreaLegalReformar);
            this.GroupBox4.Controls.Add(this.label70);
            this.GroupBox4.Controls.Add(this.txtAreaLegalConstr);
            this.GroupBox4.Controls.Add(this.label67);
            this.GroupBox4.Controls.Add(this.txtTESTADA_PRINCIPAL);
            this.GroupBox4.Controls.Add(this.label68);
            this.GroupBox4.Controls.Add(this.txtAREA_TERRENO);
            this.GroupBox4.Enabled = false;
            this.GroupBox4.Location = new System.Drawing.Point(6, 49);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(940, 295);
            this.GroupBox4.TabIndex = 292;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Características do Terreno";
            // 
            // ckbNumeracaoPredial
            // 
            this.ckbNumeracaoPredial.AutoSize = true;
            this.ckbNumeracaoPredial.Location = new System.Drawing.Point(691, 260);
            this.ckbNumeracaoPredial.Name = "ckbNumeracaoPredial";
            this.ckbNumeracaoPredial.Size = new System.Drawing.Size(122, 17);
            this.ckbNumeracaoPredial.TabIndex = 308;
            this.ckbNumeracaoPredial.Text = "Numeração Predial?";
            this.ckbNumeracaoPredial.UseVisualStyleBackColor = true;
            this.ckbNumeracaoPredial.CheckStateChanged += new System.EventHandler(this.txtAREA_TERRENO_TextChanged);
            // 
            // chkEnquadramentoDemolicao
            // 
            this.chkEnquadramentoDemolicao.AutoSize = true;
            this.chkEnquadramentoDemolicao.Location = new System.Drawing.Point(619, 225);
            this.chkEnquadramentoDemolicao.Name = "chkEnquadramentoDemolicao";
            this.chkEnquadramentoDemolicao.Size = new System.Drawing.Size(61, 17);
            this.chkEnquadramentoDemolicao.TabIndex = 307;
            this.chkEnquadramentoDemolicao.Text = "Manual";
            this.chkEnquadramentoDemolicao.UseVisualStyleBackColor = true;
            this.chkEnquadramentoDemolicao.CheckStateChanged += new System.EventHandler(this.chkEnquadramentoBaseISS_CheckStateChanged);
            // 
            // chkEnquadramentoReforma
            // 
            this.chkEnquadramentoReforma.AutoSize = true;
            this.chkEnquadramentoReforma.Enabled = false;
            this.chkEnquadramentoReforma.Location = new System.Drawing.Point(400, 263);
            this.chkEnquadramentoReforma.Name = "chkEnquadramentoReforma";
            this.chkEnquadramentoReforma.Size = new System.Drawing.Size(61, 17);
            this.chkEnquadramentoReforma.TabIndex = 306;
            this.chkEnquadramentoReforma.Text = "Manual";
            this.chkEnquadramentoReforma.UseVisualStyleBackColor = true;
            // 
            // chkEnquadramentoPenalidade
            // 
            this.chkEnquadramentoPenalidade.AutoSize = true;
            this.chkEnquadramentoPenalidade.Enabled = false;
            this.chkEnquadramentoPenalidade.Location = new System.Drawing.Point(847, 225);
            this.chkEnquadramentoPenalidade.Name = "chkEnquadramentoPenalidade";
            this.chkEnquadramentoPenalidade.Size = new System.Drawing.Size(61, 17);
            this.chkEnquadramentoPenalidade.TabIndex = 305;
            this.chkEnquadramentoPenalidade.Text = "Manual";
            this.chkEnquadramentoPenalidade.UseVisualStyleBackColor = true;
            // 
            // chkEnquadramentoBaseISS
            // 
            this.chkEnquadramentoBaseISS.AutoSize = true;
            this.chkEnquadramentoBaseISS.Location = new System.Drawing.Point(619, 263);
            this.chkEnquadramentoBaseISS.Name = "chkEnquadramentoBaseISS";
            this.chkEnquadramentoBaseISS.Size = new System.Drawing.Size(61, 17);
            this.chkEnquadramentoBaseISS.TabIndex = 304;
            this.chkEnquadramentoBaseISS.Text = "Manual";
            this.chkEnquadramentoBaseISS.UseVisualStyleBackColor = true;
            this.chkEnquadramentoBaseISS.CheckStateChanged += new System.EventHandler(this.chkEnquadramentoBaseISS_CheckStateChanged);
            // 
            // lblEnquadramento_Base_ISS
            // 
            this.lblEnquadramento_Base_ISS.AutoSize = true;
            this.lblEnquadramento_Base_ISS.Location = new System.Drawing.Point(463, 244);
            this.lblEnquadramento_Base_ISS.Name = "lblEnquadramento_Base_ISS";
            this.lblEnquadramento_Base_ISS.Size = new System.Drawing.Size(133, 13);
            this.lblEnquadramento_Base_ISS.TabIndex = 303;
            this.lblEnquadramento_Base_ISS.Text = "Área Base ISS Engenharia";
            // 
            // chkEnquadramentoConstrucao
            // 
            this.chkEnquadramentoConstrucao.AutoSize = true;
            this.chkEnquadramentoConstrucao.Location = new System.Drawing.Point(178, 263);
            this.chkEnquadramentoConstrucao.Name = "chkEnquadramentoConstrucao";
            this.chkEnquadramentoConstrucao.Size = new System.Drawing.Size(61, 17);
            this.chkEnquadramentoConstrucao.TabIndex = 301;
            this.chkEnquadramentoConstrucao.Text = "Manual";
            this.chkEnquadramentoConstrucao.UseVisualStyleBackColor = true;
            this.chkEnquadramentoConstrucao.CheckStateChanged += new System.EventHandler(this.chkEnquadramentoBaseISS_CheckStateChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(691, 206);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(138, 13);
            this.label14.TabIndex = 300;
            this.label14.Text = "Enquadramento Penalidade";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(463, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 13);
            this.label7.TabIndex = 298;
            this.label7.Text = "Enquadramento Demolição";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(244, 244);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 13);
            this.label6.TabIndex = 296;
            this.label6.Text = "Enquadramento Reforma";
            // 
            // ckbImplantada
            // 
            this.ckbImplantada.AutoSize = true;
            this.ckbImplantada.Location = new System.Drawing.Point(691, 12);
            this.ckbImplantada.Name = "ckbImplantada";
            this.ckbImplantada.Size = new System.Drawing.Size(163, 17);
            this.ckbImplantada.TabIndex = 136;
            this.ckbImplantada.Text = "Área Implantada a Legalizar?";
            this.ckbImplantada.UseVisualStyleBackColor = true;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(22, 244);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(139, 13);
            this.label99.TabIndex = 252;
            this.label99.Text = "Enquadramento Construção";
            // 
            // txtAreaEdicula
            // 
            this.txtAreaEdicula.AllowNegative = false;
            this.txtAreaEdicula.DigitsInGroup = 0;
            this.txtAreaEdicula.Flags = 65536;
            this.txtAreaEdicula.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaEdicula.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaEdicula.Location = new System.Drawing.Point(691, 146);
            this.txtAreaEdicula.MaxDecimalPlaces = 2;
            this.txtAreaEdicula.MaxLength = 14;
            this.txtAreaEdicula.MaxWholeDigits = 12;
            this.txtAreaEdicula.Name = "txtAreaEdicula";
            this.txtAreaEdicula.Prefix = "";
            this.txtAreaEdicula.RangeMax = 2147483647D;
            this.txtAreaEdicula.RangeMin = 0D;
            this.txtAreaEdicula.Size = new System.Drawing.Size(150, 20);
            this.txtAreaEdicula.TabIndex = 124;
            this.txtAreaEdicula.Text = "0";
            this.txtAreaEdicula.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaEdicula.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(687, 129);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(87, 13);
            this.label87.TabIndex = 250;
            this.label87.Text = "Área de Edícula:";
            // 
            // lblIdLancamento
            // 
            this.lblIdLancamento.AutoSize = true;
            this.lblIdLancamento.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdLancamento.Location = new System.Drawing.Point(888, 40);
            this.lblIdLancamento.Name = "lblIdLancamento";
            this.lblIdLancamento.Size = new System.Drawing.Size(0, 16);
            this.lblIdLancamento.TabIndex = 248;
            this.lblIdLancamento.Visible = false;
            // 
            // ckbElevador
            // 
            this.ckbElevador.AutoSize = true;
            this.ckbElevador.Location = new System.Drawing.Point(691, 32);
            this.ckbElevador.Name = "ckbElevador";
            this.ckbElevador.Size = new System.Drawing.Size(108, 17);
            this.ckbElevador.TabIndex = 137;
            this.ckbElevador.Text = "Possui Elevador?";
            this.ckbElevador.UseVisualStyleBackColor = true;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(244, 168);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(144, 13);
            this.label97.TabIndex = 154;
            this.label97.Text = "Área de Terreno a Aumentar:";
            // 
            // txtAreaTerrenoAumentar
            // 
            this.txtAreaTerrenoAumentar.AllowNegative = false;
            this.txtAreaTerrenoAumentar.DigitsInGroup = 0;
            this.txtAreaTerrenoAumentar.Flags = 65536;
            this.txtAreaTerrenoAumentar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaTerrenoAumentar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaTerrenoAumentar.Location = new System.Drawing.Point(247, 184);
            this.txtAreaTerrenoAumentar.MaxDecimalPlaces = 2;
            this.txtAreaTerrenoAumentar.MaxLength = 14;
            this.txtAreaTerrenoAumentar.MaxWholeDigits = 12;
            this.txtAreaTerrenoAumentar.Name = "txtAreaTerrenoAumentar";
            this.txtAreaTerrenoAumentar.Prefix = "";
            this.txtAreaTerrenoAumentar.RangeMax = 2147483647D;
            this.txtAreaTerrenoAumentar.RangeMin = 0D;
            this.txtAreaTerrenoAumentar.Size = new System.Drawing.Size(150, 20);
            this.txtAreaTerrenoAumentar.TabIndex = 126;
            this.txtAreaTerrenoAumentar.Text = "0";
            this.txtAreaTerrenoAumentar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaTerrenoAumentar.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(463, 168);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(188, 13);
            this.label95.TabIndex = 152;
            this.label95.Text = "Testada a Deduzir - Desmembramento";
            // 
            // txtTestadaAumentar
            // 
            this.txtTestadaAumentar.AllowNegative = false;
            this.txtTestadaAumentar.DigitsInGroup = 0;
            this.txtTestadaAumentar.Flags = 65536;
            this.txtTestadaAumentar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTestadaAumentar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTestadaAumentar.Location = new System.Drawing.Point(691, 184);
            this.txtTestadaAumentar.MaxDecimalPlaces = 2;
            this.txtTestadaAumentar.MaxLength = 14;
            this.txtTestadaAumentar.MaxWholeDigits = 12;
            this.txtTestadaAumentar.Name = "txtTestadaAumentar";
            this.txtTestadaAumentar.Prefix = "";
            this.txtTestadaAumentar.RangeMax = 2147483647D;
            this.txtTestadaAumentar.RangeMin = 0D;
            this.txtTestadaAumentar.Size = new System.Drawing.Size(150, 20);
            this.txtTestadaAumentar.TabIndex = 128;
            this.txtTestadaAumentar.Text = "0";
            this.txtTestadaAumentar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTestadaAumentar.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(689, 168);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(106, 13);
            this.label93.TabIndex = 150;
            this.label93.Text = "Testada a Aumentar:";
            // 
            // txtTestadaDeduzir
            // 
            this.txtTestadaDeduzir.AllowNegative = false;
            this.txtTestadaDeduzir.DigitsInGroup = 0;
            this.txtTestadaDeduzir.Flags = 65536;
            this.txtTestadaDeduzir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTestadaDeduzir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTestadaDeduzir.Location = new System.Drawing.Point(467, 184);
            this.txtTestadaDeduzir.MaxDecimalPlaces = 2;
            this.txtTestadaDeduzir.MaxLength = 14;
            this.txtTestadaDeduzir.MaxWholeDigits = 12;
            this.txtTestadaDeduzir.Name = "txtTestadaDeduzir";
            this.txtTestadaDeduzir.Prefix = "";
            this.txtTestadaDeduzir.RangeMax = 2147483647D;
            this.txtTestadaDeduzir.RangeMin = 0D;
            this.txtTestadaDeduzir.Size = new System.Drawing.Size(150, 20);
            this.txtTestadaDeduzir.TabIndex = 127;
            this.txtTestadaDeduzir.Text = "0";
            this.txtTestadaDeduzir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTestadaDeduzir.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(24, 169);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(202, 13);
            this.label91.TabIndex = 148;
            this.label91.Text = "Área de Terreno a Deduzir - Implantação:";
            // 
            // txtAreaTerrenoDeduzir
            // 
            this.txtAreaTerrenoDeduzir.AllowNegative = false;
            this.txtAreaTerrenoDeduzir.DigitsInGroup = 0;
            this.txtAreaTerrenoDeduzir.Flags = 65536;
            this.txtAreaTerrenoDeduzir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaTerrenoDeduzir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaTerrenoDeduzir.Location = new System.Drawing.Point(25, 184);
            this.txtAreaTerrenoDeduzir.MaxDecimalPlaces = 2;
            this.txtAreaTerrenoDeduzir.MaxLength = 14;
            this.txtAreaTerrenoDeduzir.MaxWholeDigits = 12;
            this.txtAreaTerrenoDeduzir.Name = "txtAreaTerrenoDeduzir";
            this.txtAreaTerrenoDeduzir.Prefix = "";
            this.txtAreaTerrenoDeduzir.RangeMax = 2147483647D;
            this.txtAreaTerrenoDeduzir.RangeMin = 0D;
            this.txtAreaTerrenoDeduzir.Size = new System.Drawing.Size(150, 20);
            this.txtAreaTerrenoDeduzir.TabIndex = 125;
            this.txtAreaTerrenoDeduzir.Text = "0";
            this.txtAreaTerrenoDeduzir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaTerrenoDeduzir.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(463, 92);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(225, 13);
            this.label89.TabIndex = 146;
            this.label89.Text = "Números de Unidades Autônomas a Legalizar:";
            // 
            // txtNumeroUnidAutonomas
            // 
            this.txtNumeroUnidAutonomas.AllowNegative = false;
            this.txtNumeroUnidAutonomas.DigitsInGroup = 0;
            this.txtNumeroUnidAutonomas.Flags = 65536;
            this.txtNumeroUnidAutonomas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumeroUnidAutonomas.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNumeroUnidAutonomas.Location = new System.Drawing.Point(466, 108);
            this.txtNumeroUnidAutonomas.MaxDecimalPlaces = 2;
            this.txtNumeroUnidAutonomas.MaxLength = 14;
            this.txtNumeroUnidAutonomas.MaxWholeDigits = 12;
            this.txtNumeroUnidAutonomas.Name = "txtNumeroUnidAutonomas";
            this.txtNumeroUnidAutonomas.Prefix = "";
            this.txtNumeroUnidAutonomas.RangeMax = 2147483647D;
            this.txtNumeroUnidAutonomas.RangeMin = 0D;
            this.txtNumeroUnidAutonomas.Size = new System.Drawing.Size(150, 20);
            this.txtNumeroUnidAutonomas.TabIndex = 119;
            this.txtNumeroUnidAutonomas.Text = "0";
            this.txtNumeroUnidAutonomas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNumeroUnidAutonomas.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(245, 207);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(205, 13);
            this.label66.TabIndex = 142;
            this.label66.Text = "Abrigo Desmontável Existente Legalizado:";
            // 
            // txtDesmontavelLegalizado
            // 
            this.txtDesmontavelLegalizado.AllowNegative = false;
            this.txtDesmontavelLegalizado.DigitsInGroup = 0;
            this.txtDesmontavelLegalizado.Flags = 65536;
            this.txtDesmontavelLegalizado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesmontavelLegalizado.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDesmontavelLegalizado.Location = new System.Drawing.Point(247, 222);
            this.txtDesmontavelLegalizado.MaxDecimalPlaces = 2;
            this.txtDesmontavelLegalizado.MaxLength = 14;
            this.txtDesmontavelLegalizado.MaxWholeDigits = 12;
            this.txtDesmontavelLegalizado.Name = "txtDesmontavelLegalizado";
            this.txtDesmontavelLegalizado.Prefix = "";
            this.txtDesmontavelLegalizado.RangeMax = 2147483647D;
            this.txtDesmontavelLegalizado.RangeMin = 0D;
            this.txtDesmontavelLegalizado.Size = new System.Drawing.Size(150, 20);
            this.txtDesmontavelLegalizado.TabIndex = 130;
            this.txtDesmontavelLegalizado.Text = "0";
            this.txtDesmontavelLegalizado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDesmontavelLegalizado.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(22, 206);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(217, 13);
            this.label65.TabIndex = 140;
            this.label65.Text = "Abrigo Desmontável a Legalizar/Regularizar:";
            // 
            // txtDesmontavelLegalizar
            // 
            this.txtDesmontavelLegalizar.AllowNegative = false;
            this.txtDesmontavelLegalizar.DigitsInGroup = 0;
            this.txtDesmontavelLegalizar.Flags = 65536;
            this.txtDesmontavelLegalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesmontavelLegalizar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDesmontavelLegalizar.Location = new System.Drawing.Point(25, 222);
            this.txtDesmontavelLegalizar.MaxDecimalPlaces = 2;
            this.txtDesmontavelLegalizar.MaxLength = 14;
            this.txtDesmontavelLegalizar.MaxWholeDigits = 12;
            this.txtDesmontavelLegalizar.Name = "txtDesmontavelLegalizar";
            this.txtDesmontavelLegalizar.Prefix = "";
            this.txtDesmontavelLegalizar.RangeMax = 2147483647D;
            this.txtDesmontavelLegalizar.RangeMin = 0D;
            this.txtDesmontavelLegalizar.Size = new System.Drawing.Size(150, 20);
            this.txtDesmontavelLegalizar.TabIndex = 129;
            this.txtDesmontavelLegalizar.Text = "0";
            this.txtDesmontavelLegalizar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDesmontavelLegalizar.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(689, 92);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(115, 13);
            this.label63.TabIndex = 136;
            this.label63.Text = "Números de Unidades:";
            // 
            // txtUnidades
            // 
            this.txtUnidades.AllowNegative = false;
            this.txtUnidades.DigitsInGroup = 0;
            this.txtUnidades.Flags = 65536;
            this.txtUnidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnidades.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtUnidades.Location = new System.Drawing.Point(691, 108);
            this.txtUnidades.MaxDecimalPlaces = 0;
            this.txtUnidades.MaxLength = 14;
            this.txtUnidades.MaxWholeDigits = 12;
            this.txtUnidades.Name = "txtUnidades";
            this.txtUnidades.Prefix = "";
            this.txtUnidades.RangeMax = 2147483647D;
            this.txtUnidades.RangeMin = 1D;
            this.txtUnidades.Size = new System.Drawing.Size(150, 20);
            this.txtUnidades.TabIndex = 120;
            this.txtUnidades.Text = "1";
            this.txtUnidades.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUnidades.Leave += new System.EventHandler(this.txtAREA_TERRENO_TextChanged);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(464, 16);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(124, 13);
            this.label77.TabIndex = 134;
            this.label77.Text = "Área total da Construção";
            // 
            // txtAreaTotal
            // 
            this.txtAreaTotal.AllowNegative = true;
            this.txtAreaTotal.DigitsInGroup = 0;
            this.txtAreaTotal.Enabled = false;
            this.txtAreaTotal.Flags = 0;
            this.txtAreaTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaTotal.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaTotal.Location = new System.Drawing.Point(466, 32);
            this.txtAreaTotal.MaxDecimalPlaces = 2;
            this.txtAreaTotal.MaxLength = 10;
            this.txtAreaTotal.MaxWholeDigits = 8;
            this.txtAreaTotal.Name = "txtAreaTotal";
            this.txtAreaTotal.Prefix = "";
            this.txtAreaTotal.RangeMax = 2147483647D;
            this.txtAreaTotal.RangeMin = -2147483648D;
            this.txtAreaTotal.ReadOnly = true;
            this.txtAreaTotal.Size = new System.Drawing.Size(150, 20);
            this.txtAreaTotal.TabIndex = 132;
            this.txtAreaTotal.Text = "0";
            this.txtAreaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaTotal.TextChanged += new System.EventHandler(this.txtAreaTotal_TextChanged);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(462, 130);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(159, 13);
            this.label82.TabIndex = 133;
            this.label82.Text = "Área decadência de Demolição:";
            // 
            // txtAreaDecadDemolir
            // 
            this.txtAreaDecadDemolir.AllowNegative = false;
            this.txtAreaDecadDemolir.DigitsInGroup = 0;
            this.txtAreaDecadDemolir.Flags = 65536;
            this.txtAreaDecadDemolir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaDecadDemolir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaDecadDemolir.Location = new System.Drawing.Point(465, 146);
            this.txtAreaDecadDemolir.MaxDecimalPlaces = 2;
            this.txtAreaDecadDemolir.MaxLength = 14;
            this.txtAreaDecadDemolir.MaxWholeDigits = 12;
            this.txtAreaDecadDemolir.Name = "txtAreaDecadDemolir";
            this.txtAreaDecadDemolir.Prefix = "";
            this.txtAreaDecadDemolir.RangeMax = 2147483647D;
            this.txtAreaDecadDemolir.RangeMin = 0D;
            this.txtAreaDecadDemolir.Size = new System.Drawing.Size(150, 20);
            this.txtAreaDecadDemolir.TabIndex = 123;
            this.txtAreaDecadDemolir.Text = "0";
            this.txtAreaDecadDemolir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaDecadDemolir.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(22, 129);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(79, 13);
            this.label75.TabIndex = 130;
            this.label75.Text = "Área a Demolir:";
            // 
            // txtAreaDemolir
            // 
            this.txtAreaDemolir.AllowNegative = false;
            this.txtAreaDemolir.DigitsInGroup = 0;
            this.txtAreaDemolir.Flags = 65536;
            this.txtAreaDemolir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaDemolir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaDemolir.Location = new System.Drawing.Point(25, 146);
            this.txtAreaDemolir.MaxDecimalPlaces = 2;
            this.txtAreaDemolir.MaxLength = 10;
            this.txtAreaDemolir.MaxWholeDigits = 8;
            this.txtAreaDemolir.Name = "txtAreaDemolir";
            this.txtAreaDemolir.Prefix = "";
            this.txtAreaDemolir.RangeMax = 2147483647D;
            this.txtAreaDemolir.RangeMin = -2147483648D;
            this.txtAreaDemolir.Size = new System.Drawing.Size(150, 20);
            this.txtAreaDemolir.TabIndex = 121;
            this.txtAreaDemolir.Text = "0";
            this.txtAreaDemolir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaDemolir.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(688, 54);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(201, 13);
            this.label76.TabIndex = 129;
            this.label76.Text = "Área Existente Legalizada de Construção";
            // 
            // txtAreaExistenteLegalConst
            // 
            this.txtAreaExistenteLegalConst.AllowNegative = false;
            this.txtAreaExistenteLegalConst.DigitsInGroup = 0;
            this.txtAreaExistenteLegalConst.Flags = 65536;
            this.txtAreaExistenteLegalConst.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaExistenteLegalConst.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaExistenteLegalConst.Location = new System.Drawing.Point(691, 70);
            this.txtAreaExistenteLegalConst.MaxDecimalPlaces = 2;
            this.txtAreaExistenteLegalConst.MaxLength = 14;
            this.txtAreaExistenteLegalConst.MaxWholeDigits = 12;
            this.txtAreaExistenteLegalConst.Name = "txtAreaExistenteLegalConst";
            this.txtAreaExistenteLegalConst.Prefix = "";
            this.txtAreaExistenteLegalConst.RangeMax = 2147483647D;
            this.txtAreaExistenteLegalConst.RangeMin = 0D;
            this.txtAreaExistenteLegalConst.Size = new System.Drawing.Size(150, 20);
            this.txtAreaExistenteLegalConst.TabIndex = 116;
            this.txtAreaExistenteLegalConst.Text = "0";
            this.txtAreaExistenteLegalConst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaExistenteLegalConst.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(22, 92);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(87, 13);
            this.label73.TabIndex = 126;
            this.label73.Text = "Área a Reformar:";
            this.label73.Click += new System.EventHandler(this.label73_Click);
            // 
            // txtAreaReformar
            // 
            this.txtAreaReformar.AllowNegative = false;
            this.txtAreaReformar.DigitsInGroup = 0;
            this.txtAreaReformar.Flags = 65536;
            this.txtAreaReformar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaReformar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaReformar.Location = new System.Drawing.Point(25, 108);
            this.txtAreaReformar.MaxDecimalPlaces = 2;
            this.txtAreaReformar.MaxLength = 10;
            this.txtAreaReformar.MaxWholeDigits = 8;
            this.txtAreaReformar.Name = "txtAreaReformar";
            this.txtAreaReformar.Prefix = "";
            this.txtAreaReformar.RangeMax = 2147483647D;
            this.txtAreaReformar.RangeMin = 0D;
            this.txtAreaReformar.Size = new System.Drawing.Size(150, 20);
            this.txtAreaReformar.TabIndex = 117;
            this.txtAreaReformar.Text = "0";
            this.txtAreaReformar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaReformar.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(24, 54);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(85, 13);
            this.label74.TabIndex = 125;
            this.label74.Text = "Área a Construir:";
            // 
            // txtAreaConstruir
            // 
            this.txtAreaConstruir.AllowNegative = false;
            this.txtAreaConstruir.DigitsInGroup = 0;
            this.txtAreaConstruir.Flags = 65536;
            this.txtAreaConstruir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaConstruir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaConstruir.Location = new System.Drawing.Point(25, 70);
            this.txtAreaConstruir.MaxDecimalPlaces = 2;
            this.txtAreaConstruir.MaxLength = 14;
            this.txtAreaConstruir.MaxWholeDigits = 12;
            this.txtAreaConstruir.Name = "txtAreaConstruir";
            this.txtAreaConstruir.Prefix = "";
            this.txtAreaConstruir.RangeMax = 2147483647D;
            this.txtAreaConstruir.RangeMin = 0D;
            this.txtAreaConstruir.Size = new System.Drawing.Size(150, 20);
            this.txtAreaConstruir.TabIndex = 113;
            this.txtAreaConstruir.Text = "0";
            this.txtAreaConstruir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaConstruir.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(463, 56);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(163, 13);
            this.label71.TabIndex = 122;
            this.label71.Text = "Área decadência de Construção:";
            // 
            // txtAreaDecadConstr
            // 
            this.txtAreaDecadConstr.AllowNegative = false;
            this.txtAreaDecadConstr.DigitsInGroup = 0;
            this.txtAreaDecadConstr.Flags = 65536;
            this.txtAreaDecadConstr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaDecadConstr.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaDecadConstr.Location = new System.Drawing.Point(466, 70);
            this.txtAreaDecadConstr.MaxDecimalPlaces = 2;
            this.txtAreaDecadConstr.MaxLength = 10;
            this.txtAreaDecadConstr.MaxWholeDigits = 8;
            this.txtAreaDecadConstr.Name = "txtAreaDecadConstr";
            this.txtAreaDecadConstr.Prefix = "";
            this.txtAreaDecadConstr.RangeMax = 2147483647D;
            this.txtAreaDecadConstr.RangeMin = 0D;
            this.txtAreaDecadConstr.Size = new System.Drawing.Size(150, 20);
            this.txtAreaDecadConstr.TabIndex = 115;
            this.txtAreaDecadConstr.Text = "0";
            this.txtAreaDecadConstr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaDecadConstr.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(245, 129);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(212, 13);
            this.label72.TabIndex = 121;
            this.label72.Text = "Área a Legalizar/Regularizar de Demolição:";
            // 
            // txtAreaLegalDemolir
            // 
            this.txtAreaLegalDemolir.AllowNegative = false;
            this.txtAreaLegalDemolir.DigitsInGroup = 0;
            this.txtAreaLegalDemolir.Flags = 65536;
            this.txtAreaLegalDemolir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaLegalDemolir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaLegalDemolir.Location = new System.Drawing.Point(247, 146);
            this.txtAreaLegalDemolir.MaxDecimalPlaces = 2;
            this.txtAreaLegalDemolir.MaxLength = 14;
            this.txtAreaLegalDemolir.MaxWholeDigits = 12;
            this.txtAreaLegalDemolir.Name = "txtAreaLegalDemolir";
            this.txtAreaLegalDemolir.Prefix = "";
            this.txtAreaLegalDemolir.RangeMax = 2147483647D;
            this.txtAreaLegalDemolir.RangeMin = 0D;
            this.txtAreaLegalDemolir.Size = new System.Drawing.Size(150, 20);
            this.txtAreaLegalDemolir.TabIndex = 122;
            this.txtAreaLegalDemolir.Text = "0";
            this.txtAreaLegalDemolir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaLegalDemolir.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(243, 92);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(202, 13);
            this.label69.TabIndex = 118;
            this.label69.Text = "Área a Legalizar/Regularizar de Reforma:";
            // 
            // txtAreaLegalReformar
            // 
            this.txtAreaLegalReformar.AllowNegative = false;
            this.txtAreaLegalReformar.DigitsInGroup = 0;
            this.txtAreaLegalReformar.Flags = 65536;
            this.txtAreaLegalReformar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaLegalReformar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaLegalReformar.Location = new System.Drawing.Point(247, 108);
            this.txtAreaLegalReformar.MaxDecimalPlaces = 2;
            this.txtAreaLegalReformar.MaxLength = 10;
            this.txtAreaLegalReformar.MaxWholeDigits = 8;
            this.txtAreaLegalReformar.Name = "txtAreaLegalReformar";
            this.txtAreaLegalReformar.Prefix = "";
            this.txtAreaLegalReformar.RangeMax = 2147483647D;
            this.txtAreaLegalReformar.RangeMin = 0D;
            this.txtAreaLegalReformar.Size = new System.Drawing.Size(150, 20);
            this.txtAreaLegalReformar.TabIndex = 118;
            this.txtAreaLegalReformar.Text = "0";
            this.txtAreaLegalReformar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaLegalReformar.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(245, 54);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(216, 13);
            this.label70.TabIndex = 117;
            this.label70.Text = "Área a Legalizar/Regularizar de Construção:";
            // 
            // txtAreaLegalConstr
            // 
            this.txtAreaLegalConstr.AllowNegative = false;
            this.txtAreaLegalConstr.DigitsInGroup = 0;
            this.txtAreaLegalConstr.Flags = 65536;
            this.txtAreaLegalConstr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaLegalConstr.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaLegalConstr.Location = new System.Drawing.Point(247, 70);
            this.txtAreaLegalConstr.MaxDecimalPlaces = 2;
            this.txtAreaLegalConstr.MaxLength = 14;
            this.txtAreaLegalConstr.MaxWholeDigits = 12;
            this.txtAreaLegalConstr.Name = "txtAreaLegalConstr";
            this.txtAreaLegalConstr.Prefix = "";
            this.txtAreaLegalConstr.RangeMax = 2147483647D;
            this.txtAreaLegalConstr.RangeMin = 0D;
            this.txtAreaLegalConstr.Size = new System.Drawing.Size(150, 20);
            this.txtAreaLegalConstr.TabIndex = 114;
            this.txtAreaLegalConstr.Text = "0";
            this.txtAreaLegalConstr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAreaLegalConstr.Leave += new System.EventHandler(this.txtCamposDecimal);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(245, 16);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(92, 13);
            this.label67.TabIndex = 114;
            this.label67.Text = "Testada Principal:";
            // 
            // txtTESTADA_PRINCIPAL
            // 
            this.txtTESTADA_PRINCIPAL.AllowNegative = false;
            this.txtTESTADA_PRINCIPAL.DigitsInGroup = 0;
            this.txtTESTADA_PRINCIPAL.Enabled = false;
            this.txtTESTADA_PRINCIPAL.Flags = 65536;
            this.txtTESTADA_PRINCIPAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTESTADA_PRINCIPAL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTESTADA_PRINCIPAL.Location = new System.Drawing.Point(247, 32);
            this.txtTESTADA_PRINCIPAL.MaxDecimalPlaces = 2;
            this.txtTESTADA_PRINCIPAL.MaxLength = 10;
            this.txtTESTADA_PRINCIPAL.MaxWholeDigits = 8;
            this.txtTESTADA_PRINCIPAL.Name = "txtTESTADA_PRINCIPAL";
            this.txtTESTADA_PRINCIPAL.Prefix = "";
            this.txtTESTADA_PRINCIPAL.RangeMax = 2147483647D;
            this.txtTESTADA_PRINCIPAL.RangeMin = 0D;
            this.txtTESTADA_PRINCIPAL.ReadOnly = true;
            this.txtTESTADA_PRINCIPAL.Size = new System.Drawing.Size(150, 20);
            this.txtTESTADA_PRINCIPAL.TabIndex = 112;
            this.txtTESTADA_PRINCIPAL.Text = "0";
            this.txtTESTADA_PRINCIPAL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(23, 16);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(87, 13);
            this.label68.TabIndex = 113;
            this.label68.Text = "Área do Terreno:";
            // 
            // txtAREA_TERRENO
            // 
            this.txtAREA_TERRENO.AllowNegative = false;
            this.txtAREA_TERRENO.DigitsInGroup = 0;
            this.txtAREA_TERRENO.Enabled = false;
            this.txtAREA_TERRENO.Flags = 65536;
            this.txtAREA_TERRENO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAREA_TERRENO.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAREA_TERRENO.Location = new System.Drawing.Point(25, 32);
            this.txtAREA_TERRENO.MaxDecimalPlaces = 2;
            this.txtAREA_TERRENO.MaxLength = 14;
            this.txtAREA_TERRENO.MaxWholeDigits = 12;
            this.txtAREA_TERRENO.Name = "txtAREA_TERRENO";
            this.txtAREA_TERRENO.Prefix = "";
            this.txtAREA_TERRENO.RangeMax = 2147483647D;
            this.txtAREA_TERRENO.RangeMin = 0D;
            this.txtAREA_TERRENO.ReadOnly = true;
            this.txtAREA_TERRENO.Size = new System.Drawing.Size(150, 20);
            this.txtAREA_TERRENO.TabIndex = 111;
            this.txtAREA_TERRENO.Text = "0";
            this.txtAREA_TERRENO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbxDadosLancamento
            // 
            this.gbxDadosLancamento.Controls.Add(this.dgvLancamentoConstrucao);
            this.gbxDadosLancamento.Location = new System.Drawing.Point(7, 600);
            this.gbxDadosLancamento.Name = "gbxDadosLancamento";
            this.gbxDadosLancamento.Size = new System.Drawing.Size(948, 71);
            this.gbxDadosLancamento.TabIndex = 292;
            this.gbxDadosLancamento.TabStop = false;
            // 
            // dgvLancamentoConstrucao
            // 
            this.dgvLancamentoConstrucao.AllowUserToAddRows = false;
            this.dgvLancamentoConstrucao.AutoGenerateColumns = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLancamentoConstrucao.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvLancamentoConstrucao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLancamentoConstrucao.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_NOTIFICACAOC,
            this.TIPO,
            this.AREA_TERRENO,
            this.AREA_TERRENO_TESTADO,
            this.TIPO_IMOVEL,
            this.SUBTIPO_IMOVEL,
            this.ELEVADOR});
            this.dgvLancamentoConstrucao.DataSource = this.mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLancamentoConstrucao.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvLancamentoConstrucao.Location = new System.Drawing.Point(-2, 12);
            this.dgvLancamentoConstrucao.Name = "dgvLancamentoConstrucao";
            this.dgvLancamentoConstrucao.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLancamentoConstrucao.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvLancamentoConstrucao.RowHeadersVisible = false;
            this.dgvLancamentoConstrucao.RowHeadersWidth = 11;
            this.dgvLancamentoConstrucao.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLancamentoConstrucao.Size = new System.Drawing.Size(943, 53);
            this.dgvLancamentoConstrucao.TabIndex = 291;
            this.dgvLancamentoConstrucao.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLancamentoConstrucao_CellDoubleClick);
            // 
            // ID_NOTIFICACAOC
            // 
            this.ID_NOTIFICACAOC.DataPropertyName = "ID_NOTIFICACAO";
            this.ID_NOTIFICACAOC.HeaderText = "ID_NOTIFICACAO";
            this.ID_NOTIFICACAOC.Name = "ID_NOTIFICACAOC";
            this.ID_NOTIFICACAOC.ReadOnly = true;
            this.ID_NOTIFICACAOC.Visible = false;
            // 
            // TIPO
            // 
            this.TIPO.DataPropertyName = "TIPO";
            this.TIPO.FillWeight = 200F;
            this.TIPO.HeaderText = "Tipo";
            this.TIPO.Name = "TIPO";
            this.TIPO.ReadOnly = true;
            this.TIPO.Width = 200;
            // 
            // AREA_TERRENO
            // 
            this.AREA_TERRENO.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.AREA_TERRENO.DataPropertyName = "AREA_TERRENO";
            this.AREA_TERRENO.HeaderText = "Área do terreno";
            this.AREA_TERRENO.Name = "AREA_TERRENO";
            this.AREA_TERRENO.ReadOnly = true;
            this.AREA_TERRENO.Width = 96;
            // 
            // AREA_TERRENO_TESTADO
            // 
            this.AREA_TERRENO_TESTADO.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.AREA_TERRENO_TESTADO.DataPropertyName = "AREA_TERRENO_TESTADO";
            this.AREA_TERRENO_TESTADO.HeaderText = "Área do terreno testado";
            this.AREA_TERRENO_TESTADO.Name = "AREA_TERRENO_TESTADO";
            this.AREA_TERRENO_TESTADO.ReadOnly = true;
            this.AREA_TERRENO_TESTADO.Width = 131;
            // 
            // TIPO_IMOVEL
            // 
            this.TIPO_IMOVEL.DataPropertyName = "TIPO_IMOVEL";
            this.TIPO_IMOVEL.FillWeight = 150F;
            this.TIPO_IMOVEL.HeaderText = "Tipo Imóvel";
            this.TIPO_IMOVEL.Name = "TIPO_IMOVEL";
            this.TIPO_IMOVEL.ReadOnly = true;
            this.TIPO_IMOVEL.Width = 150;
            // 
            // SUBTIPO_IMOVEL
            // 
            this.SUBTIPO_IMOVEL.DataPropertyName = "SUBTIPO_IMOVEL";
            this.SUBTIPO_IMOVEL.FillWeight = 200F;
            this.SUBTIPO_IMOVEL.HeaderText = "Subtipo Imóvel";
            this.SUBTIPO_IMOVEL.Name = "SUBTIPO_IMOVEL";
            this.SUBTIPO_IMOVEL.ReadOnly = true;
            this.SUBTIPO_IMOVEL.Width = 200;
            // 
            // ELEVADOR
            // 
            this.ELEVADOR.DataPropertyName = "ELEVADOR";
            this.ELEVADOR.HeaderText = "Elevador";
            this.ELEVADOR.Name = "ELEVADOR";
            this.ELEVADOR.ReadOnly = true;
            // 
            // mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource
            // 
            this.mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_LANCAMENTO";
            this.mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // tbgInscricao
            // 
            this.tbgInscricao.Controls.Add(this.grpUnificacao);
            this.tbgInscricao.Location = new System.Drawing.Point(4, 22);
            this.tbgInscricao.Name = "tbgInscricao";
            this.tbgInscricao.Padding = new System.Windows.Forms.Padding(3);
            this.tbgInscricao.Size = new System.Drawing.Size(530, 206);
            this.tbgInscricao.TabIndex = 2;
            this.tbgInscricao.Text = "Unificação de Inscrição Imobíliaria";
            this.tbgInscricao.UseVisualStyleBackColor = true;
            // 
            // grpUnificacao
            // 
            this.grpUnificacao.Controls.Add(this.panel4);
            this.grpUnificacao.Controls.Add(this.lblIdUnificacao);
            this.grpUnificacao.Controls.Add(this.dgvUnificacao);
            this.grpUnificacao.Location = new System.Drawing.Point(6, 6);
            this.grpUnificacao.Name = "grpUnificacao";
            this.grpUnificacao.Size = new System.Drawing.Size(953, 538);
            this.grpUnificacao.TabIndex = 251;
            this.grpUnificacao.TabStop = false;
            this.grpUnificacao.Text = "Inscrição";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbxLOTEAMENTOUNI);
            this.panel4.Controls.Add(this.cbxCONDOMINIOUNI);
            this.panel4.Controls.Add(this.TXTCIDADEUNI);
            this.panel4.Controls.Add(this.TXTUFUNI);
            this.panel4.Controls.Add(label64);
            this.panel4.Controls.Add(this.TXTLOTEUNI);
            this.panel4.Controls.Add(label90);
            this.panel4.Controls.Add(this.btnBuscarUnificacao);
            this.panel4.Controls.Add(this.btnAdicionarUnificacao);
            this.panel4.Controls.Add(label88);
            this.panel4.Controls.Add(this.txtInscricaoUnificacao);
            this.panel4.Controls.Add(this.TXTQUADRAUNI);
            this.panel4.Controls.Add(this.label132);
            this.panel4.Controls.Add(label100);
            this.panel4.Controls.Add(this.txtTestadaUnificacao);
            this.panel4.Controls.Add(label104);
            this.panel4.Controls.Add(this.label134);
            this.panel4.Controls.Add(this.TXTLOGRADOUROUNI);
            this.panel4.Controls.Add(this.txtAreaTerrenoUnificacao);
            this.panel4.Controls.Add(label108);
            this.panel4.Controls.Add(label110);
            this.panel4.Controls.Add(this.TXTBAIRROUNI);
            this.panel4.Controls.Add(label112);
            this.panel4.Controls.Add(this.TXTCEPUNI);
            this.panel4.Controls.Add(label113);
            this.panel4.Controls.Add(label114);
            this.panel4.Controls.Add(this.TXTCOMPLEMENTOUNI);
            this.panel4.Controls.Add(label116);
            this.panel4.Controls.Add(this.TXTNUMEROUNI);
            this.panel4.Controls.Add(label118);
            this.panel4.Location = new System.Drawing.Point(8, 16);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(939, 164);
            this.panel4.TabIndex = 293;
            // 
            // cbxLOTEAMENTOUNI
            // 
            this.cbxLOTEAMENTOUNI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxLOTEAMENTOUNI.Enabled = false;
            this.cbxLOTEAMENTOUNI.FormattingEnabled = true;
            this.cbxLOTEAMENTOUNI.Location = new System.Drawing.Point(120, 112);
            this.cbxLOTEAMENTOUNI.Name = "cbxLOTEAMENTOUNI";
            this.cbxLOTEAMENTOUNI.Size = new System.Drawing.Size(269, 21);
            this.cbxLOTEAMENTOUNI.TabIndex = 264;
            // 
            // cbxCONDOMINIOUNI
            // 
            this.cbxCONDOMINIOUNI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCONDOMINIOUNI.Enabled = false;
            this.cbxCONDOMINIOUNI.FormattingEnabled = true;
            this.cbxCONDOMINIOUNI.Location = new System.Drawing.Point(120, 137);
            this.cbxCONDOMINIOUNI.Name = "cbxCONDOMINIOUNI";
            this.cbxCONDOMINIOUNI.Size = new System.Drawing.Size(269, 21);
            this.cbxCONDOMINIOUNI.TabIndex = 263;
            // 
            // TXTCIDADEUNI
            // 
            this.TXTCIDADEUNI.Location = new System.Drawing.Point(445, 86);
            this.TXTCIDADEUNI.MaxLength = 75;
            this.TXTCIDADEUNI.Name = "TXTCIDADEUNI";
            this.TXTCIDADEUNI.ReadOnly = true;
            this.TXTCIDADEUNI.Size = new System.Drawing.Size(303, 20);
            this.TXTCIDADEUNI.TabIndex = 262;
            // 
            // TXTUFUNI
            // 
            this.TXTUFUNI.Flags = 0;
            this.TXTUFUNI.Location = new System.Drawing.Point(120, 86);
            this.TXTUFUNI.Mask = "";
            this.TXTUFUNI.Name = "TXTUFUNI";
            this.TXTUFUNI.ReadOnly = true;
            this.TXTUFUNI.Size = new System.Drawing.Size(88, 20);
            this.TXTUFUNI.TabIndex = 259;
            // 
            // TXTLOTEUNI
            // 
            this.TXTLOTEUNI.Location = new System.Drawing.Point(444, 139);
            this.TXTLOTEUNI.Name = "TXTLOTEUNI";
            this.TXTLOTEUNI.ReadOnly = true;
            this.TXTLOTEUNI.Size = new System.Drawing.Size(111, 20);
            this.TXTLOTEUNI.TabIndex = 256;
            // 
            // btnBuscarUnificacao
            // 
            this.btnBuscarUnificacao.Location = new System.Drawing.Point(268, 9);
            this.btnBuscarUnificacao.Name = "btnBuscarUnificacao";
            this.btnBuscarUnificacao.Size = new System.Drawing.Size(63, 23);
            this.btnBuscarUnificacao.TabIndex = 2;
            this.btnBuscarUnificacao.Text = "Buscar";
            this.btnBuscarUnificacao.UseVisualStyleBackColor = true;
            this.btnBuscarUnificacao.Click += new System.EventHandler(this.btnBuscarUnificacao_Click);
            // 
            // btnAdicionarUnificacao
            // 
            this.btnAdicionarUnificacao.Location = new System.Drawing.Point(754, 135);
            this.btnAdicionarUnificacao.Name = "btnAdicionarUnificacao";
            this.btnAdicionarUnificacao.Size = new System.Drawing.Size(63, 23);
            this.btnAdicionarUnificacao.TabIndex = 3;
            this.btnAdicionarUnificacao.Text = "Adicionar";
            this.btnAdicionarUnificacao.UseVisualStyleBackColor = true;
            this.btnAdicionarUnificacao.Click += new System.EventHandler(this.btnAdicionarUnificacao_Click);
            // 
            // txtInscricaoUnificacao
            // 
            this.txtInscricaoUnificacao.AllowNegative = true;
            this.txtInscricaoUnificacao.DigitsInGroup = 0;
            this.txtInscricaoUnificacao.Flags = 0;
            this.txtInscricaoUnificacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInscricaoUnificacao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtInscricaoUnificacao.Location = new System.Drawing.Point(120, 10);
            this.txtInscricaoUnificacao.MaxDecimalPlaces = 0;
            this.txtInscricaoUnificacao.MaxLength = 18;
            this.txtInscricaoUnificacao.MaxWholeDigits = 18;
            this.txtInscricaoUnificacao.Name = "txtInscricaoUnificacao";
            this.txtInscricaoUnificacao.Prefix = "";
            this.txtInscricaoUnificacao.RangeMax = 2147483647D;
            this.txtInscricaoUnificacao.RangeMin = -2147483648D;
            this.txtInscricaoUnificacao.Size = new System.Drawing.Size(142, 20);
            this.txtInscricaoUnificacao.TabIndex = 1;
            this.txtInscricaoUnificacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TXTQUADRAUNI
            // 
            this.TXTQUADRAUNI.Location = new System.Drawing.Point(445, 112);
            this.TXTQUADRAUNI.Name = "TXTQUADRAUNI";
            this.TXTQUADRAUNI.ReadOnly = true;
            this.TXTQUADRAUNI.Size = new System.Drawing.Size(110, 20);
            this.TXTQUADRAUNI.TabIndex = 255;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(556, 142);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(92, 13);
            this.label132.TabIndex = 114;
            this.label132.Text = "Testada Principal:";
            // 
            // txtTestadaUnificacao
            // 
            this.txtTestadaUnificacao.AllowNegative = false;
            this.txtTestadaUnificacao.DigitsInGroup = 0;
            this.txtTestadaUnificacao.Flags = 65536;
            this.txtTestadaUnificacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTestadaUnificacao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtTestadaUnificacao.Location = new System.Drawing.Point(654, 138);
            this.txtTestadaUnificacao.MaxDecimalPlaces = 2;
            this.txtTestadaUnificacao.MaxLength = 10;
            this.txtTestadaUnificacao.MaxWholeDigits = 8;
            this.txtTestadaUnificacao.Name = "txtTestadaUnificacao";
            this.txtTestadaUnificacao.Prefix = "";
            this.txtTestadaUnificacao.RangeMax = 2147483647D;
            this.txtTestadaUnificacao.RangeMin = 0D;
            this.txtTestadaUnificacao.ReadOnly = true;
            this.txtTestadaUnificacao.Size = new System.Drawing.Size(94, 20);
            this.txtTestadaUnificacao.TabIndex = 112;
            this.txtTestadaUnificacao.TabStop = false;
            this.txtTestadaUnificacao.Text = "0";
            this.txtTestadaUnificacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(561, 115);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(87, 13);
            this.label134.TabIndex = 113;
            this.label134.Text = "Área do Terreno:";
            // 
            // TXTLOGRADOUROUNI
            // 
            this.TXTLOGRADOUROUNI.Location = new System.Drawing.Point(120, 36);
            this.TXTLOGRADOUROUNI.Name = "TXTLOGRADOUROUNI";
            this.TXTLOGRADOUROUNI.ReadOnly = true;
            this.TXTLOGRADOUROUNI.Size = new System.Drawing.Size(393, 20);
            this.TXTLOGRADOUROUNI.TabIndex = 218;
            // 
            // txtAreaTerrenoUnificacao
            // 
            this.txtAreaTerrenoUnificacao.AllowNegative = false;
            this.txtAreaTerrenoUnificacao.DigitsInGroup = 0;
            this.txtAreaTerrenoUnificacao.Flags = 65536;
            this.txtAreaTerrenoUnificacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAreaTerrenoUnificacao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtAreaTerrenoUnificacao.Location = new System.Drawing.Point(654, 112);
            this.txtAreaTerrenoUnificacao.MaxDecimalPlaces = 2;
            this.txtAreaTerrenoUnificacao.MaxLength = 14;
            this.txtAreaTerrenoUnificacao.MaxWholeDigits = 12;
            this.txtAreaTerrenoUnificacao.Name = "txtAreaTerrenoUnificacao";
            this.txtAreaTerrenoUnificacao.Prefix = "";
            this.txtAreaTerrenoUnificacao.RangeMax = 2147483647D;
            this.txtAreaTerrenoUnificacao.RangeMin = 0D;
            this.txtAreaTerrenoUnificacao.ReadOnly = true;
            this.txtAreaTerrenoUnificacao.Size = new System.Drawing.Size(94, 20);
            this.txtAreaTerrenoUnificacao.TabIndex = 2;
            this.txtAreaTerrenoUnificacao.TabStop = false;
            this.txtAreaTerrenoUnificacao.Text = "0";
            this.txtAreaTerrenoUnificacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TXTBAIRROUNI
            // 
            this.TXTBAIRROUNI.Location = new System.Drawing.Point(445, 61);
            this.TXTBAIRROUNI.MaxLength = 75;
            this.TXTBAIRROUNI.Name = "TXTBAIRROUNI";
            this.TXTBAIRROUNI.ReadOnly = true;
            this.TXTBAIRROUNI.Size = new System.Drawing.Size(303, 20);
            this.TXTBAIRROUNI.TabIndex = 221;
            // 
            // TXTCEPUNI
            // 
            this.TXTCEPUNI.Flags = 0;
            this.TXTCEPUNI.Location = new System.Drawing.Point(660, 35);
            this.TXTCEPUNI.Mask = "#####-###";
            this.TXTCEPUNI.Name = "TXTCEPUNI";
            this.TXTCEPUNI.ReadOnly = true;
            this.TXTCEPUNI.Size = new System.Drawing.Size(88, 20);
            this.TXTCEPUNI.TabIndex = 217;
            // 
            // TXTCOMPLEMENTOUNI
            // 
            this.TXTCOMPLEMENTOUNI.Location = new System.Drawing.Point(120, 61);
            this.TXTCOMPLEMENTOUNI.MaxLength = 30;
            this.TXTCOMPLEMENTOUNI.Name = "TXTCOMPLEMENTOUNI";
            this.TXTCOMPLEMENTOUNI.ReadOnly = true;
            this.TXTCOMPLEMENTOUNI.Size = new System.Drawing.Size(269, 20);
            this.TXTCOMPLEMENTOUNI.TabIndex = 220;
            // 
            // TXTNUMEROUNI
            // 
            this.TXTNUMEROUNI.AllowNegative = true;
            this.TXTNUMEROUNI.DigitsInGroup = 0;
            this.TXTNUMEROUNI.Flags = 0;
            this.TXTNUMEROUNI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTNUMEROUNI.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TXTNUMEROUNI.Location = new System.Drawing.Point(572, 35);
            this.TXTNUMEROUNI.MaxDecimalPlaces = 0;
            this.TXTNUMEROUNI.MaxLength = 5;
            this.TXTNUMEROUNI.MaxWholeDigits = 5;
            this.TXTNUMEROUNI.Name = "TXTNUMEROUNI";
            this.TXTNUMEROUNI.Prefix = "";
            this.TXTNUMEROUNI.RangeMax = 2147483647D;
            this.TXTNUMEROUNI.RangeMin = -2147483648D;
            this.TXTNUMEROUNI.ReadOnly = true;
            this.TXTNUMEROUNI.Size = new System.Drawing.Size(53, 20);
            this.TXTNUMEROUNI.TabIndex = 219;
            this.TXTNUMEROUNI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblIdUnificacao
            // 
            this.lblIdUnificacao.AutoSize = true;
            this.lblIdUnificacao.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdUnificacao.Location = new System.Drawing.Point(352, 53);
            this.lblIdUnificacao.Name = "lblIdUnificacao";
            this.lblIdUnificacao.Size = new System.Drawing.Size(0, 16);
            this.lblIdUnificacao.TabIndex = 292;
            this.lblIdUnificacao.Visible = false;
            // 
            // dgvUnificacao
            // 
            this.dgvUnificacao.AllowUserToAddRows = false;
            this.dgvUnificacao.AutoGenerateColumns = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUnificacao.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvUnificacao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUnificacao.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.AREA_TERRENO_UNIFICACAO,
            this.AREA_TERRENO_TESTADO_UNIFICACAO,
            this.cEPDataGridViewTextBoxColumn,
            this.lOGRADOURODataGridViewTextBoxColumn,
            this.nUMERODataGridViewTextBoxColumn,
            this.cOMPLEMENTODataGridViewTextBoxColumn,
            this.bAIRRODataGridViewTextBoxColumn,
            this.cIDADEDataGridViewTextBoxColumn,
            this.uFDataGridViewTextBoxColumn,
            this.qUADRADataGridViewTextBoxColumn,
            this.lOTEDataGridViewTextBoxColumn,
            this.cONDOMINIODataGridViewTextBoxColumn,
            this.lOTEAMENTODataGridViewTextBoxColumn,
            this.ExcluirUnificacao});
            this.dgvUnificacao.DataSource = this.mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUnificacao.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvUnificacao.Location = new System.Drawing.Point(8, 189);
            this.dgvUnificacao.Name = "dgvUnificacao";
            this.dgvUnificacao.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUnificacao.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvUnificacao.RowHeadersVisible = false;
            this.dgvUnificacao.RowHeadersWidth = 11;
            this.dgvUnificacao.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUnificacao.Size = new System.Drawing.Size(941, 296);
            this.dgvUnificacao.TabIndex = 291;
            this.dgvUnificacao.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUnificacao_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "INSCRICAO";
            this.dataGridViewTextBoxColumn1.FillWeight = 150F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Inscrição";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // AREA_TERRENO_UNIFICACAO
            // 
            this.AREA_TERRENO_UNIFICACAO.DataPropertyName = "AREA_TERRENO";
            this.AREA_TERRENO_UNIFICACAO.HeaderText = "Área Terreno";
            this.AREA_TERRENO_UNIFICACAO.Name = "AREA_TERRENO_UNIFICACAO";
            this.AREA_TERRENO_UNIFICACAO.ReadOnly = true;
            // 
            // AREA_TERRENO_TESTADO_UNIFICACAO
            // 
            this.AREA_TERRENO_TESTADO_UNIFICACAO.DataPropertyName = "AREA_TERRENO_TESTADO";
            this.AREA_TERRENO_TESTADO_UNIFICACAO.FillWeight = 150F;
            this.AREA_TERRENO_TESTADO_UNIFICACAO.HeaderText = "Área Terreno Testado";
            this.AREA_TERRENO_TESTADO_UNIFICACAO.Name = "AREA_TERRENO_TESTADO_UNIFICACAO";
            this.AREA_TERRENO_TESTADO_UNIFICACAO.ReadOnly = true;
            this.AREA_TERRENO_TESTADO_UNIFICACAO.Width = 150;
            // 
            // cEPDataGridViewTextBoxColumn
            // 
            this.cEPDataGridViewTextBoxColumn.DataPropertyName = "CEP";
            this.cEPDataGridViewTextBoxColumn.HeaderText = "CEP";
            this.cEPDataGridViewTextBoxColumn.Name = "cEPDataGridViewTextBoxColumn";
            this.cEPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lOGRADOURODataGridViewTextBoxColumn
            // 
            this.lOGRADOURODataGridViewTextBoxColumn.DataPropertyName = "LOGRADOURO";
            this.lOGRADOURODataGridViewTextBoxColumn.HeaderText = "Logradouro";
            this.lOGRADOURODataGridViewTextBoxColumn.Name = "lOGRADOURODataGridViewTextBoxColumn";
            this.lOGRADOURODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nUMERODataGridViewTextBoxColumn
            // 
            this.nUMERODataGridViewTextBoxColumn.DataPropertyName = "NUMERO";
            this.nUMERODataGridViewTextBoxColumn.HeaderText = "Numero";
            this.nUMERODataGridViewTextBoxColumn.Name = "nUMERODataGridViewTextBoxColumn";
            this.nUMERODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cOMPLEMENTODataGridViewTextBoxColumn
            // 
            this.cOMPLEMENTODataGridViewTextBoxColumn.DataPropertyName = "COMPLEMENTO";
            this.cOMPLEMENTODataGridViewTextBoxColumn.HeaderText = "Complemento";
            this.cOMPLEMENTODataGridViewTextBoxColumn.Name = "cOMPLEMENTODataGridViewTextBoxColumn";
            this.cOMPLEMENTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bAIRRODataGridViewTextBoxColumn
            // 
            this.bAIRRODataGridViewTextBoxColumn.DataPropertyName = "BAIRRO";
            this.bAIRRODataGridViewTextBoxColumn.HeaderText = "Bairro";
            this.bAIRRODataGridViewTextBoxColumn.Name = "bAIRRODataGridViewTextBoxColumn";
            this.bAIRRODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cIDADEDataGridViewTextBoxColumn
            // 
            this.cIDADEDataGridViewTextBoxColumn.DataPropertyName = "CIDADE";
            this.cIDADEDataGridViewTextBoxColumn.HeaderText = "Cidade";
            this.cIDADEDataGridViewTextBoxColumn.Name = "cIDADEDataGridViewTextBoxColumn";
            this.cIDADEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // uFDataGridViewTextBoxColumn
            // 
            this.uFDataGridViewTextBoxColumn.DataPropertyName = "UF";
            this.uFDataGridViewTextBoxColumn.HeaderText = "UF";
            this.uFDataGridViewTextBoxColumn.Name = "uFDataGridViewTextBoxColumn";
            this.uFDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qUADRADataGridViewTextBoxColumn
            // 
            this.qUADRADataGridViewTextBoxColumn.DataPropertyName = "QUADRA";
            this.qUADRADataGridViewTextBoxColumn.HeaderText = "Quadra";
            this.qUADRADataGridViewTextBoxColumn.Name = "qUADRADataGridViewTextBoxColumn";
            this.qUADRADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lOTEDataGridViewTextBoxColumn
            // 
            this.lOTEDataGridViewTextBoxColumn.DataPropertyName = "LOTE";
            this.lOTEDataGridViewTextBoxColumn.HeaderText = "Lote";
            this.lOTEDataGridViewTextBoxColumn.Name = "lOTEDataGridViewTextBoxColumn";
            this.lOTEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cONDOMINIODataGridViewTextBoxColumn
            // 
            this.cONDOMINIODataGridViewTextBoxColumn.DataPropertyName = "CONDOMINIO";
            this.cONDOMINIODataGridViewTextBoxColumn.HeaderText = "Condomínio";
            this.cONDOMINIODataGridViewTextBoxColumn.Name = "cONDOMINIODataGridViewTextBoxColumn";
            this.cONDOMINIODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lOTEAMENTODataGridViewTextBoxColumn
            // 
            this.lOTEAMENTODataGridViewTextBoxColumn.DataPropertyName = "LOTEAMENTO";
            this.lOTEAMENTODataGridViewTextBoxColumn.HeaderText = "Loteamento";
            this.lOTEAMENTODataGridViewTextBoxColumn.Name = "lOTEAMENTODataGridViewTextBoxColumn";
            this.lOTEAMENTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ExcluirUnificacao
            // 
            this.ExcluirUnificacao.FillWeight = 50F;
            this.ExcluirUnificacao.HeaderText = "Exc";
            this.ExcluirUnificacao.Name = "ExcluirUnificacao";
            this.ExcluirUnificacao.ReadOnly = true;
            this.ExcluirUnificacao.Text = "Excluir";
            this.ExcluirUnificacao.UseColumnTextForButtonValue = true;
            this.ExcluirUnificacao.Width = 50;
            // 
            // mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource
            // 
            this.mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_UNIFICACAO";
            this.mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // tbgIptu
            // 
            this.tbgIptu.Location = new System.Drawing.Point(4, 22);
            this.tbgIptu.Name = "tbgIptu";
            this.tbgIptu.Padding = new System.Windows.Forms.Padding(3);
            this.tbgIptu.Size = new System.Drawing.Size(530, 206);
            this.tbgIptu.TabIndex = 3;
            this.tbgIptu.Text = "IPTU";
            this.tbgIptu.UseVisualStyleBackColor = true;
            // 
            // tbpParcelas
            // 
            this.tbpParcelas.Controls.Add(this.label147);
            this.tbpParcelas.Controls.Add(this.label146);
            this.tbpParcelas.Controls.Add(this.dgvParcelaDetalhe);
            this.tbpParcelas.Controls.Add(this.dgvParcela);
            this.tbpParcelas.Location = new System.Drawing.Point(4, 22);
            this.tbpParcelas.Name = "tbpParcelas";
            this.tbpParcelas.Padding = new System.Windows.Forms.Padding(3);
            this.tbpParcelas.Size = new System.Drawing.Size(544, 238);
            this.tbpParcelas.TabIndex = 6;
            this.tbpParcelas.Text = "Parcelas";
            this.tbpParcelas.UseVisualStyleBackColor = true;
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Enabled = false;
            this.label147.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label147.Location = new System.Drawing.Point(5, 304);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(140, 16);
            this.label147.TabIndex = 248;
            this.label147.Text = "Detalhes da Parcela:";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Enabled = false;
            this.label146.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label146.Location = new System.Drawing.Point(5, 4);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(67, 16);
            this.label146.TabIndex = 247;
            this.label146.Text = "Parcelas:";
            // 
            // dgvParcelaDetalhe
            // 
            this.dgvParcelaDetalhe.AllowUserToAddRows = false;
            this.dgvParcelaDetalhe.AllowUserToDeleteRows = false;
            this.dgvParcelaDetalhe.AllowUserToResizeRows = false;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelaDetalhe.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvParcelaDetalhe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParcelaDetalhe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tRIBUTODataGridViewTextBoxColumn,
            this.Data,
            this.vALORDataGridViewTextBoxColumn,
            this.vALORJUROSDataGridViewTextBoxColumn1,
            this.vALORMULTADataGridViewTextBoxColumn1,
            this.vALORCORRECAODataGridViewTextBoxColumn,
            this.JUROS_COMP,
            this.vALORTOTALDataGridViewTextBoxColumn});
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvParcelaDetalhe.DefaultCellStyle = dataGridViewCellStyle27;
            this.dgvParcelaDetalhe.Location = new System.Drawing.Point(4, 323);
            this.dgvParcelaDetalhe.MultiSelect = false;
            this.dgvParcelaDetalhe.Name = "dgvParcelaDetalhe";
            this.dgvParcelaDetalhe.ReadOnly = true;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelaDetalhe.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvParcelaDetalhe.RowHeadersWidth = 11;
            this.dgvParcelaDetalhe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParcelaDetalhe.Size = new System.Drawing.Size(961, 263);
            this.dgvParcelaDetalhe.TabIndex = 2;
            this.dgvParcelaDetalhe.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvParcelaDetalhe_CellContentClick);
            // 
            // tRIBUTODataGridViewTextBoxColumn
            // 
            this.tRIBUTODataGridViewTextBoxColumn.DataPropertyName = "TRIBUTODESC";
            this.tRIBUTODataGridViewTextBoxColumn.HeaderText = "Tributo";
            this.tRIBUTODataGridViewTextBoxColumn.Name = "tRIBUTODataGridViewTextBoxColumn";
            this.tRIBUTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Data
            // 
            this.Data.DataPropertyName = "DATA_DEBITO";
            this.Data.HeaderText = "Data";
            this.Data.Name = "Data";
            this.Data.ReadOnly = true;
            // 
            // vALORDataGridViewTextBoxColumn
            // 
            this.vALORDataGridViewTextBoxColumn.DataPropertyName = "VALOR";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle21;
            this.vALORDataGridViewTextBoxColumn.HeaderText = "Valor";
            this.vALORDataGridViewTextBoxColumn.Name = "vALORDataGridViewTextBoxColumn";
            this.vALORDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vALORJUROSDataGridViewTextBoxColumn1
            // 
            this.vALORJUROSDataGridViewTextBoxColumn1.DataPropertyName = "VALOR_JUROS";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORJUROSDataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle22;
            this.vALORJUROSDataGridViewTextBoxColumn1.HeaderText = "Juros";
            this.vALORJUROSDataGridViewTextBoxColumn1.Name = "vALORJUROSDataGridViewTextBoxColumn1";
            this.vALORJUROSDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // vALORMULTADataGridViewTextBoxColumn1
            // 
            this.vALORMULTADataGridViewTextBoxColumn1.DataPropertyName = "VALOR_MULTA";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORMULTADataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle23;
            this.vALORMULTADataGridViewTextBoxColumn1.HeaderText = "Multa";
            this.vALORMULTADataGridViewTextBoxColumn1.Name = "vALORMULTADataGridViewTextBoxColumn1";
            this.vALORMULTADataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // vALORCORRECAODataGridViewTextBoxColumn
            // 
            this.vALORCORRECAODataGridViewTextBoxColumn.DataPropertyName = "VALOR_CORRECAO";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORCORRECAODataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle24;
            this.vALORCORRECAODataGridViewTextBoxColumn.HeaderText = "Correção";
            this.vALORCORRECAODataGridViewTextBoxColumn.Name = "vALORCORRECAODataGridViewTextBoxColumn";
            this.vALORCORRECAODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // JUROS_COMP
            // 
            this.JUROS_COMP.DataPropertyName = "JUROS_COMPENSATORIO";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.JUROS_COMP.DefaultCellStyle = dataGridViewCellStyle25;
            this.JUROS_COMP.HeaderText = "Juros Comp.";
            this.JUROS_COMP.Name = "JUROS_COMP";
            this.JUROS_COMP.ReadOnly = true;
            // 
            // vALORTOTALDataGridViewTextBoxColumn
            // 
            this.vALORTOTALDataGridViewTextBoxColumn.DataPropertyName = "VALOR_TOTAL";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORTOTALDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle26;
            this.vALORTOTALDataGridViewTextBoxColumn.HeaderText = "Total";
            this.vALORTOTALDataGridViewTextBoxColumn.Name = "vALORTOTALDataGridViewTextBoxColumn";
            this.vALORTOTALDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dgvParcela
            // 
            this.dgvParcela.AllowUserToAddRows = false;
            this.dgvParcela.AllowUserToDeleteRows = false;
            this.dgvParcela.AllowUserToResizeRows = false;
            this.dgvParcela.AutoGenerateColumns = false;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcela.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvParcela.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParcela.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idParcela,
            this.PARCELA,
            this.AVISO,
            this.DATA_VENCIMENTO,
            this.VALOR_PARCELA,
            this.vALORMULTADataGridViewTextBoxColumn,
            this.vALORJUROSDataGridViewTextBoxColumn,
            this.correcao,
            this.JUROS_COMPENSATORIO,
            this.VALORTOTAL,
            this.VALOR_PAGO,
            this.DATA_PAGAMENTO,
            this.DATA_BAIXA,
            this.BAIXA_OBSERVACAO,
            this.BAIXAR});
            this.dgvParcela.DataSource = this.mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvParcela.DefaultCellStyle = dataGridViewCellStyle40;
            this.dgvParcela.Location = new System.Drawing.Point(2, 27);
            this.dgvParcela.MultiSelect = false;
            this.dgvParcela.Name = "dgvParcela";
            this.dgvParcela.ReadOnly = true;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcela.RowHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.dgvParcela.RowHeadersWidth = 11;
            this.dgvParcela.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParcela.Size = new System.Drawing.Size(963, 267);
            this.dgvParcela.TabIndex = 1;
            this.dgvParcela.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvParcela_CellClick);
            this.dgvParcela.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgvParcela_CurrentCellDirtyStateChanged);
            // 
            // idParcela
            // 
            this.idParcela.DataPropertyName = "ID_NOTIFICACAO_PARCELAMENTO_PARCELA";
            this.idParcela.HeaderText = "";
            this.idParcela.Name = "idParcela";
            this.idParcela.ReadOnly = true;
            this.idParcela.Visible = false;
            // 
            // PARCELA
            // 
            this.PARCELA.DataPropertyName = "PARCELA";
            this.PARCELA.FillWeight = 50F;
            this.PARCELA.HeaderText = "Parcela";
            this.PARCELA.Name = "PARCELA";
            this.PARCELA.ReadOnly = true;
            this.PARCELA.Width = 50;
            // 
            // AVISO
            // 
            this.AVISO.DataPropertyName = "AVISO";
            this.AVISO.HeaderText = "Aviso";
            this.AVISO.Name = "AVISO";
            this.AVISO.ReadOnly = true;
            // 
            // DATA_VENCIMENTO
            // 
            this.DATA_VENCIMENTO.DataPropertyName = "DATA_VENCIMENTO";
            this.DATA_VENCIMENTO.HeaderText = "Vencimento";
            this.DATA_VENCIMENTO.Name = "DATA_VENCIMENTO";
            this.DATA_VENCIMENTO.ReadOnly = true;
            // 
            // VALOR_PARCELA
            // 
            this.VALOR_PARCELA.DataPropertyName = "VALOR_PARCELA";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALOR_PARCELA.DefaultCellStyle = dataGridViewCellStyle30;
            this.VALOR_PARCELA.HeaderText = "Valor";
            this.VALOR_PARCELA.Name = "VALOR_PARCELA";
            this.VALOR_PARCELA.ReadOnly = true;
            // 
            // vALORMULTADataGridViewTextBoxColumn
            // 
            this.vALORMULTADataGridViewTextBoxColumn.DataPropertyName = "VALOR_MULTA";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORMULTADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle31;
            this.vALORMULTADataGridViewTextBoxColumn.HeaderText = "Multa";
            this.vALORMULTADataGridViewTextBoxColumn.Name = "vALORMULTADataGridViewTextBoxColumn";
            this.vALORMULTADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vALORJUROSDataGridViewTextBoxColumn
            // 
            this.vALORJUROSDataGridViewTextBoxColumn.DataPropertyName = "VALOR_JUROS";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.vALORJUROSDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle32;
            this.vALORJUROSDataGridViewTextBoxColumn.HeaderText = "Juros";
            this.vALORJUROSDataGridViewTextBoxColumn.Name = "vALORJUROSDataGridViewTextBoxColumn";
            this.vALORJUROSDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // correcao
            // 
            this.correcao.DataPropertyName = "CORRECAO";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.correcao.DefaultCellStyle = dataGridViewCellStyle33;
            this.correcao.HeaderText = "Correção";
            this.correcao.Name = "correcao";
            this.correcao.ReadOnly = true;
            // 
            // JUROS_COMPENSATORIO
            // 
            this.JUROS_COMPENSATORIO.DataPropertyName = "JUROS_COMPENSATORIO";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.JUROS_COMPENSATORIO.DefaultCellStyle = dataGridViewCellStyle34;
            this.JUROS_COMPENSATORIO.HeaderText = "Juros Comp.";
            this.JUROS_COMPENSATORIO.Name = "JUROS_COMPENSATORIO";
            this.JUROS_COMPENSATORIO.ReadOnly = true;
            // 
            // VALORTOTAL
            // 
            this.VALORTOTAL.DataPropertyName = "TOTAL";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALORTOTAL.DefaultCellStyle = dataGridViewCellStyle35;
            this.VALORTOTAL.HeaderText = "Total";
            this.VALORTOTAL.Name = "VALORTOTAL";
            this.VALORTOTAL.ReadOnly = true;
            // 
            // VALOR_PAGO
            // 
            this.VALOR_PAGO.DataPropertyName = "VALOR_PAGO";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VALOR_PAGO.DefaultCellStyle = dataGridViewCellStyle36;
            this.VALOR_PAGO.HeaderText = "Valor Pago";
            this.VALOR_PAGO.Name = "VALOR_PAGO";
            this.VALOR_PAGO.ReadOnly = true;
            // 
            // DATA_PAGAMENTO
            // 
            this.DATA_PAGAMENTO.DataPropertyName = "DATA_PAGAMENTO";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.DATA_PAGAMENTO.DefaultCellStyle = dataGridViewCellStyle37;
            this.DATA_PAGAMENTO.FillWeight = 110F;
            this.DATA_PAGAMENTO.HeaderText = "Dt. Pagamento";
            this.DATA_PAGAMENTO.Name = "DATA_PAGAMENTO";
            this.DATA_PAGAMENTO.ReadOnly = true;
            this.DATA_PAGAMENTO.Width = 110;
            // 
            // DATA_BAIXA
            // 
            this.DATA_BAIXA.DataPropertyName = "DATA_BAIXA";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.DATA_BAIXA.DefaultCellStyle = dataGridViewCellStyle38;
            this.DATA_BAIXA.HeaderText = "Dt Baixa";
            this.DATA_BAIXA.Name = "DATA_BAIXA";
            this.DATA_BAIXA.ReadOnly = true;
            // 
            // BAIXA_OBSERVACAO
            // 
            this.BAIXA_OBSERVACAO.DataPropertyName = "BAIXA_OBSERVACAO";
            this.BAIXA_OBSERVACAO.HeaderText = "Observação";
            this.BAIXA_OBSERVACAO.Name = "BAIXA_OBSERVACAO";
            this.BAIXA_OBSERVACAO.ReadOnly = true;
            // 
            // BAIXAR
            // 
            dataGridViewCellStyle39.NullValue = "Baixar";
            this.BAIXAR.DefaultCellStyle = dataGridViewCellStyle39;
            this.BAIXAR.FillWeight = 45F;
            this.BAIXAR.HeaderText = "";
            this.BAIXAR.Name = "BAIXAR";
            this.BAIXAR.ReadOnly = true;
            this.BAIXAR.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BAIXAR.Text = "Baixar";
            this.BAIXAR.Width = 45;
            // 
            // mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource
            // 
            this.mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELA";
            this.mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource.DataSource = this.dSNotificacaoLancamento;
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnFinalizar.Enabled = false;
            this.btnFinalizar.Location = new System.Drawing.Point(228, 3);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(75, 23);
            this.btnFinalizar.TabIndex = 6;
            this.btnFinalizar.Text = "Finalizar";
            this.btnFinalizar.UseVisualStyleBackColor = true;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // btnRerratificar
            // 
            this.btnRerratificar.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRerratificar.Enabled = false;
            this.btnRerratificar.Location = new System.Drawing.Point(453, 3);
            this.btnRerratificar.Name = "btnRerratificar";
            this.btnRerratificar.Size = new System.Drawing.Size(75, 23);
            this.btnRerratificar.TabIndex = 7;
            this.btnRerratificar.Text = "Rerratificar";
            this.btnRerratificar.UseVisualStyleBackColor = true;
            this.btnRerratificar.Click += new System.EventHandler(this.btnRerratificar_Click);
            // 
            // tbpParcelamentoAnterior
            // 
            this.tbpParcelamentoAnterior.Controls.Add(this.dgvParcelamentoAnterior);
            this.tbpParcelamentoAnterior.Controls.Add(this.label148);
            this.tbpParcelamentoAnterior.Controls.Add(this.label150);
            this.tbpParcelamentoAnterior.Controls.Add(this.label149);
            this.tbpParcelamentoAnterior.Controls.Add(this.dgvParcelaDetalheAnterior);
            this.tbpParcelamentoAnterior.Controls.Add(this.dgvParcelasAnterior);
            this.tbpParcelamentoAnterior.Location = new System.Drawing.Point(4, 22);
            this.tbpParcelamentoAnterior.Name = "tbpParcelamentoAnterior";
            this.tbpParcelamentoAnterior.Padding = new System.Windows.Forms.Padding(3);
            this.tbpParcelamentoAnterior.Size = new System.Drawing.Size(544, 238);
            this.tbpParcelamentoAnterior.TabIndex = 7;
            this.tbpParcelamentoAnterior.Text = "Parcelamento Anteriores";
            this.tbpParcelamentoAnterior.UseVisualStyleBackColor = true;
            // 
            // dgvParcelamentoAnterior
            // 
            this.dgvParcelamentoAnterior.AllowUserToAddRows = false;
            this.dgvParcelamentoAnterior.AllowUserToDeleteRows = false;
            this.dgvParcelamentoAnterior.AllowUserToResizeRows = false;
            this.dgvParcelamentoAnterior.AutoGenerateColumns = false;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelamentoAnterior.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.dgvParcelamentoAnterior.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParcelamentoAnterior.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_NOTIFICACAO_PARCELAMENTO,
            this.aSSUNTODataGridViewTextBoxColumn,
            this.nOMEDataGridViewTextBoxColumn,
            this.cPFDataGridViewTextBoxColumn,
            this.rESPONSAVELDataGridViewTextBoxColumn,
            this.rESPONSAVELCPFDataGridViewTextBoxColumn,
            this.lOGRADOURODataGridViewTextBoxColumn1,
            this.bAIRRODataGridViewTextBoxColumn1,
            this.cIDADEDataGridViewTextBoxColumn1,
            this.nUMERODataGridViewTextBoxColumn1,
            this.cEPDataGridViewTextBoxColumn1,
            this.uFDataGridViewTextBoxColumn1,
            this.pROCURADORDataGridViewTextBoxColumn,
            this.pROCURADORCPFDataGridViewTextBoxColumn,
            this.Imprimir});
            this.dgvParcelamentoAnterior.DataSource = this.mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvParcelamentoAnterior.DefaultCellStyle = dataGridViewCellStyle44;
            this.dgvParcelamentoAnterior.Location = new System.Drawing.Point(4, 22);
            this.dgvParcelamentoAnterior.MultiSelect = false;
            this.dgvParcelamentoAnterior.Name = "dgvParcelamentoAnterior";
            this.dgvParcelamentoAnterior.ReadOnly = true;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle45.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelamentoAnterior.RowHeadersDefaultCellStyle = dataGridViewCellStyle45;
            this.dgvParcelamentoAnterior.RowHeadersWidth = 11;
            this.dgvParcelamentoAnterior.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParcelamentoAnterior.Size = new System.Drawing.Size(976, 132);
            this.dgvParcelamentoAnterior.TabIndex = 253;
            this.dgvParcelamentoAnterior.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvParcelamentoAnterior_CellClick);
            // 
            // ID_NOTIFICACAO_PARCELAMENTO
            // 
            this.ID_NOTIFICACAO_PARCELAMENTO.DataPropertyName = "ID_NOTIFICACAO_PARCELAMENTO";
            this.ID_NOTIFICACAO_PARCELAMENTO.HeaderText = "Parcelamento";
            this.ID_NOTIFICACAO_PARCELAMENTO.Name = "ID_NOTIFICACAO_PARCELAMENTO";
            this.ID_NOTIFICACAO_PARCELAMENTO.ReadOnly = true;
            // 
            // aSSUNTODataGridViewTextBoxColumn
            // 
            this.aSSUNTODataGridViewTextBoxColumn.DataPropertyName = "ASSUNTO";
            this.aSSUNTODataGridViewTextBoxColumn.HeaderText = "Assunto";
            this.aSSUNTODataGridViewTextBoxColumn.Name = "aSSUNTODataGridViewTextBoxColumn";
            this.aSSUNTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nOMEDataGridViewTextBoxColumn
            // 
            this.nOMEDataGridViewTextBoxColumn.DataPropertyName = "NOME";
            this.nOMEDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nOMEDataGridViewTextBoxColumn.Name = "nOMEDataGridViewTextBoxColumn";
            this.nOMEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cPFDataGridViewTextBoxColumn
            // 
            this.cPFDataGridViewTextBoxColumn.DataPropertyName = "CPF";
            this.cPFDataGridViewTextBoxColumn.HeaderText = "CPF";
            this.cPFDataGridViewTextBoxColumn.Name = "cPFDataGridViewTextBoxColumn";
            this.cPFDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rESPONSAVELDataGridViewTextBoxColumn
            // 
            this.rESPONSAVELDataGridViewTextBoxColumn.DataPropertyName = "RESPONSAVEL";
            this.rESPONSAVELDataGridViewTextBoxColumn.HeaderText = "Responsável";
            this.rESPONSAVELDataGridViewTextBoxColumn.Name = "rESPONSAVELDataGridViewTextBoxColumn";
            this.rESPONSAVELDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rESPONSAVELCPFDataGridViewTextBoxColumn
            // 
            this.rESPONSAVELCPFDataGridViewTextBoxColumn.DataPropertyName = "RESPONSAVEL_CPF";
            this.rESPONSAVELCPFDataGridViewTextBoxColumn.HeaderText = "Responsável CPF";
            this.rESPONSAVELCPFDataGridViewTextBoxColumn.Name = "rESPONSAVELCPFDataGridViewTextBoxColumn";
            this.rESPONSAVELCPFDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lOGRADOURODataGridViewTextBoxColumn1
            // 
            this.lOGRADOURODataGridViewTextBoxColumn1.DataPropertyName = "LOGRADOURO";
            this.lOGRADOURODataGridViewTextBoxColumn1.HeaderText = "Logradouro";
            this.lOGRADOURODataGridViewTextBoxColumn1.Name = "lOGRADOURODataGridViewTextBoxColumn1";
            this.lOGRADOURODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // bAIRRODataGridViewTextBoxColumn1
            // 
            this.bAIRRODataGridViewTextBoxColumn1.DataPropertyName = "BAIRRO";
            this.bAIRRODataGridViewTextBoxColumn1.HeaderText = "Bairro";
            this.bAIRRODataGridViewTextBoxColumn1.Name = "bAIRRODataGridViewTextBoxColumn1";
            this.bAIRRODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // cIDADEDataGridViewTextBoxColumn1
            // 
            this.cIDADEDataGridViewTextBoxColumn1.DataPropertyName = "CIDADE";
            this.cIDADEDataGridViewTextBoxColumn1.HeaderText = "Cidade";
            this.cIDADEDataGridViewTextBoxColumn1.Name = "cIDADEDataGridViewTextBoxColumn1";
            this.cIDADEDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // nUMERODataGridViewTextBoxColumn1
            // 
            this.nUMERODataGridViewTextBoxColumn1.DataPropertyName = "NUMERO";
            this.nUMERODataGridViewTextBoxColumn1.HeaderText = "Número";
            this.nUMERODataGridViewTextBoxColumn1.Name = "nUMERODataGridViewTextBoxColumn1";
            this.nUMERODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // cEPDataGridViewTextBoxColumn1
            // 
            this.cEPDataGridViewTextBoxColumn1.DataPropertyName = "CEP";
            this.cEPDataGridViewTextBoxColumn1.HeaderText = "CEP";
            this.cEPDataGridViewTextBoxColumn1.Name = "cEPDataGridViewTextBoxColumn1";
            this.cEPDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // uFDataGridViewTextBoxColumn1
            // 
            this.uFDataGridViewTextBoxColumn1.DataPropertyName = "UF";
            this.uFDataGridViewTextBoxColumn1.HeaderText = "UF";
            this.uFDataGridViewTextBoxColumn1.Name = "uFDataGridViewTextBoxColumn1";
            this.uFDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pROCURADORDataGridViewTextBoxColumn
            // 
            this.pROCURADORDataGridViewTextBoxColumn.DataPropertyName = "PROCURADOR";
            this.pROCURADORDataGridViewTextBoxColumn.HeaderText = "Procurador";
            this.pROCURADORDataGridViewTextBoxColumn.Name = "pROCURADORDataGridViewTextBoxColumn";
            this.pROCURADORDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pROCURADORCPFDataGridViewTextBoxColumn
            // 
            this.pROCURADORCPFDataGridViewTextBoxColumn.DataPropertyName = "PROCURADOR_CPF";
            this.pROCURADORCPFDataGridViewTextBoxColumn.HeaderText = "Procurador CPF";
            this.pROCURADORCPFDataGridViewTextBoxColumn.Name = "pROCURADORCPFDataGridViewTextBoxColumn";
            this.pROCURADORCPFDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Imprimir
            // 
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle43.NullValue = null;
            dataGridViewCellStyle43.Padding = new System.Windows.Forms.Padding(1);
            this.Imprimir.DefaultCellStyle = dataGridViewCellStyle43;
            this.Imprimir.FillWeight = 20F;
            this.Imprimir.HeaderText = "";
            this.Imprimir.Image = ((System.Drawing.Image)(resources.GetObject("Imprimir.Image")));
            this.Imprimir.Name = "Imprimir";
            this.Imprimir.ReadOnly = true;
            this.Imprimir.Width = 20;
            // 
            // mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource
            // 
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO";
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Enabled = false;
            this.label148.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label148.Location = new System.Drawing.Point(8, 407);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(140, 16);
            this.label148.TabIndex = 252;
            this.label148.Text = "Detalhes da Parcela:";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Enabled = false;
            this.label150.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label150.Location = new System.Drawing.Point(8, 158);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(67, 16);
            this.label150.TabIndex = 251;
            this.label150.Text = "Parcelas:";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Enabled = false;
            this.label149.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.Location = new System.Drawing.Point(8, 3);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(103, 16);
            this.label149.TabIndex = 251;
            this.label149.Text = "Parcelamentos";
            // 
            // dgvParcelaDetalheAnterior
            // 
            this.dgvParcelaDetalheAnterior.AllowUserToAddRows = false;
            this.dgvParcelaDetalheAnterior.AllowUserToDeleteRows = false;
            this.dgvParcelaDetalheAnterior.AllowUserToResizeRows = false;
            this.dgvParcelaDetalheAnterior.AutoGenerateColumns = false;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelaDetalheAnterior.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle46;
            this.dgvParcelaDetalheAnterior.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParcelaDetalheAnterior.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tRIBUTODataGridViewTextBoxColumn1,
            this.vALORJUROSDataGridViewTextBoxColumn3,
            this.vALORMULTADataGridViewTextBoxColumn3,
            this.vALORCORRECAODataGridViewTextBoxColumn1,
            this.vALORDataGridViewTextBoxColumn1,
            this.vALORTOTALDataGridViewTextBoxColumn1});
            this.dgvParcelaDetalheAnterior.DataSource = this.mOParcelaDetalheAnterior;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvParcelaDetalheAnterior.DefaultCellStyle = dataGridViewCellStyle47;
            this.dgvParcelaDetalheAnterior.Location = new System.Drawing.Point(7, 426);
            this.dgvParcelaDetalheAnterior.MultiSelect = false;
            this.dgvParcelaDetalheAnterior.Name = "dgvParcelaDetalheAnterior";
            this.dgvParcelaDetalheAnterior.ReadOnly = true;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelaDetalheAnterior.RowHeadersDefaultCellStyle = dataGridViewCellStyle48;
            this.dgvParcelaDetalheAnterior.RowHeadersWidth = 11;
            this.dgvParcelaDetalheAnterior.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParcelaDetalheAnterior.Size = new System.Drawing.Size(976, 164);
            this.dgvParcelaDetalheAnterior.TabIndex = 250;
            // 
            // tRIBUTODataGridViewTextBoxColumn1
            // 
            this.tRIBUTODataGridViewTextBoxColumn1.DataPropertyName = "TRIBUTO";
            this.tRIBUTODataGridViewTextBoxColumn1.HeaderText = "Tributo";
            this.tRIBUTODataGridViewTextBoxColumn1.Name = "tRIBUTODataGridViewTextBoxColumn1";
            this.tRIBUTODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // vALORJUROSDataGridViewTextBoxColumn3
            // 
            this.vALORJUROSDataGridViewTextBoxColumn3.DataPropertyName = "VALOR_JUROS";
            this.vALORJUROSDataGridViewTextBoxColumn3.HeaderText = "Juros";
            this.vALORJUROSDataGridViewTextBoxColumn3.Name = "vALORJUROSDataGridViewTextBoxColumn3";
            this.vALORJUROSDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // vALORMULTADataGridViewTextBoxColumn3
            // 
            this.vALORMULTADataGridViewTextBoxColumn3.DataPropertyName = "VALOR_MULTA";
            this.vALORMULTADataGridViewTextBoxColumn3.HeaderText = "Multa";
            this.vALORMULTADataGridViewTextBoxColumn3.Name = "vALORMULTADataGridViewTextBoxColumn3";
            this.vALORMULTADataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // vALORCORRECAODataGridViewTextBoxColumn1
            // 
            this.vALORCORRECAODataGridViewTextBoxColumn1.DataPropertyName = "VALOR_CORRECAO";
            this.vALORCORRECAODataGridViewTextBoxColumn1.HeaderText = "Correção";
            this.vALORCORRECAODataGridViewTextBoxColumn1.Name = "vALORCORRECAODataGridViewTextBoxColumn1";
            this.vALORCORRECAODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // vALORDataGridViewTextBoxColumn1
            // 
            this.vALORDataGridViewTextBoxColumn1.DataPropertyName = "VALOR";
            this.vALORDataGridViewTextBoxColumn1.HeaderText = "Valor";
            this.vALORDataGridViewTextBoxColumn1.Name = "vALORDataGridViewTextBoxColumn1";
            this.vALORDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // vALORTOTALDataGridViewTextBoxColumn1
            // 
            this.vALORTOTALDataGridViewTextBoxColumn1.DataPropertyName = "VALOR_TOTAL";
            this.vALORTOTALDataGridViewTextBoxColumn1.HeaderText = "Total";
            this.vALORTOTALDataGridViewTextBoxColumn1.Name = "vALORTOTALDataGridViewTextBoxColumn1";
            this.vALORTOTALDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // mOParcelaDetalheAnterior
            // 
            this.mOParcelaDetalheAnterior.DataMember = "MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHE";
            this.mOParcelaDetalheAnterior.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // dgvParcelasAnterior
            // 
            this.dgvParcelasAnterior.AllowUserToAddRows = false;
            this.dgvParcelasAnterior.AllowUserToDeleteRows = false;
            this.dgvParcelasAnterior.AllowUserToResizeRows = false;
            this.dgvParcelasAnterior.AutoGenerateColumns = false;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelasAnterior.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.dgvParcelasAnterior.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParcelasAnterior.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn52,
            this.dataGridViewTextBoxColumn53});
            this.dgvParcelasAnterior.DataSource = this.mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource;
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle50.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle50.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle50.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle50.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvParcelasAnterior.DefaultCellStyle = dataGridViewCellStyle50;
            this.dgvParcelasAnterior.Location = new System.Drawing.Point(5, 178);
            this.dgvParcelasAnterior.MultiSelect = false;
            this.dgvParcelasAnterior.Name = "dgvParcelasAnterior";
            this.dgvParcelasAnterior.ReadOnly = true;
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle51.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle51.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle51.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle51.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParcelasAnterior.RowHeadersDefaultCellStyle = dataGridViewCellStyle51;
            this.dgvParcelasAnterior.RowHeadersWidth = 11;
            this.dgvParcelasAnterior.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParcelasAnterior.Size = new System.Drawing.Size(976, 219);
            this.dgvParcelasAnterior.TabIndex = 249;
            this.dgvParcelasAnterior.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvParcelasAnterior_CellClick);
            // 
            // ID_NOTIFICACAO_PARCELAMENTO_PARCELA
            // 
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA.DataPropertyName = "ID_NOTIFICACAO_PARCELAMENTO_PARCELA";
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA.HeaderText = "ID_NOTIFICACAO_PARCELAMENTO_PARCELA";
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA.Name = "ID_NOTIFICACAO_PARCELAMENTO_PARCELA";
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA.ReadOnly = true;
            this.ID_NOTIFICACAO_PARCELAMENTO_PARCELA.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "PARCELA";
            this.dataGridViewTextBoxColumn14.HeaderText = "Parcela";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "AVISO";
            this.dataGridViewTextBoxColumn15.HeaderText = "Aviso";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "DATA_VENCIMENTO";
            this.dataGridViewTextBoxColumn35.HeaderText = "Vencimento";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "VALOR_PARCELA";
            this.dataGridViewTextBoxColumn50.HeaderText = "Valor";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            this.dataGridViewTextBoxColumn50.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "VALOR_PAGO";
            this.dataGridViewTextBoxColumn51.HeaderText = "Valor Pago";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            this.dataGridViewTextBoxColumn51.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.DataPropertyName = "DATA_PAGAMENTO";
            this.dataGridViewTextBoxColumn52.FillWeight = 110F;
            this.dataGridViewTextBoxColumn52.HeaderText = "Dt. Pagamento";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            this.dataGridViewTextBoxColumn52.ReadOnly = true;
            this.dataGridViewTextBoxColumn52.Width = 110;
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "DATA_BAIXA";
            this.dataGridViewTextBoxColumn53.HeaderText = "Dt. Baixa";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            this.dataGridViewTextBoxColumn53.ReadOnly = true;
            // 
            // mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource
            // 
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_PARCELA";
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // btnOpcoesParcelamento
            // 
            this.btnOpcoesParcelamento.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnOpcoesParcelamento.Enabled = false;
            this.btnOpcoesParcelamento.Location = new System.Drawing.Point(603, 3);
            this.btnOpcoesParcelamento.Name = "btnOpcoesParcelamento";
            this.btnOpcoesParcelamento.Size = new System.Drawing.Size(90, 23);
            this.btnOpcoesParcelamento.TabIndex = 295;
            this.btnOpcoesParcelamento.Text = "+ &Parcelamento";
            this.btnOpcoesParcelamento.UseVisualStyleBackColor = true;
            this.btnOpcoesParcelamento.Click += new System.EventHandler(this.btnOpcoesParcelamento_Click);
            // 
            // cmdParcelamento
            // 
            this.cmdParcelamento.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmCancelar,
            this.tsmCalcular});
            this.cmdParcelamento.Name = "cmsOpcoes";
            this.cmdParcelamento.Size = new System.Drawing.Size(191, 48);
            // 
            // tsmCancelar
            // 
            this.tsmCancelar.Name = "tsmCancelar";
            this.tsmCancelar.Size = new System.Drawing.Size(190, 22);
            this.tsmCancelar.Text = "Cancelar Parcelmento";
            this.tsmCancelar.Click += new System.EventHandler(this.tsmCancelar_Click);
            // 
            // tsmCalcular
            // 
            this.tsmCalcular.Name = "tsmCalcular";
            this.tsmCalcular.Size = new System.Drawing.Size(190, 22);
            this.tsmCalcular.Text = "Novo Cálculo";
            this.tsmCalcular.Visible = false;
            this.tsmCalcular.Click += new System.EventHandler(this.tsmCalcular_Click);
            // 
            // btnSuspender
            // 
            this.btnSuspender.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnSuspender.Enabled = false;
            this.btnSuspender.Location = new System.Drawing.Point(378, 3);
            this.btnSuspender.Name = "btnSuspender";
            this.btnSuspender.Size = new System.Drawing.Size(75, 23);
            this.btnSuspender.TabIndex = 296;
            this.btnSuspender.Text = "Suspender";
            this.btnSuspender.UseVisualStyleBackColor = true;
            this.btnSuspender.Click += new System.EventHandler(this.btnSuspender_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtMATRICULA_CARTORIO);
            this.panel6.Controls.Add(this.txtMATRICULA_CARTORIO_CIDADE);
            this.panel6.Controls.Add(label11);
            this.panel6.Controls.Add(this.txtMATRICULA_DATA_REGISTRO);
            this.panel6.Controls.Add(label12);
            this.panel6.Controls.Add(label18);
            this.panel6.Controls.Add(this.txtMATRICULA_NUMERO);
            this.panel6.Controls.Add(label20);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.txtDataIntimacao);
            this.panel6.Controls.Add(this.grpTipoCiencia);
            this.panel6.Controls.Add(this.grpIncidencia);
            this.panel6.Controls.Add(this.grpDiferimento);
            this.panel6.Controls.Add(this.txtCiencia);
            this.panel6.Controls.Add(this.label155);
            this.panel6.Controls.Add(this.txtOBSERVACAO);
            this.panel6.Controls.Add(this.pcbData);
            this.panel6.Controls.Add(this.txtNUMERO_PROCESSO);
            this.panel6.Controls.Add(lblNumeroProcesso);
            this.panel6.Controls.Add(lblEmail);
            this.panel6.Controls.Add(this.txtEMAIL);
            this.panel6.Controls.Add(this.txtExigibilidade);
            this.panel6.Controls.Add(lblObsGeral);
            this.panel6.Controls.Add(lblDataExigibilidade);
            this.panel6.Controls.Add(lblDataCiencia);
            this.panel6.Location = new System.Drawing.Point(9, 219);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(940, 357);
            this.panel6.TabIndex = 264;
            // 
            // txtMATRICULA_CARTORIO
            // 
            this.txtMATRICULA_CARTORIO.AllowNegative = true;
            this.txtMATRICULA_CARTORIO.DigitsInGroup = 0;
            this.txtMATRICULA_CARTORIO.Flags = 0;
            this.txtMATRICULA_CARTORIO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMATRICULA_CARTORIO.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtMATRICULA_CARTORIO.Location = new System.Drawing.Point(120, 327);
            this.txtMATRICULA_CARTORIO.MaxDecimalPlaces = 0;
            this.txtMATRICULA_CARTORIO.MaxLength = 18;
            this.txtMATRICULA_CARTORIO.MaxWholeDigits = 18;
            this.txtMATRICULA_CARTORIO.Name = "txtMATRICULA_CARTORIO";
            this.txtMATRICULA_CARTORIO.Prefix = "";
            this.txtMATRICULA_CARTORIO.RangeMax = 2147483647D;
            this.txtMATRICULA_CARTORIO.RangeMin = -2147483648D;
            this.txtMATRICULA_CARTORIO.Size = new System.Drawing.Size(42, 20);
            this.txtMATRICULA_CARTORIO.TabIndex = 331;
            this.txtMATRICULA_CARTORIO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMATRICULA_CARTORIO_CIDADE
            // 
            this.txtMATRICULA_CARTORIO_CIDADE.Location = new System.Drawing.Point(168, 327);
            this.txtMATRICULA_CARTORIO_CIDADE.Name = "txtMATRICULA_CARTORIO_CIDADE";
            this.txtMATRICULA_CARTORIO_CIDADE.Size = new System.Drawing.Size(344, 20);
            this.txtMATRICULA_CARTORIO_CIDADE.TabIndex = 326;
            // 
            // txtMATRICULA_DATA_REGISTRO
            // 
            this.txtMATRICULA_DATA_REGISTRO.Flags = 65536;
            this.txtMATRICULA_DATA_REGISTRO.Location = new System.Drawing.Point(414, 304);
            this.txtMATRICULA_DATA_REGISTRO.Name = "txtMATRICULA_DATA_REGISTRO";
            this.txtMATRICULA_DATA_REGISTRO.RangeMax = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtMATRICULA_DATA_REGISTRO.RangeMin = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtMATRICULA_DATA_REGISTRO.Size = new System.Drawing.Size(98, 20);
            this.txtMATRICULA_DATA_REGISTRO.TabIndex = 324;
            this.txtMATRICULA_DATA_REGISTRO.Visible = false;
            // 
            // txtMATRICULA_NUMERO
            // 
            this.txtMATRICULA_NUMERO.Location = new System.Drawing.Point(120, 304);
            this.txtMATRICULA_NUMERO.Name = "txtMATRICULA_NUMERO";
            this.txtMATRICULA_NUMERO.Size = new System.Drawing.Size(162, 20);
            this.txtMATRICULA_NUMERO.TabIndex = 323;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(255, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 322;
            this.label5.Text = "Data da Intimação:";
            // 
            // txtDataIntimacao
            // 
            this.txtDataIntimacao.Flags = 65536;
            this.txtDataIntimacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataIntimacao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtDataIntimacao.Location = new System.Drawing.Point(356, 28);
            this.txtDataIntimacao.Name = "txtDataIntimacao";
            this.txtDataIntimacao.RangeMax = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtDataIntimacao.RangeMin = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtDataIntimacao.Size = new System.Drawing.Size(86, 20);
            this.txtDataIntimacao.TabIndex = 321;
            this.txtDataIntimacao.Leave += new System.EventHandler(this.txtDataIntimacao_Leave);
            // 
            // grpTipoCiencia
            // 
            this.grpTipoCiencia.Controls.Add(this.rdbExigibilidade);
            this.grpTipoCiencia.Controls.Add(this.rdbAvisoRecebimento);
            this.grpTipoCiencia.Location = new System.Drawing.Point(477, 16);
            this.grpTipoCiencia.Name = "grpTipoCiencia";
            this.grpTipoCiencia.Size = new System.Drawing.Size(354, 51);
            this.grpTipoCiencia.TabIndex = 320;
            this.grpTipoCiencia.TabStop = false;
            this.grpTipoCiencia.Text = "Tipo de Ciência";
            // 
            // rdbExigibilidade
            // 
            this.rdbExigibilidade.AutoSize = true;
            this.rdbExigibilidade.Location = new System.Drawing.Point(198, 19);
            this.rdbExigibilidade.Name = "rdbExigibilidade";
            this.rdbExigibilidade.Size = new System.Drawing.Size(51, 17);
            this.rdbExigibilidade.TabIndex = 321;
            this.rdbExigibilidade.Text = "Edital";
            this.rdbExigibilidade.UseVisualStyleBackColor = true;
            this.rdbExigibilidade.CheckedChanged += new System.EventHandler(this.rdbExigibilidade_CheckedChanged_1);
            this.rdbExigibilidade.Click += new System.EventHandler(this.rdbExigibilidade_Click);
            // 
            // rdbAvisoRecebimento
            // 
            this.rdbAvisoRecebimento.AutoSize = true;
            this.rdbAvisoRecebimento.Checked = true;
            this.rdbAvisoRecebimento.Location = new System.Drawing.Point(29, 19);
            this.rdbAvisoRecebimento.Name = "rdbAvisoRecebimento";
            this.rdbAvisoRecebimento.Size = new System.Drawing.Size(153, 17);
            this.rdbAvisoRecebimento.TabIndex = 320;
            this.rdbAvisoRecebimento.TabStop = true;
            this.rdbAvisoRecebimento.Text = "Aviso de Recebimento(AR)";
            this.rdbAvisoRecebimento.UseVisualStyleBackColor = true;
            this.rdbAvisoRecebimento.Click += new System.EventHandler(this.rdbAvisoRecebimento_Click);
            // 
            // grpIncidencia
            // 
            this.grpIncidencia.Controls.Add(this.txtIncidencia);
            this.grpIncidencia.Controls.Add(this.label24);
            this.grpIncidencia.Controls.Add(this.rdbIncidenciaSim);
            this.grpIncidencia.Controls.Add(this.rdbIncidenciaNao);
            this.grpIncidencia.Location = new System.Drawing.Point(57, 202);
            this.grpIncidencia.Name = "grpIncidencia";
            this.grpIncidencia.Size = new System.Drawing.Size(428, 78);
            this.grpIncidencia.TabIndex = 317;
            this.grpIncidencia.TabStop = false;
            this.grpIncidencia.Text = "Incidência do ISS da Construção?";
            this.grpIncidencia.Visible = false;
            // 
            // txtIncidencia
            // 
            this.txtIncidencia.Enabled = false;
            this.txtIncidencia.Location = new System.Drawing.Point(47, 35);
            this.txtIncidencia.Multiline = true;
            this.txtIncidencia.Name = "txtIncidencia";
            this.txtIncidencia.Size = new System.Drawing.Size(375, 39);
            this.txtIncidencia.TabIndex = 315;
            this.txtIncidencia.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // rdbIncidenciaSim
            // 
            this.rdbIncidenciaSim.AutoSize = true;
            this.rdbIncidenciaSim.Checked = true;
            this.rdbIncidenciaSim.Location = new System.Drawing.Point(49, 15);
            this.rdbIncidenciaSim.Name = "rdbIncidenciaSim";
            this.rdbIncidenciaSim.Size = new System.Drawing.Size(42, 17);
            this.rdbIncidenciaSim.TabIndex = 312;
            this.rdbIncidenciaSim.TabStop = true;
            this.rdbIncidenciaSim.Text = "Sim";
            this.rdbIncidenciaSim.UseVisualStyleBackColor = true;
            this.rdbIncidenciaSim.Click += new System.EventHandler(this.rdbIncidenciaSim_Click);
            // 
            // rdbIncidenciaNao
            // 
            this.rdbIncidenciaNao.AutoSize = true;
            this.rdbIncidenciaNao.Location = new System.Drawing.Point(97, 15);
            this.rdbIncidenciaNao.Name = "rdbIncidenciaNao";
            this.rdbIncidenciaNao.Size = new System.Drawing.Size(45, 17);
            this.rdbIncidenciaNao.TabIndex = 313;
            this.rdbIncidenciaNao.Text = "Não";
            this.rdbIncidenciaNao.UseVisualStyleBackColor = true;
            this.rdbIncidenciaNao.Click += new System.EventHandler(this.rdbIncidenciaSim_Click);
            // 
            // grpDiferimento
            // 
            this.grpDiferimento.Controls.Add(this.txtDiferimento);
            this.grpDiferimento.Controls.Add(this.rdbDiferimentoNao);
            this.grpDiferimento.Controls.Add(this.rdbDiferimentoSim);
            this.grpDiferimento.Controls.Add(this.label27);
            this.grpDiferimento.Location = new System.Drawing.Point(491, 202);
            this.grpDiferimento.Name = "grpDiferimento";
            this.grpDiferimento.Size = new System.Drawing.Size(424, 78);
            this.grpDiferimento.TabIndex = 316;
            this.grpDiferimento.TabStop = false;
            this.grpDiferimento.Text = "Diferimento?";
            this.grpDiferimento.Visible = false;
            // 
            // txtDiferimento
            // 
            this.txtDiferimento.Enabled = false;
            this.txtDiferimento.Location = new System.Drawing.Point(42, 35);
            this.txtDiferimento.Multiline = true;
            this.txtDiferimento.Name = "txtDiferimento";
            this.txtDiferimento.Size = new System.Drawing.Size(375, 39);
            this.txtDiferimento.TabIndex = 325;
            this.txtDiferimento.Validating += new System.ComponentModel.CancelEventHandler(this.txtCEP_Validating);
            // 
            // rdbDiferimentoNao
            // 
            this.rdbDiferimentoNao.AutoSize = true;
            this.rdbDiferimentoNao.Checked = true;
            this.rdbDiferimentoNao.Location = new System.Drawing.Point(93, 13);
            this.rdbDiferimentoNao.Name = "rdbDiferimentoNao";
            this.rdbDiferimentoNao.Size = new System.Drawing.Size(45, 17);
            this.rdbDiferimentoNao.TabIndex = 323;
            this.rdbDiferimentoNao.TabStop = true;
            this.rdbDiferimentoNao.Text = "Não";
            this.rdbDiferimentoNao.UseVisualStyleBackColor = true;
            this.rdbDiferimentoNao.Click += new System.EventHandler(this.rdbDiferimentoSim_Click);
            // 
            // rdbDiferimentoSim
            // 
            this.rdbDiferimentoSim.AutoSize = true;
            this.rdbDiferimentoSim.Location = new System.Drawing.Point(45, 13);
            this.rdbDiferimentoSim.Name = "rdbDiferimentoSim";
            this.rdbDiferimentoSim.Size = new System.Drawing.Size(42, 17);
            this.rdbDiferimentoSim.TabIndex = 322;
            this.rdbDiferimentoSim.Text = "Sim";
            this.rdbDiferimentoSim.UseVisualStyleBackColor = true;
            this.rdbDiferimentoSim.Click += new System.EventHandler(this.rdbDiferimentoSim_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(4, 38);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(32, 13);
            this.label27.TabIndex = 321;
            this.label27.Text = "Obs.:";
            // 
            // txtCiencia
            // 
            this.txtCiencia.Flags = 65536;
            this.txtCiencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCiencia.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtCiencia.Location = new System.Drawing.Point(120, 28);
            this.txtCiencia.Name = "txtCiencia";
            this.txtCiencia.RangeMax = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtCiencia.RangeMin = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtCiencia.Size = new System.Drawing.Size(86, 20);
            this.txtCiencia.TabIndex = 257;
            this.txtCiencia.Validating += new System.ComponentModel.CancelEventHandler(this.txtCiencia_Validating);
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label155.Location = new System.Drawing.Point(3, 4);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(131, 16);
            this.label155.TabIndex = 248;
            this.label155.Text = "Informações Gerais";
            // 
            // pcbData
            // 
            this.pcbData.Image = ((System.Drawing.Image)(resources.GetObject("pcbData.Image")));
            this.pcbData.InitialImage = ((System.Drawing.Image)(resources.GetObject("pcbData.InitialImage")));
            this.pcbData.Location = new System.Drawing.Point(445, 26);
            this.pcbData.Name = "pcbData";
            this.pcbData.Size = new System.Drawing.Size(21, 21);
            this.pcbData.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcbData.TabIndex = 309;
            this.pcbData.TabStop = false;
            this.pcbData.Visible = false;
            this.pcbData.Click += new System.EventHandler(this.pcbData_Click);
            // 
            // txtExigibilidade
            // 
            this.txtExigibilidade.Flags = 65536;
            this.txtExigibilidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExigibilidade.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtExigibilidade.Location = new System.Drawing.Point(120, 52);
            this.txtExigibilidade.Name = "txtExigibilidade";
            this.txtExigibilidade.RangeMax = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtExigibilidade.RangeMin = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.txtExigibilidade.Size = new System.Drawing.Size(86, 20);
            this.txtExigibilidade.TabIndex = 258;
            this.txtExigibilidade.Validating += new System.ComponentModel.CancelEventHandler(this.txtCiencia_Validating);
            // 
            // lblStatusNotificacao
            // 
            this.lblStatusNotificacao.AutoSize = true;
            this.lblStatusNotificacao.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatusNotificacao.ForeColor = System.Drawing.Color.Red;
            this.lblStatusNotificacao.Location = new System.Drawing.Point(8, 2);
            this.lblStatusNotificacao.Name = "lblStatusNotificacao";
            this.lblStatusNotificacao.Size = new System.Drawing.Size(0, 19);
            this.lblStatusNotificacao.TabIndex = 296;
            // 
            // dA_TB_TRIBUTOTableAdapter1
            // 
            this.dA_TB_TRIBUTOTableAdapter1.ClearBeforeFill = true;
            // 
            // tbpHistorico
            // 
            this.tbpHistorico.Controls.Add(this.dgvHistorico);
            this.tbpHistorico.Controls.Add(this.label156);
            this.tbpHistorico.Location = new System.Drawing.Point(4, 22);
            this.tbpHistorico.Name = "tbpHistorico";
            this.tbpHistorico.Padding = new System.Windows.Forms.Padding(3);
            this.tbpHistorico.Size = new System.Drawing.Size(544, 238);
            this.tbpHistorico.TabIndex = 8;
            this.tbpHistorico.Text = "Histórico";
            this.tbpHistorico.UseVisualStyleBackColor = true;
            // 
            // dgvHistorico
            // 
            this.dgvHistorico.AllowUserToAddRows = false;
            this.dgvHistorico.AllowUserToDeleteRows = false;
            this.dgvHistorico.AllowUserToResizeRows = false;
            this.dgvHistorico.AutoGenerateColumns = false;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHistorico.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.dgvHistorico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistorico.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mOTIVODataGridViewTextBoxColumn,
            this.pROCESSODataGridViewTextBoxColumn,
            this.PROCESSO_ANO,
            this.dATADataGridViewTextBoxColumn,
            this.tIPODataGridViewTextBoxColumn,
            this.uSUARIOINCLUSAODataGridViewTextBoxColumn});
            this.dgvHistorico.DataSource = this.bindingSourceHistorico;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvHistorico.DefaultCellStyle = dataGridViewCellStyle54;
            this.dgvHistorico.Location = new System.Drawing.Point(2, 25);
            this.dgvHistorico.MultiSelect = false;
            this.dgvHistorico.Name = "dgvHistorico";
            this.dgvHistorico.ReadOnly = true;
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle55.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle55.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle55.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle55.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHistorico.RowHeadersDefaultCellStyle = dataGridViewCellStyle55;
            this.dgvHistorico.RowHeadersWidth = 11;
            this.dgvHistorico.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHistorico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHistorico.Size = new System.Drawing.Size(976, 564);
            this.dgvHistorico.TabIndex = 255;
            // 
            // mOTIVODataGridViewTextBoxColumn
            // 
            this.mOTIVODataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.mOTIVODataGridViewTextBoxColumn.DataPropertyName = "MOTIVO";
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.mOTIVODataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle53;
            this.mOTIVODataGridViewTextBoxColumn.FillWeight = 380F;
            this.mOTIVODataGridViewTextBoxColumn.HeaderText = "Motivo";
            this.mOTIVODataGridViewTextBoxColumn.Name = "mOTIVODataGridViewTextBoxColumn";
            this.mOTIVODataGridViewTextBoxColumn.ReadOnly = true;
            this.mOTIVODataGridViewTextBoxColumn.Width = 5;
            // 
            // pROCESSODataGridViewTextBoxColumn
            // 
            this.pROCESSODataGridViewTextBoxColumn.DataPropertyName = "PROCESSO";
            this.pROCESSODataGridViewTextBoxColumn.HeaderText = "Processo";
            this.pROCESSODataGridViewTextBoxColumn.Name = "pROCESSODataGridViewTextBoxColumn";
            this.pROCESSODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // PROCESSO_ANO
            // 
            this.PROCESSO_ANO.DataPropertyName = "PROCESSO_ANO";
            this.PROCESSO_ANO.HeaderText = "Ano Processo";
            this.PROCESSO_ANO.Name = "PROCESSO_ANO";
            this.PROCESSO_ANO.ReadOnly = true;
            // 
            // dATADataGridViewTextBoxColumn
            // 
            this.dATADataGridViewTextBoxColumn.DataPropertyName = "DATA";
            this.dATADataGridViewTextBoxColumn.HeaderText = "Data";
            this.dATADataGridViewTextBoxColumn.Name = "dATADataGridViewTextBoxColumn";
            this.dATADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tIPODataGridViewTextBoxColumn
            // 
            this.tIPODataGridViewTextBoxColumn.DataPropertyName = "TIPO";
            this.tIPODataGridViewTextBoxColumn.FillWeight = 180F;
            this.tIPODataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tIPODataGridViewTextBoxColumn.Name = "tIPODataGridViewTextBoxColumn";
            this.tIPODataGridViewTextBoxColumn.ReadOnly = true;
            this.tIPODataGridViewTextBoxColumn.Width = 180;
            // 
            // uSUARIOINCLUSAODataGridViewTextBoxColumn
            // 
            this.uSUARIOINCLUSAODataGridViewTextBoxColumn.DataPropertyName = "USUARIO_INCLUSAO";
            this.uSUARIOINCLUSAODataGridViewTextBoxColumn.HeaderText = "Usuário";
            this.uSUARIOINCLUSAODataGridViewTextBoxColumn.Name = "uSUARIOINCLUSAODataGridViewTextBoxColumn";
            this.uSUARIOINCLUSAODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bindingSourceHistorico
            // 
            this.bindingSourceHistorico.DataMember = "MO_NOTIFICACAO_LANCAMENTO_HISTORICO";
            this.bindingSourceHistorico.DataSource = this.dSNotificacaoLancamento;
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Enabled = false;
            this.label156.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label156.Location = new System.Drawing.Point(6, 6);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(63, 16);
            this.label156.TabIndex = 254;
            this.label156.Text = "Histórico";
            // 
            // btnDa
            // 
            this.btnDa.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnDa.Enabled = false;
            this.btnDa.Location = new System.Drawing.Point(693, 3);
            this.btnDa.Name = "btnDa";
            this.btnDa.Size = new System.Drawing.Size(73, 23);
            this.btnDa.TabIndex = 297;
            this.btnDa.Text = "Enc. D.A.";
            this.btnDa.UseVisualStyleBackColor = true;
            this.btnDa.Click += new System.EventHandler(this.btnDa_Click);
            // 
            // pnlRemessa
            // 
            this.pnlRemessa.Controls.Add(this.label1);
            this.pnlRemessa.Controls.Add(this.txtControleLegalidade);
            this.pnlRemessa.Controls.Add(this.txtProcessoRemessa);
            this.pnlRemessa.Controls.Add(this.label2);
            this.pnlRemessa.Controls.Add(this.label3);
            this.pnlRemessa.Controls.Add(this.txtDataRemessa);
            this.pnlRemessa.Controls.Add(this.label4);
            this.pnlRemessa.Location = new System.Drawing.Point(9, 587);
            this.pnlRemessa.Name = "pnlRemessa";
            this.pnlRemessa.Size = new System.Drawing.Size(940, 75);
            this.pnlRemessa.TabIndex = 250;
            this.pnlRemessa.Visible = false;
            // 
            // txtControleLegalidade
            // 
            this.txtControleLegalidade.Flags = 0;
            this.txtControleLegalidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtControleLegalidade.ForeColor = System.Drawing.Color.Red;
            this.txtControleLegalidade.InvalidChars = new char[] {
        '%',
        '\'',
        '*',
        '\"',
        '+',
        '?',
        '>',
        '<',
        ':',
        '\\'};
            this.txtControleLegalidade.Location = new System.Drawing.Point(272, 50);
            this.txtControleLegalidade.Multiline = true;
            this.txtControleLegalidade.Name = "txtControleLegalidade";
            this.txtControleLegalidade.ReadOnly = true;
            this.txtControleLegalidade.Size = new System.Drawing.Size(594, 20);
            this.txtControleLegalidade.TabIndex = 184;
            // 
            // txtProcessoRemessa
            // 
            this.txtProcessoRemessa.Flags = 0;
            this.txtProcessoRemessa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProcessoRemessa.ForeColor = System.Drawing.Color.Red;
            this.txtProcessoRemessa.InvalidChars = new char[] {
        '%',
        '\'',
        '*',
        '\"',
        '+',
        '?',
        '>',
        '<',
        ':',
        '\\'};
            this.txtProcessoRemessa.Location = new System.Drawing.Point(116, 50);
            this.txtProcessoRemessa.Name = "txtProcessoRemessa";
            this.txtProcessoRemessa.ReadOnly = true;
            this.txtProcessoRemessa.Size = new System.Drawing.Size(145, 20);
            this.txtProcessoRemessa.TabIndex = 183;
            // 
            // txtDataRemessa
            // 
            this.txtDataRemessa.Flags = 0;
            this.txtDataRemessa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataRemessa.ForeColor = System.Drawing.Color.Red;
            this.txtDataRemessa.Location = new System.Drawing.Point(6, 50);
            this.txtDataRemessa.Mask = "##/##/####";
            this.txtDataRemessa.Name = "txtDataRemessa";
            this.txtDataRemessa.ReadOnly = true;
            this.txtDataRemessa.Size = new System.Drawing.Size(100, 20);
            this.txtDataRemessa.TabIndex = 179;
            // 
            // dataGridViewImageColumn1
            // 
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle59.NullValue = null;
            dataGridViewCellStyle59.Padding = new System.Windows.Forms.Padding(1);
            this.dataGridViewImageColumn1.DefaultCellStyle = dataGridViewCellStyle59;
            this.dataGridViewImageColumn1.FillWeight = 16F;
            this.dataGridViewImageColumn1.HeaderText = "";
            this.dataGridViewImageColumn1.Image = ((System.Drawing.Image)(resources.GetObject("dataGridViewImageColumn1.Image")));
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Width = 16;
            // 
            // mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource
            // 
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource.DataMember = "MO_NOTIFICACAO_LANCAMENTO_PARCELAMENTO_DETALHE";
            this.mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource.DataSource = typeof(PMV.Tributario.DL.Fiscalizacao.DS.DSNotificacaoLancamento);
            // 
            // NotificacaoLancamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 775);
            this.Controls.Add(this.lblRetificada);
            this.Controls.Add(this.lblStatusNotificacao);
            this.Name = "NotificacaoLancamento";
            this.Text = "Notificação de Lançamento";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NotificacaoLancamento_FormClosing);
            this.Load += new System.EventHandler(this.NotificacaoLancamento_Load);
            this.Controls.SetChildIndex(this.lblStatusNotificacao, 0);
            this.Controls.SetChildIndex(this.lblRetificada, 0);
            this.Controls.SetChildIndex(this.pnlBotoes_02, 0);
            this.Controls.SetChildIndex(this.pnlBotoes_01, 0);
            this.Controls.SetChildIndex(this.tbcCadastro, 0);
            this.tbcCadastro.ResumeLayout(false);
            this.tbpCadastro.ResumeLayout(false);
            this.tbpCadastro.PerformLayout();
            this.tbpPesquisa.ResumeLayout(false);
            this.pnlBotoes_02.ResumeLayout(false);
            this.pnlBotoes_01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotificacao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSNotificacaoLancamento)).EndInit();
            this.tbpAssunto.ResumeLayout(false);
            this.tbpAssunto.PerformLayout();
            this.tbpContribuinte.ResumeLayout(false);
            this.gbxSujeitoPassivo.ResumeLayout(false);
            this.pnl_Botoes_Contribuinte.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContribuinte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource)).EndInit();
            this.grpSujeicao.ResumeLayout(false);
            this.grpSujeicao.PerformLayout();
            this.pnlDescricao.ResumeLayout(false);
            this.pnlDescricao.PerformLayout();
            this.pnlEndereco.ResumeLayout(false);
            this.pnlEndereco.PerformLayout();
            this.pnlCanceladoRemessa.ResumeLayout(false);
            this.pnlCanceladoRemessa.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.tbpParcelamento.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelamantoComplemento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource)).EndInit();
            this.pnlParcelamentoParcela.ResumeLayout(false);
            this.pnlParcelamentoParcela.PerformLayout();
            this.pnlParcelamentoDados.ResumeLayout(false);
            this.pnlParcelamentoDados.PerformLayout();
            this.cmsOpcoes.ResumeLayout(false);
            this.tbpLancamento.ResumeLayout(false);
            this.tblLancamentos.ResumeLayout(false);
            this.tbgConstrucao.ResumeLayout(false);
            this.pnl_Botoes_Construcao.ResumeLayout(false);
            this.grpConstrucao.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grpAreas.ResumeLayout(false);
            this.grpAreas.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.gbxDadosLancamento.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLancamentoConstrucao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource)).EndInit();
            this.tbgInscricao.ResumeLayout(false);
            this.grpUnificacao.ResumeLayout(false);
            this.grpUnificacao.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUnificacao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource)).EndInit();
            this.tbpParcelas.ResumeLayout(false);
            this.tbpParcelas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelaDetalhe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcela)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource)).EndInit();
            this.tbpParcelamentoAnterior.ResumeLayout(false);
            this.tbpParcelamentoAnterior.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelamentoAnterior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelaDetalheAnterior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOParcelaDetalheAnterior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParcelasAnterior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource)).EndInit();
            this.cmdParcelamento.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.grpTipoCiencia.ResumeLayout(false);
            this.grpTipoCiencia.PerformLayout();
            this.grpIncidencia.ResumeLayout(false);
            this.grpIncidencia.PerformLayout();
            this.grpDiferimento.ResumeLayout(false);
            this.grpDiferimento.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbData)).EndInit();
            this.tbpHistorico.ResumeLayout(false);
            this.tbpHistorico.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistorico)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceHistorico)).EndInit();
            this.pnlRemessa.ResumeLayout(false);
            this.pnlRemessa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource mO_NOTIFICACAO_LANCAMENTOBindingSource;
        private DL.Fiscalizacao.DS.DSNotificacaoLancamento dSNotificacaoLancamento;
        private System.Windows.Forms.DataGridView dgvNotificacao;
        private System.Windows.Forms.TabPage tbpAssunto;
        private AMS.TextBox.IntegerTextBox txtANO_NOTIFICACAO;
        private System.Windows.Forms.TextBox txtID_NOTIFICACAO;
        private System.Windows.Forms.TextBox txtNUMERO_NOTIFICACAO;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.TabPage tbpContribuinte;
        private System.Windows.Forms.TextBox txtNUMERO_PROCESSO;
        private System.Windows.Forms.TextBox txtEMAIL;
        private System.Windows.Forms.TextBox txtOBSERVACAO;
        private System.Windows.Forms.Panel pnlCanceladoRemessa;
        private AMS.TextBox.AlphanumericTextBox txtMOTIVO_CANCELAMENTO;
        private AMS.TextBox.AlphanumericTextBox txtPROCESSO_CANCELAMENTO;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private AMS.TextBox.MaskedTextBox txtDATA_CANCELAMENTO;
        private System.Windows.Forms.Label lblDataCancela;
        private System.Windows.Forms.TextBox txtLOGRADOURO;
        private System.Windows.Forms.ComboBox cbxCIDADE;
        private System.Windows.Forms.TextBox txtBAIRRO;
        private System.Windows.Forms.ComboBox cbxUF;
        private AMS.TextBox.MaskedTextBox txtCEP;
        private System.Windows.Forms.TextBox txtCOMPLEMENTO;
        private AMS.TextBox.IntegerTextBox txtNUMERO;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.BindingSource mO_NOTIFICACAO_LANCAMENTO_CONTRIBUINTEBindingSource;
        private System.Windows.Forms.CheckBox chkPRINCIPAL;
        private System.Windows.Forms.TextBox txtOBSERVACAO_P;
        private System.Windows.Forms.Panel pnlDescricao;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCONTRIBUINTE;
        private System.Windows.Forms.TextBox txtComoResponsavel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnBuscarInscricao;
        private AMS.TextBox.IntegerTextBox txtINSCRICAO;
        private System.Windows.Forms.RadioButton rdbMob;
        private System.Windows.Forms.RadioButton rdbImob;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.Button btnOpcoes;
        private AMS.TextBox.DateTextBox txtDATA_NOTIFICACAO;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage tbpParcelamento;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.BindingSource mO_NOTIFICACAO_LANCAMENTO_PARCELABindingSource;
        public System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_NOTIFICACAO;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn INSCRICAO;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        public System.Windows.Forms.Panel pnlEndereco;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtLogradouroResp;
        private System.Windows.Forms.ComboBox cbxCidadeResp;
        private System.Windows.Forms.TextBox txtBairroResp;
        private System.Windows.Forms.ComboBox cbxUFResp;
        private AMS.TextBox.MaskedTextBox txtCepResp;
        private System.Windows.Forms.TextBox txtComplResp;
        private AMS.TextBox.MaskedTextBox txtNumeroResp;
        private AMS.TextBox.MaskedTextBox txtDocProfissional;
        private System.Windows.Forms.CheckedListBox ckbSubnivel;
        private System.Windows.Forms.CheckedListBox ckbQualificacao;
        private System.Windows.Forms.Button btnPessoa;
        private System.Windows.Forms.Label lblId;
        private AMS.TextBox.MaskedTextBox txtCPFCNPJ;
        private System.Windows.Forms.TextBox txtNOME_RAZAO;
        private System.Windows.Forms.ComboBox cbxTipo;
        private System.Windows.Forms.ContextMenuStrip cmsOpcoes;
        private System.Windows.Forms.ToolStripMenuItem tsmEvento;
        private System.Windows.Forms.TabPage tbpLancamento;
        private System.Windows.Forms.TabControl tblLancamentos;
        private System.Windows.Forms.TabPage tbgConstrucao;
        private System.Windows.Forms.TextBox txtLOTE_IMOVEL;
        private System.Windows.Forms.TextBox txtQUADRA_IMOVEL;
        private SearchComboBox.SearchComboBox cbxCONDOMINIO;
        private SearchComboBox.SearchComboBox cbxLOTEAMENTO;
        private System.Windows.Forms.BindingSource mO_NOTIFICACAO_LANCAMENTO_LANCAMENTOBindingSource;
        private System.Windows.Forms.Label lblInscricaoMun;
        private System.Windows.Forms.Label lblInscrito;
        private System.Windows.Forms.RadioButton rblNao;
        private System.Windows.Forms.RadioButton rblSim;
        private System.Windows.Forms.TabPage tbgInscricao;
        private System.Windows.Forms.GroupBox grpUnificacao;
        private System.Windows.Forms.DataGridView dgvUnificacao;
        private System.Windows.Forms.Button btnAdicionarUnificacao;
        private System.Windows.Forms.Button btnBuscarUnificacao;
        private System.Windows.Forms.Label label132;
        private AMS.TextBox.IntegerTextBox txtInscricaoUnificacao;
        private AMS.TextBox.NumericTextBox txtTestadaUnificacao;
        private System.Windows.Forms.Label label134;
        private AMS.TextBox.NumericTextBox txtAreaTerrenoUnificacao;
        private System.Windows.Forms.BindingSource mO_NOTIFICACAO_LANCAMENTO_UnificacaoBindingSource;
        private System.Windows.Forms.Label lblIdUnificacao;
        private System.Windows.Forms.GroupBox grpSujeicao;
        public System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox TXTLOTEUNI;
        private System.Windows.Forms.TextBox TXTQUADRAUNI;
        private System.Windows.Forms.TextBox TXTLOGRADOUROUNI;
        private System.Windows.Forms.TextBox TXTBAIRROUNI;
        private AMS.TextBox.MaskedTextBox TXTCEPUNI;
        private System.Windows.Forms.TextBox TXTCOMPLEMENTOUNI;
        private AMS.TextBox.IntegerTextBox TXTNUMEROUNI;
        private System.Windows.Forms.TextBox TXTCIDADEUNI;
        private AMS.TextBox.MaskedTextBox TXTUFUNI;
        private SearchComboBox.SearchComboBox cbxLOTEAMENTOUNI;
        private SearchComboBox.SearchComboBox cbxCONDOMINIOUNI;
        private System.Windows.Forms.TextBox txtTestadaOriginal;
        private System.Windows.Forms.TextBox txtAreaOriginal;
        private AMS.TextBox.MaskedTextBox txtCPFResponsavel;
        private System.Windows.Forms.TextBox txtResponsavel;
        private System.Windows.Forms.ToolStripMenuItem imprimirDemonstrativoToolStripMenuItem;
        private System.Windows.Forms.Panel pnlParcelamentoDados;
        private AMS.TextBox.IntegerTextBox txtTotalDevido;
        private AMS.TextBox.IntegerTextBox txtValor;
        private AMS.TextBox.IntegerTextBox txtValorParcela;
        private AMS.TextBox.IntegerTextBox txtValorTotal;
        private AMS.TextBox.IntegerTextBox txtExpediente;
        private AMS.TextBox.IntegerTextBox txtJurosCompensatorios;
        private System.Windows.Forms.Label label36;
        private AMS.TextBox.IntegerTextBox txtQtdeParcela;
        private AMS.TextBox.IntegerTextBox txtDescontoPenalidade;
        private System.Windows.Forms.Label lblDescontoPenalidade;
        private AMS.TextBox.MaskedTextBox txtCPFResponsavelParcelamento;
        private System.Windows.Forms.TextBox txtResponsavelParcelamento;
        private System.Windows.Forms.TextBox txtNOME_RAZAOParcelamento;
        private AMS.TextBox.MaskedTextBox txtCPFCNPJParcelamento;
        private AMS.TextBox.MaskedTextBox txtNumeroRespParcelamento;
        private System.Windows.Forms.TextBox txtLogradouroRespParcelamento;
        private System.Windows.Forms.TextBox txtBairroRespParcelamento;
        private AMS.TextBox.MaskedTextBox txtCepRespParcelamento;
        private System.Windows.Forms.TextBox txtComplRespParcelamento;
        private System.Windows.Forms.Panel pnlParcelamentoParcela;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TextBox txtProcurador;
        private AMS.TextBox.MaskedTextBox txtCPFProcurador;
        private System.Windows.Forms.TextBox txtAssuntoParcelamento;
        private AMS.TextBox.DateTextBox txtVencimento;
        private System.Windows.Forms.TabPage tbpParcelas;
        private System.Windows.Forms.DataGridView dgvParcela;
        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.Button btnRerratificar;
        private System.Windows.Forms.TextBox txtUFParcelamento;
        private System.Windows.Forms.TextBox txtCidadeParcelamento;
        private System.Windows.Forms.DataGridView dgvParcelaDetalhe;
        private System.Windows.Forms.TabPage tbpParcelamentoAnterior;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.DataGridView dgvParcelamentoAnterior;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.DataGridView dgvParcelaDetalheAnterior;
        private System.Windows.Forms.DataGridView dgvParcelasAnterior;
        private System.Windows.Forms.BindingSource mONOTIFICACAOLANCAMENTOPARCELAMENTODETALHEBindingSource;
        private System.Windows.Forms.BindingSource mONOTIFICACAOLANCAMENTOPARCELAMENTOBindingSource;
        private System.Windows.Forms.BindingSource mONOTIFICACAOLANCAMENTOPARCELAMENTOPARCELABindingSource;
        private System.Windows.Forms.BindingSource mOParcelaDetalheAnterior;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_NOTIFICACAO_PARCELAMENTO_PARCELA;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn tRIBUTODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORJUROSDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORMULTADataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORCORRECAODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORTOTALDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.DataGridView dgvParcelamantoComplemento;
        private System.Windows.Forms.BindingSource mONOTIFICACAOLANCAMENTOPARCELAMENTOCOMPLEMENTOBindingSource;
        private System.Windows.Forms.Button btnEfetivarReparcelar;
        private System.Windows.Forms.Button btnOpcoesParcelamento;
        private System.Windows.Forms.ContextMenuStrip cmdParcelamento;
        private System.Windows.Forms.ToolStripMenuItem tsmCancelar;
        private System.Windows.Forms.ToolStripMenuItem tsmCalcular;
        private System.Windows.Forms.Button btnCancelarOperacao;
        private AMS.TextBox.IntegerTextBox txtJuros;
        private AMS.TextBox.IntegerTextBox txtCorrecao;
        private AMS.TextBox.IntegerTextBox txtMulta;
        private System.Windows.Forms.Button btnSuspender;
        private AMS.TextBox.IntegerTextBox txtExpedienteAnterior;
        private System.Windows.Forms.Label lblExpedienteAnterior;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtParcCancelado;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label lblSuspCanc;
        private System.Windows.Forms.Label lblStatusNotificacao;
        private System.Windows.Forms.Label lblRetificada;
        private System.Windows.Forms.ToolStripMenuItem mnuCarne;
        private System.Windows.Forms.ToolStripMenuItem mnuDemonstrativoParc;
        private System.Windows.Forms.ToolStripMenuItem mnutermoConfissao;
        private DL.DividaAtiva.DS.DSTabelaTableAdapters.DA_TB_TRIBUTOTableAdapter dA_TB_TRIBUTOTableAdapter1;
        private System.Windows.Forms.TabPage tbpHistorico;
        private System.Windows.Forms.DataGridView dgvHistorico;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.BindingSource bindingSourceHistorico;
        private System.Windows.Forms.DataGridViewTextBoxColumn tRIBUTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORJUROSDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORMULTADataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORCORRECAODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn JUROS_COMP;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORTOTALDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblCodParcelamento;
        private AMS.TextBox.MaskedTextBox txtCodParcelamento;
        private System.Windows.Forms.Button btnDa;
        private System.Windows.Forms.Panel pnlRemessa;
        private AMS.TextBox.AlphanumericTextBox txtControleLegalidade;
        private AMS.TextBox.AlphanumericTextBox txtProcessoRemessa;
        private AMS.TextBox.MaskedTextBox txtDataRemessa;
        private AMS.TextBox.DateTextBox txtCiencia;
        private AMS.TextBox.DateTextBox txtExigibilidade;
        private System.Windows.Forms.DataGridViewButtonColumn ExcluirUnificacao;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn AREA_TERRENO_UNIFICACAO;
        private System.Windows.Forms.DataGridViewTextBoxColumn AREA_TERRENO_TESTADO_UNIFICACAO;
        private System.Windows.Forms.DataGridViewTextBoxColumn cEPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOGRADOURODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMERODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMPLEMENTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bAIRRODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDADEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qUADRADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOTEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cONDOMINIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOTEAMENTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOTIVODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROCESSODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PROCESSO_ANO;
        private System.Windows.Forms.DataGridViewTextBoxColumn dATADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIPODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSUARIOINCLUSAODataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtInscriMun;
        private System.Windows.Forms.CheckedListBox ckbSubnivelProp;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtIncidencia;
        private System.Windows.Forms.RadioButton rdbIncidenciaNao;
        private System.Windows.Forms.RadioButton rdbIncidenciaSim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox grpIncidencia;
        private System.Windows.Forms.GroupBox grpDiferimento;
        private System.Windows.Forms.TextBox txtDiferimento;
        private System.Windows.Forms.RadioButton rdbDiferimentoNao;
        private System.Windows.Forms.RadioButton rdbDiferimentoSim;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TabPage tbgIptu;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewImageColumn Imprimir;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_NOTIFICACAO_PARCELAMENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn aSSUNTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rESPONSAVELDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rESPONSAVELCPFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOGRADOURODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bAIRRODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDADEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMERODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cEPDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn uFDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROCURADORDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROCURADORCPFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRIBUTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DATA_DEBITO;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALOR_ABATIMENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALOR_UFM;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALOR_JUROS;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALOR_MULTA;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        private System.Windows.Forms.ToolStripMenuItem saldoDevedorToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn idParcela;
        private System.Windows.Forms.DataGridViewLinkColumn BAIXAR;
        private System.Windows.Forms.DataGridViewTextBoxColumn PARCELA;
        private System.Windows.Forms.DataGridViewTextBoxColumn AVISO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DATA_VENCIMENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALOR_PARCELA;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORMULTADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORJUROSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn correcao;
        private System.Windows.Forms.DataGridViewTextBoxColumn JUROS_COMPENSATORIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALORTOTAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn VALOR_PAGO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DATA_PAGAMENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DATA_BAIXA;
        private System.Windows.Forms.DataGridViewTextBoxColumn BAIXA_OBSERVACAO;
        private System.Windows.Forms.GroupBox gbxSujeitoPassivo;
        private System.Windows.Forms.DataGridView dgvContribuinte;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_NOTIFICACAO_CONTRIBUINTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn QUALIFICACAO_DESCRICAO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPFCNPJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOME_RAZAO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOCUMENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn INSCRICAO_MUNICIPAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn RESPONSAVEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPF_RESPONSAVEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn OBSERVACAO;
        private System.Windows.Forms.DataGridViewCheckBoxColumn PRINCIPAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn CONTRIBUINTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn COMO_RESPONSAVEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn LOGRADOURO;
        private System.Windows.Forms.DataGridViewTextBoxColumn NUMERO;
        private System.Windows.Forms.DataGridViewTextBoxColumn COMPLEMENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn UF;
        private System.Windows.Forms.DataGridViewTextBoxColumn CIDADE;
        private System.Windows.Forms.DataGridViewTextBoxColumn BAIRRO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CEP;
        private System.Windows.Forms.DataGridViewTextBoxColumn QUALIFICACAO;
        private AMS.TextBox.DateTextBox txtDataIntimacao;
        private System.Windows.Forms.GroupBox grpTipoCiencia;
        private System.Windows.Forms.RadioButton rdbExigibilidade;
        private System.Windows.Forms.RadioButton rdbAvisoRecebimento;
        private System.Windows.Forms.PictureBox pcbData;
        private System.Windows.Forms.GroupBox gbxDadosLancamento;
        private System.Windows.Forms.DataGridView dgvLancamentoConstrucao;
        private System.Windows.Forms.GroupBox grpConstrucao;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label lblTaxaAlvara;
        private System.Windows.Forms.Label lblTaxaLicenca;
        private System.Windows.Forms.Label lblTaxaPenalidades;
        private System.Windows.Forms.Label lblTaxaAlinhamento;
        private System.Windows.Forms.Label lblTaxaConstrucao;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lblImpostoISSReforma;
        private System.Windows.Forms.Label lblImpostoISSConstrucao;
        private System.Windows.Forms.Label lblImpostoSSEngenharia;
        private System.Windows.Forms.Label lblImpostoISSDemolicao;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblBaseISSDemolicao;
        private System.Windows.Forms.Label lblBaseISSReforma;
        private System.Windows.Forms.Label lblBaseISSConstrucao;
        private System.Windows.Forms.Label lblBaseISSEngenharia;
        private System.Windows.Forms.GroupBox grpAreas;
        private System.Windows.Forms.Label lblMedidaPenalidade;
        private System.Windows.Forms.Label lblMedidaISSEngenharia;
        private System.Windows.Forms.Label lblMedidaISSReforma;
        private System.Windows.Forms.Label lblMedidaISSDemolicao;
        private System.Windows.Forms.Label lblMedidaISSConstrucao;
        private System.Windows.Forms.Label lblAreaBaseISSEngenharia;
        private System.Windows.Forms.Label lblPenalidade;
        private System.Windows.Forms.Label lblAreaBaseIssRefor;
        private System.Windows.Forms.Label lblAreaBaseISSEng;
        private System.Windows.Forms.Label lblAreaBaseISSReforma;
        private System.Windows.Forms.Label lblAreaBaseIssDemol;
        private System.Windows.Forms.Label lblAreaBaseISSDemolicao;
        private System.Windows.Forms.Label lblAreaBaseIssConstr;
        private System.Windows.Forms.Label lblAreaBaseISSConstrucao;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox ckbMista;
        private System.Windows.Forms.ComboBox cbxSubtipoImovel;
        private System.Windows.Forms.ComboBox cbxTipoImovel;
        private System.Windows.Forms.ComboBox cbxTipoConstr;
        private System.Windows.Forms.GroupBox GroupBox4;
        private System.Windows.Forms.Label label14;
        private AMS.TextBox.NumericTextBox txtEnquadramentoPenalidade;
        private System.Windows.Forms.Label label7;
        private AMS.TextBox.NumericTextBox txtEnquadramentoDemolicao;
        private System.Windows.Forms.Label label6;
        private AMS.TextBox.NumericTextBox txtEnquadramentoReforma;
        private System.Windows.Forms.CheckBox ckbImplantada;
        private System.Windows.Forms.Label label99;
        private AMS.TextBox.NumericTextBox txtEnquadramento;
        private AMS.TextBox.NumericTextBox txtAreaEdicula;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label lblIdLancamento;
        private System.Windows.Forms.CheckBox ckbElevador;
        private System.Windows.Forms.Label label97;
        private AMS.TextBox.NumericTextBox txtAreaTerrenoAumentar;
        private System.Windows.Forms.Label label95;
        private AMS.TextBox.NumericTextBox txtTestadaAumentar;
        private System.Windows.Forms.Label label93;
        private AMS.TextBox.NumericTextBox txtTestadaDeduzir;
        private System.Windows.Forms.Label label91;
        private AMS.TextBox.NumericTextBox txtAreaTerrenoDeduzir;
        private System.Windows.Forms.Label label89;
        private AMS.TextBox.NumericTextBox txtNumeroUnidAutonomas;
        private System.Windows.Forms.Label label66;
        private AMS.TextBox.NumericTextBox txtDesmontavelLegalizado;
        private System.Windows.Forms.Label label65;
        private AMS.TextBox.NumericTextBox txtDesmontavelLegalizar;
        private System.Windows.Forms.Label label63;
        private AMS.TextBox.NumericTextBox txtUnidades;
        private System.Windows.Forms.Label label77;
        private AMS.TextBox.NumericTextBox txtAreaTotal;
        private System.Windows.Forms.Label label82;
        private AMS.TextBox.NumericTextBox txtAreaDecadDemolir;
        private System.Windows.Forms.Label label75;
        private AMS.TextBox.NumericTextBox txtAreaDemolir;
        private System.Windows.Forms.Label label76;
        private AMS.TextBox.NumericTextBox txtAreaExistenteLegalConst;
        private System.Windows.Forms.Label label73;
        private AMS.TextBox.NumericTextBox txtAreaReformar;
        private System.Windows.Forms.Label label74;
        private AMS.TextBox.NumericTextBox txtAreaConstruir;
        private System.Windows.Forms.Label label71;
        private AMS.TextBox.NumericTextBox txtAreaDecadConstr;
        private System.Windows.Forms.Label label72;
        private AMS.TextBox.NumericTextBox txtAreaLegalDemolir;
        private System.Windows.Forms.Label label69;
        private AMS.TextBox.NumericTextBox txtAreaLegalReformar;
        private System.Windows.Forms.Label label70;
        private AMS.TextBox.NumericTextBox txtAreaLegalConstr;
        private System.Windows.Forms.Label label67;
        private AMS.TextBox.NumericTextBox txtTESTADA_PRINCIPAL;
        private System.Windows.Forms.Label label68;
        private AMS.TextBox.NumericTextBox txtAREA_TERRENO;
        private System.Windows.Forms.CheckBox chkEnquadramentoConstrucao;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_NOTIFICACAOC;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIPO;
        private System.Windows.Forms.DataGridViewTextBoxColumn AREA_TERRENO;
        private System.Windows.Forms.DataGridViewTextBoxColumn AREA_TERRENO_TESTADO;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIPO_IMOVEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn SUBTIPO_IMOVEL;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ELEVADOR;
        private System.Windows.Forms.Label label5;
        private Componentes.rtfEditor txtASSUNTO;
        private Componentes.rtfEditor txtFATO_JURIDICO;
        private System.Windows.Forms.Label lblEnquadramento_Base_ISS;
        private AMS.TextBox.NumericTextBox txtEnquadramentoBaseISS;
        private System.Windows.Forms.CheckBox chkEnquadramentoBaseISS;
        private System.Windows.Forms.CheckBox chkEnquadramentoPenalidade;
        private System.Windows.Forms.CheckBox chkEnquadramentoDemolicao;
        private System.Windows.Forms.CheckBox chkEnquadramentoReforma;
        private System.Windows.Forms.CheckBox ckbNumeracaoPredial;
        private System.Windows.Forms.Label lblTaxaNumPredial;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtMATRICULA_CARTORIO_CIDADE;
        private AMS.TextBox.DateTextBox txtMATRICULA_DATA_REGISTRO;
        private System.Windows.Forms.TextBox txtMATRICULA_NUMERO;
        private AMS.TextBox.IntegerTextBox txtMATRICULA_CARTORIO;
        public System.Windows.Forms.Panel pnl_Botoes_Contribuinte;
        public System.Windows.Forms.Button btnLimparContribuinte;
        public System.Windows.Forms.Button btnGravarContribuinte;
        public System.Windows.Forms.Button btnExcluirContribuinte;
        public System.Windows.Forms.Button btnEditarContribuinte;
        public System.Windows.Forms.Button btnIncluirContribuinte;
        public System.Windows.Forms.Panel pnl_Botoes_Construcao;
        public System.Windows.Forms.Button btnLimparConstrucao;
        public System.Windows.Forms.Button btnGravarConstrucao;
        public System.Windows.Forms.Button btnExcluirConstrucao;
        public System.Windows.Forms.Button btnEditarConstrucao;
        public System.Windows.Forms.Button btnIncluirConstrucao;
    }
}