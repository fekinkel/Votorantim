﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace Servico_CNPJ
{
    public partial class Service : ServiceBase
    {
        Timer timer1;
        public Service()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            DateTime dt = DateTime.Now;
            DateTime dtc = new DateTime(dt.Year, dt.Month, dt.Day, 21, 55, 00);
            TimeSpan d = dtc - dt;
            timer1 = new Timer(new TimerCallback(timer1_Tick), null, d.Milliseconds, 600000);
        }

        protected override void OnStop()
        {
            StreamWriter vWriter = new StreamWriter(@"c:\temp\testeServico.txt", true);

            vWriter.WriteLine("Servico Parado: " + DateTime.Now.ToString());
            vWriter.Flush();
            vWriter.Close();

        }
        private void timer1_Tick(object sender)
        {
            StreamWriter vWriter = new StreamWriter(@"c:\temp\testeServico.txt", true);
            vWriter.WriteLine("Servico Rodando: " + DateTime.Now.ToString());
            vWriter.Flush();
            vWriter.Close();
        }
    }
}
