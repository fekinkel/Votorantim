﻿namespace Win_CNPJ
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            txtUrl = new TextBox();
            label = new Label();
            progressBar1 = new ProgressBar();
            button2 = new Button();
            btnIniciar = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(51, 105);
            button1.Name = "button1";
            button1.Size = new Size(122, 23);
            button1.TabIndex = 0;
            button1.Text = "Start DownLoad";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtUrl
            // 
            txtUrl.Location = new Point(47, 37);
            txtUrl.Name = "txtUrl";
            txtUrl.Size = new Size(681, 23);
            txtUrl.TabIndex = 1;
            txtUrl.Text = "https://arquivos.receitafederal.gov.br/dados/cnpj/dados_abertos_cnpj";
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new Point(50, 157);
            label.Name = "label";
            label.Size = new Size(38, 15);
            label.TabIndex = 2;
            label.Text = "label1";
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(69, 205);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(631, 23);
            progressBar1.TabIndex = 3;
            // 
            // button2
            // 
            button2.Location = new Point(208, 105);
            button2.Name = "button2";
            button2.Size = new Size(108, 23);
            button2.TabIndex = 4;
            button2.Text = "Descompactar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btnIniciar
            // 
            btnIniciar.Location = new Point(396, 109);
            btnIniciar.Name = "btnIniciar";
            btnIniciar.Size = new Size(75, 23);
            btnIniciar.TabIndex = 5;
            btnIniciar.Text = "Iniciar";
            btnIniciar.UseVisualStyleBackColor = true;
            btnIniciar.Click += btnIniciar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(773, 235);
            Controls.Add(btnIniciar);
            Controls.Add(button2);
            Controls.Add(progressBar1);
            Controls.Add(label);
            Controls.Add(txtUrl);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox txtUrl;
        private Label label;
        private ProgressBar progressBar1;
        private Button button2;
        private Button btnIniciar;
    }
}
