using SevenZip;
using System.ComponentModel;
using System.Net;

namespace Win_CNPJ
{
    public partial class Form1 : Form
    {
        private String _nomeArquivo;
        private String _endPoint = "https://arquivos.receitafederal.gov.br/dados/cnpj/dados_abertos_cnpj";
        private String _nomePath;
        private String _nomeZip;
        private String _nomeCsv;
        private String _URL;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            startDownload(_URL, "Cnaes");
        }
        private void Iniciar()
        {
            
            _URL = $"{txtUrl.Text}/{DateTime.Now.Year.ToString()}-{DateTime.Now.Month.ToString("D2")}";
            if (VerificarURL(_URL))
            {
                _nomePath = $"C:\\Temp\\Receita\\";

            }
            else { MessageBox.Show($"N�O EXISTE {_URL}"); }
        }
        private bool VerificarURL(String url)
        {
            WebRequest request = WebRequest.Create(url);

            try
            {
                //Envia a requisi��o e recebe uma resposta ,  n�o recebendo � lan�ada uma exce��o e o c�digo segue pro catch
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                //Testa se o status code da resposta foi 200 ,  que � retornado quando a url est� online .

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    // Execute seu c�digo...
                    return true;
                }
                else
                {
                    //status code diferente de OK, manda pro catch
                    return false;
                }
            }
            catch
            {
                // Feche seu app aqui
                return false;

            }
        }
        private void startDownload(String url, String arquivo)
        {
            Thread thread = new Thread(() =>
            {
                WebClient client = new WebClient();
                client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                client.DownloadFileCompleted += new AsyncCompletedEventHandler(client_DownloadFileCompleted);
                String nomeArquivo = $"{Path.GetFileName(url)}/{arquivo}";
                _nomeArquivo = @"C:\Temp\Download\" + arquivo;
                _nomeZip = @"C:\Temp\ZIP\" + arquivo;
                client.DownloadFileAsync(new Uri($"{url}/{arquivo}.zip"), @"C:\Temp\Download\" + arquivo);
            });
            thread.Start();
        }
        void client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            this.BeginInvoke((MethodInvoker)delegate
            {
                double bytesIn = double.Parse(e.BytesReceived.ToString());
                double totalBytes = double.Parse(e.TotalBytesToReceive.ToString());
                double percentage = bytesIn / totalBytes * 100;
                label.Text = "Baixado: " + e.BytesReceived + " of " + e.TotalBytesToReceive;
                progressBar1.Value = int.Parse(Math.Truncate(percentage).ToString());
            });
        }
        void client_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            this.BeginInvoke((MethodInvoker)delegate
            {
                label.Text = "Download Completo";
                progressBar1.Value = 0;
            });
        }
        void Descompactar()
        {
            SevenZipBase.SetLibraryPath("C:\\Program Files\\7-Zip\\7z.dll");
            using (var zip = new SevenZipExtractor(_nomeArquivo))
            {
                zip.ExtractArchive(_nomeZip);
                var arquivos = zip.ArchiveFileNames;
                FileInfo file = new FileInfo(_nomeArquivo + arquivos[0]);
                if (file.Exists)
                {
                    File.Move(_nomeArquivo + arquivos[0], _nomeArquivo + _nomeCsv);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Descompactar();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            Iniciar();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Iniciar();
        }
    }
}
