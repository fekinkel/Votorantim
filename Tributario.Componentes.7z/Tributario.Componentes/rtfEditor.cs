﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace PMV.Tributario.Componentes
{
    public partial class rtfEditor : UserControl
    {
        #region "Propriedades"
        private InstalledFontCollection fontes;
        public delegate void EnviarSalvar(String msg);
        private EnviarSalvar OnSalvar;
        private String dirArquivo;
        private Dictionary<String, String> _dic;
        private String _Text;
        private string _Text_HTML;
        private bool _Alterado;
        private bool _Edicao;
        private bool _SomenteLeitura;
        private int Inicio;
        private int Comprimento;
        public string Text { get { return getText(); } set { setText(value); } }
        public string Html { get { return getHtml(); } }
        public bool ReadOnly { set { _SomenteLeitura = value; HabilitarComponentes(); } }
        #endregion

        #region "Constructor"
        public rtfEditor()
        {
            InitializeComponent();
            fontes = new InstalledFontCollection();
            IniciarComponente();
            CarregarPadrao();
        }

        #endregion

        #region "Eventos"
        private void setText(string texto)
        {
            _Alterado = false;
            _Edicao = false;
            _Text = "";
            DesabilitarControles();
            try
            {
                //MessageBox.Show("Set Texto");

                if (string.IsNullOrEmpty(texto))
                {
                    _Text = "{\\rtf1\\ansi\\deff3\\adeflang1025\\par}";
                }
                else
                {
                    _Text = texto;
                }                
                CarregarRich();
            }
            catch (Exception ex)
            {

            }
        }
        private string getText()
        {
            if (_Alterado)
            {

                _Text = "";
                Stream stringStream = new MemoryStream();
                rtdTextBox.SaveFile("C:\\Temp\\temp_out.rtf");
                StreamReader reader = new StreamReader("C:\\Temp\\temp_out.rtf");
                //rtdTextBox.SaveFile(stringStream, RichTextBoxStreamType.PlainText);
                //StreamReader reader = new StreamReader(stringStream);
                string linha;
                while ((linha = reader.ReadLine()) != null)
                {
                    _Text = _Text + linha + "\r\n";
                }
                reader.Close();
                //File.Delete("C:\\Temp\\temp_out.rtf");


                /*
                using (var rtfMemoryStream = new MemoryStream())
                {
                    rtdTextBox.SaveFile(rtfMemoryStream, RichTextBoxStreamType.RichText);
                    rtfMemoryStream.Seek(0, SeekOrigin.Begin);
                    using (var reader = new StreamReader(rtfMemoryStream))
                    {
                        string linha;
                        while ((linha = reader.ReadLine()) != null)
                        {
                            _Text = _Text + linha + "\r\n";
                        }
                        return reader.ReadToEnd();
                    }                    
                }
                */
            }
            return _Text;

        }
        private string getHtml()
        {
            try
            {
#if NETCORE
                  // Add a reference to the NuGet package System.Text.Encoding.CodePages for .Net core only
                  Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
#endif
                string[] strs = _Text.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                Stream stringStream = new MemoryStream();
                string linha;
                foreach (string line in strs)
                {
                    linha = line;
                    foreach (var item in _dic)
                    {
                        string s = $"@{item.Key}";
                        if (linha.IndexOf(s) >= 0)
                        {
                            linha = linha.Replace(s, item.Value);
                        }
                    }
                    StreamWriter writer = new StreamWriter(stringStream);
                    writer.Write(linha + "\r\n");
                    writer.Flush();
                }
                stringStream.Position = 0;

                return RtfPipe.Rtf.ToHtml(stringStream);
            }
            catch (Exception ex)
            {
                return "<div></div>";
            }
        }
        private void btsAbrir_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.InitialDirectory = @"C:\\";
            dialog.Filter = "Ritch Text Format (rtf) |*.rtf";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                rtdTextBox.LoadFile(dialog.FileName);
            }
        }
        private void cbsMacro_SelectedIndexChanged(object sender, EventArgs e)
        {
            string txt = rtdTextBox.SelectedText;
            if (txt != null)
            {
                int k = cbsMacro.SelectedIndex;
                int i = 1;
                foreach (var item in _dic)
                {
                    if (i == k)
                    {
                        string s = $"@{item.Key}";
                        rtdTextBox.SelectedText = s;
                    }
                    i++;
                }
            }
        }
        private void rtdTextBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void btsAlterar_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Alterar Inicio");
            if (_Alterado)
            {
                SalvarRich();
                //MessageBox.Show("Alterar Rich");
                
                btsAlterar.BackColor = Control.DefaultBackColor;
                _Alterado = false;
            }
            else
            {
                
                btsAlterar.BackColor = Color.Gray;
                _Alterado = true;
            }
            MessageBox.Show("Alterar Carregar Rich");

            CarregarRich();
            MessageBox.Show("Alterar Habilitar");

            HabilitarComponentes();
            DesabilitarControles();
            //_Edicao = !_Edicao;
        }
        private void btsNegrito_Click(object sender, EventArgs e)
        {
            Font fonte_selecionada = rtdTextBox.SelectionFont;
            if (fonte_selecionada != null)
            {
                rtdTextBox.SelectionFont = new Font(fonte_selecionada, fonte_selecionada.Style ^ FontStyle.Bold);
            }
        }
        private void btsItalico_Click(object sender, EventArgs e)
        {
            Font fonte_selecionada = rtdTextBox.SelectionFont;
            if (fonte_selecionada != null)
            {
                rtdTextBox.SelectionFont = new Font(fonte_selecionada, fonte_selecionada.Style ^ FontStyle.Italic);
            }
        }
        private void btsSublinhado_Click(object sender, EventArgs e)
        {
            Font fonte_selecionada = rtdTextBox.SelectionFont;
            if (fonte_selecionada != null)
            {
                rtdTextBox.SelectionFont = new Font(fonte_selecionada, fonte_selecionada.Style ^ FontStyle.Underline);
            }
        }
        private void rtdTextBox_SelectionChanged(object sender, EventArgs e)
        {
            if (rtdTextBox.SelectionFont != null)
            {
                if (rtdTextBox.SelectionFont != null)
                {
                    Font fonte = rtdTextBox.SelectionFont;

                    btsNegrito.Checked = (fonte.Bold);
                    btsItalico.Checked = (fonte.Italic);
                    btsSublinhado.Checked = (fonte.Underline);

                    string nome = fonte.FontFamily.Name;
                    float tamanho = fonte.Size;

                    int i = cbsFonte.Items.IndexOf(nome);
                    cbsFonte.SelectedIndex = i;

                    int j = cbsFonteTamanho.Items.IndexOf($"{tamanho} pt");
                    cbsFonteTamanho.SelectedIndex = j;
                }
            }
        }
        private void cbsFonteTamanho_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rtdTextBox.SelectionFont != null)
            {
                string fonte = cbsFonteTamanho.Items[cbsFonteTamanho.SelectedIndex].ToString();
                int fontesize = Int32.Parse(fonte.Replace("pt", ""));
                Font fonte_selecionada = rtdTextBox.SelectionFont;
                if (fonte_selecionada != null)
                {
                    rtdTextBox.SelectionFont = new Font(fonte_selecionada.FontFamily, fontesize);
                }
                rtdTextBox.Focus();
            }
        }
        private void cbsFonte_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rtdTextBox.SelectionFont != null)
            {
                string fonte = cbsFonte.Items[cbsFonte.SelectedIndex].ToString();
                Font fonte_selecionada = rtdTextBox.SelectionFont;
                if (fonte_selecionada != null)
                {
                    rtdTextBox.SelectionFont = new Font(fonte, fonte_selecionada.Size);
                }
                //rtdTextBox.Select(Inicio, Comprimento);
                rtdTextBox.Focus();
            }
        }

        private void btsCorFonte_Click(object sender, EventArgs e)
        {
            Color cor = rtdTextBox.SelectionColor;
            if (cor != null)
            {
                rtdTextBox.SelectionColor = btsCorFonte.BackColor;
            }
        }
        private void sbsCorFonte_ButtonClick(object sender, EventArgs e)
        {
        }
        private void sbsCorFonte_DropDownOpening(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog();
            btsCorFonte.BackColor = colorDialog.Color;
            rtdTextBox.Focus();
        }
        private void sbsCorDestaque_ButtonClick(object sender, EventArgs e)
        {
        }
        private void btsCorDestaque_Click(object sender, EventArgs e)
        {
            Color cor = rtdTextBox.SelectionBackColor;
            if (cor != null)
            {
                rtdTextBox.SelectionBackColor = btsCorDestaque.BackColor;
            }
        }
        private void sbsCorDestaque_DropDownOpening(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog();
            btsCorDestaque.BackColor = colorDialog.Color;
            rtdTextBox.Focus();
        }


        #endregion

        #region "Métodos"

        private void HabilitarComponentes()
        {
            //MessageBox.Show("Habilitar Componentes");
            tspRtf.Enabled = !_SomenteLeitura;
            if (_Alterado && !_SomenteLeitura)
            {
                rtdTextBox.Enabled = true;
            }
            else
            {
                rtdTextBox.Enabled = false;
            }
        }
        private void IniciarComponente()
        {
            //tspRtf.Enabled = false;
            _Edicao = false;
            //string lblinfo = $"{fontes.Families.Count} & " fontes instaladas";
            cbsFonte.Items.Clear();
            try
            {
                foreach (var item in fontes.Families)
                {
                    cbsFonte.Items.Add(item.Name);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar as Fontes : & {ex.Message}");
            }
            cbsFonteTamanho.Items.Clear();
            try
            {
                float[] tamanhofonte = { 5, 6, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
                foreach (var item in tamanhofonte)
                {
                    cbsFonteTamanho.Items.Add($"{item} pt");
                }
            }
            catch (Exception ex)
            { }
        }
        private void CarregarRich()
        {            
            if(String.IsNullOrEmpty(_Text) )
            {
                MessageBox.Show("Tem texto ");
            }
            else
            {
                MessageBox.Show("Não tem texto ");
            }
            rtdTextBox.Clear();
            try
            {
                string[] strs = _Text.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                Stream stringStream = new MemoryStream();
                string linha;
                foreach (string line in strs)
                {
                    linha = line;
                    if (!_Alterado)
                    {
                        if (_dic != null)
                        {
                            foreach (var item in _dic)
                            {
                                string s = $"@{item.Key}";
                                if (linha.IndexOf(s) >= 0)
                                {
                                    linha = linha.Replace(s, item.Value);
                                }
                            }
                        }
                    }
                    StreamWriter writer = new StreamWriter(stringStream);
                    writer.Write(linha + "\r\n");
                    writer.Flush();
                }
                stringStream.Position = 0;
                rtdTextBox.LoadFile(stringStream, RichTextBoxStreamType.RichText);
                stringStream.Close();
                var fonte = rtdTextBox.SelectionFont;
                cbsFonte.SelectedIndex = cbsFonte.Items.IndexOf(fonte.Name);
                cbsFonteTamanho.SelectedIndex = cbsFonteTamanho.Items.IndexOf($"{fonte.Size} pt");

                //MessageBox.Show("Fim Carregar Rich");
            }
            catch (Exception ex)
            {
                Mensagem.MsgExcecao("Atenção", ex);
            }

        }
        private void SalvarRich()
        {
            getText();
        }
        public void MacroSubstituicao(Dictionary<String, String> dic)
        {
            cbsMacro.Items.Clear();
            if (dic != null)
            {
                //MessageBox.Show("Macro Substituicao");
                cbsMacro.Visible = true;
                cbsMacro.Items.Add($"Selecione um item para Substituir...");
                if (dic.Count > 0)
                {
                    try
                    {
                        _dic = dic;
                        foreach (var item in dic)
                        {
                            if (item.Key.IndexOf(" ") == -1)
                            {
                                cbsMacro.Items.Add($"@{item.Key}");
                            }
                            else
                            {
                                throw new ArgumentException("Chave não pode ter espaço em branco!");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        cbsMacro.Visible = false;
                        _dic.Clear();
                    }
                }
            }
            else
            {
                cbsMacro.Visible = false;
            }
        }
        private void DesabilitarControles()
        {
            bool isOK = _Alterado;
            btsAbrir.Enabled = isOK;
            sbsCorDestaque.Enabled = isOK;
            sbsCorFonte.Enabled = isOK;
            btsItalico.Enabled = isOK;
            btsNegrito.Enabled = isOK;
            btsSalvar.Enabled = isOK;
            btsSublinhado.Enabled = isOK;
            cbsFonte.Enabled = isOK;
            cbsMacro.Enabled = isOK;

            //rtdTextBox.Width = 
        }
        private void CarregarPadrao()
        {
            btsCorFonte.BackColor = Color.Black;
            btsCorDestaque.BackColor = Color.Black;
        }
        #endregion

    }
}
